--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.13
-- Dumped by pg_dump version 11.2

-- Started on 2019-10-23 17:09:36

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 3097 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 193 (class 1255 OID 45294)
-- Name: release_audit(); Type: FUNCTION; Schema: public; Owner: jenkins
--

CREATE FUNCTION public.release_audit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
	old_status_code 	int8;
	new_status_code 	int8;
begin
	IF TG_OP = 'UPDATE' then
		old_status_code := old.status_code;
	end if;
	new_status_code := new.status_code;

	INSERT INTO release_audits(release_id,old_status_code,new_status_code,changed_on)
	VALUES(NEW.id,old_status_code,new_status_code,now());
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.release_audit() OWNER TO jenkins;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 190 (class 1259 OID 44450)
-- Name: manifest; Type: TABLE; Schema: public; Owner: jenkins
--

CREATE TABLE public.manifest (
    id bigint NOT NULL,
    id_release bigint NOT NULL,
    ms_name character varying(255) NOT NULL,
    ms_version character varying(255) NOT NULL,
    ms_deps character varying(255) NOT NULL
);


ALTER TABLE public.manifest OWNER TO jenkins;

--
-- TOC entry 189 (class 1259 OID 44448)
-- Name: manifest_id_seq; Type: SEQUENCE; Schema: public; Owner: jenkins
--

CREATE SEQUENCE public.manifest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manifest_id_seq OWNER TO jenkins;

--
-- TOC entry 3098 (class 0 OID 0)
-- Dependencies: 189
-- Name: manifest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jenkins
--

ALTER SEQUENCE public.manifest_id_seq OWNED BY public.manifest.id;


--
-- TOC entry 188 (class 1259 OID 44428)
-- Name: release; Type: TABLE; Schema: public; Owner: jenkins
--

CREATE TABLE public.release (
    id bigint NOT NULL,
    rel_num character varying NOT NULL,
    is_hotfix boolean DEFAULT false NOT NULL,
    type_code bigint NOT NULL,
    status_code bigint NOT NULL
);


ALTER TABLE public.release OWNER TO jenkins;

--
-- TOC entry 192 (class 1259 OID 45288)
-- Name: release_audits; Type: TABLE; Schema: public; Owner: jenkins
--

CREATE TABLE public.release_audits (
    id bigint NOT NULL,
    release_id bigint NOT NULL,
    old_status_code bigint,
    new_status_code bigint NOT NULL,
    changed_on timestamp without time zone NOT NULL
);


ALTER TABLE public.release_audits OWNER TO jenkins;

--
-- TOC entry 191 (class 1259 OID 45286)
-- Name: release_audits_id_seq; Type: SEQUENCE; Schema: public; Owner: jenkins
--

CREATE SEQUENCE public.release_audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.release_audits_id_seq OWNER TO jenkins;

--
-- TOC entry 3099 (class 0 OID 0)
-- Dependencies: 191
-- Name: release_audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jenkins
--

ALTER SEQUENCE public.release_audits_id_seq OWNED BY public.release_audits.id;


--
-- TOC entry 187 (class 1259 OID 44426)
-- Name: release_id_seq; Type: SEQUENCE; Schema: public; Owner: jenkins
--

CREATE SEQUENCE public.release_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.release_id_seq OWNER TO jenkins;

--
-- TOC entry 3100 (class 0 OID 0)
-- Dependencies: 187
-- Name: release_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jenkins
--

ALTER SEQUENCE public.release_id_seq OWNED BY public.release.id;


--
-- TOC entry 185 (class 1259 OID 44416)
-- Name: release_status; Type: TABLE; Schema: public; Owner: jenkins
--

CREATE TABLE public.release_status (
    code bigint NOT NULL,
    status character varying(255) NOT NULL
);


ALTER TABLE public.release_status OWNER TO jenkins;

--
-- TOC entry 186 (class 1259 OID 44421)
-- Name: release_type; Type: TABLE; Schema: public; Owner: jenkins
--

CREATE TABLE public.release_type (
    code bigint NOT NULL,
    type character varying(255) NOT NULL
);


ALTER TABLE public.release_type OWNER TO jenkins;

--
-- TOC entry 2948 (class 2604 OID 44453)
-- Name: manifest id; Type: DEFAULT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.manifest ALTER COLUMN id SET DEFAULT nextval('public.manifest_id_seq'::regclass);


--
-- TOC entry 2946 (class 2604 OID 44431)
-- Name: release id; Type: DEFAULT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release ALTER COLUMN id SET DEFAULT nextval('public.release_id_seq'::regclass);


--
-- TOC entry 2949 (class 2604 OID 45291)
-- Name: release_audits id; Type: DEFAULT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release_audits ALTER COLUMN id SET DEFAULT nextval('public.release_audits_id_seq'::regclass);



--
-- TOC entry 3084 (class 0 OID 44416)
-- Dependencies: 185
-- Data for Name: release_status; Type: TABLE DATA; Schema: public; Owner: jenkins
--

INSERT INTO public.release_status VALUES (1, 'RC');
INSERT INTO public.release_status VALUES (2, 'RF');
INSERT INTO public.release_status VALUES (3, 'R');
INSERT INTO public.release_status VALUES (4, 'AR');


--
-- TOC entry 3085 (class 0 OID 44421)
-- Dependencies: 186
-- Data for Name: release_type; Type: TABLE DATA; Schema: public; Owner: jenkins
--

INSERT INTO public.release_type VALUES (1, 'MICROSERVICE');
INSERT INTO public.release_type VALUES (2, 'CONFLUENT');



--
-- TOC entry 2959 (class 2606 OID 44458)
-- Name: manifest manifest_pkey; Type: CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.manifest
    ADD CONSTRAINT manifest_pkey PRIMARY KEY (id);


--
-- TOC entry 2961 (class 2606 OID 45293)
-- Name: release_audits release_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release_audits
    ADD CONSTRAINT release_audits_pkey PRIMARY KEY (id);


--
-- TOC entry 2955 (class 2606 OID 44437)
-- Name: release release_pkey; Type: CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release
    ADD CONSTRAINT release_pkey PRIMARY KEY (id);


--
-- TOC entry 2951 (class 2606 OID 44420)
-- Name: release_status release_status_pkey; Type: CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release_status
    ADD CONSTRAINT release_status_pkey PRIMARY KEY (code);


--
-- TOC entry 2953 (class 2606 OID 44425)
-- Name: release_type release_type_pkey; Type: CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release_type
    ADD CONSTRAINT release_type_pkey PRIMARY KEY (code);


--
-- TOC entry 2957 (class 2606 OID 105812)
-- Name: release uniquerel_const; Type: CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release
    ADD CONSTRAINT uniquerel_const UNIQUE (rel_num, type_code);


--
-- TOC entry 2966 (class 2620 OID 45296)
-- Name: release release_insert; Type: TRIGGER; Schema: public; Owner: jenkins
--

CREATE TRIGGER release_insert AFTER INSERT ON public.release FOR EACH ROW EXECUTE PROCEDURE public.release_audit();


--
-- TOC entry 2965 (class 2620 OID 45295)
-- Name: release release_update; Type: TRIGGER; Schema: public; Owner: jenkins
--

CREATE TRIGGER release_update AFTER UPDATE ON public.release FOR EACH ROW EXECUTE PROCEDURE public.release_audit();


--
-- TOC entry 2964 (class 2606 OID 105821)
-- Name: manifest id_release_fk; Type: FK CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.manifest
    ADD CONSTRAINT id_release_fk FOREIGN KEY (id_release) REFERENCES public.release(id) ON DELETE CASCADE;


--
-- TOC entry 2963 (class 2606 OID 44443)
-- Name: release status_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release
    ADD CONSTRAINT status_code_fk FOREIGN KEY (status_code) REFERENCES public.release_status(code) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 2962 (class 2606 OID 44438)
-- Name: release type_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: jenkins
--

ALTER TABLE ONLY public.release
    ADD CONSTRAINT type_code_fk FOREIGN KEY (type_code) REFERENCES public.release_type(code) ON UPDATE RESTRICT ON DELETE RESTRICT;


-- Completed on 2019-10-23 17:09:39

--
-- PostgreSQL database dump complete
--

CREATE TABLE public.deploy (
	id bigserial NOT NULL PRIMARY KEY,
	ms_name varchar(255) NOT NULL,
	ms_version varchar(255) NOT NULL,
	env varchar(10) NOT NULL,
	tstamp timestamp NOT NULL DEFAULT now()
);

