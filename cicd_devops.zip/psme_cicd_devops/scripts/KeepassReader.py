#!/usr/bin/env python
import libkeepass
import sys
import json
import argparse
import os

db_path = None
password = None

parser = argparse.ArgumentParser()
parser.add_argument("operation", choices=[
                    'get-credentials', 'get-entry', 'get-all-entries', 'get-from-token'])
parser.add_argument("-k", "--token-path")
parser.add_argument("-g", "--group-path")
parser.add_argument("-t", "--title")
parser.add_argument("-f", "--filters", nargs='*')
parser.add_argument("--local-path")
parser.add_argument("--password-file")
args = parser.parse_args()

group_path = args.group_path

local_keepass_path = args.local_path
keepass_pwd_file = args.password_file

def main():
    if args.operation == 'get-credentials':
        if None in [args.title, args.group_path]:
            parser.error('title and group-path required with get-credentials')
        print get_credentials(args.group_path, args.title)
    elif args.operation == 'get-entry':
        if None in [args.title, args.group_path]:
            parser.error('title and group-path required with get-entry')
        entries = get_group_entries(args.group_path)
        print get_entry_from_title(
            entries, args.title, Filters=args.filters, Output='json')
    elif args.operation == 'get-all-entries':
        if None in [args.group_path]:
            parser.error('group-path required with get-all-entries')
        print get_group_entries(args.group_path, Output='json')
    elif args.operation == 'get-from-token':
        if None in [args.token_path]:
            parser.error('token-path required with get-from-token')
        token = parse_token_path(args.token_path)
        global group_path
        group_path = token[0]
        entries = get_group_entries(token[0])
        print get_entry_from_title(
            entries, token[1], Filters=token[2], Output='single')
    #clean()


def clean():
    os.remove(db_path)


def parse_token_path(token_path):
    app = token_path.split(';')
    filters = [app[1]]
    app = app[0].split('\\')
    app.pop(0)
    title = app.pop()
    group_path = '/'.join(app)
    return (group_path, title, filters)


def init_db_reader():
    global db_path
    global password
    if db_path is None or password is None:
        db_path = local_keepass_path
        password = get_db_masterkey(File=keepass_pwd_file)


def get_db_masterkey(**kwargs):
    file_path = None
    if 'File' in kwargs:
        file_path = kwargs['File']
        with open(file_path) as fp:
            e_pwd = fp.read()
    return e_pwd


def get_group_entries(group_path, **kwags):
    init_db_reader()
    output = 'dict'
    if 'Output' in kwags and kwags['Output'] in ('raw', 'dict', 'json'):
        output = kwags['Output']
    groups = group_path.split('/')
    with libkeepass.open(db_path, password=password) as kdb:
        group = kdb.obj_root.find('.//Group')
        while len(groups) > 0:
            group_name = groups.pop(0)
            group = get_group(group, group_name)
    entries = group.findall('./Entry')
    if output != 'raw':
        entries = entries_to_dict(entries)
        if output == 'json':
            entries = json.dumps(entries, indent=2)
    return entries


def entries_to_dict(entries):
    ret = {}
    for entry in entries:
        uuid = entry.find('./UUID').text
        kv = {string.find(
            './Key').text: string.find('./Value').text for string in entry.findall('./String')}
        kv.update({'UUID': uuid})
        ret.update({uuid: kv})
    return ret


def get_entry_from_title(entries, title, **kwargs):
    app = None
    if type(entries) != dict:
        if type(entries) == list:
            entries = entries_to_dict(entries)
        else:
            entries = json.loads(entries)
    for entry in entries.values():
        if entry['Title'] == title:
            app = entry
            break
    if not app:
        raise Exception('No entry with title "%s" in group "%s"' %
                        (title, group_path))
    ret = app
    if 'Filters' in kwargs and kwargs['Filters'] is not None:
        ret = {}
        for filter in kwargs['Filters']:
            if filter not in app:
                raise Exception(
                    '%s not a valid filter for entries.\nValid filters: %s' % (filter, app.keys()))
            ret.update({filter: app[filter]})
    if 'Output' in kwargs:
        if kwargs['Output'] == 'single' and len(kwargs['Filters']) == 1:
            ret = ret[kwargs['Filters'][0]]
        elif kwargs['Output'] == 'json':
            ret = json.dumps(ret, indent=2)
        else:
            raise Exception('"Output" value is not valid: "%s"' %
                            kwargs['Output'])
    return ret


def get_credentials(group_path, title):
    entries = get_group_entries(group_path)
    entry = get_entry_from_title(entries, title, Filters=[
                                 'UserName', 'Password'])
    ret = (entry['UserName'], entry['Password'])
    return ret


def get_group(parent_group, group_name):
    for group in parent_group.findall('./Group'):
        if group.find('./Name').text == group_name:
            return group
    raise Exception('%s not found in %s' %
                    (group_name, parent_group.find('./Name')))

# execute only if run as a script
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print e
        sys.exit(1)
