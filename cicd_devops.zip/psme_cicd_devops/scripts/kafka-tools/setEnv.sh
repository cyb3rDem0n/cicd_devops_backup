#!/bin/bash
TEST_TMP_BK="confbk4-mi1.secreloaded.sec:9092,confbk5-mi1.secreloaded.sec:9092,confbk6-mi1.secreloaded.sec:9092"
TEST_TMP_ZK="confzk4-mi1.secreloaded.sec:2181,confzk5-mi1.secreloaded.sec:2181,confzk6-mi1.secreloaded.sec:2181"
TEST_BK="EUITBAKFKBKTE1.te.seccloud.internal:9092,EUITBAKFKBKTE2.te.seccloud.internal:9092,EUITBAKFKBKTE3.te.seccloud.internal:9092"
TEST_ZK="EUITBAKFKZKTE1.te.seccloud.internal:2181,EUITBAKFKZKTE2.te.seccloud.internal:2181,EUITBAKFKZKTE3.te.seccloud.internal:2181"
COLL_BK="EUITBAKFKBKPP04.pp.seccloud.internal:9092,EUITBAKFKBKPP05.pp.seccloud.internal:9092,EUITBAKFKBKPP06.pp.seccloud.internal:9092"
COLL_ZK="EUITBAKFKZKPP04.pp.seccloud.internal:2181,EUITBAKFKZKPP05.pp.seccloud.internal:2181,EUITBAKFKZKPP06.pp.seccloud.internal:2181"
PROD_BK="EUITBAKFKBKPR01.seccloud.internal:9092,EUITBAKFKBKPR02.seccloud.internal:9092,EUITBAKFKBKPR03.seccloud.internal:9092"
PROD_ZK="EUITBAKFKZKPR01.seccloud.internal:2181,EUITBAKFKZKPR02.seccloud.internal:2181,EUITBAKFKZKPR03.seccloud.internal:2181"
export KAFKA_OPTS="-Xms1g -Xmx1g:$KAFKA_OPTS"

