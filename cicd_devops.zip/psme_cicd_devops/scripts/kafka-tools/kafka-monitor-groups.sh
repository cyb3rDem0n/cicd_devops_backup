#!/bin/bash

KAFKA_TOOLS_HOME=$(find . -name 'kafka-tools.sh' -printf "%h" | sort -u)
if [[ "$KAFKA_TOOLS_HOME" == "" ]]; then
	KAFKA_TOOLS_HOME="."
fi

BROKER=""
ZOOKEEPER=""
CLIENT_PROPS=""
OPER=""
CFG_LIST=""
DEST_ENV=""

source setEnv.sh

for i in "$@"
do
	case $i in
		-h|--help)
		echo ""
	        echo "  kafka-monitor-groups - Help"
		echo "	  -env/--environment=<ENV>:"
		echo "	    Valori ammessi per ENV=[test-temp, test, coll, prod]" 
		echo ""
		echo "	  -g/--groups=<GROUPS>"
		echo "	    Lista dei dei consumer groups da monitorare separati da virgola"
		echo ""
		exit 0
		shift
		;;
		*)
	esac
done

for i in "$@"
do
	case $i in 
		-env=*|--environment=*)
		DEST_ENV="${i#*=}"
		shift
		;;
		-g=*|--groups=*)
		GROUPS_LIST="${i#*=}"
		shift 
		;;
		*)
		echo "Parametro $i non riconosciuto"
		exit 104
		# unknown option
		;;
	esac
done


if [[ "$DEST_ENV" != "test-temp" && "$DEST_ENV" != "test" && "$DEST_ENV" != "coll" && "$DEST_ENV" != "prod" ]]; then
	echo "Errore specificare un ambiente test-temp/test/coll/prod"
	exit 100
fi

if [[ "$DEST_ENV" = "test-temp" ]]; then 
	BROKER=$TEST_TMP_BK
	ZOOKEEPER=$TEST_TMP_ZK
	CLIENT_PROPS="$KAFKA_TOOLS_HOME/client.test.temp.properties"
elif [[ "$DEST_ENV" = "test" ]]; then 
	BROKER=$TEST_BK
	ZOOKEEPER=$TEST_ZK
	CLIENT_PROPS="$KAFKA_TOOLS_HOME/client.test.properties"
elif [[ "$DEST_ENV" = "coll" ]]; then 
	BROKER=$COLL_BK
	ZOOKEEPER=$COLL_ZK
	CLIENT_PROPS="$KAFKA_TOOLS_HOME/client.coll.properties"
elif [[ "$DEST_ENV" = "prod" ]]; then 
	BROKER=$PROD_BK
	ZOOKEEPER=$PROD_ZK
	CLIENT_PROPS="./client.prod.properties"
fi

GRUPPI=[]
if [[ "$GROUPS_LIST" = "" ]]; then
	echo "La lista dei gruppi da monitorare è vuota"
	exit 101
fi
if [[ "$GROUPS_LIST" = *","* ]]; then
	IFS=',' read -r -a GRUPPI <<< "$GROUPS_LIST"
else GRUPPI[0]=$GROUPS_LIST
fi

echo ""
for i in "${GROUPS_LIST[@]}"
do
	cmd="kafka-consumer-groups --bootstrap-server $BROKER --describe --group $i --command-config $CLIENT_PROPS"
	echo "Executing"
	echo "$cmd"
	$cmd
	echo ""
	status=$?
	[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
	echo ""
done


