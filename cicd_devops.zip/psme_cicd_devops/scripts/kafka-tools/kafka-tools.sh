#!/bin/bash

KAFKA_TOOLS_HOME=$(find . -name 'kafka-tools.sh' -printf "%h" | sort -u)
if [[ "$KAFKA_TOOLS_HOME" == "" ]]; then
	KAFKA_TOOLS_HOME="."
fi
BROKER=""
ZOOKEEPER=""
CLIENT_PROPS=""
OPER=""
CFG_LIST=""
DEST_ENV=""

source setEnv.sh

for i in "$@"
do
	case $i in
		-h|--help)
		echo ""
	        echo "  kafka-tools - Help"
		echo "	  -env/--environment=<ENV>:"
		echo "	    Valori ammessi per ENV=[test-temp, test, coll, prod]" 
		echo ""
		echo "	  -op/--operation=<OPER>"
		echo "	    Valori ammessi per OPER=[DESC, CREATE, ALTER, LIST, DELETE]"
		echo ""
		echo "	  -cl/--config-list=<CFG_LIST>"
		echo "	    CFG_LIST è la lista delle configurazioni per ALTER o CREATE così come documentazione del tool kafka-topics.sh"
		echo "      In alternativa è possibile specificare il path del file contenente le configurazioni da applicare."
		echo "      Le configurazioni devono essere scritte come richieste dal tool kafka-topics.sh sia in caso di -op=CREATE che -op=ALTER"
		echo
		echo "	  -tl/--topic-list=<TOPIC_LIST>"
		echo "	    TOPIC_LIST è la lista separata da ',' contente uno o più topic sui quali operare."
		echo "       In alternativa è possibile valorizzare il parametro con il path del file contenente la lista dei topic su cui operare"
		echo ""
		exit 0
		shift
		;;
		*)
	esac
done

for i in "$@"
do
	case $i in 
		-env=*|--environment=*)
		DEST_ENV="${i#*=}"
		shift
		;;
		-op=*|--operation=*)
		OPER="${i#*=}"
		shift 
		;;
		-cl=*|--config-list=*)
		CFG_LIST="${i#*=}"
		shift 
		;;
		-tl=*|--topic-list=*)
		TOPIC_LIST="${i#*=}"
		shift
		;;
		*)
		echo "Parametro $i non riconosciuto"
		exit 104
		# unknown option
		;;
	esac
done


if [[ "$DEST_ENV" != "test-temp" && "$DEST_ENV" != "test" && "$DEST_ENV" != "coll" && "$DEST_ENV" != "prod" ]]; then
	echo "Errore specificare un ambiente test-temp/test/coll/prod"
	exit 100
fi

if [[ "$OPER" != "DEL" && "$OPER" != "CREATE" && "$OPER" != "ALTER" && "$OPER" != "LIST" && "$OPER" != "DESC" ]]; then
	echo "Errore: Operazione sconosciuta!: $OPER"
	exit 101
fi

if [[ ("$OPER" = "DESC" || "$OPER" = "CREATE" || "$OPER" = "DEL" || "$OPER" = "ALTER") && "$TOPIC_LIST" = "" ]]; then
	echo "Errore: Con le operazioni DESC, CREATE, ALTER, DEL è necessario specificare il/i topic con -tl/--topic-list"
	exit 102
fi


if [[ ("$OPER" = "CREATE" || "$OPER" = "ALTER") && "$CFG_LIST" = "" ]]; then
	echo "Errore: Con le operazioni CREATE e ALTER è necessario specificare la lista delle configurazioni con --cl/--config-list"
	exit 103
fi


if [[ "$DEST_ENV" = "test-temp" ]]; then 
	BROKER=$TEST_TMP_BK
	ZOOKEEPER=$TEST_TMP_ZK
	CLIENT_PROPS="$KAFKA_TOOLS_HOME/client.test.temp.properties"
elif [[ "$DEST_ENV" = "test" ]]; then 
	BROKER=$TEST_BK
	ZOOKEEPER=$TEST_ZK
	CLIENT_PROPS="$KAFKA_TOOLS_HOME/client.test.properties"
elif [[ "$DEST_ENV" = "coll" ]]; then 
	BROKER=$COLL_BK
	ZOOKEEPER=$COLL_ZK
	CLIENT_PROPS="$KAFKA_TOOLS_HOME/client.coll.properties"
elif [[ "$DEST_ENV" = "prod" ]]; then 
	BROKER=$PROD_BK
	ZOOKEEPER=$PROD_ZK
	CLIENT_PROPS="$KAFKA_TOOLS_HOME/client.prod.properties"
fi


if [[ ( "$OPER" = "ALTER" || "$OPER" = "CREATE") && !( "$CFG_LIST" = "--"* ) ]]; then
  if [[ ! -f  $CFG_LIST ]]; then
    echo "Il file delle configurazioni per CREATE o ALTER non esiste"
    exit 105
  else CFG_LIST=$(cat $CFG_LIST)
  fi
fi

if [[ ( "$OPER" = "ALTER" || "$OPER" = "CREATE" || "$OPER" = "DEL" || "$OPER" = "DESC" ) && "$TOPIC_LIST" == *".list" ]]; then
  echo "$TOPIC_LIST"
  if [[ ! -f  $TOPIC_LIST ]]; then
    echo "Il file della lista dei topic non esiste"
    exit 106
  else TOPIC_LIST=$(cat $TOPIC_LIST)
  fi
fi


TOPICS=[]
IFS=',' read -r -a TOPICS <<< "$TOPIC_LIST"
#echo "${TOPICS[@]}"
echo ""

if [ "$OPER" = "LIST" ]; then
	if [ "$CLIENT_PROPS" != "" ]; then
		cmd="kafka-topics --bootstrap-server $BROKER --list --command-config $CLIENT_PROPS"
		echo "Executing"
		echo "$cmd"
		echo ""
		#$cmd  
		echo ""
		status=$?
		[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
		echo ""

	else 
		cmd="kafka-topics --bootstrap-server $BROKER --list"
		echo "Executing"
		echo"$cmd"
		echo ""
		#$cmd
		echo ""
		status=$?
		[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
		echo ""
	fi
fi
if [ "$OPER" = "CREATE" ]; then
	if [ "$BROKER" != "" ]; then
		for i in "${TOPICS[@]}"
		do
			if [ "$CLIENT_PROPS" != "" ]; then
				cmd="kafka-topics --bootstrap-server $BROKER --create --topic $i --command-config $CLIENT_PROPS $CFG_LIST"
				echo "Executing"
				echo "$cmd"
				echo ""
				#$cmd
				echo ""
				status=$?
				[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
				echo ""
			else 
				cmd="kafka-topics --bootstrap-server $BROKER --create --topic $i $CFG_LIST"
				echo "Executing"
				echo "$cmd"
				echo ""
				#$cmd
				echo ""
				status=$?
				[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
				echo ""
			fi
		done
	fi
fi
if [ "$OPER" = "ALTER" ]; then
	if [ "$BROKER" != "" ]; then
		for i in "${TOPICS[@]}"
                do
			if [ "$CLIENT_PROPS" != "" ]; then
				cmd="kafka-topics --zookeeper $ZOOKEEPER --alter --topic $i --command-config $CLIENT_PROPS $CFG_LIST"
				echo "Executing"
				echo "$cmd"
				echo ""
				#$cmd
				echo ""
				status=$?
				[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
				echo ""
			else
			        cmd="kafka-topics --zookeeper $ZOOKEEPER --alter --topic $i $CFG_LIST"	
				echo "Executing"
				echo "$cmd"
				echo""
				#$cmd
				echo ""
				status=$?
				[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
				echo ""
			fi
		done
	fi
fi
if [ "$OPER" = "DEL" ]; then
	if [ "$BROKER" != "" ]; then
		for i in "${TOPICS[@]}"
		do
			echo "$i"
			if [ "$CLIENT_PROPS" != "" ]; then
				cmd="kafka-topics --bootstrap-server $BROKER --delete --topic $i --command-config $CLIENT_PROPS"
				echo "Executing"
				echo "$cmd"
				echo ""
				#$cmd 
				echo ""
				status=$?
				[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
				echo ""
			else 
				cmd="kafka-topics --bootstrap-server $BROKER --delete --topic $i"
				echo "Executing"
				echo "$cmd"
				echo ""
				#$cmd
				echo ""
				status=$?
				[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
				echo ""
			fi
		done
	fi
fi                                                                                                                                                                              
if [ "$OPER" = "DESC" ]; then
	if [ "$BROKER" != "" ]; then
		for i in "${TOPICS[@]}"
		do
			if [ "$CLIENT_PROPS" != "" ]; then
				cmd="kafka-topics --bootstrap-server $BROKER --describe --topic $i --command-config $CLIENT_PROPS"
				echo "Executing"
				echo "$cmd"
				echo ""
				#$cmd
				echo ""
				status=$?
				[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
				echo ""
			else
			        cmd="kafka-topics --bootstrap-server $BROKER --describe --topic $i"	
				echo "Executing"
				echo "$cmd"
				echo ""
				#$cmd
				echo ""
				status=$?
				[ $status -eq 0 ] && echo "Comando eseguito con successo" || echo "Comando fallito"
				echo ""
			fi
		done
	fi
fi

