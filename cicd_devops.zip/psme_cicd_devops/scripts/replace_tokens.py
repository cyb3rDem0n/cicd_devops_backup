import os
import argparse
import re
import yaml
import json
import base64

parser = argparse.ArgumentParser()
parser.add_argument(
    '--file', '-f', help='File to be processed (that contains tokens)')
parser.add_argument(
    '--list', '-l', help='List of the files to be processed (json format)')
parser.add_argument('--directory', '-d',
                    help='All files in that folder will be processed to replace tokens')
parser.add_argument(
    '--tokenfile', '-t', required=True, help='path of the file that contains the tokens definition')
parser.add_argument('--microservice', '-m', help='Name of the microservice')
parser.add_argument('--not-encode', action='store_true', help='Skip encode step')
parser.add_argument('--not-decode', action='store_true', help='Skip decode step')
parser.add_argument('--decode-b64', action='store_true', help='Decode tokens that starts with b64->')
parser.add_argument('--debug', '-D', action='store_true')
parser.add_argument('--dry-run', action='store_true')
args = parser.parse_args()


def parse_tokens_yaml(tokenfile, group=None):
    with open(tokenfile, 'r') as f:
        try:
            tokens = yaml.load(f, Loader=yaml.FullLoader)
        except yaml.YAMLError as exc:
            print(exc)
            quit(1)
    if group:
        tokens = tokens.get(group, dict())
    for token in tokens:
        if type(tokens[token]) == str and tokens[token][:6] == 'eb64->':
            tokens[token] = tokens[token][6:] if args.not_encode else base64.b64encode('%s' % (tokens[token][6:]))
        elif type(tokens[token]) == str and tokens[token][:6] == 'db64->':
            tokens[token] = tokens[token][6:] if args.not_decode else base64.b64decode('%s' % (tokens[token][6:]))
        elif type(tokens[token]) == str and tokens[token][:5] == 'b64->':
            tokens[token] = base64.b64decode('%s' % (tokens[token][5:])) if args.decode_b64 else tokens[token][5:]
    return tokens


def get_token_value(token, tokens):
    token = token.replace('###', '')
    value = tokens.get(token)
    if value is not None and type(value) != str:
        value = json.dumps(value)
    return value


if not args.file and not args.list and not args.directory:
    print('ERROR: at least one option have to be specifed')
    quit(1)

list_files = None

if args.file:
    list_files = [args.file]
    # with open(fname) as f:
    #     list_files = f.readlines()
    #     # you may also want to remove whitespace characters like `\n` at the end of each line
    #     list_files = [x.strip() for x in list_files]
elif args.list:
    list_files = json.loads(args.list)
elif args.directory:
    list_files = os.listdir(args.directory)
    delimiter = ''
    if args.directory[-1] != '/':
        delimiter = '/'
    list_files = ['{}{}{}'.format(args.directory, delimiter, x) for x in list_files if 'README' not in x]
    print(list_files)

tmp, extension = os.path.splitext(args.tokenfile)
if extension == '.yaml':
    tokens = parse_tokens_yaml(args.tokenfile, args.microservice)
else:
    raise Exception('{} not supported'.format(extension))
if args.debug:
    print(json.dumps(tokens, indent=2))

for path in list_files:
    if 'README' in path:
        continue
    print('{} {}...'.format('DryRun' if args.dry_run else 'Processing', path))
    lines = None
    content = None
    with open(path, 'r') as f:
        content = f.read()
        lines = content.split('\n')

    tokens_list = []
    for l in lines:
        if(bool(re.match('([^#]*###[a-zA-Z0-9_.-]*###)', l))):
            tokens_list.extend(re.findall('(###[a-zA-Z0-9_.-]*###)', l))
    # tokens_list = re.findall('(###[a-zA-Z0-9_.-]*###)', content)
    if len(tokens_list) == 0:
        print('Escaped. No tokens in {}'.format(path))
        continue
    tokens_list = list(set(tokens_list))
    for t in tokens_list:
        value = get_token_value(t, tokens)
        if value is None:
            raise Exception('No value for token {}'.format(t))
        content = content.replace(t, value)
    if not args.dry_run:
        with open(path, 'w') as f:
            f.write(content)
        print('Completed {}'.format(path))
    else:
        print('Completed DryRun {}'.format(path))
