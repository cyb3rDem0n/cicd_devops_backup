#!/bin/bash/env python

import winrm
import argparse


class WinRmClient:

    def __init__(self, host, user, password):
        self.user = user
        self.password = password
        self.host = host
        self.winrmsession = winrm.Session(self.host, auth=(self.user, self.password), server_cert_validation='ignore')
# , transport='ntlm', server_cert_validation='ignore')

    def run_powershell_script(self, ps_script):
        self.winrmsession.run_ps(ps_script)


def prepare_args():
    parser = argparse.ArgumentParser(description='Executes a script on a remote windows host')
    parser.add_argument('--host', metavar='h', type=str, help='specify windows remote host', dest='host')
    parser.add_argument('--user', metavar='u', type=str, help='specify user for windows remote', dest='user')
    parser.add_argument('--password', metavar='p', type=str, help='specify password for windows remote', dest='password'
                        )
    parser.add_argument('--script', metavar='s', type=str, help='specify a powershell inline script', dest='script')

    return parser.parse_args()


args = prepare_args()
winrmClient = WinRmClient(args.host, args.user, args.password)
winrmClient.run_powershell_script(args.script)


