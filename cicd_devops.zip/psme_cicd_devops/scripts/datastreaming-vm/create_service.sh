SERVICE_NAME=""
START_EXEC=""
STOP_EXEC=""
USER=""
for i in "$@"
do
	case $i in
		-h|--help)
		echo ""
	        echo "  create_service - Help"
		echo "		crea un servizio di sistema avviabile con systemctl per il nome di servizio passato in input "
		echo "	 	Syntax: create_service [-s/--service] <service>"
		echo "	  	    -s/--service: nome del servizio da creare"
		echo "          -start/--start-exec: path assolto dell'eseguibile per lo start del servizio"
		echo "          -stop/--stop-exec: path assoluto del'eseguibile per lo stop del servizio"
		echo "          -u/--user: utente da abilitare al servizio"
		exit 0
		shift
		;;
		*)
	esac
done

for i in "$@"
do
	case $i in 
		-s=*|--service=*)
		SERVICE_NAME="${i#*=}"
		shift
		;;
                -start=*|--start-exec=*)
                START_EXEC="${i#*=}"
                shift
                ;;
                -stop=*|--stop-exec=*)
                STOP_EXEC="${i#*=}"
                shift
                ;;
		-u=*|--USER=*)
                USER="${i#*=}"
                shift
                ;;

		*)
		echo "Parametro $i non riconosciuto"
		exit 104
		# unknown option
		;;
	esac
done

if [[ "$SERVICE_NAME" = "" ]]; then
	echo "Errore specificare il nome del servizio da creare"
	exit 100
fi

if [[ "$START_EXEC" = "" ]]; then
	echo "Errore: specificare il percorso dell'eseguibile per lo start del servizio"
	exit 101
fi

if [[ "$STOP_EXEC" = "" ]]; then
	echo "Errore: specifcare il percorso dell'eseguibile per lo stop del servizio"
	exit 102
fi

if [[ "$USER" = "" ]]; then
        echo "Errore: specifcare l'utente da abilitare al servizio"
        exit 103
fi


cat >/etc/systemd/system/"$SERVICE_NAME".service <<EOL
[Unit]
Description=Microservice $SERVICE_NAME 
After=network.target 

[Service] 
Type=simple 
ExecStart=/bin/bash $START_EXEC
ExecStop=/bin/bash $STOP_EXEC 

[Install] 
WantedBy=default.target
EOL

chmod 664 /etc/systemd/system/"$SERVICE_NAME".service
systemctl daemon-reload

cat >>/etc/sudoers <<EOL
$USER      ALL=(ALL)       NOPASSWD:/usr/bin/systemctl start $SERVICE_NAME, /usr/bin/systemctl stop $SERVICE_NAME
EOL

