import com.opensymphony.workflow.InvalidInputException
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import org.apache.log4j.Category
import com.atlassian.jira.project.Project
import com.atlassian.jira.project.version.Version

def Category log = Category.getInstance("com.onresolve.jira.groovy")
log.setLevel(org.apache.log4j.Level.INFO)

CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
CustomField versionField = customFieldManager.getCustomFieldObjectByName("Wave")
CustomField projectField = customFieldManager.getCustomFieldObjectByName("Progetto")
def projectValue = issue.getCustomFieldValue(projectField)
def versionValue = issue.getCustomFieldValue(versionField)
log.info "versionValue:  ${versionValue}"

Project p =ComponentAccessor.getProjectManager().getProjectObjByName("${projectValue}")
Collection<Version> versions=p.getVersions()
for(Version v:versions){
    log.info "Version:  name  ${v.getName()} Release date: ${v.getReleaseDate()}  Start date: ${v.getStartDate()}"
}

if(versions?.find { it.getName() == "${versionValue}" }){
    log.info "Version found:  ${versionValue}"
}
else throw new InvalidInputException("Wave",
        "Wave deve essere una Release esistente nel progetto ${projectValue}")
