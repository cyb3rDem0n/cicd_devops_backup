import com.atlassian.jira.component.ComponentAccessor

// descrizione
// update jenkins field to promotingImages

// the name of the custom field to change
final String customFieldName = "Jenkins"

// the new value for that field
final String newValue = "promotingImages"

def customFieldManager = ComponentAccessor.customFieldManager
def customField = customFieldManager.getCustomFieldObjects(issue).find { it.name == customFieldName }

assert customField: "Could not find custom field with name $customFieldName"

issue.setCustomFieldValue(customField, newValue)