import com.atlassian.jira.issue.comments.CommentManager
import com.atlassian.jira.issue.status.Status
import com.opensymphony.workflow.InvalidInputException
import com.opensymphony.workflow.loader.ActionDescriptor
import groovy.json.JsonSlurperClassic;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.fields.CustomField;
import org.apache.log4j.Category;

import com.onresolve.scriptrunner.db.DatabaseUtil

Category logger = Category.getInstance("com.onresolve.jira.groovy")
logger.setLevel(org.apache.log4j.Level.INFO)


def user = ComponentAccessor.getUserManager().getUserByName('jira.bot.user')
def commentMgr = ComponentAccessor.getCommentManager()
def customFieldManager = ComponentAccessor.getCustomFieldManager()

CustomField progettoField = customFieldManager.getCustomFieldObjectByName("Progetto")
String progettoValue = issue.getCustomFieldValue(progettoField)

CustomField waveField = customFieldManager.getCustomFieldObjectByName("Wave")
String waveValue = issue.getCustomFieldValue(waveField)

String applicatioType = waveValue.toString().contains('streaming') ? 'DataStreaming' : 'ApiServices'

List manifestList = issue.getDescription().replace('\r','').tokenize('\n').collect { it.tokenize(':')[0].trim() }
List prodManifestList = []

def sqlConnectionName = "${progettoValue} PostgreSQL".toString()
DatabaseUtil.withSql(sqlConnectionName) { sql ->
    String query = """select microservice 
from release_manifest_info rmi
join (SELECT max(r.id) as id_release, r.id_wave 
\t\tFROM "release" r
\t\tWHERE r.curr_env = 'prod'
\t\tgroup by r.id_wave) as res on res.id_wave = rmi.id_wave and res.id_release = rmi.id_release
where wave = '${waveValue}' """.toString()

    def rows = sql.rows(query)
    rows.each { el ->
        prodManifestList.add(el.get('microservice') as String)
    }
}

logger.info("manifestList: ${manifestList}")
logger.info("prodManifestList: ${prodManifestList}")

List missingMS = []
prodManifestList.each {
    if(!manifestList.contains(it)){
        missingMS.add(it)
    }
}

logger.info("missingMS: ${missingMS}")

if(missingMS.size()>0){
    String msg = "Errore: i seguenti microservizi presenti in produzione non sono nel manifest da deployare:\n[${missingMS.join(', ')}]".toString()
    throw new InvalidInputException(msg)
}

