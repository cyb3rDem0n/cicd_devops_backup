import com.atlassian.jira.issue.Issue
import com.atlassian.jira.project.version.Version
import com.atlassian.jira.event.project.VersionReleaseEvent
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.user.ApplicationUser
import org.apache.log4j.Logger
import org.apache.log4j.Level


VersionReleaseEvent event = event as VersionReleaseEvent
def log = Logger.getLogger(this.getClass())
log.setLevel(Level.DEBUG)
ApplicationUser user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
log.info("NewReleaseVersionListener Started")


String curlCmd = "curl -X POST http://jenkins-cb-devops.apps.secreloaded.sec/job/Service/job/close_release/buildWithParameters?token=TOKEN"+
        "&NOTIFICATION_MAIL="+user.getEmailAddress()+"&RELEASE_NUMBER="+event.getVersion().toString().trim()+
        " -u ServiceDevOps:118826fa53785440a7347e2d040c987133";
log.info("curl to jenkis:\n"+curlCmd)
def proc = curlCmd.execute()
