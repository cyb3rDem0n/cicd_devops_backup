import groovy.json.JsonSlurperClassic

import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.user.ApplicationUser
import org.apache.log4j.Category

import com.onresolve.scriptrunner.db.DatabaseUtil

import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.KeyManager
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSession
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.security.cert.X509Certificate

ApplicationUser user = ComponentAccessor.getUserManager().getUserByName('jira.bot.user')
ApplicationUser loggedUser = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()

Category logger = Category.getInstance("com.onresolve.jira.groovy")
logger.setLevel(org.apache.log4j.Level.INFO)

CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
CustomField progettoField = customFieldManager.getCustomFieldObjectByName("Progetto")
String progettoValue = issue.getCustomFieldValue(progettoField)
CustomField rollbackField = customFieldManager.getCustomFieldObjectByName("Rollback automatico")
String rollbackValue = issue.getCustomFieldValue(rollbackField)
boolean autoRollback = (rollbackValue == 'Si')
CustomField waveField = customFieldManager.getCustomFieldObjectByName("Wave")
String waveValue = issue.getCustomFieldValue(waveField)

CustomField manifestField = customFieldManager.getCustomFieldObjectByName("Manifest")
String manifestVersion = issue.getCustomFieldValue(manifestField).toString()

String manifest = URLEncoder.encode(issue.getDescription(), 'UTF-8')

boolean isRedeploy = true

def isWaveReleaseIssue = false
switch (issue.getIssueType().getName()) {
    case 'Wave Release':
        isWaveReleaseIssue = true
        break
    case 'Hotfix Release':
        autoRollback = isRedeploy
        break
    case 'Parallel Release':
        autoRollback = false
        break
}

Map mapParams = [
        token             : 'TOKEN',
        MANIFEST_VERSION  : manifestVersion.trim(),
        RELEASE_NUMBER    : issue.getKey(),
        WAVE              : waveValue.trim(),
        ISSUE_KEY         : issue.getKey(),
        DEPLOY_MANIFEST   : manifest.trim(),
        CLUSTER_TYPE      : 'prod',
        AUTO_ROLLBACK     : autoRollback,        // true per produzione per wave e hotfix release
        AUTO_MERGE        : false,               // non va fatto per redeploy
        FORCE_REDEPLOY    : isRedeploy,
        NOTIFICATION_MAIL : loggedUser.getEmailAddress()
]
String params = mapParams.collect { k, v -> "${k}=${v}" }.join('&')

String ENV = 'prod' // Serve per selezionare le giuste info di jenkins da DB
Map options = (Map) DatabaseUtil.withSql("${progettoValue} Endpoints" as String) { sql ->
    def res = sql.firstRow("select * from endpoint where env = '${ENV}' AND tool = 'jenkins'".toString())
    return [mocked: res.get('mocked'), baseUrl: res.get('baseurl'), user: res.get('user'), auth: res.get('auth'), endpoints: (res.get('endpoints') ? new JsonSlurperClassic().parseText(res.get('endpoints').toString()) : null)]
}

def endpoint = "${options.baseUrl}/${(options.endpoints as Map).deploy}/buildWithParameters?${params}";
if (!options.mocked) {

    List<TrustManager> trustAllCerts = []
    trustAllCerts.add(
            new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return null }

                public void checkClientTrusted(X509Certificate[] certs, String authType) {}

                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
            }
    )

    List<KeyManager> trustAllKey = []
    trustAllKey.add(new KeyManager() {})

    // Install the all-trusting trust manager
    SSLContext sc = SSLContext.getInstance("SSL")
    sc.init(trustAllKey.toArray() as KeyManager[], trustAllCerts.toArray() as TrustManager[], new java.security.SecureRandom())
    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory())

    // Create all-trusting host name verifier
    HostnameVerifier allHostsValid = new HostnameVerifier() {
        public boolean verify(String hostname, SSLSession session) { return true }
    }

// Install the all-trusting host verifier
    HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid)

    URL url = new URL(endpoint);
    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
    connection.requestMethod = "POST"
    connection.doOutput = true
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("Authorization", options.auth as String)
    connection.connect()

    if(400 > connection.getResponseCode()){
        def commentMgr = ComponentAccessor.getCommentManager()
        def comment = "*E' stata avviata su Jenkins la pipeline di orchestrazione per effettuare il deploy nell'ambiente [cb-prod]:*\n\nhttps://jenkins-cb-devops.apps.pod1.seccloud.internal/job/Service/job/DeployOrchestrator/"
        commentMgr.create(issue, user, comment, true)
    }

    logger.info("Calling url: " + url)
    logger.info("ResponseCode: " + connection.getResponseCode())
    logger.info("getResponseMessage: " + connection.getResponseMessage())
} else {
    logger.info("Call to url is mocked [${endpoint}] ")
}