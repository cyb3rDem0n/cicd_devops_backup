import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.MutableIssue
import org.apache.log4j.Category;
 

import com.atlassian.crowd.embedded.api.User
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.component.ComponentAccessor


def Category log = Category.getInstance("com.onresolve.jira.groovy")
log.setLevel(org.apache.log4j.Level.INFO)
 

def userManager = ComponentAccessor.getUserManager()
def groupManager = ComponentAccessor.getGroupManager()
def group = userManager.getGroup("copybanking_jira_releasemanagers")
Collection<ApplicationUser> usersInGroup = groupManager.getUsersInGroup(group)

 

def watcherManager = ComponentAccessor.getWatcherManager()
MutableIssue issue = issue as MutableIssue
usersInGroup.each{ user ->
    log.info ("Adding user ${user} as watcher fir this issue")
    watcherManager.startWatching(user, issue)
}
