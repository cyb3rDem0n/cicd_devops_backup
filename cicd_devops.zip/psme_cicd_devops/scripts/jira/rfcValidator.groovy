import com.opensymphony.workflow.InvalidInputException
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.comments.CommentManager
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.user.ApplicationUser
import java.sql.Timestamp
import com.onresolve.scriptrunner.db.DatabaseUtil


//: contiene il codice rfc, char(50), contiene per esempio 2020000085318
String codice_rfc
//contiene l’ambiente target del change, con dominio: “Test”, “Prod”, “Rollout”
String ambiente
//dominio: Software, Parametri, Componente Tecnologica
String tipo_intervento
//dominio: “Applicativo”, “Infrastruttura”
String tipo_passaggio
String stato_rfc
Timestamp inizioIntervento

ApplicationUser currentUser = ComponentAccessor.getUserManager().getUserByName('jira.bot.user')
CommentManager commentMgr = ComponentAccessor.getCommentManager()
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
CustomField rfcField = customFieldManager.getCustomFieldObjectByName("RFC number")
def rfcValue = issue.getCustomFieldValue(rfcField)

String query = "SELECT codice_rfc, ambiente, dataora_iniziointervento, dataora_fineintervento," +
        "applicazione_cod, applicazione_nome, tipo_intervento, tipo_passaggio, referente_nome," +
        "referente_cognome, referente_username, referente_email, descrizione_change, stato_rfc " +
        "from [SEC_RFC].[dbo].[rfc_maininfo_extended] " +
        "where codice_rfc = ${rfcValue}"

boolean isRFCValid = false
StringBuffer buffer = new StringBuffer()

DatabaseUtil.withSql('RFCTest') { sql ->
    if(!sql){
        buffer.append("Errore: RFC Number ${codice_rfc} non è presente a sistema")
    }
    else{
        codice_rfc = sql.firstRow(query)[0] as String
        ambiente = sql.firstRow(query)[1] as String
        tipo_intervento = sql.firstRow(query)[6] as String
        tipo_passaggio = sql.firstRow(query)[7] as String
        stato_rfc = sql.firstRow(query)[13] as String
        inizioIntervento = sql.firstRow(query)[2] as Timestamp
    }

}


if(""==buffer.toString())
{
    Timestamp now = new Timestamp(System.currentTimeMillis())
    Calendar cal = Calendar.getInstance()
    cal.setTime(new Date(inizioIntervento.time))
    cal.set(Calendar.HOUR_OF_DAY, 23)
    cal.set(Calendar.MINUTE, 59)
    cal.set(Calendar.SECOND,59)
    Timestamp nextMidnight = new Timestamp(cal.getTimeInMillis())

    if(tipo_intervento!="Software"){
        buffer.append("Errore codice_rfc ${codice_rfc} non valido\ntipo_intervento diverso da 'Software': ${tipo_intervento}\n")
        isRFCValid = false
    }
    else if(tipo_passaggio!="Applicativo"){
        buffer.append("Errore codice_rfc ${codice_rfc} non valido\ntipo_intervento diverso da 'Applicativo': ${tipo_passaggio}\n")
        isRFCValid = false
    }
    else if(ambiente!="Prod"){
        buffer.append("Errore codice_rfc ${codice_rfc} non valido\nambiente operativo diverso da 'Prod': ${ambiente}\n")
        isRFCValid = false
    }
    else if (stato_rfc != "Esecuzione") {
        buffer.append("Errore codice_rfc ${codice_rfc} non valido\nstato_rfc operativo diverso da 'Esecuzione': ${stato_rfc}\n")
        isRFCValid = false
    }
    else if (!(now.compareTo(inizioIntervento) >= 0)) {
        buffer.append("Errore codice_rfc ${codice_rfc} non valido\nNon è possibile iniziare l'attività prima della data ${inizioIntervento.toString()}\n")
        isRFCValid = false
    }
    else if (!(now.compareTo(nextMidnight) <= 0)) {
        buffer.append("Errore codice_rfc ${codice_rfc} non valido\nNon è possibile iniziare l'attività dopo la data ${nextMidnight.toString()}\n")
        isRFCValid = false
    }
    else{
        buffer.append("Il Codice RFC è valido: ${codice_rfc}\n")
        isRFCValid = true
    }
}

commentMgr.create(issue, currentUser, buffer.toString(), true)
if(!isRFCValid){
    throw new InvalidInputException(buffer.toString())
}

