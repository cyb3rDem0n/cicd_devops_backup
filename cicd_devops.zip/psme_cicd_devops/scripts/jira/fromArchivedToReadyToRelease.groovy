import com.atlassian.jira.component.ComponentAccessor

customFieldManager = ComponentAccessor.customFieldManager
def optionsManager = ComponentAccessor.optionsManager
def issueManager = ComponentAccessor.issueManager

def customField = customFieldManager.getCustomFieldObjectByName("isRollback")
def fieldConfig = customField.getRelevantConfig(issue)
def options = optionsManager.getOptions(fieldConfig)

def optionsToSet = options.findAll { it.value in ["enabled"] }
issue.setCustomFieldValue(customField, optionsToSet)