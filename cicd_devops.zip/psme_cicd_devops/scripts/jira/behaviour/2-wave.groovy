import com.onresolve.scriptrunner.db.DatabaseUtil
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.CustomFieldManager
import com.onresolve.jira.groovy.user.FieldBehaviours
import com.onresolve.scriptrunner.db.NoSuchDataSourceException
import groovy.transform.BaseScript

@BaseScript FieldBehaviours fieldBehaviours

def customFieldManager = ComponentAccessor.getComponent(CustomFieldManager)
def optionsManager = ComponentAccessor.getOptionsManager()

def manifestField = customFieldManager.getCustomFieldObjectByName("Manifest")
def config = manifestField.getRelevantConfig(getIssueContext())
def options = optionsManager.getOptions(config)

def wave = getFieldById(getFieldChanged()).getValue()
log.info('\n----------------------------------\n' + "wave: \n" + wave + '\n----------------------------------\n')

Map manifestVersions = [(-1 as long): 'None']

if(getActionName() == "Create") {
    def progetto = getFieldByName('Progetto').getValue()
    if (progetto) {
        def sqlConnectionName = "${progetto} PostgreSQL".toString()
        try {
            manifestVersions << (Map) DatabaseUtil.withSql(sqlConnectionName) { sql ->
                // target query
                int limit = 10
                String query = """select min(id_manifest) as id, manifest_version from release_manifest_info where wave = '${wave}' and manifest_version IS NOT NULL group by manifest_version order by id DESC limit ${limit}""".toString()
                Map ret = [:]
                def rows = sql.rows(query)
                rows.eachWithIndex { el, i ->
                    def option = options.find { it.value == el[1] as String }
                    //log.info('\n----------------------------------\n'+"option: \n"+option+'\n----------------------------------\n')
                    if (!option) {
                        option = optionsManager.createOption(config, null, el[0] as long, el[1] as String)
                        options.addOption(option, el[1] as String)
                    }
                    ret.put(option.getOptionId(), el[1] as String)
                }
                return ret
            }
        } catch (NoSuchDataSourceException e) {
            log.warn(e.toString())
        }

    }

//log.info('\n----------------------------------\n' + "set manifestVersions: \n" + manifestVersions + '\n----------------------------------\n')

    getFieldByName("Manifest").setFieldOptions(manifestVersions)
    if (manifestVersions == [(-1 as long): 'None'] || !getFieldByName("Manifest").getValue()) {
        log.info('\n----------------------------------\n' + "setting manifest value to None" + '\n----------------------------------\n')
        getFieldByName("Manifest").setFormValue('None')
        getFieldById("description").setFormValue("")
    }
}


