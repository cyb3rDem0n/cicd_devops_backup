import com.onresolve.scriptrunner.db.DatabaseUtil
import com.onresolve.jira.groovy.user.FieldBehaviours
import com.onresolve.scriptrunner.db.NoSuchDataSourceException
import groovy.transform.BaseScript

@BaseScript FieldBehaviours fieldBehaviours

def manifestVersion = getFieldByName('Manifest').getValue()
log.info('\n----------------------------------\n' + "manifestVersion: \n" + manifestVersion + '\n----------------------------------\n')

def description = ""

if(getActionName() == "Create") {
    def progetto = getFieldByName('Progetto').getValue()
    if (progetto && manifestVersion) {
        def sqlConnectionName = "${progetto} PostgreSQL".toString()
        try {
            String wave = getFieldByName("Wave").getValue() as String
            description = DatabaseUtil.withSql(sqlConnectionName) { sql ->
                //String dataQuery = """select microservice, build_num from release_manifest_info where version = '${manifestVersion}'""".toString()
                // target query
                String dataQuery = """select distinct id_manifest, microservice, build_num from release_manifest_info where manifest_version = '${manifestVersion}' and wave = '${wave}'""".toString()
                def rows = sql.rows(dataQuery).collect { "${it.get('microservice')}: ${it.get('build_num')}" }
                return rows.join('\n')
            }
        } catch (NoSuchDataSourceException e) {
            log.warn(e.toString())
        }
    }

    log.info('\n----------------------------------\n' + "set Description: \n" + description + '\n----------------------------------\n')

    getFieldById("description").setFormValue(description)

}