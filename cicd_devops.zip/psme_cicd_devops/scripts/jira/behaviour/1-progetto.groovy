import com.onresolve.scriptrunner.db.DatabaseUtil
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.CustomFieldManager
import com.onresolve.jira.groovy.user.FieldBehaviours
import com.onresolve.scriptrunner.db.NoSuchDataSourceException
import groovy.transform.BaseScript

@BaseScript FieldBehaviours fieldBehaviours

def customFieldManager = ComponentAccessor.getComponent(CustomFieldManager)
def optionsManager = ComponentAccessor.getOptionsManager()

def waveField = customFieldManager.getCustomFieldObjectByName("Wave")
def config = waveField.getRelevantConfig(getIssueContext())
def options = optionsManager.getOptions(config)

Map waves = [(-1 as long): 'None']

def progettoField = getFieldById(getFieldChanged())

if (getActionName() == "Create") {
    progettoField.setRequired(true)
    progettoField.setHidden(false)
} else {
    progettoField.setRequired(false)
    progettoField.setHidden(true)

    getFieldByName("Wave").setReadOnly(true)
    getFieldByName("Manifest").setReadOnly(true)
    descriptionField.setReadOnly(true)
}

if(getActionName() == "Create") {
    def progetto = progettoField.getValue()
    log.info('\n----------------------------------\n' + "Progetto: \n" + progetto + '\n----------------------------------\n')
    if (progetto) {
        def sqlConnectionName = "${progetto} PostgreSQL".toString()
        try {
            waves << (Map) DatabaseUtil.withSql(sqlConnectionName) { sql ->
                Map ret = [:]
                def rows = sql.rows("select id, name from wave")
                rows.each { el ->
                    def option = options.find { it.value == el[1] as String }
                    //log.info('\n----------------------------------\n'+"option: \n"+option+'\n----------------------------------\n')
                    if (!option) {
                        option = optionsManager.createOption(config, null, el[0] as long, el[1] as String)
                        options.addOption(option, el[1] as String)
                    }
                    ret.put(option.getOptionId(), el[1] as String)
                }
                return ret
            }
        } catch (NoSuchDataSourceException e) {
            log.warn(e.toString())
        }
    }

//log.info('\n----------------------------------\n'+"set waves: \n"+waves+'\n----------------------------------\n')

    getFieldByName("Wave").setFieldOptions(waves)

}