import com.atlassian.jira.issue.status.Status
import com.onresolve.scriptrunner.db.DatabaseUtil
import com.onresolve.scriptrunner.db.NoSuchDataSourceException
import com.onresolve.scriptrunner.runner.rest.common.CustomEndpointDelegate
import com.opensymphony.workflow.loader.ActionDescriptor
import groovy.json.JsonBuilder
import groovy.json.JsonSlurperClassic
import groovy.transform.BaseScript
import com.atlassian.jira.component.ComponentAccessor
import org.apache.log4j.Category

import javax.ws.rs.core.MultivaluedMap
import javax.ws.rs.core.Response
import javax.servlet.http.HttpServletRequest
import com.atlassian.jira.bc.user.search.UserSearchService
import com.atlassian.jira.bc.user.search.UserSearchParams
import com.atlassian.jira.user.ApplicationUser

import java.sql.Timestamp
import java.text.SimpleDateFormat


@BaseScript CustomEndpointDelegate delegate

def customFieldManager = ComponentAccessor.getCustomFieldManager()
def issueManager = ComponentAccessor.getIssueManager()
def issueService = ComponentAccessor.getIssueService()
def workflowManager = ComponentAccessor.getWorkflowManager()

Category logger = Category.getInstance("com.onresolve.jira.groovy")
logger.setLevel(org.apache.log4j.Level.INFO)

private Response checkUserAuthentication(String userName) {
    if (!(userName in ['gabriele_lagana', 'jira.bot.user']))
        return Response.status(Response.Status.UNAUTHORIZED).entity(new JsonBuilder([error: "[${userName}] is not authorized"]).toString()).build()
    return null
}

private ApplicationUser findUser(String userName) {
    def userSearchService = ComponentAccessor.getComponent(UserSearchService.class);
    def userSearchParams = (new UserSearchParams.Builder()).allowEmptyQuery(true).includeActive(true).includeInactive(true).maxResults(10).build();

    return userSearchService.findUsers(userName, userSearchParams).get(0)
}

checkAuth(httpMethod: "GET", groups: ["jira-administrators"]) { MultivaluedMap queryParams, String body, HttpServletRequest request ->
    logger.info("*** CUSTOM RESTAPI --> updateCustomField ***")
    String loggedUserName = request.getUserPrincipal().getName()
    Response unauthorized = checkUserAuthentication(loggedUserName)
    if (unauthorized != null)
        return unauthorized
    return Response.ok(new JsonBuilder([status: 200, message: "Autorizzato"]).toString()).build()
}

updateCustomField(httpMethod: "POST", groups: ["jira-administrators"]) { MultivaluedMap queryParams, String body, HttpServletRequest request ->
    logger.info("*** CUSTOM RESTAPI --> updateCustomField ***")
    String loggedUserName = request.getUserPrincipal().getName()
    Response unauthorized = checkUserAuthentication(loggedUserName)
    if (unauthorized != null)
        return unauthorized
    String issueKey = queryParams.get('ISSUE')[0]
    logger.info("*** CUSTOM RESTAPI --> updateCustomField *** issueKey: " + issueKey)

    def user = findUser(loggedUserName)
    logger.info("*** CUSTOM RESTAPI --> updateCustomField *** user: " + user.getName())

    def issue = issueManager.getIssueByCurrentKey(issueKey)

    Map mapParams = new JsonSlurperClassic().parseText(body) as Map
    logger.info("*** CUSTOM RESTAPI --> updateCustomField *** mapParams: ${mapParams}")

    if (mapParams.size() == 0) {
        return Response.ok(new JsonBuilder([status: 200, message: "Nessuna modifica"]).toString()).build()
    }

    def issueInputParameters = issueService.newIssueInputParameters();
    mapParams.each { fieldName, value ->
        if (fieldName.toString().toLowerCase() == 'comment') {
            issueInputParameters.setComment(value as String)
            return
        }
        String applyVal = null
        def field = customFieldManager.getCustomFieldObjectByName(fieldName as String)
        if (value instanceof Map) {
            String key = (value as Map).keySet()[0].toString().toLowerCase()
            switch (key){
                case 'option':
                    def optionsManager = ComponentAccessor.getOptionsManager()
                    def config = field.getRelevantConfig(issue)
                    def options = optionsManager.getOptions(config)
                    if(fieldName == 'Manifest'){
                        def progetto = customFieldManager.getCustomFieldObjectByName('Progetto').getValue(issue)
                        def wave = customFieldManager.getCustomFieldObjectByName('Wave').getValue(issue)
                        def sqlConnectionName = "${progetto} PostgreSQL".toString()
                        try {
                            DatabaseUtil.withSql(sqlConnectionName) { sql ->
                                // target query
                                int limit = 10
                                String query = """select min(id_manifest) as id, manifest_version from release_manifest_info where wave = '${wave}' and manifest_version IS NOT NULL group by manifest_version order by id DESC limit ${limit}""".toString()
                                Map ret = [:]
                                def rows = sql.rows(query)
                                rows.eachWithIndex { el, i ->
                                    def option = options.find { it.value == el[1] as String }
                                    //log.info('\n----------------------------------\n'+"option: \n"+option+'\n----------------------------------\n')
                                    if (!option) {
                                        option = optionsManager.createOption(config, null, el[0] as long, el[1] as String)
                                        logger.info("adding option: ${option.toString()}")
                                        options.addOption(option, el[1] as String)
                                    }
                                }
                            }
                        } catch (NoSuchDataSourceException e) {
                            logger.info(e.toString())
                        }
                        optionsManager.updateOptions(options)
                        options = optionsManager.getOptions(config)
                        logger.info("versions: ${options.toString()}")
                    }

                    def option = options.find { it.value == (value.get(key) as String) }
                    applyVal = option.getOptionId().toString()
                    break
                case 'datetime':
                    def ts = Timestamp.valueOf(value.get(key) as String)
                    applyVal = new SimpleDateFormat("d/MMM/yy hh:mm a").format(new Date(ts.getTime()))
                    break
            }
        } else if (value instanceof List) {
            // TODO
            return
        } else {
            //logger.info("*** CUSTOM RESTAPI --> updateCustomField *** modifico il campo '${fieldName}' con valore '${value}'")
            applyVal = value as String
        }
        issueInputParameters.addCustomFieldValue(field.getId(), applyVal)
    }
    issueInputParameters.setRetainExistingValuesWhenParameterNotProvided(true, true)
    // validate update -------------
    def updateValidationResult = issueService.validateUpdate(user, issue.getId(), issueInputParameters);

    if (updateValidationResult.isValid()) {
        // update the issue ----------
        def updateResult = issueService.update(user, updateValidationResult);
        if (!updateResult.isValid()) {
            logger.error("*** CUSTOM RESTAPI --> updateCustomField *** updateResult: " + updateResult.getErrorCollection().toString())
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(new JsonBuilder([
                            status : Response.Status.INTERNAL_SERVER_ERROR.statusCode,
                            message: "[${issue.getKey()}] update non valido",
                            error  : updateResult.getErrorCollection().toString()
                    ]).toString())
                    .build()
        }
        logger.info("*** CUSTOM RESTAPI --> updateCustomField *** update effettuato con successo per ${mapParams} --- ${updateResult.toString()}")
        return Response.ok(new JsonBuilder([status: 200, message: "[${issue.getKey()}] updated", updates: mapParams]).toString()).build()
    } else {
        logger.error("*** CUSTOM RESTAPI --> updateCustomField *** updateValidationResult" + updateValidationResult.getErrorCollection().toString())
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                .entity(new JsonBuilder([
                        status : Response.Status.INTERNAL_SERVER_ERROR.statusCode,
                        message: "[${issue.getKey()}] validazione update non superata",
                        error  : updateValidationResult.getErrorCollection().toString()
                ]).toString())
                .build()
    }
}

transition(httpMethod: "POST", groups: ["jira-administrators"]) { MultivaluedMap queryParams, String body, HttpServletRequest request ->
    logger.info("*** CUSTOM RESTAPI --> transition ***")
    String loggedUserName = request.getUserPrincipal().getName()
    Response unauthorized = checkUserAuthentication(loggedUserName)
    if (unauthorized != null)
        return unauthorized
    String issueKey = queryParams.get('ISSUE')[0]
    logger.info("*** CUSTOM RESTAPI --> transition *** issueKey: " + issueKey)

    def user = findUser(loggedUserName)
    logger.info("*** CUSTOM RESTAPI --> transition *** user: " + user.getName())

    def issue = issueManager.getIssueByCurrentKey(issueKey)

    Map mapParams = new JsonSlurperClassic().parseText(body) as Map
    logger.info("*** CUSTOM RESTAPI --> transition *** mapParams: ${mapParams}")

    def workflow = workflowManager.getWorkflow(issue)
    Status currentStatus = issue.getStatus()
    def currentStep = workflow.getLinkedStep(currentStatus)
    def allStatus = workflow.getLinkedStatusObjects()

    List<ActionDescriptor> actions = currentStep.getActions()
    Integer actionId = null
    for (ActionDescriptor actionDescriptor : actions) {
        if (mapParams.transitionName) {
            if (actionDescriptor.getName() == mapParams.transitionName) {
                actionId = actionDescriptor.getId()
                break
            }
        } else if (mapParams.targetStatus) {
            def nextStatusId = workflowManager.getNextStatusIdForAction(issue, actionDescriptor.getId())
            Status nextStatus = allStatus.find { it.getId() == nextStatusId }
            if (nextStatus?.getName() == mapParams.targetStatus) {
                actionId = actionDescriptor.getId()
                break
            }
        }
    }
    if (actionId == null) {
        String errorMsg = "[${issue.getKey()}] " +
                (mapParams.transitionName ?
                        "Nessuna transizione disponibile con nome '${mapParams.transitionName}'" :
                        "Nessuna transizione disponibile verso lo stato '${mapParams.targetStatus}'")
        logger.info("*** CUSTOM RESTAPI --> transition *** ${errorMsg}")
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).
                entity(new JsonBuilder([
                        status : Response.Status.INTERNAL_SERVER_ERROR.statusCode,
                        message: errorMsg,
                        error  : null
                ]).toString()).build()
    }

    def issueInputParameters = issueService.newIssueInputParameters()
    if (mapParams.comment) {
        log.info(mapParams.comment)
        issueInputParameters.setComment(mapParams.comment as String)
    }
    def transitionValidationResult = issueService.validateTransition(user, issue.getId(), actionId, issueInputParameters);
    if (transitionValidationResult.isValid()) {
        def transitionResult = issueService.transition(user, transitionValidationResult)
        if (!transitionResult.isValid()) {
            String errorMsg = "[${issue.getKey()}] " +
                    (mapParams.transitionName ?
                            "Transizione con nome '${mapParams.transitionName}' non valida" :
                            "Transizione allo stato '${mapParams.targetStatus}' non valida")
            logger.error("*** CUSTOM RESTAPI --> transition *** ${errorMsg}")
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity(new JsonBuilder([
                            status : Response.Status.INTERNAL_SERVER_ERROR.statusCode,
                            message: errorMsg,
                            error  : transitionResult.getErrorCollection().toString()
                    ]).toString())
                    .build()
        }
        String msg = "[${issue.getKey()}] " +
                (mapParams.transitionName ?
                        "Transizione con nome '${mapParams.transitionName}' effettuata con successo" :
                        "Transizione allo stato '${mapParams.targetStatus}' effettuata con successo")
        logger.info("*** CUSTOM RESTAPI --> transition *** ${msg}")
        return Response.ok(new JsonBuilder([
                status : 200,
                message: msg
        ]).toString())
                .build()
    } else {
        String errorMsg = "[${issue.getKey()}] " +
                (mapParams.transitionName ?
                        "Validazione non superata per la transizione con nome '${mapParams.transitionName}'" :
                        "Validazione non superata per la transizione allo stato '${mapParams.targetStatus}'")

        logger.error("*** CUSTOM RESTAPI --> transition *** ${errorMsg}")
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                .entity(new JsonBuilder([
                        status : Response.Status.INTERNAL_SERVER_ERROR.statusCode,
                        message: errorMsg,
                        error  : transitionValidationResult.getErrorCollection().toString()
                ]).toString())
                .build()
    }
}



