import com.onresolve.scriptrunner.runner.rest.common.CustomEndpointDelegate
import groovy.json.JsonBuilder
import groovy.json.JsonSlurperClassic
import groovy.transform.BaseScript

import javax.ws.rs.core.MultivaluedMap
import javax.ws.rs.core.Response
import javax.servlet.http.HttpServletRequest

@BaseScript CustomEndpointDelegate delegate

Map jenkinsMap = [
        temp   : [
                baseUrl  : "http://jenkins-cb-devops.apps.secreloaded.sec",
                auth     : "Basic U2VydmljZURldk9wczoxMTg4MjZmYTUzNzg1NDQwYTczNDdlMmQwNDBjOTg3MTMz",
                endpoints: [
                        promote: "job/Service/job/PromoteImages",
                        deploy : "job/Service/job/DeployOrchestrator"
                ]
        ],
        preprod: [
                baseUrl  : "https://jenkins-cb-devops.apps.dv.seccloud.internal",
                auth     : "",
                endpoints: [
                        promote: "job/Service/job/PromoteImages",
                        deploy : "job/Service/job/DeployOrchestrator"
                ]
        ],
        prod   : [
                baseUrl  : "https://jenkins-cb-devops.apps.pod1.seccloud.internal",
                auth     : "",
                endpoints: [
                        promote: "job/Service/job/PromoteImages",
                        deploy : "job/Service/job/DeployOrchestrator"
                ]
        ]
]

private Response buildJenkins(Map jenkins, MultivaluedMap queryParams, String body) {
    // Bloccata esecuzione pipeline
    return Response.status(Response.Status.ACCEPTED).entity(new JsonBuilder([message: "Pipeline execution blocked"]).toString()).build()

    // Nel body devono essere presenti tutti i parametri da passare alla pipeline jenkins
    Map mapParams = new JsonSlurperClassic().parseText(body) as Map
    String params = mapParams.collect { k, v -> "${k}=${v}" }.join('&')

    // Come parametri della richiesta accetta 'op' --> promote|deploy
    String endpoint = (jenkins.endpoints as Map).get(queryParams.get('op'))
    String pipeUrl = "${jenkins.baseUrl}/${endpoint}/buildWithParameters?${params}"

    URL url = new URL(pipeUrl);
    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
    connection.requestMethod = "POST"
    connection.doOutput = true
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("Authorization", jenkins.auth as String);
    connection.connect();

    log.info("Calling url: " + url)
    if (connection.getResponseCode() > 399)
        return Response.status(connection.getResponseCode()).entity(new JsonBuilder([error: connection.getResponseMessage()]).toString()).build();
    return Response.ok(connection.getResponseMessage()).build();
}

private Response checkUser(HttpServletRequest request){
    if (request.getUserPrincipal().getName() != 'jira.bot.user')
        return Response.status(Response.Status.UNAUTHORIZED).entity(new JsonBuilder([error: "[${request.getUserPrincipal().getName()}] is not authorized"]).toString()).build()
    return null
}

testAuth(httpMethod: "GET", groups: ["jira-administrators"]) { MultivaluedMap queryParams, String body, HttpServletRequest request ->
    Response unauthorized = checkUser(request)
    if (unauthorized != null)
        return unauthorized
    return Response.ok('Authorized').build();
}

buildJenkinsPipelineTemp(httpMethod: "POST", groups: ["jira-administrators"]) { MultivaluedMap queryParams, String body, HttpServletRequest request ->
    Response unauthorized = checkUser(request)
    if (unauthorized != null)
        return unauthorized
    return buildJenkins(jenkinsMap.get('temp'), queryParams, body)
}

buildJenkinsPipelineTarget(httpMethod: "POST", groups: ["jira-administrators"]) { MultivaluedMap queryParams, String body, HttpServletRequest request ->
    Response unauthorized = checkUser(request)
    if (unauthorized != null)
        return unauthorized
    return buildJenkins(jenkinsMap.get('preprod'), queryParams, body)
}

buildJenkinsPipelineProd(httpMethod: "POST", groups: ["jira-administrators"]) { MultivaluedMap queryParams, String body, HttpServletRequest request ->
    Response unauthorized = checkUser(request)
    if (unauthorized != null)
        return unauthorized
    return buildJenkins(jenkinsMap.get('prod'), queryParams, body)
}

