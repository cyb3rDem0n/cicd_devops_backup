import com.opensymphony.workflow.InvalidInputException
import groovy.json.JsonSlurperClassic
import org.yaml.snakeyaml.Yaml
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.comments.CommentManager
import org.apache.log4j.Category
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.fields.CustomField
import com.onresolve.scriptrunner.db.DatabaseUtil

Category logger = Category.getInstance("com.onresolve.jira.groovy")
logger.setLevel(org.apache.log4j.Level.INFO)

ApplicationUser user = ComponentAccessor.getUserManager().getUserByName('jira.bot.user')

customFieldManager = ComponentAccessor.getCustomFieldManager()
def issueService = ComponentAccessor.getIssueService()

def progettoField = customFieldManager.getCustomFieldObjectByName("Progetto")
def progettoValue = issue.getCustomFieldValue(progettoField)
def waveField = customFieldManager.getCustomFieldObjectByName("Wave")
def waveValue = issue.getCustomFieldValue(waveField)

Map requestManifest = (new Yaml()).load(issue.getDescription())
//token produzione
def bearerToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJjYi1kZXZvcHMiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlY3JldC5uYW1lIjoiamlyYS5ib3QudXNlci10b2tlbi1nNGdyNSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJqaXJhLmJvdC51c2VyIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiMzRjYWU1YjMtNzgwZC0xMWVhLWE0YzAtMDA1MDU2YTI4MDdmIiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50OmNiLWRldm9wczpqaXJhLmJvdC51c2VyIn0.cj78xfkJsXs1CbDNL01PyoGi1DdsZcyq4tS9sBaZLelrr8zDBFP0gRV0FLMV0bRhAMj1nHTFbT15VTpwjvFlfDm07cSiHqn4yFDec7nXM1g2ShrZEfLdcyHkjIUCGid7pzHI7ilT4PDclXyw9SfCQ3fKYOrU-JtqAwborZv59PzCyx4M1tjXgPkQ5-fUA8CwoztWvM_mds9O5zGDrSpT4uO9eXv8xDjtqG8JhWZE3nqQ2fwqT5BY9jAGGD4JrGYKHpojUNuB1HuBf2lTZO0yS8Eqyprl_utexHaof6Auc1NuIM4SRiDHEinYNxDKxcnKDFEJdNLn3_-J15rm54sUpw"
Map options = (Map) DatabaseUtil.withSql("${progettoValue} Endpoints" as String) { sql ->
    def res = sql.firstRow("select * from endpoint where env = 'prod' AND tool = 'openshift'".toString())
    return [mocked: res.get('mocked'), baseUrl: res.get('baseurl'), user: res.get('user'), auth: res.get('auth'), endpoints: (res.get('endpoints') ? new JsonSlurperClassic().parseText(res.get('endpoints').toString()) : null)]
}

String openshiftNamespace = waveValue.toString().contains('streaming') ? 'cb-streaming-prod' : 'cb-prod'

String labelSelector = progettoValue.toString().toLowerCase()
if (labelSelector == 'copybanking') {
    labelSelector = 'cb'
}

// Lista dei pod relativi alle dc
def currentManifest = [:]
def diffManifest = [:]
def rollBackManifest = [:]
def response_string
boolean requestFailed = false
// Lista delle dc
if(!options.mocked){
    String endpoint = (options.endpoints.getDeploymentConfigs as String).replaceAll("#openshiftNamespace#","${openshiftNamespace}").replaceAll("#labelSelector#", "${labelSelector}")
    URL url = new URL("${options.baseUrl}/${endpoint}" as String)
    HttpURLConnection connection = (HttpURLConnection) url.openConnection()
    connection.requestMethod = args.method ?: "GET"
    connection.doOutput = true
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("Authorization", "Bearer ${bearerToken}")
    connection.connect()

    if(logger) {
        logger.info("Calling url: " + url)
        logger.info("ResponseCode: " + connection.getResponseCode())
        logger.info("getResponseMessage: " + connection.getResponseMessage())
    }
    if(200==connection.getResponseCode()){
        InputStream response = connection.getInputStream();
        response_string = response.getText()
        def dcs = new JsonSlurperClassic().parseText(response_string)

        // Recupero lista dei pod
        dcs.items.each {
            if(!requestFailed){
                def dcName = it.metadata.name
                endpoint = (options.endpoints.getPodsDc as String).replaceAll("#openshiftNamespace#","${openshiftNamespace}").replaceAll("#dcName#", "${dcName}")
                url = new URL("${options.baseUrl}/${endpoint}" as String)
                connection = (HttpURLConnection) url.openConnection()
                connection.requestMethod = args.method ?: "GET"
                connection.doOutput = true
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("Authorization", "Bearer ${bearerToken}")
                connection.connect()

                if(logger) {
                    logger.info("Calling url: " + url)
                    logger.info("ResponseCode: " + connection.getResponseCode())
                    logger.info("getResponseMessage: " + connection.getResponseMessage())
                }
                if(200==connection.getResponseCode()){
                    response = connection.getInputStream();
                    response_string =response.getText()
                    def dcPods = new JsonSlurperClassic().parseText(response_string)
                    if (dcPods.items) {
                        currentManifest.put(dcName, dcPods.items[0].metadata.labels.version)
                    }
                }
                else requestFailed = true
            }
        }

        // Lista degli statefulsets
        if(!requestFailed){
            def statefulSets = ['datagrid-service']
            statefulSets.each { ss ->
                if(!requestFailed){
                    endpoint = (options.endpoints.getPodsSs as String).replaceAll("#openshiftNamespace#","${openshiftNamespace}").replaceAll("#ss#", "${ss}")
                    url = new URL("${options.baseUrl}/${endpoint}" as String)
                    connection = (HttpURLConnection) url.openConnection()
                    connection.requestMethod = args.method ?: "GET"
                    connection.doOutput = true
                    connection.setRequestProperty("Accept", "application/json")
                    connection.setRequestProperty("Authorization", "Bearer ${bearerToken}")
                    connection.connect()

                    if(logger) {
                        logger.info("Calling url: " + url)
                        logger.info("ResponseCode: " + connection.getResponseCode())
                        logger.info("getResponseMessage: " + connection.getResponseMessage())
                    }

                    if(200==connection.getResponseCode()){
                        response = connection.getInputStream();
                        response_string =response.getText()
                        def ssPods = new JsonSlurperClassic().parseText(response_string)
                        if (ssPods.items) {
                            currentManifest.put(ss, ssPods.items[0].metadata.labels.version)
                        }
                    }
                    else requestFailed = true
                }
            }

            if(!requestFailed){
                requestManifest.each { ms, v ->
                    if (!currentManifest.get(ms) || currentManifest.get(ms) != v){
                        diffManifest.put(ms, v)
                        if(currentManifest.get(ms)){
                            rollBackManifest.put(ms, currentManifest.get(ms))
                        }

                    }
                }

                //Update RollBack version
                customFieldManager = ComponentAccessor.getCustomFieldManager()
                def rollBackVersionValue = ""+(new Yaml()).dumpAsMap(rollBackManifest)
                CustomField rollbackVersionField = customFieldManager.getCustomFieldObjectByName("Rollback Version")
                issue.setCustomFieldValue(rollbackVersionField, rollBackVersionValue)

                //Add Commento
                CommentManager commentMgr = ComponentAccessor.getCommentManager()
                def comment = "*Lista dei microservizi che verranno deployati in ambiente di produzione:*\n\n"+(new Yaml()).dumpAsMap(diffManifest)
                commentMgr.create(issue, user, comment, true)
            }
        }
    }
}

