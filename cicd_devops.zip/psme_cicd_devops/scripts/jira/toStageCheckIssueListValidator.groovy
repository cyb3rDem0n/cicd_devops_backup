import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.search.SearchQuery
import org.apache.log4j.Category

Category logger = Category.getInstance("com.onresolve.jira.groovy")
logger.setLevel(org.apache.log4j.Level.INFO)

// prendo le info necessarie a fare il JQL
def customFieldMgr = ComponentAccessor.getCustomFieldManager()
def cFieldProgetto = customFieldMgr.getCustomFieldObjectByName("Progetto")
def cFieldValueProgetto = issue.getCustomFieldValue(cFieldProgetto)
logger.info("Progetto="+cFieldValueProgetto.toString())
def cFieldWave = customFieldMgr.getCustomFieldObjectByName("Wave")
def cFieldValueWave = issue.getCustomFieldValue(cFieldWave)
logger.info("Wave="+cFieldValueWave.toString())

def (applicationContextPrefix, applicationContextPostfix) = cFieldValueWave.toString().tokenize( '-' )
logger.info("Wave prefix="+applicationContextPrefix.toString())


def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchProvider = ComponentAccessor.getComponent(SearchProvider)
def user = ComponentAccessor.getUserManager().getUserByName('jira.bot.user')

//def query = jqlQueryParser.parseQuery("project = SECRM AND issuetype = Release AND status = Stage AND Jenkins ~ deployingCollaudo AND Progetto = "+cFieldValueProgetto.toString()+" AND Wave = "+cFieldValueWave.toString())
def jqlQuery = 'issueFunction in issueFieldMatch("project = '+issue.projectObject.key+' AND status = Stage AND Jenkins ~ deployingCollaudo AND Progetto = '+cFieldValueProgetto.toString()+'", Wave, "'+applicationContextPrefix.toString()+'.*")'
logger.info("JQL="+jqlQuery.toString())

def query = jqlQueryParser.parseQuery(jqlQuery)
logger.info("Query: "+query.getQueryString())

def searchQuery = SearchQuery.create(query, user)

//def results = searchProvider.search(query, user, PagerFilter.getUnlimitedFilter())
def results = searchProvider.search(searchQuery, PagerFilter.getUnlimitedFilter())

logger.info("Total issues: ${results}")
logger.info("Total issues: ${results.total}")

if (results.total > 0) 
	return false
return true
