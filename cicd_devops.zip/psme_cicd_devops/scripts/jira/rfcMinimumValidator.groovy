import com.opensymphony.workflow.InvalidInputException
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.comments.CommentManager
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.user.ApplicationUser
import com.onresolve.scriptrunner.db.DatabaseUtil
/*import org.apache.log4j.Category;
Category logger = Category.getInstance("com.onresolve.jira.groovy")
logger.setLevel(org.apache.log4j.Level.INFO)*/

String codice_rfc
//dominio: Software, Parametri, Componente Tecnologica
String tipo_intervento
//dominio: “Applicativo”, “Infrastruttura”
String tipo_passaggio
//contiene l’ambiente target del change, con dominio: “Test”, “Prod”, “Rollout”
String ambiente

ApplicationUser currentUser = ComponentAccessor.getUserManager().getUserByName('jira.bot.user')
CommentManager commentMgr = ComponentAccessor.getCommentManager()
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
CustomField rfcField = customFieldManager.getCustomFieldObjectByName("RFC number")
def rfcValue = issue.getCustomFieldValue(rfcField)

String query = "SELECT codice_rfc, ambiente, dataora_iniziointervento, dataora_fineintervento," +
        "applicazione_cod, applicazione_nome, tipo_intervento, tipo_passaggio, referente_nome," +
        "referente_cognome, referente_username, referente_email, descrizione_change, stato_rfc " +
        "from [SEC_RFC].[dbo].[rfc_maininfo_extended] " +
        "where codice_rfc = ${rfcValue}"

boolean isRFCValid = false
StringBuffer buffer = new StringBuffer()

DatabaseUtil.withSql('RFCTest') { sql ->
    if(!sql){
        buffer.append("Errore: RFC Number ${codice_rfc} non è presente a sistema")
    }
    else{
        codice_rfc = sql.firstRow(query)[0] as String
        ambiente = sql.firstRow(query)[1] as String
        tipo_intervento = sql.firstRow(query)[6] as String
        tipo_passaggio = sql.firstRow(query)[7] as String
    }

}

if(""==buffer.toString())
{
    if(tipo_intervento!="Software"){
        buffer.append("Errore: RFC Number ${codice_rfc} non valido\ntipo_intervento diverso da 'Software': ${tipo_intervento}\n")
        isRFCValid = false
    }
    else if(tipo_passaggio!="Applicativo"){
        buffer.append("Errore: RFC Number ${codice_rfc} non valido\ntipo_intervento diverso da 'Applicativo': ${tipo_passaggio}\n")
        isRFCValid = false
    }
    else if(ambiente!="Prod"){
        buffer.append("Errore: RFC Number ${codice_rfc} non valido\nambiente diverso da 'Prod': ${ambiente}\n")
        isRFCValid = false
    }
    else{
        buffer.append("RFC Number è valido: ${codice_rfc}\n")
        isRFCValid = true
    }
}

commentMgr.create(issue, currentUser, buffer.toString(), true)
if(!isRFCValid){
    throw new InvalidInputException(buffer.toString())
}
