import com.atlassian.jira.web.bean.PagerFilter

import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.issue.search.SearchResults
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.user.ApplicationUser
import org.apache.log4j.Category


ApplicationUser user = ComponentAccessor.getUserManager().getUserByName('jira.bot.user')
ApplicationUser loggedUser = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()

Category logger = Category.getInstance("com.onresolve.jira.groovy")
logger.setLevel(org.apache.log4j.Level.INFO)

def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchProvider = ComponentAccessor.getComponent(SearchProvider)

CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
CustomField progettoField = customFieldManager.getCustomFieldObjectByName("Progetto")
String progettoValue = issue.getCustomFieldValue(progettoField)
CustomField waveField = customFieldManager.getCustomFieldObjectByName("Wave")
String waveValue = issue.getCustomFieldValue(waveField)


def query = jqlQueryParser.parseQuery("""issueFunction in issueFieldMatch("project = SECRM AND Progetto = '${progettoValue}' AND issuetype = '${issue.getIssueType().getName()}' AND status = Live", Wave, "${waveValue.replaceAll(/wave\d+/, '.*')}") ORDER BY 'Produzione deploy time' DESC """.toString())
SearchResults results = searchProvider.search(query, user, PagerFilter.getUnlimitedFilter())

//def i = results.getIssues().find {it.getKey() == issue.getKey()}
def index = results.getIssues().indexOf(issue)

return (index == 0)

