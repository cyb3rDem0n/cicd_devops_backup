import com.atlassian.jira.component.ComponentAccessor

customFieldManager = ComponentAccessor.customFieldManager
def customField = customFieldManager.getCustomFieldObjectByName("isRollback")
def customFieldValue = (Collection) issue.getCustomFieldValue(customField)

for(i in 0..customFieldValue.size()-1)
{
    customFieldValue.removeElement(customFieldValue.getAt(i));
}
issue.setCustomFieldValue(customField, customFieldValue)