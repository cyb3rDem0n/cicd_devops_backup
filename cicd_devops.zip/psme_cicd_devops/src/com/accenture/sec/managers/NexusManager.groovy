package com.accenture.sec.managers

import com.accenture.sec.runners.CurlRunner
import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.utils.CommonUtils


/**
 * NexusManager - class to manage Nexus integration with API
 */
class NexusManager implements Serializable {

    private def pipeline
    private String credentialsId
    private String nexusURL

    /**
     * Constructor
     *
     * @param pipeline def object
     * @param nexusURL Host URL of the Nexus service
     * @param credsId ID of the credentials saved in the credential store
     */
    NexusManager(def pipeline, String nexusURL, String credsId) {
        this.pipeline = pipeline
        this.nexusURL = nexusURL
        this.credentialsId = credsId
    }

    /**
     * Return the format of a Nexus Repository [maven2, npm, raw, ...]
     *
     * @param nexusRepoName The name of the nexus repository
     * @return
     */
    private String getRepoType(String nexusRepoName) {
        def params = [endpoint: "${this.nexusURL}/service/rest/v1/repositories", method: 'GET', acceptType: 'APPLICATION_JSON']
        def repoList = callAPI(params)
        def repo = repoList.find { it.name == nexusRepoName }
        if (repo == null) {
            throw new NexusManagerException("${nexusRepoName} is not present in Nexus ${this.nexusURL}")
        }
        return repo.format
    }


    /**
     * Upload a package specified from filePath on the nexusRepoName repository.
     * map object will contain data parameter if required, maven2 repositories require artifact GAV info to upload a package
     *
     * @param nexusRepoName Name of the repository
     * @param filePath path of the file to be uploaded
     * @param map map containing artifact info
     * @return
     */
    def upload(def nexusRepoName, def filePath, def map = null) {
        List formData = null
        def url = "${this.nexusURL}/service/rest/v1/components?repository=${nexusRepoName}"
        def repoType = getRepoType(nexusRepoName as String)
        def fileName = filePath.tokenize('/')[-1]
        def fileUrl = "${this.nexusURL}/repository/${nexusRepoName}/"
        switch (repoType) {
            case 'maven2':
                CommonUtils.checkInputParameters(map, 'groupId,artifactId,packageVersion,packaging')
                formData = [
                        "maven2.groupId=${map.groupId}",
                        "maven2.artifactId=${map.artifactId}",
                        "maven2.version=${map.packageVersion}",
                        "maven2.asset1=@${filePath}",
                        "maven2.asset1.extension=${map.packaging}"
                ]
                fileUrl += "${map.groupId.replaceAll('\\.', '/')}/${map.artifactId}/${map.packageVersion}/${map.artifactId}-${map.packageVersion}.${map.packaging}"
                break
            case 'npm':
                formData = ["npm.asset=@${filePath}"]
                fileUrl = null
                break
            case 'raw':
                map.fileName = (map.fileName ?: fileName)
                map.directory = (map.directory ?: '/')
                formData = [
                        "raw.directory=${map.directory}",
                        "raw.asset1=@${filePath}",
                        "raw.asset1.filename=${map.fileName}"
                ]
                fileUrl += "${map.directory}/${map.fileName}"
                break
            default:
                throw new NexusManagerException("${repoType} not implemented in upload function")
                break
        }
        this.pipeline.echo("Uploading ${filePath} to ${nexusRepoName} artifact with info ${map} ...")
        RunnerResult result = null
        this.pipeline.withCredentials([this.pipeline.usernameColonPassword(credentialsId: this.credentialsId, variable: 'creds')]) {
            def params = [
                    url    : url,
                    method : 'POST',
                    headers: ['Content-Type: multipart/form-data', 'Accept: application/json'],
                    form   : formData,
                    auth   : this.pipeline.env.creds
            ]
            result = (new CurlRunner(this.pipeline)).execWithStatus(params)
            if (result.exitCode > 299) {
                throw new NexusManagerException("Error uploading ${filePath} on ${this.nexusURL}/${nexusRepoName}\nResponse: ${result.toMap()}")
            }
        }
        if (fileUrl)
            return fileUrl
        return result
    }

    /**
     * ### Not working HttpRequest plugin, not supported content-type multipart/form-data ###
     * Upload a package specified from filePath on the nexusRepoName repository.
     * map object will contain data parameter if required, maven2 repositories require artifact GAV info to upload a package
     *
     * @param nexusRepoName Name of the repository
     * @param filePath path of the file to be uploaded
     * @param map map containing artifact info
     * @return
     */
    /*
    def uploadWithPlugin(def nexusRepoName, def filePath, def map = null) {
        return null
        Map formData = null
        def url = "${this.nexusURL}/service/rest/v1/components?repository=${nexusRepoName}"
        def repoType = getRepoType(nexusRepoName as String)
        def fileName = filePath.tokenize('/')[-1]
        def multipartName = null
        switch (repoType) {
            case 'maven2':
                CommonUtils.checkInputParameters(map, 'groupId,artifactId,packageVersion,packaging')
                multipartName = 'maven2.asset1'
                formData = [
                        'maven2.groupId'         : map.groupId,
                        'maven2.artifactId'      : map.artifactId,
                        'maven2.version'         : map.packageVersion,
                        'maven2.asset1'          : filePath,
                        'maven2.asset1.extension': map.packaging
                ]
                break
            case 'npm':
                multipartName = 'npm.asset'
                formData = ['npm.asset': filePath]
                break
            case 'raw':
                multipartName = 'raw.asset1'
                formData = ['raw.directory'      : map.directory ?: '/',
                            'raw.asset1'         : filePath,
                            'raw.asset1.filename': map.fileName ?: fileName
                ]
                break
            default:
                throw new NexusManagerException("${repoType} not implemented in upload function")
                break
        }
        this.pipeline.echo("Uploading ${filePath} to ${nexusRepoName} artifact with info ${map} ...")
        def params = [
                endpoint         : url,
                method           : 'POST',
                contentType      : 'APPLICATION_FORM',
                uploadFile       : filePath,
                multipartName    : multipartName,
                payload          : CommonUtils.toJson(formData),
                validOnErrorCodes: true
        ]
        def result = callAPI(params)
        return result
    }*/

    /**
     * Download a package from the repository nexusRepoName.
     *
     * @param nexusRepoName
     * @param map contain information about the package to be downloaded. Mandatory: artifactId - name of the package
     *                                                                               packageVersion - version of the package
     *                                                                               groupId - (only for maven2 repo) group of package
     *                                                                    Optional:  packaging - default jar for maven2 and tgz for npm
     * @param destFolder the destination folder. default 'package-${map.artifactId}'
     * @return
     */
    def download(def nexusRepoName, Map map, def destFolder = '.', def repoType = null) {
        def url
        repoType = (repoType ?: getRepoType(nexusRepoName as String))
//        if (!destFolder) {
//            destFolder = "."
//        }
//        else{
//            if(destFolder[0] != '/' && destFolder[0..1] != './')
//                destFolder = "./${destFolder}"
//            this.pipeline.sh("#!/bin/bash \n mkdir -p \"${destFolder}\"")
//        }
        def destFile = null
        switch (repoType) {
            case 'maven2':
                CommonUtils.checkInputParameters(map, 'groupId,artifactId,packageVersion')
                map.groupId = map.groupId.replaceAll('\\.', '/')
                map.packaging = map.packaging ?: 'jar'
                url = "${this.nexusURL}/repository/${nexusRepoName}/${map.groupId}/${map.artifactId}/${map.packageVersion}/${map.artifactId}-${map.packageVersion}.${map.packaging}"
                destFile = "${map.artifactId}-${map.packageVersion}.${map.packaging}"
                break
            case 'npm':
                CommonUtils.checkInputParameters(map, 'artifactId,packageVersion')
                map.packaging = map.packaging ?: 'tgz'
                url = "${this.nexusURL}/repository/${nexusRepoName}/${map.artifactId}/-/${map.artifactId}-${map.packageVersion}.${map.packaging}"
                destFile = "${map.artifactId}-${map.packageVersion}.${map.packaging}"
                break
            case 'raw':
                CommonUtils.checkInputParameters(map, 'directory,fileName')
                url = "${this.nexusURL}/repository/${nexusRepoName}/${map.directory}/${map.fileName}"
                destFile = "${map.fileName}"
                break
            default:
                throw new NexusManagerException("${repoType} not implemented in download function")
                break
        }
        this.pipeline.echo("Downloading from ${nexusRepoName} artifact with info ${map} to '${destFolder}/${destFile}' ...")
        this.pipeline.dir(destFolder) {
            def requestMap = [timeout: 60, endpoint: url, method: 'GET', outputFile: "./${destFile}", validOnErrorCodes: true]
            def result
            pipeline.retry(3) {
                result = callAPI(requestMap)
            }
            if (pipeline.findFiles(glob: "./${destFile}").size() > 0) {
                throw new NexusManagerException("Error downloading '${destFile}' from ${this.nexusURL}/${nexusRepoName}")
            }
        }
        return "${destFolder}/${destFile}".toString()
    }

    @Deprecated
    def download(def nexusRepoName, def map, def destFolder, def unused, def unused2) {
        CommonUtils.checkInputParameters(map, 'groupId,artifactId,packageVersion,packaging')
        map.groupId = map.groupId.replaceAll('\\.', '/')
        def url = "${this.nexusURL}/repository/${nexusRepoName}/${map.groupId}/${map.artifactId}/${map.packageVersion}/${map.artifactId}-${map.packageVersion}.${map.packaging}"
        if (!destFolder) {
            destFolder = "package-${map.artifactId}"
        }
        pipeline.withCredentials([usernameColonPassword(credentialsId: credentialsId, variable: 'creds')]) {
            pipeline.dir(destFolder) {
                pipeline.sh """#!/bin/bash -x
          curl -u ${pipeline.env.creds} -X GET '${url}' -o "${map.artifactId}-${map.packageVersion}.${map.packaging}" 2>/dev/null
        """
                if (pipeline.findFiles(glob: "${map.artifactId}-${map.packageVersion}.${map.packaging}").size() > 0) {
                    throw new NexusManagerException("ERROR: '${map.artifactId}-${map.packageVersion}.zip' not downloaded")
                }
            }

        }
        return "${destFolder}/${map.artifactId}-${map.packageVersion}.${map.packaging}"
    }

    /**
     * Function that call the Nexus API. Accept a map in input in which are defined all the options of the call
     *
     * @param params a map containing all the options. Mandatory: method - GET|POST|PUT|REMOVE
     *                                                            endpoint - endpoint of the API
     *                                                 Optional: validOnErrorCodes - string representing a range of valid codes (ex. 100:399)
     *                                                           payload - string in json format or Map containing all the data to be passed in a POST|PUT request
     *                                                           printOutput - default false. Define if the call have to print the output log
     *                                                           outputFile - path of the file that will contain the output of the request
     *
     * @return
     */
    private def callAPI(Map params) {
        CommonUtils.checkInputParameters(params, 'method,endpoint')
        String validCodes = params.validOnErrorCodes ? "100:599" : "100:399"
        def requestMap = [
                httpMode          : "${params.method ?: 'GET'}",
                ignoreSslErrors   : true,
                validResponseCodes: validCodes,
                url               : "${params.endpoint}"
        ]
        if (this.credentialsId) {
            requestMap.put('authentication', this.credentialsId)
        }
        params.acceptType && requestMap.put('acceptType', params.acceptType)
        if (params.uploadFile && params.multipartName) {
            requestMap.put('uploadFile', params.uploadFile)
            requestMap.put('multipartName', params.multipartName)
        }
        if (params.payload != null) {
            requestMap.put('contentType', (params.contentType ?: 'APPLICATION_JSON'))
            String payload = null
            if (params.payload instanceof Map) {
                payload = parsePayload(params.payload, requestMap.contentType)
            } else {
                payload = params.payload
            }
            requestMap.put('requestBody', payload)
        }
        if (!params.printOutput) {
            requestMap.put('quiet', true)
        }
        if (params.outputFile != null) {
            requestMap.put('outputFile', "${params.outputFile}")
        }
        if (params.timeout != null) {
            requestMap.put('timeout', params.timeout)
        }
        def result = pipeline.httpRequest(requestMap)
        if (result.status > 399) {
            throw new NexusManagerException("ERROR: ${result.status} - ${result.content}")
        }
        def output = (requestMap.acceptType == 'APPLICATION_JSON') ? CommonUtils.parseJson(result.content as String) : (result.content as String)
        return output
    }

    private def parsePayload(Map payload, def contentType) {
        switch (contentType) {
            case 'APPLICATION_JSON':
                return CommonUtils.toJson(payload)
            case 'APPLICATION_FORM':
                def ret = ""
                payload.eachWithIndex { it, i ->
                    ret += "${it.key}=${it.value}"
                    if (i < payload.size() - 1)
                        ret += "&"
                }
                return ret
        }
    }

    private class NexusManagerException extends Exception {
        NexusManagerException(def message) {
            super(message)
        }
    }

}
