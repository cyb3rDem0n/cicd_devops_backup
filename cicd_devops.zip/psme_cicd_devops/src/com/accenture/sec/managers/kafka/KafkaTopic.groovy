package com.accenture.sec.managers.kafka

class KafkaTopic implements Serializable {
    private String name
    private String messageDownconversionEnable
    private String fileDeleteDelayMs
    private String segmentMs
    private String minCompactionLagMs
    private String retentionBytes
    private String segmentIndexBytes
    private String cleanupPolicy
    private String followerReplicationThrottledReplicas
    private String messageTimestampDifferenceMaxMs
    private String segmentJitterMs
    private String preallocate
    private String messageTimestampType
    private String messageFormatVersion
    private String segmentBytes
    private String uncleanLeaderElectionEnable
    private String maxMessageBytes
    private String retentionMs
    private String flushMs
    private String deleteRetentionMs
    private String leaderReplicationThrottledReplicas
    private String minInsyncReplicas
    private String flushMessages
    private String compressionType
    private String indexIntervalBytes
    private String minCleanableDirtyRatio
    private String replicationFactor
    private String partitions

    public static final HashMap<String, String> topicConfigsConversionMap = [
            cleanupPolicy                       : 'cleanup.policy',
            compressionType                     : 'compression.type',
            deleteRetentionMs                   : 'delete.retention.ms',
            fileDeleteDelayMs                   : 'file.delete.delay.ms',
            flushMessages                       : 'flush.messages',
            flushMs                             : 'flush.ms',
            followerReplicationThrottledReplicas: 'follower.replication.throttled.replicas',
            indexIntervalBytes                  : 'index.interval.bytes',
            leaderReplicationThrottledReplicas  : 'leader.replication.throttled.replicas',
            maxMessageBytes                     : 'max.message.bytes',
            messageDownconversionEnable         : 'message.downconversion.enable',
            messageFormatVersion                : 'message.format.version',
            messageTimestampDifferenceMaxMs     : 'message.timestamp.difference.max.ms',
            messageTimestampType                : 'message.timestamp.type',
            minCleanableDirtyRatio              : 'min.cleanable.dirty.ratio',
            minCompactionLagMs                  : 'min.compaction.lag.ms',
            minInsyncReplicas                   : 'min.insync.replicas',
            preallocate                         : 'preallocate',
            retentionBytes                      : 'retention.bytes',
            retentionMs                         : 'retention.ms',
            segmentBytes                        : 'segment.bytes',
            segmentIndexBytes                   : 'segment.index.bytes',
            segmentJitterMs                     : 'segment.jitter.ms',
            segmentMs                           : 'segment.ms',
            uncleanLeaderElectionEnable         : 'unclean.leader.election.enable'
    ]


    @Override
    String toString(){
        StringBuffer buf = new StringBuffer("[\n")
        buf = buf.append(this.name? "name: "+this.name+"\n" :"")
                .append(this.messageDownconversionEnable? "messageDownconversionEnable: "+this.messageDownconversionEnable+"\n" :"")
                .append(this.fileDeleteDelayMs? "fileDeleteDelayMs: "+this.fileDeleteDelayMs+"\n" :"")
                .append(this.segmentMs? "segmentMs: "+this.segmentMs+"\n" :"")
                .append(this.minCompactionLagMs? "minCompactionLagMs: "+this.minCompactionLagMs+"\n" :"")
                .append(this.retentionBytes? "retentionBytes: "+this.retentionBytes+"\n" :"")
                .append(this.segmentIndexBytes? "segmentIndexBytes: "+this.segmentIndexBytes+"\n" :"")
                .append(this.cleanupPolicy? "cleanupPolicy: "+this.cleanupPolicy+"\n" :"")
                .append(this.followerReplicationThrottledReplicas? "followerReplicationThrottledReplicas: "+this.followerReplicationThrottledReplicas+"\n" :"")
                .append(this.messageTimestampDifferenceMaxMs? "messageTimestampDifferenceMaxMs: "+this.messageTimestampDifferenceMaxMs+"\n" :"")
                .append(this.segmentJitterMs? "segmentJitterMs: "+this.segmentJitterMs+"\n" :"")
                .append(this.preallocate? "preallocate: "+this.preallocate+"\n" :"")
                .append(this.messageTimestampType? "messageTimestampType: "+this.messageTimestampType+"\n" :"")
                .append(this.messageFormatVersion? "messageFormatVersion: "+this.messageFormatVersion+"\n" :"")
                .append(this.segmentBytes? "segmentBytes: "+this.segmentBytes+"\n" :"")
                .append(this.uncleanLeaderElectionEnable? "uncleanLeaderElectionEnable: "+this.uncleanLeaderElectionEnable+"\n" :"")
                .append(this.maxMessageBytes? "maxMessageBytes: "+this.maxMessageBytes+"\n" :"")
                .append(this.retentionMs? "retentionMs: "+this.retentionMs+"\n" :"")
                .append(this.flushMs? "flushMs: "+this.fileDeleteDelayMs+"\n" :"")
                .append(this.deleteRetentionMs? "deleteRetentionMs: "+this.deleteRetentionMs+"\n" :"")
                .append(this.leaderReplicationThrottledReplicas? "leaderReplicationThrottledReplicas: "+this.leaderReplicationThrottledReplicas+"\n" :"")
                .append(this.minInsyncReplicas? "minInsyncReplicas: "+this.minInsyncReplicas+"\n" :"")
                .append(this.flushMessages? "flushMessages: "+this.flushMessages+"\n" :"")
                .append(this.compressionType? "compressionType: "+this.compressionType+"\n" :"")
                .append(this.indexIntervalBytes? "indexIntervalBytes: "+this.indexIntervalBytes+"\n" :"")
                .append(this.minCleanableDirtyRatio? "minCleanableDirtyRatio: "+this.minCleanableDirtyRatio+"\n" :"")
                .append(this.replicationFactor? "replicationFactor: "+this.replicationFactor+"\n" :"")
                .append(this.partitions? "partitions: "+this.partitions+"\n" :"")
                .append("]")
        return buf.toString()
    }

    KafkaTopic(String topicName){
        if (topicName != null && ""!=topicName){
            this.name = topicName
            this.messageDownconversionEnable = "true"
            this.fileDeleteDelayMs="60000"
            this.segmentMs="604800000"
            this.minCompactionLagMs="0"
            this.retentionBytes="-1"
            this.segmentIndexBytes="10485760"
            this.cleanupPolicy="delete"
            this.followerReplicationThrottledReplicas=""
            this.messageTimestampDifferenceMaxMs="9223372036854775807"
            this.segmentJitterMs="0"
            this.preallocate="false"
            this.messageTimestampType="CreateTime"
            this.messageFormatVersion="2.1-IV2"
            this.segmentBytes="1073741824"
            this.uncleanLeaderElectionEnable="false"
            this.maxMessageBytes="1000012"
            this.retentionMs="604800000"
            this.flushMs="9223372036854775807"
            this.deleteRetentionMs="86400000"
            this.leaderReplicationThrottledReplicas=""
            this.minInsyncReplicas="1"
            this.flushMessages="9223372036854775807"
            this.compressionType="producer"
            this.indexIntervalBytes="4096"
            this.minCleanableDirtyRatio="0.5"
            this.replicationFactor="3"
            this.partitions="1"
        }
    }

    String getReplicationFactor() {
        return replicationFactor
    }

    void setReplicationFactor(String replicationFactor) {
        //Parametro non modificabile
        this.replicationFactor = 3
        //replicationFactor
    }

    String getPartitions() {
        return partitions
    }

    void setPartitions(String partitions) {
        this.partitions = partitions
    }

    String getName() {
        return name
    }

    void setName(String name) {
        this.name = name
    }

    String getCleanupPolicy() {
        return cleanupPolicy
    }

    void setCleanupPolicy(String cleanupPolicy) {
        this.cleanupPolicy = cleanupPolicy
    }

    String getCompressionType() {
        return compressionType
    }

    void setCompressionType(String compressionType) {
        this.compressionType = compressionType
    }

    String getDeleteRetentionMs() {
        return deleteRetentionMs
    }

    void setDeleteRetentionMs(String deleteRetentionMs) {
        this.deleteRetentionMs = deleteRetentionMs
    }

    String getFileDeleteDelayMs() {
        return fileDeleteDelayMs
    }

    void setFileDeleteDelayMs(String fileDeleteDelayMs) {
        this.fileDeleteDelayMs = fileDeleteDelayMs
    }

    String getFlushMessages() {
        return flushMessages
    }

    void setFlushMessages(String flushMessages) {
        this.flushMessages = flushMessages
    }

    String getFlushMs() {
        return flushMs
    }

    void setFlushMs(String flushMs) {
        this.flushMs = flushMs
    }

    String getFollowerReplicationThrottledReplicas() {
        return followerReplicationThrottledReplicas
    }

    void setFollowerReplicationThrottledReplicas(String followerReplicationThrottledReplicas) {
        this.followerReplicationThrottledReplicas = followerReplicationThrottledReplicas
    }

    String getIndexIntervalBytes() {
        return indexIntervalBytes
    }

    void setIndexIntervalBytes(String indexIntervalBytes) {
        this.indexIntervalBytes = indexIntervalBytes
    }

    String getLeaderReplicationThrottledReplicas() {
        return leaderReplicationThrottledReplicas
    }

    void setLeaderReplicationThrottledReplicas(String leaderReplicationThrottledReplicas) {
        this.leaderReplicationThrottledReplicas = leaderReplicationThrottledReplicas
    }

    String getMaxMessageBytes() {
        return maxMessageBytes
    }

    void setMaxMessageBytes(String maxMessageBytes) {
        this.maxMessageBytes = maxMessageBytes
    }

    String getMessageDownconversionEnable() {
        return messageDownconversionEnable
    }

    void setMessageDownconversionEnable(String messageDownconversionEnable) {
        this.messageDownconversionEnable = messageDownconversionEnable
    }

    String getMessageFormatVersion() {
        return messageFormatVersion
    }

    void setMessageFormatVersion(String messageFormatVersion) {
        this.messageFormatVersion = messageFormatVersion
    }

    String getMessageTimestampDifferenceMaxMs() {
        return messageTimestampDifferenceMaxMs
    }

    void setMessageTimestampDifferenceMaxMs(String messageTimestampDifferenceMaxMs) {
        this.messageTimestampDifferenceMaxMs = messageTimestampDifferenceMaxMs
    }

    String getMessageTimestampType() {
        return messageTimestampType
    }

    void setMessageTimestampType(String messageTimestampType) {
        this.messageTimestampType = messageTimestampType
    }

    String getMinCleanableDirtyRatio() {
        return minCleanableDirtyRatio
    }

    void setMinCleanableDirtyRatio(String minCleanableDirtyRatio) {
        this.minCleanableDirtyRatio = minCleanableDirtyRatio
    }

    String getMinCompactionLagMs() {
        return minCompactionLagMs
    }

    void setMinCompactionLagMs(String minCompactionLagMs) {
        this.minCompactionLagMs = minCompactionLagMs
    }

    String getMinInsyncReplicas() {
        return minInsyncReplicas
    }

    void setMinInsyncReplicas(String minInsyncReplicas) {
        this.minInsyncReplicas = minInsyncReplicas
    }

    String getPreallocate() {
        return preallocate
    }

    void setPreallocate(String preallocate) {
        this.preallocate = preallocate
    }

    String getRetentionBytes() {
        return retentionBytes
    }

    void setRetentionBytes(String retentionBytes) {
        this.retentionBytes = retentionBytes
    }

    String getRetentionMs() {
        return retentionMs
    }

    void setRetentionMs(String retentionMs) {
        this.retentionMs = retentionMs
    }

    String getSegmentBytes() {
        return segmentBytes
    }

    void setSegmentBytes(String segmentBytes) {
        this.segmentBytes = segmentBytes
    }

    String getSegmentIndexBytes() {
        return segmentIndexBytes
    }

    void setSegmentIndexBytes(String segmentIndexBytes) {
        this.segmentIndexBytes = segmentIndexBytes
    }

    String getSegmentJitterMs() {
        return segmentJitterMs
    }

    void setSegmentJitterMs(String segmentJitterMs) {
        this.segmentJitterMs = segmentJitterMs
    }

    String getSegmentMs() {
        return segmentMs
    }

    void setSegmentMs(String segmentMs) {
        this.segmentMs = segmentMs
    }

    String getUncleanLeaderElectionEnable() {
        return uncleanLeaderElectionEnable
    }

    void setUncleanLeaderElectionEnable(String uncleanLeaderElectionEnable) {
        this.uncleanLeaderElectionEnable = uncleanLeaderElectionEnable
    }

    ArrayList<TopicConfigProperty> getConfigChanged(def config, String partitions) {

        ArrayList<TopicConfigProperty> changelist = new ArrayList<>()
        TopicConfigProperty configProperty

        if(config!=null && config.configs!=null){
            /*Riduzione delle partizioni del topic NON supportato da kafka*/
            if (this.partitions!= null && Integer.parseInt(this.partitions) > Integer.parseInt(partitions)) {
                configProperty = new TopicConfigProperty()
                configProperty.setName("partitions")
                configProperty.setValue(this.partitions)
                changelist.add(configProperty)
            }

            if (this.messageDownconversionEnable!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("messageDownconversionEnable"))}""" && this.messageDownconversionEnable != """${config.configs.get(topicConfigsConversionMap.get("messageDownconversionEnable"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("messageDownconversionEnable")
                configProperty.setValue(this.messageDownconversionEnable)
                changelist.add(configProperty)
            }

            if (this.fileDeleteDelayMs!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("fileDeleteDelayMs"))}""" && this.fileDeleteDelayMs != """${config.configs.get(topicConfigsConversionMap.get("fileDeleteDelayMs"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("fileDeleteDelayMs")
                configProperty.setValue(this.fileDeleteDelayMs)
                changelist.add(configProperty)
            }

            if (this.segmentMs!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("segmentMs"))}""" && this.segmentMs != """${config.configs.get(topicConfigsConversionMap.get("segmentMs"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("segmentMs")
                configProperty.setValue(this.segmentMs)
                changelist.add(configProperty)
            }

            if (this.minCompactionLagMs!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("minCompactionLagMs"))}""" && this.minCompactionLagMs != """${config.configs.get(topicConfigsConversionMap.get("minCompactionLagMs"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("minCompactionLagMs")
                configProperty.setValue(this.minCompactionLagMs)
                changelist.add(configProperty)
            }

            if (this.retentionBytes!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("retentionBytes"))}""" && this.retentionBytes != """${config.configs.get(topicConfigsConversionMap.get("retentionBytes"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("retentionBytes")
                configProperty.setValue(this.retentionBytes)
                changelist.add(configProperty)
            }

            if (this.segmentIndexBytes!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("segmentIndexBytes"))}""" && this.segmentIndexBytes != """${config.configs.get(topicConfigsConversionMap.get("segmentIndexBytes"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("segmentIndexBytes")
                configProperty.setValue(this.segmentIndexBytes)
                changelist.add(configProperty)
            }

            if (this.cleanupPolicy!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("cleanupPolicy"))}""" && this.cleanupPolicy != """${config.configs.get(topicConfigsConversionMap.get("cleanupPolicy"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("cleanupPolicy")
                configProperty.setValue(this.cleanupPolicy)
                changelist.add(configProperty)
            }

            if (this.followerReplicationThrottledReplicas!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("followerReplicationThrottledReplicas"))}""" && this.followerReplicationThrottledReplicas != """${config.configs.get(topicConfigsConversionMap.get("followerReplicationThrottledReplicas"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("followerReplicationThrottledReplicas")
                configProperty.setValue(this.followerReplicationThrottledReplicas)
                changelist.add(configProperty)
            }

            if (this.messageTimestampDifferenceMaxMs!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("messageTimestampDifferenceMaxMs"))}""" && this.messageTimestampDifferenceMaxMs != """${config.configs.get(topicConfigsConversionMap.get("messageTimestampDifferenceMaxMs"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("messageTimestampDifferenceMaxMs")
                configProperty.setValue(this.messageTimestampDifferenceMaxMs)
                changelist.add(configProperty)
            }

            if (this.segmentJitterMs!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("segmentJitterMs"))}""" && this.segmentJitterMs != """${config.configs.get(topicConfigsConversionMap.get("segmentJitterMs"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("segmentJitterMs")
                configProperty.setValue(this.segmentJitterMs)
                changelist.add(configProperty)
            }


            if (this.preallocate!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("preallocate"))}""" && this.preallocate != """${config.configs.get(topicConfigsConversionMap.get("preallocate"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("preallocate")
                configProperty.setValue(this.preallocate)
                changelist.add(configProperty)
            }
            if (this.messageTimestampType!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("messageTimestampType"))}""" && this.messageTimestampType != """${config.configs.get(topicConfigsConversionMap.get("messageTimestampType"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("messageTimestampType")
                configProperty.setValue(this.messageTimestampType)
                changelist.add(configProperty)
            }

            if (this.messageFormatVersion!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("messageFormatVersion"))}""" && this.messageFormatVersion != """${config.configs.get(topicConfigsConversionMap.get("messageFormatVersion"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("messageFormatVersion")
                configProperty.setValue(this.messageFormatVersion)
                changelist.add(configProperty)
            }

            if (this.segmentBytes!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("segmentBytes"))}""" && this.segmentBytes != """${config.configs.get(topicConfigsConversionMap.get("segmentBytes"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("segmentBytes")
                configProperty.setValue(this.segmentBytes)
                changelist.add(configProperty)
            }

            if (this.uncleanLeaderElectionEnable!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("uncleanLeaderElectionEnable"))}""" && this.uncleanLeaderElectionEnable != """${config.configs.get(topicConfigsConversionMap.get("uncleanLeaderElectionEnable"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("uncleanLeaderElectionEnable")
                configProperty.setValue(this.uncleanLeaderElectionEnable)
                changelist.add(configProperty)
            }

            if (this.maxMessageBytes!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("maxMessageBytes"))}""" && this.maxMessageBytes != """${config.configs.get(topicConfigsConversionMap.get("maxMessageBytes"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("maxMessageBytes")
                configProperty.setValue(this.maxMessageBytes)
                changelist.add(configProperty)
            }

            if (this.retentionMs!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("retentionMs"))}""" && this.retentionMs != """${config.configs.get(topicConfigsConversionMap.get("retentionMs"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("retentionMs")
                configProperty.setValue(this.retentionMs)
                changelist.add(configProperty)
            }

            if (this.flushMs!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("flushMs"))}""" && this.flushMs != """${config.configs.get(topicConfigsConversionMap.get("flushMs"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("flushMs")
                configProperty.setValue(this.flushMs)
                changelist.add(configProperty)
            }

            if (this.deleteRetentionMs!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("deleteRetentionMs"))}""" && this.deleteRetentionMs != """${config.configs.get(topicConfigsConversionMap.get("deleteRetentionMs"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("deleteRetentionMs")
                configProperty.setValue(this.deleteRetentionMs)
                changelist.add(configProperty)
            }

            if (this.leaderReplicationThrottledReplicas!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("leaderReplicationThrottledReplicas"))}""" && this.leaderReplicationThrottledReplicas != """${config.configs.get(topicConfigsConversionMap.get("leaderReplicationThrottledReplicas"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("leaderReplicationThrottledReplicas")
                configProperty.setValue(this.leaderReplicationThrottledReplicas)
                changelist.add(configProperty)
            }

            if (this.minInsyncReplicas!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("minInsyncReplicas"))}""" && this.minInsyncReplicas != """${config.configs.get(topicConfigsConversionMap.get("minInsyncReplicas"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("minInsyncReplicas")
                configProperty.setValue(this.minInsyncReplicas)
                changelist.add(configProperty)
            }

            if (this.flushMessages!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("flushMessages"))}""" && this.flushMessages != """${config.configs.get(topicConfigsConversionMap.get("flushMessages"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("flushMessages")
                configProperty.setValue(this.flushMessages)
                changelist.add(configProperty)
            }

            if (this.compressionType!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("compressionType"))}""" && this.compressionType != """${config.configs.get(topicConfigsConversionMap.get("compressionType"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("compressionType")
                configProperty.setValue(this.compressionType)
                changelist.add(configProperty)
            }

            if (this.indexIntervalBytes!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("indexIntervalBytes"))}""" && this.indexIntervalBytes != """${config.configs.get(topicConfigsConversionMap.get("indexIntervalBytes"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("indexIntervalBytes")
                configProperty.setValue(this.indexIntervalBytes)
                changelist.add(configProperty)
            }

            if (this.minCleanableDirtyRatio!= null && ""!="""${config.configs.get(topicConfigsConversionMap.get("minCleanableDirtyRatio"))}""" && this.minCleanableDirtyRatio != """${config.configs.get(topicConfigsConversionMap.get("minCleanableDirtyRatio"))}""") {
                configProperty = new TopicConfigProperty()
                configProperty.setName("minCleanableDirtyRatio")
                configProperty.setValue(this.minCleanableDirtyRatio)
                changelist.add(configProperty)
            }
        }
        
        return changelist
    }

}
