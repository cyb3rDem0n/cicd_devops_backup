package com.accenture.sec.managers.kafka

class TopicConfigProperty implements Serializable {
    String name
    String value

    String getName() {
        return name
    }

    void setName(String name) {
        this.name = name
    }

    String getValue() {
        return value
    }

    void setValue(String value) {
        this.value = value
    }

    @Override
    String toString(){
        return "[ \nproperty name: "+(this.name == null? "":this.name)+"\nproperty value: "+(this.value == null? "":this.value)+"\n]"
    }
}
