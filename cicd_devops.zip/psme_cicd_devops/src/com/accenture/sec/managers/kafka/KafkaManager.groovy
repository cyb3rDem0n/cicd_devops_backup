package com.accenture.sec.managers.kafka

import com.accenture.sec.runners.CurlRunner
import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.runners.ShRunner
import com.accenture.sec.utils.CommonUtils


class KafkaManager implements Serializable {

    private def pipeline

    private String restProxyCredsId
    private String brokerCredsId
    private String restProxy
    private String broker
    private String zookeeper
    private String topicPrefix = ""
    private boolean restProxySkipCAcert = false
    private boolean restProxySkipSSL = false
    private boolean brokerSkipSSL = false
    private boolean restProxySkipBasicAuth = false
    private boolean brokerSkipBasicAuth = false
    private CurlRunner curlRunner
    private ShRunner shRunner

    private static enum KAFKA_OPER {CREATE, ALTER, DELETE}

    private static String[] clientPropertiesTemplate = ["""sasl.mechanism=PLAIN
ssl.truststore.location=#KEYSTORE_PATH#
ssl.truststore.password=#KEYSTORE_PASSWORD#
ssl.keystore.location=#KEYSTORE_PATH#
ssl.keystore.password=#KEYSTORE_PASSWORD#
security.protocol=SASL_SSL
sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username="#KAFKA_USER#" password="#KAFKA_PASSWORD#";
   """,
                                                 """sasl.mechanism=PLAIN
security.protocol=SASL
sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username="#KAFKA_USER#" password="#KAFKA_PASSWORD#";
   """,
    ]

    private static String[] topicOperations = [
            "kafka-topics.sh --bootstrap-server #BK_URL# --create --topic #TOPIC_NAME# --partitions #PARTITIONS# --replication-factor #REPL_FACTOR# #CONFIGS# --command-config #CMD_CFG#",
            "kafka-topics.sh --bootstrap-server #BK_URL# --create --topic #TOPIC_NAME# --partitions #PARTITIONS# --replication-factor #REPL_FACTOR# #CONFIGS#",
            "kafka-topics.sh --zookeeper #ZK_URL# --alter --topic #TOPIC_NAME# #CONFIGS#  --command-config #CMD_CFG#",
            "kafka-topics.sh --zookeeper #ZK_URL# --alter --topic #TOPIC_NAME# #CONFIGS#",
            "kafka-topics.sh --bootstrap-server #BK_URL# --delete --topic #TOPIC_NAME#  --command-config #CMD_CFG#",
            "kafka-topics.sh --bootstrap-server #BK_URL# --delete --topic #TOPIC_NAME#"
        ]

    KafkaManager(def pipeline, def kafkaConfig) {
        if(pipeline){
            this.pipeline = pipeline
            this.restProxy = kafkaConfig.restProxy.url
            this.restProxyCredsId = kafkaConfig.restProxy.credsId
            this.brokerCredsId = kafkaConfig.broker.credsId
            this.broker = kafkaConfig.broker.url
            this.zookeeper = kafkaConfig.zookeeper.url
            this.topicPrefix = kafkaConfig.envForDeploy == null ? "" : "${kafkaConfig.envForDeploy}"
            this.restProxySkipSSL = kafkaConfig.restProxy.get('skipSSL', false).toBoolean()
            this.restProxySkipCAcert = kafkaConfig.restProxy.get('skipCAcert', false).toBoolean()
            this.brokerSkipSSL = kafkaConfig.broker.get('skipSSL', false).toBoolean()
            this.restProxySkipBasicAuth = kafkaConfig.restProxy.get('skipBasicAuth', false).toBoolean()
            this.brokerSkipBasicAuth = kafkaConfig.broker.get('skipBasicAuth', false).toBoolean()
            this.curlRunner = new CurlRunner(pipeline)
            this.shRunner = new ShRunner(pipeline)
        }
        else{
            StringBuffer buf = new StringBuffer()
            buf = buf.append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore!\nL'oggetto pipeline passato al KafkaManager è NULL!")
                    .append(CommonUtils.hrSeparator).append("\n")
            pipeline.echo "${buf.toString()}"
            pipeline.error()
        }

    }

    private isKafkaCliAuthenticated(){
        return (this.brokerSkipBasicAuth == false || this.brokerSkipSSL == false)
    }

    static int getClientPropertiesTemplate(boolean skipBA, boolean skipSSL ){
        int index = -1
        if(!skipBA && !skipSSL) index = 0
        if(skipSSL && !skipBA) index = 1
        return index
    }

    void initSecurity(){
        String clientProperties = clientPropertiesTemplate[getClientPropertiesTemplate(this.brokerSkipBasicAuth, this.brokerSkipSSL)]
        if(!this.brokerSkipBasicAuth) {
            if (this.brokerCredsId != null && "" == this.brokerCredsId) {
                StringBuffer buf = new StringBuffer()
                buf = buf.append(CommonUtils.hrSeparator).append("\n")
                        .append("\nErrore!\nLa configurazione devops prevede basic authentication per i broker kafka ma non e' configurata la chiave per recuperare le credenziali su Jenkins")
                        .append(CommonUtils.hrSeparator).append("\n")
                this.pipeline.echo "${buf.toString()}"
                this.pipeline.error()
            }
            this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: this.brokerCredsId, passwordVariable: 'kafkaPassword', usernameVariable: 'kafkaUser')]) {
                    clientProperties = clientProperties.replaceAll("#KAFKA_USER#", "${this.pipeline.env.kafkaUser}")
                            .replaceAll("#KAFKA_PASSWORD#", "${this.pipeline.env.kafkaPassword}")

                    this.pipeline.writeFile(file: "${this.pipeline.WORKSPACE}/client.properties", text: "${clientProperties}")
            }

        }
        if(!this.brokerSkipSSL) {
            if (this.brokerCredsId != null && "" == this.brokerCredsId) {
                StringBuffer buf = new StringBuffer()
                buf = buf.append(CommonUtils.hrSeparator).append("\n")
                        .append("Errore!\nLa configurazione devops prevede l'autenticazione sul keystore per i broker kafka ma non e' configurata la chiave per recuperare le credenziali su Jenkins")
                        .append(CommonUtils.hrSeparator).append("\n")
                this.pipeline.echo "${buf.toString()}"
                this.pipeline.error()
            }
            this.pipeline.withCredentials([this.pipeline.string(credentialsId: 'keystore_password', variable: 'keystorePassword')]) {
                clientProperties = clientProperties.replaceAll("#KEYSTORE_PATH#", "${this.pipeline.env.KEYSTORE_PATH}")
                        .replaceAll("#KEYSTORE_PASSWORD#", "${this.pipeline.env.keystorePassword}")

                this.pipeline.writeFile(file: "${this.pipeline.WORKSPACE}/client.properties", text: "${clientProperties}")
            }
        }
    }

    /**
     * CHIAMATE AI SERVIZI DEL KAFKA ZOOKEEPER
     * */
    void createTopic(KafkaTopic kafkaTopic) {
        if(kafkaTopic!=null){
            if(kafkaTopic.getName().startsWith(topicPrefix)){
                StringBuffer configs = new StringBuffer()
                configs = kafkaTopic.getMessageDownconversionEnable() != null && ""!=kafkaTopic.getMessageDownconversionEnable() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("messageDownconversionEnable")).append("=").append(kafkaTopic.getMessageDownconversionEnable()) : configs
                configs = kafkaTopic.getFileDeleteDelayMs() != null && ""!=kafkaTopic.getFileDeleteDelayMs() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("fileDeleteDelayMs")).append("=").append(kafkaTopic.getFileDeleteDelayMs()) : configs
                configs = kafkaTopic.getSegmentMs() != null && ""!=kafkaTopic.getSegmentMs() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("segmentMs")).append("=").append(kafkaTopic.getSegmentMs()) : configs
                configs = kafkaTopic.getMinCompactionLagMs() != null && ""!=kafkaTopic.getMinCompactionLagMs() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("minCompactionLagMs")).append("=").append(kafkaTopic.getMinCompactionLagMs()) : configs
                configs = kafkaTopic.getRetentionBytes() != null && ""!=kafkaTopic.getRetentionBytes() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("retentionBytes")).append("=").append(kafkaTopic.getRetentionBytes()) : configs
                configs = kafkaTopic.getSegmentIndexBytes() != null && ""!=kafkaTopic.getSegmentIndexBytes() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("segmentIndexBytes")).append("=").append(kafkaTopic.getSegmentIndexBytes()) : configs
                configs = kafkaTopic.getCleanupPolicy() != null && ""!=kafkaTopic.getCleanupPolicy() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("cleanupPolicy")).append("=").append(kafkaTopic.getCleanupPolicy()) : configs
                configs = kafkaTopic.getFollowerReplicationThrottledReplicas() != null && ""!=kafkaTopic.getFollowerReplicationThrottledReplicas() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("followerReplicationThrottledReplicas")).append("=").append(kafkaTopic.getFollowerReplicationThrottledReplicas()) : configs
                configs = kafkaTopic.getMessageTimestampDifferenceMaxMs() != null && ""!=kafkaTopic.getMessageTimestampDifferenceMaxMs() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("messageTimestampDifferenceMaxMs")).append("=").append(kafkaTopic.getMessageTimestampDifferenceMaxMs()) : configs
                configs = kafkaTopic.getSegmentJitterMs() != null && ""!=kafkaTopic.getSegmentJitterMs() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("segmentJitterMs")).append("=").append(kafkaTopic.getSegmentJitterMs()) : configs
                configs = kafkaTopic.getPreallocate() != null && ""!=kafkaTopic.getPreallocate() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("preallocate")).append("=").append(kafkaTopic.getPreallocate()) : configs
                configs = kafkaTopic.getMessageTimestampType() != null && ""!=kafkaTopic.getMessageTimestampType() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("messageTimestampType")).append("=").append(kafkaTopic.getMessageTimestampType()) : configs
                configs = kafkaTopic.getMessageFormatVersion() != null && ""!=kafkaTopic.getMessageFormatVersion() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("messageFormatVersion")).append("=").append(kafkaTopic.getMessageFormatVersion()) : configs
                configs = kafkaTopic.getSegmentBytes() != null && ""!=kafkaTopic.getSegmentBytes() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("segmentBytes")).append("=").append(kafkaTopic.getSegmentBytes()) : configs
                configs = kafkaTopic.getUncleanLeaderElectionEnable() != null && ""!=kafkaTopic.getUncleanLeaderElectionEnable() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("uncleanLeaderElectionEnable")).append("=").append(kafkaTopic.getUncleanLeaderElectionEnable()) : configs
                configs = kafkaTopic.getMaxMessageBytes() != null && ""!=kafkaTopic.getMaxMessageBytes() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("maxMessageBytes")).append("=").append(kafkaTopic.getMaxMessageBytes()) : configs
                configs = kafkaTopic.getRetentionMs() != null && ""!=kafkaTopic.getRetentionMs() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("retentionMs")).append("=").append(kafkaTopic.getRetentionMs()) : configs
                configs = kafkaTopic.getFlushMs() != null && ""!=kafkaTopic.getFlushMs() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("flushMs")).append("=").append(kafkaTopic.getFlushMs()) : configs
                configs = kafkaTopic.getDeleteRetentionMs() != null && ""!=kafkaTopic.getDeleteRetentionMs() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("deleteRetentionMs")).append("=").append(kafkaTopic.getDeleteRetentionMs()) : configs
                configs = kafkaTopic.getLeaderReplicationThrottledReplicas() != null && ""!=kafkaTopic.getLeaderReplicationThrottledReplicas() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("leaderReplicationThrottledReplicas")).append("=").append(kafkaTopic.getLeaderReplicationThrottledReplicas()) : configs
                configs = kafkaTopic.getMinInsyncReplicas() != null && ""!=kafkaTopic.getMinInsyncReplicas() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("minInsyncReplicas")).append("=").append(kafkaTopic.getMinInsyncReplicas()) : configs
                configs = kafkaTopic.getFlushMessages() != null && ""!=kafkaTopic.getFlushMessages() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("flushMessages")).append("=").append(kafkaTopic.getFlushMessages()) : configs
                configs = kafkaTopic.getCompressionType() != null && ""!=kafkaTopic.getCompressionType() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("compressionType")).append("=").append(kafkaTopic.getCompressionType()) : configs
                configs = kafkaTopic.getIndexIntervalBytes() != null && ""!=kafkaTopic.getIndexIntervalBytes() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("indexIntervalBytes")).append("=").append(kafkaTopic.getIndexIntervalBytes()) : configs
                configs = kafkaTopic.getMessageDownconversionEnable() != null && ""!=kafkaTopic.getMessageDownconversionEnable() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("messageDownconversionEnable")).append("=").append(kafkaTopic.getMessageDownconversionEnable()) : configs
                configs = kafkaTopic.getMinCleanableDirtyRatio() != null && ""!=kafkaTopic.getMinCleanableDirtyRatio() ? configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get("minCleanableDirtyRatio")).append("=").append(kafkaTopic.getMinCleanableDirtyRatio()) : configs

/*                this.pipeline.echo "####################################################################"
                this.pipeline.sh"ls -la ${this.pipeline.WORKSPACE}"
                this.pipeline.echo "####################################################################"*/

                RunnerResult result = callKafkaCli(KAFKA_OPER.CREATE, [kafkaTopic: kafkaTopic, configs: configs])
                if(result == null){
                    StringBuffer buf = new StringBuffer()
                    buf = buf.append(CommonUtils.hrSeparator).append("\n")
                            .append("Errore! La chiamata a kafka-cli ha restituito un risultato NULLO.\n")
                            .append("Parametri: \ntopic").append(kafkaTopic.toString()).append("\nconfigs:\n"+"$configs\n")
                            .append(CommonUtils.hrSeparator).append("\n")
                    this.pipeline.echo"${buf.toString()}"
                    this.pipeline.error()
                }
                if(result.exitCode!=0){
                    StringBuffer buf = new StringBuffer()
                    buf = buf.append(CommonUtils.hrSeparator).append("\n")
                            .append("Errore! Richiesta di creazione del topic con kafka-cli (tool: kafka-topics.sh) fallita per il topic ${kafkaTopic.getName()}\n")
                            .append("kafka-topics.sh exit code: ").append(result.exitCode).append("\n")
                            .append("kafka-topics.sh output: ").append(result.out).append("\n")
                            .append("kafka-topics.sh err: ").append(result.err).append("\n")
                            .append(CommonUtils.hrSeparator).append("\n")
                    this.pipeline.echo"${buf.toString()}"
                    this.pipeline.error()
                }
            }
        }
    }


    void alterTopic(KafkaTopic topic, ArrayList<TopicConfigProperty> propertyList) {
        StringBuffer configs = new StringBuffer()
        for (TopicConfigProperty property : propertyList) {
            if (property.getName() == "partitions") {
                this.pipeline.echo"${property.getName()}: ${property.getValue()}"
                configs.append(" --partitions ").append(property.getValue())
            }
            else configs.append(" --config ").append(KafkaTopic.topicConfigsConversionMap.get(property.getName())).append("=").append(property.getValue())
        }
/*        this.pipeline.echo "####################################################################"
        this.pipeline.sh"ls -la ${this.pipeline.WORKSPACE}"
        this.pipeline.echo "####################################################################"*/
        //this.pipeline.echo "CONFIGS:\n${configs.toString()}"
        RunnerResult result = callKafkaCli(KAFKA_OPER.ALTER, [kafkaTopic: topic, topicName: topic.getName(), configs: configs])
        if(result == null){
            StringBuffer buf = new StringBuffer()
            buf = buf.append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore! La chiamata a kafka-cli ha restituito un risultato NULLO.\n")
                    .append("Parametri: \ntopic name").append(topic.getName()).append("\nconfigs:\n"+"$configs\n")
                    .append(CommonUtils.hrSeparator).append("\n")
            this.pipeline.echo"${buf.toString()}"
            this.pipeline.error()
        }
        if(result.exitCode!=0){
            StringBuffer buf = new StringBuffer()
            buf = buf.append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore! Richiesta di variazione parametri del topic con kafka-cli (tool: kafka-topics.sh) fallita per il topic ${topic.getName()}}\n")
                    .append("kafka-topics.sh exit code: ").append(result.exitCode).append("\n")
                    .append("kafka-topics.sh output: ").append(result.out).append("\n")
                    .append("kafka-topics.sh err: ").append(result.err).append("\n")
                    .append(CommonUtils.hrSeparator).append("\n")
            this.pipeline.echo"${buf.toString()}"
            this.pipeline.error()
        }
    }

    void deleteTopic(String topicName) {

/*        this.pipeline.echo "####################################################################"
        this.pipeline.sh"ls -la ${this.pipeline.WORKSPACE}"
        this.pipeline.echo "####################################################################"*/
        //this.pipeline.echo "CONFIGS:\n${configs.toString()}"
        RunnerResult result = callKafkaCli(KAFKA_OPER.DELETE, [topicName: topicName])
        if(result == null){
            StringBuffer buf = new StringBuffer()
            buf = buf.append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore! La chiamata a kafka-cli ha restituito un risultato NULLO.\n")
                    .append("Parametri: \ntopic name\n").append(topicName)
                    .append(CommonUtils.hrSeparator).append("\n")
            this.pipeline.echo"${buf.toString()}"
            this.pipeline.error()
        }
        if(result.exitCode!=0){
            StringBuffer buf = new StringBuffer()
            buf = buf.append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore! Richiesta di elimninazione del topic con kafka-cli (tool: kafka-topics.sh) fallita per il topic ${topicName}}\n")
                    .append("kafka-topics.sh exit code: ").append(result.exitCode).append("\n")
                    .append("kafka-topics.sh output: ").append(result.out).append("\n")
                    .append("kafka-topics.sh err: ").append(result.err).append("\n")
                    .append(CommonUtils.hrSeparator).append("\n")
            this.pipeline.echo"${buf.toString()}"
            this.pipeline.error()
        }
    }

    /**
     * CHIAMATE AI SERVIZI DEL KAFKA REST PROXY
     * */
    List<String> listTopics() {
        RunnerResult result
        if(!this.restProxySkipBasicAuth) {
            if (this.restProxyCredsId != null && "" == this.restProxyCredsId) {
                StringBuffer buf = new StringBuffer()
                buf = buf.append(CommonUtils.hrSeparator).append("\n")
                        .append("Errore nel recupero della lista dei topic!\nLa configurazione devops prevede basic authentication ma non e' configurata la chiave per recuperare le credenziali su Jenkins")
                        .append(CommonUtils.hrSeparator).append("\n")
                this.pipeline.echo "${buf.toString()}"
                this.pipeline.error()
            }
            this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: this.restProxyCredsId, passwordVariable: 'password', usernameVariable: 'user')]) {
                if(!this.restProxySkipCAcert) {
                    if(!this.restProxySkipSSL){
                        result = this.curlRunner.execWithStatus([
                                url: "${this.restProxy}/topics",
                                method: "GET",
                                auth: "${this.pipeline.env.user}:${this.pipeline.env.password}",
                                cacert: "${this.pipeline.env.SEC_CA_CRT}"
                        ])
                    }
                    else{
                        result = this.curlRunner.execWithStatus([
                                url: "${this.restProxy}/topics",
                                method: "GET",
                                auth: "${this.pipeline.env.user}:${this.pipeline.env.password}",
                                cacert: "${this.pipeline.env.SEC_CA_CRT}",
                                skipSSL: true
                        ])
                    }
                }

            }

        }
        else if(!this.restProxySkipCAcert) {
            if(!this.restProxySkipSSL){
                result = this.curlRunner.execWithStatus([
                        url: "${this.restProxy}/topics",
                        method: "GET",
                        cacert: "${this.pipeline.env.SEC_CA_CRT}"
                ])
            }
            else{
                result = this.curlRunner.execWithStatus([
                        url: "${this.restProxy}/topics",
                        method: "GET",
                        cacert: "${this.pipeline.env.SEC_CA_CRT}",
                        skipSSL: true
                ])
            }
        }
        else {
            result = this.curlRunner.execWithStatus([
                    url: "${this.restProxy}/topics",
                    method: "GET"
            ])
        }

        if(result.exitCode!=200){
            StringBuffer buf = new StringBuffer()
            buf = buf.append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore! Richiesta della lista dei topic al Rest proxy Kafka fallita (${this.restProxy}/topics)\n")
                    .append("cURL exit code: ").append(result.exitCode).append("\n")
                    .append("cURL output: ").append(result.out).append("\n")
                    .append("cURL err: ").append(result.err).append("\n")
                    .append(CommonUtils.hrSeparator).append("\n")
            this.pipeline.echo"${buf.toString()}"
            this.pipeline.error()
        }

        String res = result.out
        this.pipeline.echo("RES1 ${res}")

        res = res.substring(1, res.length()-1).replaceAll("\"", "")
        this.pipeline.echo("RES2 ${res}")
        List<String> generalList = res.split(",")
        List<String> topicsSubset = new ArrayList<>()



        this.pipeline.echo("generalList ${generalList}")
        for(String s: generalList){
            if(""!=this.topicPrefix){
                if(s.startsWith(this.topicPrefix)){
                    topicsSubset.add(s)
                }
            }
        }
        this.pipeline.echo("topicsSubset ${topicsSubset}")
        return topicsSubset
    }

    def getTopicConfig(String topicName) {
        RunnerResult result
        if(!this.restProxySkipBasicAuth){
            if(this.restProxyCredsId!=null && ""==this.restProxyCredsId){
                StringBuffer buf = new StringBuffer()
                buf = buf.append(CommonUtils.hrSeparator).append("\n")
                        .append("Errore nel recupero della configurazione del topic!\nLa configurazione devops prevede basic authentication ma non e' configurata la chiave per recuperare le credenziali su Jenkins")
                        .append(CommonUtils.hrSeparator).append("\n")
                this.pipeline.echo"${buf.toString()}"
                this.pipeline.error()
            }
            this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: this.restProxyCredsId, passwordVariable: 'password', usernameVariable: 'user')]) {
                if(!this.restProxySkipCAcert) {
                    if (!this.restProxySkipSSL) {
                        result = this.curlRunner.execWithStatus([
                                url: "${this.restProxy}/topics/${topicName}",
                                method: "GET",
                                auth: "${this.pipeline.env.user}:${this.pipeline.env.password}",
                                cacert: "${this.pipeline.env.SEC_CA_CRT}"
                        ])
                    } else {
                        result = this.curlRunner.execWithStatus([
                                url: "${this.restProxy}/topics/${topicName}",
                                method: "GET",
                                auth: "${this.pipeline.env.user}:${this.pipeline.env.password}",
                                cacert: "${this.pipeline.env.SEC_CA_CRT}",
                                skipSSL: true
                        ])
                    }
                }
            }
        }
        else if(!this.restProxySkipCAcert) {
            if (!this.restProxySkipSSL) {
                result = this.curlRunner.execWithStatus([
                        url: "${this.restProxy}/topics/${topicName}",
                        method: "GET",
                        cacert: "${this.pipeline.env.SEC_CA_CRT}"
                ])
            } else {
                result = this.curlRunner.execWithStatus([
                        url: "${this.restProxy}/topics/${topicName}",
                        method: "GET",
                        cacert: "${this.pipeline.env.SEC_CA_CRT}",
                        skipSSL: true
                ])
            }
        }
        else{
            result = this.curlRunner.execWithStatus([
                    url: "${this.restProxy}/topics/${topicName}",
                    method: "GET"
            ])
        }
        if(result==null){
            this.pipeline.echo"Errore! la chiamata cURL verso ${this.restProxy}/topics/${topicName} ha ritornato NULL!!"
        }
        else if(result.exitCode!=200){
            StringBuffer buf = new StringBuffer()
            buf = buf.append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore! Richiesta cURL al Rest proxy Kafka fallita (${this.restProxy}/topics/${topicName})\n")
                    .append("cURL exit code: ").append(result.exitCode).append("\n")
                    .append("cURL output: ").append(result.out).append("\n")
                    .append("cURL err: ").append(result.err).append("\n")
                    .append(CommonUtils.hrSeparator).append("\n")
            this.pipeline.echo"${buf.toString()}"
            this.pipeline.error()
        }

        def config = this.pipeline.readJSON text: "${result.out}"
        return config
    }

    RunnerResult callKafkaCli(KAFKA_OPER oper, args = [:]){
        RunnerResult result = null
/*
        for(int k=0 ; k< topicOperations.size(); k++){
            String s = topicOperations[k]
            this.pipeline.echo("${k}: ${s}\n")
        }*/

        String cmd = null
        this.pipeline.echo("isKafkaCliAuthenticated: ${isKafkaCliAuthenticated()}")
        if (oper) {
            switch (oper) {
                case KAFKA_OPER.CREATE:
                    CommonUtils.checkInputParameters(args, ["kafkaTopic", "configs"])
                    cmd = isKafkaCliAuthenticated() == true ?
                            topicOperations[0].replaceAll("#BK_URL#", "${this.broker}").replaceAll("#TOPIC_NAME#", "${((KafkaTopic) args.kafkaTopic).getName()}").replaceAll("#PARTITIONS#", "${((KafkaTopic) args.kafkaTopic).getPartitions()} ").replaceAll("#REPL_FACTOR#", "${((KafkaTopic) args.kafkaTopic).getReplicationFactor()} ").replaceAll("#CONFIGS#", "${args.configs.toString()}").replaceAll("#CMD_CFG#", "${this.pipeline.env.WORKSPACE}/client.properties")
                            :
                            topicOperations[1].replaceAll("#BK_URL#", "${this.broker}").replaceAll("#TOPIC_NAME#", "${((KafkaTopic) args.kafkaTopic).getName()}").replaceAll("#PARTITIONS#", "${((KafkaTopic) args.kafkaTopic).getPartitions()} ").replaceAll("#REPL_FACTOR#", "${((KafkaTopic) args.kafkaTopic).getReplicationFactor()} ").replaceAll("#CONFIGS#", "${args.configs.toString()}")
                    //this.pipeline.echo"CMD:\n${cmd}"
                    break
                case KAFKA_OPER.ALTER:
                    CommonUtils.checkInputParameters(args, ["kafkaTopic", "configs"])
                    cmd = isKafkaCliAuthenticated() == true ?
                            topicOperations[2].replaceAll("#ZK_URL#", "${this.zookeeper}").replaceAll("#TOPIC_NAME#", "${((KafkaTopic) args.kafkaTopic).getName()}").replaceAll("#CONFIGS#", "${args.configs.toString()}").replaceAll("#CMD_CFG#", "${this.pipeline.WORKSPACE}/client.properties")
                            :
                            topicOperations[3].replaceAll("#ZK_URL#", "${this.zookeeper}").replaceAll("#TOPIC_NAME#", "${((KafkaTopic) args.kafkaTopic).getName()}").replaceAll("#CONFIGS#", "${args.configs.toString()}")
                    //this.pipeline.echo"CMD:\n${cmd}"
                    break
                case KAFKA_OPER.DELETE:
                    CommonUtils.checkInputParameters(args, ["topicName"])
                    cmd = isKafkaCliAuthenticated() == true ?
                            topicOperations[4].replaceAll("#BK_URL#", "${this.broker}").replaceAll("#TOPIC_NAME#", "${args.topicName}").replaceAll("#CMD_CFG#", "${this.pipeline.WORKSPACE}/client.properties")
                            :
                            topicOperations[5].replaceAll("#BK_URL#", "${this.broker}").replaceAll("#TOPIC_NAME#", "${args.topicName}")
                    //this.pipeline.echo"CMD:\n${cmd}"
                    break
            }
        }
        if(cmd){
            this.pipeline.echo("Executing command as follows:\n${cmd}\n")
            result = this.shRunner.execWithStatus([cmd: cmd])
        }
        return result
    }

    void startDefaultConsumer(String topicName){

        String cmd = "kafka-console-consumer.sh --bootstrap-server ${this.broker} --topic ${topicName} --from-beginning" // --command-config ${this.pipeline.WORKSPACE}/client.properties"

        RunnerResult result = this.shRunner.execWithStatus([cmd: cmd])
        StringBuffer buf = new StringBuffer("\nRESULT:\n ")
                .append("cURL exit code: ").append(result.exitCode).append("\n")
                .append("cURL output: ").append(result.out).append("\n")
                .append("cURL err: ").append(result.err).append("\n")
        this.pipeline.echo("${buf.toString()}")
    }
}
