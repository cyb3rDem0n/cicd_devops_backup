package com.accenture.sec.managers

import com.accenture.sec.utils.CommonUtils



//import com.openshift.jenkins.plugins.OpenShiftDSL

import java.util.regex.Pattern

/**
 * OpenshiftManager - class used to interact with Openshift from pipelines.
 * The assumption to use this is that cluster and project are defined in the pipeline
 * before to call the OpenshiftManager functions.
 */
class OpenshiftManager implements Serializable {

    /**
     *
     */
    protected def pipeline
    /**
     *
     */
    protected def openshift

    OpenshiftManager(def pipeline, def openshift) {
        this.pipeline = pipeline
        this.openshift = openshift
    }

    OpenshiftManager(def pipeline) {
        this(pipeline, pipeline.openshift)
    }

    def withCluster(def cluster = null, Closure body) {
        return this.openshift.withCluster(cluster, body)
    }

    def withProject(def project, Closure body) {
        return this.openshift.withProject(project, body)
    }

    def selector(def kind, def name = null, Map args = null) {
        def sel
        if (!CommonUtils.isNullOrEmpty(name))
            sel = this.openshift.selector(kind, name)
        else if (!CommonUtils.isNullOrEmpty(args))
            sel = this.openshift.selector(kind, args)
        else
            sel = this.openshift.selector(kind)
        return sel
    }

    def rsync(Object... args) {
        return this.openshift.rsync(args as String[])
    }

    def exec(Object... args) {
        return this.openshift.exec(args as String[])
    }

    /**
     * Create a bc with name msName starting from imageStream if not exist,
     * start a new build using map as options selector
     * and finally tag the image with version
     *
     * @param msName Name of the microservice, will be used to name the bc
     * @param imageStream is used to start build from
     * @param version version tag to be applied to the new image generated
     * @param map contain options for the new build. es. ['binary': true, 'from_dir': true, 'dir': 'oc-build']
     * @return
     */
    /*def buildImage(def msName, def imageStream, def version, Map map = ['binary': true, 'from_dir': true, 'dir': 'oc-build']) {

        // If not exist create a new bc with name msName, is=imageStream and binary=map.binary
        def bc = openshift.selector("bc", "${msName}")
        if (bc.exists()) {
            if (bc.object().spec.strategy.sourceStrategy.from.name != imageStream) {
                pipeline.echo("Updating buildconfig ${msName}...")
                bc.patch("\"{\\\"spec\\\":{\\\"strategy\\\":{\\\"sourceStrategy\\\":{\\\"from\\\":{\\\"name\\\":\\\"${imageStream}\\\"}}}}}\"")
            }
        } else {
            pipeline.echo("Creating buildconfig ${msName}...")
            openshift.newBuild("--name=${msName}", "--image-stream=${imageStream}", "--binary=${map.binary}")
        }

        // Prepare options variable passed to startBuild
        def opt = ''
        if (map.from_dir) {
            opt = "--from-dir=${map.dir}"
        }
        pipeline.echo("Creating image for ${msName}...")
        def ret = openshift.selector("bc", "${msName}").startBuild("${opt}", "--wait=true")
        pipeline.echo("Created image: ${ret.object().status.outputDockerImageReference}")

        // collect sha1 to tag the image created
        def sha = ret.object().status.output.to.imageDigest
        pipeline.echo("Applying tag ${version} to image...")
        // tag the image generated with version
        // is supposed the project target is the same of the source (defined out of this function)
        ret = openshift.tag("${openshift.project()}/${msName}@${sha}", "${openshift.project()}/${msName}:${version}")
        pipeline.echo("${ret.actions[0].out}")
        return ret
    }*/

    /**
     * Delete all resources tagged with filterLabel label and all the secrets that matches the secretsPattern regex
     *
     * @param filterLabel label used to filter all the resources to be deleted
     * @param secretsPattern regex to match the secrets. ex. /^secrets\/jrv\..*$/
     * @return
     */
    /*
    def cleanProject(def filterLabel, String secretsPrefix) {
        pipeline.echo("Cleanup ${openshift.project()}")
        pipeline.echo("Deleting all resources with ${filterLabel}...")
        def ret = openshift.delete("all", "-l ${filterLabel}", "--ignore-not-found=true")
        pipeline.echo("${ret.out}")

        def secrets = openshift.selector("secret")

        if (secrets.count() > 0 && secretsPrefix != null) {

            pipeline.echo("Deleting all secrets starts with ${secretsPrefix}...")
            def secretsPattern = /^secret(s)?\/${secretsPrefix}[\.-]/
            secrets.withEach {
                if (it.name() ==~ secretsPattern) {
                    it.delete()
                    //pipeline.echo(it.delete().out)
                }
            }
        }
    }*/

    /**
     * Create a spot pod from template file and wait that it's started. Expected to be a template of a single pod with 2 PARAMETERS (NAME,PROJECT)
     * NAME will be the name of the dc, PROJECT is a prefix that will be addedd to the labels to match a specific pod
     *
     * @param dcName Name of the dc that will be created
     * @param msProject Project for which the pod is created
     * @param templatePath path of the template file to be processed
     * @return
     */
    /*
    def createOndemandPod(String dcName, String msProject, String templatePath) {
        def pod = null
        *//** Example of input variables
         dcName = "${msProject}-${podSpotName}-${microservice}"
         templatePath = "jrv_cicd_devops/templates/newman_template.yaml"
         *//*
        def list = openshift.process("-f ${templatePath}", "-p=NAME=${dcName}", "-p=PROJECT=${msProject}")
        def dc = list.find { it.kind.toLowerCase() == "deploymentconfig" }
        def sel = openshift.selector("dc", "${dcName}")
        def result
        if (!sel.exists()) {
            result = openshift.create(list)
            pipeline.echo("Created dc/${dcName}")
        } else {
            result = openshift.apply(list)
            pipeline.echo("Updated dc/${dcName}")
        }
        pipeline.timeout(5) {
            if (result.narrow('dc').object().status.replicas == 0) {
                result.narrow('dc').scale("--replicas=1")
                def rollout = result.narrow('dc').rollout()
                rollout.status()
            }
            result.narrow('dc').related('pods').untilEach(1) {
                return (it.object().status.phase == "Running")
            }
        }
        def pods = result.narrow('dc').related('pods').objects()
        pod = pods.find { it.status.phase == "Running" }
        return pod?.metadata.name
    }*/

    /**
     * Create a spot pod from template and wait that it's started. Expected to be a template with a single DC
     *
     * @param template Path to the template file or name of an openshift's template
     * @param args a Map of arguments to be passed to createFromTemplate() and dedicated args
     * @return a Map containing all the resources created
     */
    def createOndemandPod(def template, Map args) {
        args << [manualRollout: false]
        def resources = this.createFromTemplate(template, args)
        def dc = openshift.selector(resources.get('deploymentconfig')[0].name())
        pipeline.echo("Rolling out ${dc.name()} ...")
        pipeline.timeout(5) {
            if (dc.object().status.replicas == 0) {
                dc.scale("--replicas=1")
                def rollout = dc.rollout()
                rollout.status()
            }
            dc.related('pods').untilEach(1) {
                return (it.object().status.phase == "Running")
            }
        }
        return openshift.selector('pod', [deploymentconfig: resources.get('deploymentconfig')[0].name().tokenize('/')[-1]]).name().tokenize('/')[-1]
//        return resources
    }

    /**
     * Process and create/update a template
     *
     * @param template Path to the template file or name of an openshift's template
     * @param args a Map of arguments to be passed to the process step.
     *              es. [parameters:[NAME:'name'],args:['--loglevel 9']]
     * @return a Map containing all the resources created/updated
     */
    def createFromTemplate(def template, Map args) {
        List _args = []
        def templateStr = "${template}"
        if ((template instanceof String || template instanceof GString) && (template.matches(Pattern.compile(/.+\.(json|yaml|yml)/)))) {
            _args.add(template)
            template = '-f'
            templateStr = 'template from file'
        }
        !CommonUtils.isNullOrEmpty(args.args) && _args.addAll(args.args)
        args.parameters?.each { param ->
            _args.addAll(["-p", "${param.key}='${param.value}'"])
        }
        pipeline.echo("Processing ${templateStr} in ${openshift.project()} with ${_args} ...")
        def list = openshift.process(template, _args as String[])
        Map resMap = [:]
        boolean manualRollout = args.manualRollout == null ? true : args.manualRollout
        list.each { el ->
            def result, revision
            pipeline.echo("Processing ${el.kind.toLowerCase()}/${el.metadata.name}...")
            def sel = openshift.selector("${el.kind.toLowerCase()}/${el.metadata.name}")
            if (!sel.exists()) {
                result = openshift.create(el)
                pipeline.echo("Created ${el.kind.toLowerCase()}/${el.metadata.name}")
            } else if (el.kind.toLowerCase() == "route") {
                result = openshift.replace(el, '--force=true', '--grace-period=0')
                pipeline.echo("Replaced ${el.kind.toLowerCase()}/${el.metadata.name}")
            } else if (el.kind.toLowerCase() == 'persistentvolumeclaim') {
                return
            } else {
                revision = sel.object().metadata.resourceVersion
                result = openshift.apply(el)
                pipeline.echo("Updated ${el.kind.toLowerCase()}/${el.metadata.name}")
            }

            resMap.get(el.kind.toLowerCase()) == null && resMap.put(el.kind.toLowerCase(), [])
            resMap[el.kind.toLowerCase()].add(result)

            if (el.kind.toLowerCase() == "deploymentconfig") {
                if (!CommonUtils.isNullOrEmpty(revision) &&
                        revision != "${result.object().metadata.resourceVersion}") {
                    manualRollout = false
                }
                if (result.object().status.replicas != 0) {
                    pipeline.timeout(5) {
//                        def rollout = openshift.selector("dc", "${el.metadata.name}").rollout()
//                        def rollout = result.rollout()
                        def rollout = openshift.selector(result.name()).rollout()
                        if (manualRollout) {
                            pipeline.echo("Manual rollout...")
                            rollout.latest()
                        }
                        rollout.status()
                    }
                }
            }
        }
        pipeline.echo("Completed creation of ${templateStr} in ${openshift.project()} with ${_args} ")
        return resMap
    }

    /**
     * Scale up or down a pod selected by dcName
     *
     * @param dcName name of the dc for which scale up or down
     * @param replica number of replicas to be applied
     * @return
     */
    def scalePod(def dcName, int replica) {
        def sel = CommonUtils.isString(dcName) ? openshift.selector('dc', "${dcName}") : dcName
        if (sel.object().status.replicas != replica) {
            pipeline.echo("Scaling ${dcName} to ${replica}...")
            def res = sel.scale("--replicas=${replica}")
            if (replica != 0) {
                pipeline.sleep(5)
                def _continue = true
                while (_continue) {
                    _continue = false
                    try {
                        sel.related('pods').withEach {
                            if (it.object().status.phase != "Running")
                                _continue = true
                        }
                    } catch (Exception e) {
                        if (!e.toString().contains("Unable to retrieve object"))
                            throw e
                        _continue = true
                    }
                }
            }
            pipeline.echo(res.out)
        }
    }

}
