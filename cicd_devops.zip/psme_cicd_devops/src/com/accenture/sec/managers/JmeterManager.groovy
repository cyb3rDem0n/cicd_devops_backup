package com.accenture.sec.managers

import com.accenture.sec.runners.ScpRunner
import com.accenture.sec.runners.SshRunner


import java.text.SimpleDateFormat

class JmeterManager implements Serializable {

    protected def pipeline
    protected String hostname
    protected String credsId
    protected boolean debug
    private SshRunner sshRunner
    private ScpRunner scpRunner

    JmeterManager(def pipeline, def hostname, def credsId) {
        this.pipeline = pipeline
        this.hostname = hostname
        this.credsId = credsId
        this.debug = false
        this.sshRunner = new SshRunner(this.pipeline)
        this.scpRunner = new ScpRunner(this.pipeline)
    }

    String runJmeterTests(Map args) {

        String date = new SimpleDateFormat("yyyy-MM-dd-HH-mm").format(new Date())
        String targetDir = "~/tests-${date}".toString()
        String sourceDir = args.sourceDir.toString() ?: "./tests"
        scpRunner.execWithStatus([
                credsId: this.credsId ?: 'ssh-jmeter-key',
                options: [StrictHostKeyChecking: 'no'],
                source : [dir: sourceDir],
                target : [remoteHost: this.hostname, dir: targetDir]
        ])

        def glob = sourceDir.startsWith('./') ? "${sourceDir.replace('./', '')}/*.jmx" : "${sourceDir}/*.jmx"
        def files = this.pipeline.findFiles(glob: glob)
        files.each { file ->
            sshRunner.execWithStatus([
                    credsId  : this.credsId ?: 'ssh-jmeter-key',
                    options  : [StrictHostKeyChecking: 'no'],
                    remoteCmd: "nohup jmeter -n -t ${targetDir}/${file.name} -l ${targetDir}/${file.name.replace('.jmx', '')}.out -e -o ${targetDir}/${file.name.replace('.jmx', '')}.web &"
            ])
        }
        return targetDir
    }

    void stopJmeterTests(Map args) {
        sshRunner.execWithStatus([
                credsId  : args.credsId ?: 'ssh-jmeter-key',
                options  : [StrictHostKeyChecking: 'no'],
                remoteCmd: "pkill -U {{user}} -f ApacheJMeter.jar -e"
        ])
    }

}
