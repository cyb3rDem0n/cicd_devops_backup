package com.accenture.sec.managers

import com.accenture.sec.utils.CommonUtils


class OpenshiftAdminManager extends OpenshiftManager {

    int loglevel = 0

    OpenshiftAdminManager(def pipeline, def openshift) {
        super(pipeline, openshift)
    }

    OpenshiftAdminManager(def pipeline) {
        super(pipeline)
    }

    void logLevel(int level){
        loglevel = level
        openshift.logLevel(level)
    }

    /**
     *
     *
     *
     * args = [cicdProject: 'cb-devops',
     *         addRoleTo  : [
     *                group: [
     *                        [role: "view", who: "CN=copybanking_bitbucket_admins,CN=users,DC=secreloaded,DC=sec"]
     *                ],
     *                user : [
     *                        [role: "admin", who: ["CN=Enrico Antonioli,CN=Users,DC=secreloaded,DC=sec"]]
     *                ]
     *        ]]
     *
     *
     * @param projectName
     * @param args
     * @return
     */
    def createProject(String projectName, Map args = null) {

        List<String> _args = []
        !CommonUtils.isNullOrEmpty(args?.displayName) && _args.add("--display-name='${args.displayName}'" as String)
        !CommonUtils.isNullOrEmpty(args?.description) && _args.add("--description='${args.description}'" as String)
        this.pipeline.echo("Creating ${projectName} with args ${_args}...")
        def project = openshift.newProject(projectName, _args.toArray() as String[])
//        args.cicdProject && addRoleTo("user", "admin", "system:serviceaccount:${args.cicdProject}:jenkins")
        this.pipeline.echo("Applying permissions to ${projectName}...")
        args.cicdProject && addRoleTo("user", "system:image-puller", "system:serviceaccount:${projectName}:default", "-n ${args.cicdProject}")
        if (args.addRoleTo) {
            args.addRoleTo.each { toWho ->
                toWho.value.each { what ->
                    if (what.who instanceof String)
                        what.who = [what.who]
                    what.who.each { who ->
                        addRoleTo(toWho.key as String, what.role as String, who as String, "-n ${projectName}")
                    }
                }
            }
        }
        this.pipeline.echo("Created ${projectName}")
        return project
    }

    def deleteProject(String projectName, Map args = null) {

        args?.cicdProject && removeUserBinding("system:serviceaccount:${projectName}:default", "${args.cicdProject}")
        this.pipeline.echo("Deleting ${projectName}...")
        def ret = openshift.delete('project', projectName)
        this.pipeline.echo("Deleted ${projectName}")
        return ret
    }

    def addRoleTo(String toWho, String role, String who, String... args) {

        this.pipeline.echo("Applying policy: add-role-to-${toWho.toLowerCase()} ${role} '${who}' ${args}")
        policy("add-role-to-${toWho.toLowerCase()} ${role} '${who}'", args)
    }

    def removeUserBinding(String who, String from){

        this.pipeline.echo("Applying policy: remove-user '${who}' -n ${from}")
        policy("remove-user '${who}' -n ${from}")
    }

    def removeRoleFrom(String fromWho, String role, String who, String... args) {

        this.pipeline.echo("Applying policy: remove-role-to-${fromWho.toLowerCase()} ${role} '${who}' ${args}")
        policy("remove-role-to-${fromWho.toLowerCase()} ${role} '${who}'", args)
    }

    private def policy(String cmd, String... args) {
//        pipeline.sh("""#!/bin/bash -e
//            oc --loglevel ${loglevel} policy ${cmd} ${args.join('')}
//        """)
        def res = this.openshift.raw("policy ${cmd} ${args.join('')}")
        def action = res.actions[0]
        action.status == 0 && pipeline.echo("${action.out}") || pipeline.echo("${action.err}")
        if(action.status == 0){
            pipeline.echo("${action.out}")
        }else{
            pipeline.echo("${action.err}")
        }
        return res
    }
}
