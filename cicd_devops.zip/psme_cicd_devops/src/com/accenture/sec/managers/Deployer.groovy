package com.accenture.sec.managers

import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.runners.ScpRunner
import com.accenture.sec.runners.SshRunner
import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.golive.GoLiveInfo
import com.accenture.sec.utils.golive.GoLiveList


class Deployer implements Serializable {

    static void executeDeploy(def pipeline, def deployStages) {
        def sel, obj, url
        def tmp = [:]
        deployStages.each { deployStage ->
            pipeline.stage("Deploy ${deployStage.groupName}") {
                pipeline.printTime("Deploy Stage group '${deployStage.groupName}'") {
                    def groupName = deployStage.groupName
                    deployStage.parallelDeployments.each { parallelDeployment ->
                        switch (parallelDeployment.type) {
                            case 'vm':
                                deployStage.groupName = "${groupName} virtual machines"
                                pipeline.parallel(parallelDeployment.parallels)
                                break;

                            case 'ocp':
                                deployStage.groupName = "${groupName} openshift"
                                pipeline.echo("pipeline.env.targetProjectOCP: ${pipeline.env.targetProjectOCP}")
                                pipeline.openshift.withCluster(pipeline.env.clusterOCP, pipeline.env.clusterCredsId) {
                                    pipeline.openshift.withProject(pipeline.env.targetProjectOCP) {
                                        // Deploy environment
                                        pipeline.parallel(parallelDeployment.parallels)
                                    }
                                }
                                break
                        }
                    }
                }
            }
        }
    }

    static List<Map<String, String>> createDeployStages(def pipeline, NexusManager nxMgr, def deployGroupsList, Map vmInfo, def servicesURL, Map dbMigration, def diffMap = null, Map options = null) {
        def deployStages = []
        int x = 0
        def diffList = diffMap?.keySet() ?: options?.deployStatus?.keySet()
        deployGroupsList.each { group ->

            def parallelDeploysOcp = [:]
            def parallelDeploysVm = [:]
            def targetEnv
            group.eachWithIndex { microservice, l ->
                def msName = microservice.key
                def msInfo = microservice.value
                if (options?.skipList != null && msName in options?.skipList)
                    return
                if (diffList != null && !(msName in diffList))
                    return
                def msVersion = diffMap ? diffMap.get(msName).version : msInfo.version
                targetEnv = diffMap ? diffMap.get(msName).target : msInfo.target

                pipeline.echo("msName: ${msName}\ntargetEnv: ${targetEnv}")
                def targetFolder
                if (targetEnv == 'ocp') {
                    parallelDeploysOcp = prepareParallelDeploymentOcp(pipeline, nxMgr, parallelDeploysOcp, dbMigration, servicesURL, msName, msVersion, options)
                    targetFolder = "package-${msName}"
                } else if (targetEnv == 'vm') {
                    parallelDeploysVm = prepareParallelDeploymentVm(pipeline, nxMgr, parallelDeploysVm, dbMigration, vmInfo, msName, msVersion, options)
                    targetFolder = "${msName}"
                    pipeline.sh("""#!/bin/bash -e
if [[ ! -d ${pipeline.env.WORKSPACE}/keys ]]; then
    mkdir -p ${pipeline.env.WORKSPACE}/keys
fi
""")
                    def machine = vmInfo.machines.find { vm -> vm.apps.find { app -> app.appname == msName } }
                    if (machine && pipeline.findFiles(glob: "keys/${machine.keyCredsId}").size() == 0) {
                        def keyFileName = "private_key_${System.currentTimeMillis()}"
                        def userVarName = "user"
                        pipeline.withCredentials([pipeline.sshUserPrivateKey(credentialsId: machine.keyCredsId, keyFileVariable: keyFileName, passphraseVariable: '', usernameVariable: userVarName)]) {
                            pipeline.sh("""#!/bin/bash
cp -rf ${pipeline.env.getProperty(keyFileName)} ${pipeline.env.WORKSPACE}/keys/${machine.keyCredsId}
chmod 400 ${pipeline.env.WORKSPACE}/keys/${machine.keyCredsId}
""")
                        }
                    }

                }
                pipeline.selectiveRetry {
                    pipeline.sh("""#!/bin/bash -e
                        rm -rf "${pipeline.env.WORKSPACE}/${targetFolder}/" || true
                    """)
                    def filePath = nxMgr.download(
                            pipeline.env.nexusArtifactRepo,
                            [
                                    groupId       : pipeline.env.nexusArtifactGroupId,
                                    artifactId    : msName,
                                    packageVersion: msVersion,
                                    packaging     : 'zip'
                            ],
                            "${targetFolder}",
                            'maven2'
                    )
                    pipeline.sh("""#!/bin/bash -e
                        unzip "${filePath}" -d "${pipeline.env.WORKSPACE}/${targetFolder}/"
                        rm -rf "${filePath}" || true
                    """)
                }
            }
            def tmpMap
            if (!CommonUtils.isNullOrEmpty(parallelDeploysVm) && !CommonUtils.isNullOrEmpty(parallelDeploysOcp)) {
                tmpMap = ["groupName": "Group ${x + 1}", parallelDeployments: [[type: 'vm', parallels: parallelDeploysVm], [type: 'ocp', parallels: parallelDeploysOcp]]]
            } else if (CommonUtils.isNullOrEmpty(parallelDeploysVm) && !CommonUtils.isNullOrEmpty(parallelDeploysOcp)) {
                tmpMap = ["groupName": "Group ${x + 1}", parallelDeployments: [[type: 'ocp', parallels: parallelDeploysOcp]]]
            } else if (!CommonUtils.isNullOrEmpty(parallelDeploysVm) && CommonUtils.isNullOrEmpty(parallelDeploysOcp)) {
                tmpMap = ["groupName": "Group ${x + 1}", parallelDeployments: [[type: 'vm', parallels: parallelDeploysVm]]]
            }

            if (tmpMap) {
                deployStages.add(tmpMap)
                x++
            }
        }

        return deployStages
    }

    static def prepareParallelDeploymentOcp(def pipeline, NexusManager nxMgr, parallelDeploys = [:], Map dbMigration, def servicesURL, def msName, def msVersion, Map options = null) {
        parallelDeploys["${msName}"] = {
            pipeline.stage(msName) {
                pipeline.script {
                    try {
                        pipeline.printTime("Stage '${msName}'") {
                            if (options?.dryrun)
                                return
                            def filePath
                            pipeline.selectiveRetry {
                                pipeline.sleep((new Random()).nextInt(20) ?: 1)
                            }
//                            pipeline.selectiveRetry {
//                                pipeline.sh("""#!/bin/bash -e
//                                        rm -rf "${pipeline.env.WORKSPACE}/package-${msName}/" || true
//                                    """)
//
//                                filePath = nxMgr.download(
//                                        pipeline.env.nexusArtifactRepo,
//                                        [
//                                                groupId       : pipeline.env.nexusArtifactGroupId,
//                                                artifactId    : msName,
//                                                packageVersion: msVersion,
//                                                packaging     : 'zip'
//                                        ],
//                                        "package-${msName}",
//                                        'maven2'
//                                )
//
//                                pipeline.sh("""#!/bin/bash -e
//                                        unzip "${filePath}" -d "${pipeline.env.WORKSPACE}/package-${msName}/"
//                                        rm -rf "${filePath}" || true
//                                    """)
//                            }

                            Map tokens
                            while (!tokens) {
                                try {
                                    tokens = pipeline.readYaml(file: "${pipeline.env.WORKSPACE}/tokens/${pipeline.env.targetProjectOCP}.yaml")
                                } catch (NotSerializableException e1) {
                                    if (!e1.getMessage().contains('FastPipedInputStream'))
                                        throw e1
                                }
                                catch (Exception e) {
                                    throw e
                                }
                            }

                            pipeline.selectiveRetry {
                                pipeline.replaceTokens(
                                        name: msName,
                                        path: "package-${msName}/deployment/templates",
                                        tokens: tokens
                                )
                            }

                            if (dbMigration && dbMigration.doMigration) {
//                                if (pipeline.findFiles(glob: "package-${msName}/deployment/database/V*__*.js").size() > 0) {
//                                    pipeline.dbMigration('mongodb', [
//                                            migrationFolder: "package-${msName}/deployment/database",
//                                            tokens         : tokens,
//                                            msName         : msName,
//                                            clean          : dbMigration.get('clean',false)
//                                    ])
//                                }

                                def check
                                check = pipeline.findFiles(glob: "package-${msName}/deployment/database/dbchangelog.xml")
                                if (check != null && check.size() > 0) {
                                    pipeline.dbMigration('liquibase', [
                                            migrationFolder: "package-${msName}/deployment/database",
                                            changeLog      : "dbchangelog.xml",
                                            tokens         : tokens,
                                            msName         : msName,
                                            clean          : dbMigration.get('clean', false)
                                    ])
                                } else {
                                    check = pipeline.findFiles(glob: "package-${msName}/deployment/database/V*__*.sql")
                                    if (check != null && check.size() > 0) {
                                        pipeline.dbMigration('flyway', [
                                                migrationFolder: "package-${msName}/deployment",
                                                tokens         : tokens,
                                                msName         : msName,
                                                clean          : dbMigration.get('clean', false)
                                        ])
                                    }
                                }
                            }
                            def serviceUrl
                            pipeline.printTime("Deploy '${msName}'", true) {
                                pipeline.echo("DEPLOYAPP:\n${pipeline.openshift}, ${msName}, ${msVersion}, [ templatesPath: ${pipeline.WORKSPACE}/package-${msName}/deployment/templates, ignoreTimeout: ${options?.ignoreTimeout ?: false}, force: ${options?.force ?: false}]")
                                serviceUrl = pipeline.deployApp(
                                        pipeline.openshift,
                                        msName,
                                        msVersion,
                                        [
                                                templatesPath: "${pipeline.WORKSPACE}/package-${msName}/deployment/templates",
                                                ignoreTimeout: options?.ignoreTimeout ?: false,
                                                force        : options?.force ?: false
                                        ]
                                )
                            }
                            if (options?.goLiveList)
                                ((GoLiveList) options.goLiveList).add(msName, msVersion)
                            servicesURL.put(msName, serviceUrl)
                        }
                        options?.deployStatus && options.deployStatus.put(msName, true)
                    } catch (Exception ex) {
                        options?.deployStatus && options.deployStatus.put(msName, false)
                        throw ex
                    }
                }
            }
        }
        return parallelDeploys
    }

    static def prepareParallelDeploymentVm(def pipeline, NexusManager nxMgr, parallelDeploys = [:], Map dbMigration, Map vmInfo, def msName, def msVersion, Map options = null) {
        parallelDeploys["${msName}"] = {
            pipeline.stage(msName) {
                pipeline.script {
                    try {
                        pipeline.printTime("Stage '${msName}'") {
                            if (options?.dryrun)
                                return
                            def filePath
                            def application
                            vmInfo.machines.each { vm ->
                                pipeline.echo("Looking for ${msName} into ${vm.apps}")
                                application = vm.apps.find {
                                    it.appname == "${msName}"
                                }
                                pipeline.echo("application: ${application}")
                                if (application) {
                                    SshRunner sshRunner = new SshRunner(pipeline)
                                    sshRunner.setExistingKeyFile("${pipeline.env.WORKSPACE}/keys/${vm.keyCredsId}", application.username)

                                    RunnerResult sshResult
                                    pipeline.selectiveRetry {
                                        pipeline.sleep((new Random()).nextInt(20) ?: 1)
                                    }

                                    Map tokens
                                    while (!tokens) {
                                        try {
                                            tokens = pipeline.readYaml(file: "${pipeline.env.WORKSPACE}/tokens/${vmInfo.tokenfile}")
                                        } catch (NotSerializableException e1) {
                                            if (!e1.getMessage().contains('FastPipedInputStream'))
                                                throw e1
                                        }
                                        catch (Exception e) {
                                            throw e
                                        }
                                    }

                                    pipeline.selectiveRetry {
                                        pipeline.replaceTokens(
                                                name: msName,
                                                path: "${msName}/deployment/conf",
                                                tokens: tokens
                                        )
                                        pipeline.replaceTokens(
                                                name: msName,
                                                path: "${msName}/deployment/secrets",
                                                tokens: tokens
                                        )
                                    }

                                    if (dbMigration && dbMigration.doMigration) {
//                                if (pipeline.findFiles(glob: "${msName}/deployment/database/V*__*.js").size() > 0) {
//                                    pipeline.dbMigration('mongodb', [
//                                            migrationFolder: "${msName}/deployment/database",
//                                            tokens         : tokens,
//                                            msName         : msName,
//                                            clean          : dbMigration.get('clean',false)
//                                    ])
//                                }

                                        def check
                                        check = pipeline.findFiles(glob: "${msName}/deployment/database/dbchangelog.xml")
                                        if (check != null && check.size() > 0) {
                                            pipeline.dbMigration('liquibase', [
                                                    migrationFolder: "${msName}/deployment/database",
                                                    changeLog      : "dbchangelog.xml",
                                                    tokens         : tokens,
                                                    msName         : msName,
                                                    clean          : dbMigration.get('clean', false)
                                            ])
                                        } else {
                                            check = pipeline.findFiles(glob: "${msName}/deployment/database/V*__*.sql")
                                            if (check != null && check.size() > 0) {
                                                pipeline.dbMigration('flyway', [
                                                        migrationFolder: "${msName}/deployment",
                                                        tokens         : tokens,
                                                        msName         : msName,
                                                        clean          : dbMigration.get('clean', false)
                                                ])
                                            }
                                        }
                                    }
                                    ScpRunner scpRunner = new ScpRunner(pipeline)
                                    scpRunner.setExistingKeyFile("${pipeline.env.WORKSPACE}/keys/${vm.keyCredsId}", application.username)

                                    RunnerResult scpResult
                                    pipeline.echo("${Colors.Bash.BLUE}Rimozione di eventuali file di rilasci precedenti da /tmp/${msName}/ ${Colors.Bash.NC}")
                                    sshResult = sshRunner.execWithStatus([
                                            host     : vm.host,
                                            options  : [StrictHostKeyChecking: 'no'],
                                            getOutput: false,
//                                            script   : """#!/bin/bash
//                                                        rm -rf /tmp/${msName}/ || true
//                                                     """,
                                            remoteCmd: "rm -rf /tmp/${msName}/ || true"
                                    ])
                                    if (sshResult?.exitCode != 0) {
                                        pipeline.echo("${Colors.Bash.RED}ERROR: ${Colors.Bash.NC}\n${sshResult.toMap()}")
                                        throw new Exception("${Colors.Bash.RED}Errore: Impossibile eliminare da host(${vm.host}) per il servizio ${application.service} la directory /tmp/${msName}/${Colors.Bash.NC}")
                                    }

                                    pipeline.echo("${Colors.Bash.BLUE}Copia dei file necessari al deploy in /tmp/${msName}/ ${Colors.Bash.NC}")
                                    scpResult = scpRunner.execWithStatus([
                                            options  : [StrictHostKeyChecking: 'no'],
                                            getOutput: false,
                                            source   : [dir: "${pipeline.env.WORKSPACE}/${msName}"],
                                            target   : [remoteHost: vm.host, dir: "/tmp/"]
                                    ])
                                    if (scpResult?.exitCode != 0) {
                                        pipeline.echo("${Colors.Bash.RED}ERROR: ${Colors.Bash.NC}\n${scpResult.toMap()}")
                                        throw new Exception("${Colors.Bash.RED}Errore: Caricamento file su host(${vm.host}) per il servizio ${application.service} fallito [${scpResult?.exitCode}]${Colors.Bash.NC}")
                                    }
                                    pipeline.echo("${Colors.Bash.BLUE}Arresto del servizio ${application.service} ${Colors.Bash.NC}")
                                    sshResult = sshRunner.execWithStatus([
                                            host     : vm.host,
                                            getOutput: false,
                                            options  : [StrictHostKeyChecking: 'no'],
                                            script   : """#!/bin/bash 
                                                        if [ -f "/opt/${msName}/.version" ]; then
                                                            sudo systemctl stop ${application.service}
                                                            exit \$?
                                                        else exit 255    
                                                        fi
                                                     """
                                    ])
                                    //Il servizio non esiste interrompo e fallisce
                                    if (sshResult?.exitCode == 4) {
                                        pipeline.echo("${Colors.Bash.RED}ERROR: ${Colors.Bash.NC}\n${sshResult.toMap()}")
                                        throw new Exception("${Colors.Bash.RED}Errore: Servizio ${application.service} non installato su host(${vm.host})${Colors.Bash.NC}")
                                    } else if (sshResult?.exitCode != 0 && sshResult?.exitCode != 255) {
                                        pipeline.echo("${Colors.Bash.RED}ERROR: ${Colors.Bash.NC}\n${sshResult.toMap()}")
                                        throw new Exception("${Colors.Bash.RED}Errore: Richiesta di stop del servizio ${application.service} fallito ${Colors.Bash.NC}")
                                    }
                                    //Servizio stopped o non mai deployato allora inizio il deploy
                                    pipeline.echo("${Colors.Bash.BLUE}Installazione nuova versione del servizio ${application.service} in /opt/${msName}  ${Colors.Bash.NC}")
                                    def script = """#!/bin/bash -e
if [[ -d /opt/tmp/ ]]; then
    find /opt/tmp/ -name "heapdump-${msName}-*.bin" -type f -mtime +30 -exec rm -f {} \\;
fi
rm -rf /opt/${msName}/* || true 
rm -rf /opt/${msName}/.version || true
find /tmp/${msName}/deployment -type f -print0 -exec dos2unix {} \\;
cp -R /tmp/${msName}/deployment/* /opt/${msName}
cp /tmp/${msName}/${msName}.jar /opt/${msName}
echo ${msVersion} > /opt/${msName}/.version
chmod u+x /opt/${msName}/scripts/*
chmod -R 600 /opt/${msName}/secrets/*
"""
                                    sshResult = sshRunner.execWithStatus([
                                            host     : vm.host,
                                            options  : [StrictHostKeyChecking: 'no'],
                                            getOutput: false,
                                            script   : script
                                    ])

                                    if (sshResult?.exitCode != 0) {
                                        pipeline.echo("${Colors.Bash.RED}ERROR: ${Colors.Bash.NC}\n${sshResult.toMap()}")
                                        throw new Exception("${Colors.Bash.RED}Errore: Installazione applicazione ${msName} fallita${Colors.Bash.NC}")
                                    }
                                    pipeline.echo("${Colors.Bash.BLUE}Avvio del servizio ${application.service} ${Colors.Bash.NC}")
                                    sshResult = sshRunner.execWithStatus([
                                            host     : vm.host,
                                            options  : [StrictHostKeyChecking: 'no'],
                                            getOutput: false,
//                                            script   : """#!/bin/bash
//                                                        sudo systemctl start ${application.service}
//                                                     """,
                                            remoteCmd: "sudo systemctl start ${application.service}"
                                    ])

                                    if (sshResult.exitCode != 0) {
                                        pipeline.echo("${Colors.Bash.RED}ERROR: ${Colors.Bash.NC}\n${sshResult.toMap()}")
                                        throw new Exception("${Colors.Bash.RED}Errore: Avvio servizio ${application.service} fallito${Colors.Bash.NC}")
                                    }
                                    pipeline.echo("${Colors.Bash.BLUE}Controllo che la nuova versione del servizio ${application.service} sia running ${Colors.Bash.NC}")

                                    sshResult = sshRunner.execWithStatus([
                                            host     : vm.host,
                                            options  : [StrictHostKeyChecking: 'no'],
                                            getOutput: false,
//                                            script   : """#!/bin/bash
//                                                        systemctl status ${application.service}
//                                                     """,
                                            remoteCmd: "systemctl status ${application.service}"
                                    ])

                                    if (sshResult.exitCode != 0) {
                                        pipeline.echo("${Colors.Bash.RED}ERROR: ${Colors.Bash.NC}\n${sshResult.toMap()}")
                                        throw new Exception("${Colors.Bash.RED}Errore: Avvio servizio ${application.service} fallito${Colors.Bash.NC}")
                                    }
//                                        pipeline.echo("${Colors.Bash.BLUE}Update del file di versione (/opt/${msName}/.version) per il  servizio ${application.service} ${Colors.Bash.NC}")
//                                        pipeline.selectiveRetry {
//                                            sshResult = sshRunner.execWithStatus([
//                                                    host     : vm.host,
//                                                    credsId  : (application.credsId ?: vm.keyCredsId),
//                                                    user     : application.username,
//                                                    options  : [StrictHostKeyChecking: 'no'],
//                                                    getOutput: false,
//                                                    script   : """#!/bin/bash -e
//                                                        echo ${msVersion} > /opt/${msName}/.version
//                                                        chmod 440 /opt/${msName}/.version
//                                                    """
//                                            ])
//                                        }
//                                        if (sshResult.exitCode != 0) {
//                                            throw new Exception("${Colors.Bash.RED}Errore: Scrittura file .version del servizio ${application.service} fallita${Colors.Bash.NC}")
//                                        }
                                    if (options?.goLiveList)
                                        ((GoLiveList) options.goLiveList).add(msName, msVersion)
                                }
                            }
                        }
                        options?.deployStatus && options.deployStatus.put(msName, true)
                    } catch (Exception ex) {
                        options?.deployStatus && options.deployStatus.put(msName, false)
                        throw ex
                    }
                }
            }
        }

        return parallelDeploys
    }

    static List createDeployGroupList(Map microservices, def pipeline = null) {
        Map tmpMicroservices = new LinkedHashMap(microservices)
        List<Map> deployGroupsList = []
        Map withDep = [:]
        int max = 5
        int count = 0
        while (!tmpMicroservices.isEmpty()) {
            Map tmp = popMicroservicesWithoutDependencies(tmpMicroservices, pipeline)
            if (count == max)
                throw new Exception("Loop nel calcolo delle dipendenze.\nControllare le dipendenze degli elementi rimanenti:\n${withDep}")
            if (tmp.without) {
                deployGroupsList.add(tmp.without)
                cleanMicroserviceDependencies(tmpMicroservices, tmp.without, pipeline)
            } else if (withDep == tmp.with) {
                count++
                pipeline && pipeline.echo("${tmp.with}")
            }
            withDep << tmp.with
        }
        return deployGroupsList
    }

/**
 * Returns a Map with name as key and version as value of each microservices that does not
 * have any dependencies. NB: This will change the microservices variable of this class,
 * deleting all microservices that don't have dependencies.
 */
    private static Map popMicroservicesWithoutDependencies(Map microservices, def pipeline = null) {
        String microserviceName = ""
        Map<String, String> microserviceInfo = [:]
        Map<String, String> microservicesWithoutDependencies = [:]
        Map microservicesWithDependencies = [:]

        microservices.each {

            microserviceName = it.key
            microserviceInfo = it.value

            // cerco tutti i microservizi senza dipendenze
            if (microserviceInfo.dependencies == null || microserviceInfo.dependencies.isEmpty()) {

                pipeline && pipeline.echo("${microserviceName} NON ha dipendenze, lo aggiungo")
                microservicesWithoutDependencies.put(microserviceName, [version: microserviceInfo.version, target: microserviceInfo.target])
                microservices.remove(microserviceName)
            } else {
                microservicesWithDependencies.put(microserviceName, microserviceInfo)
            }
        }

        return [with: microservicesWithDependencies, without: microservicesWithoutDependencies]
    }


/**
 *
 */
    private static void cleanMicroserviceDependencies(Map microservices, Map dependenciesDeployed, def pipeline = null) {
        microservices.each {
            def microserviceName = it.key
            def microserviceInfo = it.value

            pipeline && pipeline.echo("Controllo se ${microserviceName} ha dipendenze già deployate => ${microserviceInfo.dependencies}")

            if (microserviceInfo.dependencies != null) {
                def tmpDependencies = [:]

                tmpDependencies = microserviceInfo.dependencies.collect()

                pipeline && pipeline.echo("Dipendenze di ${microserviceName} => ${tmpDependencies}")


                tmpDependencies.each { dep ->
                    if (microserviceInfo.dependencies.isEmpty()) {
                        microserviceInfo.dependencies = null
                        return
                    }

                    pipeline && pipeline.echo("=======================================================")
                    pipeline && pipeline.echo("Controllo se ${microserviceName} dipende da ${dep}")


                    if (dependenciesDeployed.containsKey(dep)) {

                        pipeline && pipeline.echo("La dipendenza ${dep.toUpperCase()} è già stata deployata, la rimuovo")
                        microserviceInfo.dependencies.remove(dep)
                        pipeline && pipeline.echo("Dipendenze di ${microserviceName} => ${microserviceInfo.dependencies} (SIZE: ${microserviceInfo.dependencies.size()})")
                    } else {
                        pipeline && pipeline.echo("La dipendenza ${dep.toUpperCase()} non è ancora stata deployata")
                    }
                    pipeline && pipeline.echo("=======================================================")
                }
            } else {
                pipeline && pipeline.echo("La lista delle dipendenze di ${microserviceName} è NULL")
                return
            }
        }
    }

}
