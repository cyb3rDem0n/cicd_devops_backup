package com.accenture.sec.managers.amq

import com.accenture.sec.utils.CommonUtils


class AMQPodManager extends AbstractAMQManager {

    private String podName
    private List queueList
    private Map creds

    AMQPodManager(def pipeline, def amqEndpoint, def podName) {
        super(pipeline, amqEndpoint, '/opt/amq/bin/artemis')
        this.podName = podName.contains('pod/') ? podName.replaceAll('pod/', '') : podName as String
        this.queueList = null
        this.creds = [:]
    }


    void setCreds(def user, def password) {
        this.creds << [user: user, password: password]
    }

    @Override
    void createQueue(Map queue) {
        queue << this.creds
        if (existQueue(queue.name)) {
            this.pipeline.echo("Skipping: Queue '${queue.name}' already exists on address '${queue.address ?: queue.name}'")
            return
        } else {
            this.pipeline.echo("Creating new queue '${queue.name}' on address '${queue.address ?: queue.name}'")
            // Prepara il comando da lanciare nel pod e controlla che tutti i parametri obbligatori siano presenti
            def cmd = this.prepareQueueCmd('create', queue)

            this.debug && this.pipeline.echo("[${this.podName}] Executing: ${cmd}")
            def res = this.pipeline.openshift.exec(this.podName, '--request-timeout', '1m', "--", cmd)

            this.debug && this.pipeline.echo("Result: ${res}")
            if (isError(res)) {
                if (!res.actions[0].err.contains("Queue ${queue.name} already exists")) {
                    throw new AMQManagerException(res.actions[0].err)
                } else {
                    this.pipeline.echo("Skipping: Queue '${queue.name}' already exists on address '${queue.address ?: queue.name}'")
                }
            } else {
                this.pipeline.echo("${res.actions[0].out}")
            }
        }
    }

    @Override
    void updateQueue(Map queue) {
        queue << this.creds
        this.pipeline.echo("Updating queue '${queue.name}' on address '${queue.address ?: queue.name}'")
        // Prepara il comando da lanciare nel pod e controlla che tutti i parametri obbligatori siano presenti
        def cmd = this.prepareQueueCmd('update', queue)

        this.debug && this.pipeline.echo("[${this.podName}] Executing: ${cmd}")
        def res = this.pipeline.openshift.exec(this.podName, '--request-timeout', '1m', "--", cmd)

        this.debug && this.pipeline.echo("Result: ${res}")
        if (isError(res)) {
            throw new AMQManagerException(res.actions[0].err)
        } else {
            this.pipeline.echo("${res.actions[0].out}")
        }
    }

    @Override
    void deleteQueue(String queueName) {
        Map queue = [name: queueName]
        queue << this.creds
        def cmd = prepareQueueCmd('delete', queue)
        this.debug && this.pipeline.echo("[${this.podName}] Executing: ${cmd}")
        def res = this.pipeline.openshift.exec(this.podName, '--request-timeout', '1m', "--", cmd)
        this.debug && this.pipeline.echo("Result: ${res}")
        if (isError(res))
            throw new AMQManagerException(res.actions[0].err)
    }

    boolean existQueue(def queueName, boolean force = false) {
        if (!this.queueList || force)
            this.queueList = listQueues()
        return (queueName in this.queueList)
    }

    void deleteUnusedQueues(List neeededQueues, String prefix) {
        List tmp = listQueues(prefix)
        tmp.each { queueName ->
            if (!neeededQueues.find { it.name == queueName }) {
                this.pipeline.echo("Deleting ${queueName} ...")
                deleteQueue(queueName)
            }
        }
    }

    List listQueues(String prefix = '') {
        Map map = [name: '']
        map << this.creds
        def cmd = getQueueCmd(map)
        this.debug && this.pipeline.echo("[${this.podName}] Executing: ${cmd}")
        def res = this.pipeline.openshift.exec(this.podName, '--request-timeout', '1m', "--", cmd)
        this.debug && this.pipeline.echo("Result: ${res}")
        if (isError(res))
            return null
        List queues = res.actions[0].out.tokenize('\n').collect { return it.tokenize('|')[1].trim() }
        if (!CommonUtils.isNullOrEmpty(prefix))
            queues = queues.findAll { it ==~ /^${prefix}.*/ }
        else if(queues.size() > 1)
            queues = queues[1..-1]
        else
            queues = []
        return queues
    }

    boolean isError(def result) {
        return (result.status != 0 || result.actions[0].status != 0 || (result.actions[0].err != '' && result.actions[0].out == ''))
    }

    @Deprecated
    static List prepareTemplateParameters(Map cluster) {
        List templateParams = [
                "-p", "APPLICATION_NAME=${cluster.name}",
                "-p", "AMQ_PROTOCOL=${cluster.protocols}",
                "-p", "AMQ_QUEUES=${cluster.initial_queues ?: ''}",
                "-p", "AMQ_ADDRESSES=${cluster.addresses ?: ''}",
                "-p", "AMQ_USER=${cluster.user}",
                "-p", "AMQ_PASSWORD=${cluster.password}",
                "-p", "AMQ_NAME=${cluster.name}",
                "-p", "AMQ_CLUSTER_USER=${cluster.user_cluster}",
                "-p", "AMQ_CLUSTER_PASSWORD=${cluster.password_cluster}",
                "-p", "AMQ_REPLICAS=${cluster.replicas ?: 2}",
        ]
        if (cluster.require_login != null)
            templateParams.addAll(["-p", "AMQ_REQUIRE_LOGIN=${cluster.require_login}"])
        if (cluster.extra_args)
            templateParams.addAll(["-p", "AMQ_EXTRA_ARGS=${cluster.extra_args}"])
        if (cluster.role)
            templateParams.addAll(["-p", "AMQ_ROLE=${cluster.role}"])
        if (cluster.global_size)
            templateParams.addAll(["-p", "AMQ_GLOBAL_MAX_SIZE=${cluster.global_size}"])
        if (cluster.volume_size)
            templateParams.addAll(["-p", "VOLUME_CAPACITY=${cluster.volume_size}"])
        return templateParams
    }
}
