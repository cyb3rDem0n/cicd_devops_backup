package com.accenture.sec.managers.amq

class AMQManagerException extends Exception{
    AMQManagerException(def msg){
        super(msg)
    }
}