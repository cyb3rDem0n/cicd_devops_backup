package com.accenture.sec.managers.amq

import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.runners.ShRunner
import com.accenture.sec.utils.CommonUtils


class AMQManager extends AbstractAMQManager {

    AMQManager(def pipeline, String amqEndpoint, String artemisBinPath = "artemis") {
        super(pipeline, amqEndpoint, artemisBinPath)
    }

    @Override
    void createQueue(Map queue) {
        def cmd = this.prepareQueueCmd('create', queue)

        this.debug && this.pipeline.echo("Executing: ${cmd}")
        ShRunner shRunner = new ShRunner(this.pipeline)
        RunnerResult result = shRunner.execWithStatus([cmd: cmd, errSeparated: true, silent: true])

        this.debug && this.pipeline.echo("Result: ${result.toMap()}")
        if (!CommonUtils.isNullOrEmpty(result.err)) {
            if (!result.err.contains("Queue ${queue.name} already exists")) {
                throw new Exception(result.err)
            } else {
                this.pipeline.echo("Skipping: Queue '${queue.name}' already exists on address '${queue.address ?: queue.name}'")
            }
        } else {
            this.pipeline.echo("${result.out}")
        }
    }

    @Override
    void updateQueue(Map queue) {
        this.pipeline.echo("Updating queue '${queue.name}' on address '${queue.address ?: queue.name}'")
        // Prepara il comando da lanciare nel pod e controlla che tutti i parametri obbligatori siano presenti
        def cmd = this.prepareQueueCmd('update', queue)

        this.debug && this.pipeline.echo("Executing: ${cmd}")
        ShRunner shRunner = new ShRunner(this.pipeline)
        RunnerResult result = shRunner.execWithStatus([cmd: cmd, errSeparated: true, silent: true])

        this.debug && this.pipeline.echo("Result: ${result.toMap()}")
        if (!CommonUtils.isNullOrEmpty(result.err)) {
            throw new Exception(result.err)
        } else {
            this.pipeline.echo("${result.out}")
        }
    }

    @Override
    void deleteQueue(String queueName) {

    }
}
