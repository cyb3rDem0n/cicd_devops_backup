package com.accenture.sec.managers.amq

import com.accenture.sec.utils.CommonUtils


abstract class AbstractAMQManager implements Serializable {

    protected def pipeline
    protected String amqEndpoint
    protected String artemisBin
    protected boolean debug

    AbstractAMQManager(def pipeline, def amqEndpoint, String artemisBin){
        this.pipeline = pipeline
//        this.amqEndpoint = amqEndpoint.contains('tcp') ? amqEndpoint as String : ("tcp://${amqEndpoint}:61616" as String)
        this.amqEndpoint = amqEndpoint as String
        this.artemisBin = artemisBin
        this.debug = false
    }

    abstract void createQueue(Map queue)
    abstract void updateQueue(Map queue)
    abstract void deleteQueue(String queueName)


    protected String getQueueCmd(Map queue){
        def cmd = "${this.artemisBin} queue stat --url tcp://${this.amqEndpoint}:61616 --queueName '${queue.name}' --silent "
        if (!CommonUtils.isNullOrEmpty(queue.user) && !CommonUtils.isNullOrEmpty(queue.password))
            cmd += " --user ${queue.user} --password ${queue.password}"
        return cmd as String
    }

    /**
     *
     * @param queue una mappa che contiene la configurazione della coda
     * @param artemisBin per i pod il path del binario è '/opt/amq/bin/artemis', per sistemi in cui è nel PATH specificare solo 'artemis'
     * @return
     */
    protected String prepareQueueCmd(String op, Map queue){
        if(!(op in ['create','update','delete']))
            throw new IllegalArgumentException("Operation '${op}' not supported. Queue cmd supported [create|update|delete]")
        CommonUtils.checkInputParameters(queue,'name')
        def cmd = "${this.artemisBin} queue ${op} --url tcp://${this.amqEndpoint}:61616 --name ${queue.name} --silent "
        if (!CommonUtils.isNullOrEmpty(queue.user) && !CommonUtils.isNullOrEmpty(queue.password))
            cmd += " --user ${queue.user} --password ${queue.password}"
        switch (op){
            case 'create':
//                cmd += (queue.get('durable', true) ? " --durable" : " --no-durable")
//                cmd += (queue.get('purge_on_no_consumers', false) ? " --purge-on-no-consumers" : " --preserve-on-no-consumers")
                cmd += " --durable"
                cmd += " --preserve-on-no-consumers"
                cmd += " --auto-create-address --${queue.type.toLowerCase()}"
                //cmd += " --address ${queue.address ?: queue.name} --auto-create-address --${queue.type.toLowerCase()}"
                if (!CommonUtils.isNullOrEmpty(queue.consumers))
                    cmd += " --max-consumers ${queue.consumers}"
                if (!CommonUtils.isNullOrEmpty(queue.protocol))
                    cmd += " --protocol ${queue.protocol}"
                break
            case 'update':
                cmd += " --${queue.type.toLowerCase()}"
                if (!CommonUtils.isNullOrEmpty(queue.consumers))
                    cmd += " --max-consumers ${queue.consumers}"
                break
            case 'delete':
                cmd += " --autoDeleteAddress"
                break
        }
        return cmd as String
    }
}
