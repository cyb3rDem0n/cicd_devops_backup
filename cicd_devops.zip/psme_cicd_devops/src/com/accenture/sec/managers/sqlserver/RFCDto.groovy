package com.accenture.sec.managers.sqlserver

import com.accenture.sec.utils.CommonUtils


import java.sql.Timestamp

class RFCDto {

    private static String[] fields = [
            "codice_rfc",
            "ambiente",
            "dataora_iniziointervento",
            "dataora_fineintervento",
            "applicazione_cod",
            "applicazione_nome",
            "tipo_intervento",
            "tipo_passaggio",
            "referente_nome",
            "referente_cognome",
            "referente_username",
            "referente_email",
            "descrizione_change",
            "stato_rfc"
    ]

    RFCDto(String[] values, def pipeline) {
        if (values.size() != fields.size()) {
            StringBuffer buf = new StringBuffer()
            buf = buf.append("\n").append(CommonUtils.hrSeparator).append("\n")
                    .append("""Errore! Mismatch numero campi ritornati dalla query per il check RFC\nvalues.size():"${values.size()}"  values.size():"${fields.size()}" """)
                    .append(CommonUtils.hrSeparator).append("\n")
            pipeline.echo("${buf.toString()}")
            pipeline.error("${buf.toString()}")
        }

        this.codice_rfc = values[0].trim()
        this.ambiente = values[1].trim()
        this.dataora_iniziointervento = values[2].trim()
        this.inizioIntervento = Timestamp.valueOf(this.dataora_iniziointervento)
        this.dataora_fineintervento = values[3].trim()
        this.fineIntervento = Timestamp.valueOf(this.dataora_fineintervento)
        this.applicazione_cod = values[4].trim()
        this.applicazione_nome = values[5].trim()
        this.tipo_intervento = values[6].trim()
        this.tipo_passaggio = values[7].trim()
        this.referente_nome = values[8].trim()
        this.referente_cognome = values[9].trim()
        this.referente_username = values[10].trim()
        this.referente_email = values[11].trim()
        this.descrizione_change = values[12].trim()
        this.stato_rfc = values[13].trim()
    }

    //: contiene il codice rfc, char(50), contiene per esempio 2020000085318
    String codice_rfc
    //contiene l’ambiente target del change, con dominio: “Test”, “Prod”, “Rollout”
    String ambiente
    //contiene la data con cui è stato dichiarato l’inizio del change (formato timestamp)
    String dataora_iniziointervento
    //contiene la data con cui è stato dichiarato l’inizio del change (formato timestamp)
    String dataora_fineintervento
    //contiene l'applicazione in formato SEC da due cifre
    String applicazione_cod
    //contiene la descrizione dell’applicazione sec
    String applicazione_nome
    //dominio: Software, Parametri, Componente Tecnologica
    String tipo_intervento
    //dominio: “Applicativo”, “Infrastruttura”
    String tipo_passaggio
    String referente_nome
    String referente_cognome
    String referente_username
    String referente_email
    //descrizione del change in formato libero “ntext”
    String descrizione_change
    //approvato = “Esecuzione”
    String stato_rfc
    Timestamp inizioIntervento
    Timestamp fineIntervento

    boolean isValidRFC(String clusterType, def pipeline) {

        if (!(this.tipo_intervento == "Software" || this.tipo_intervento == "Parametri")) {
            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore tipo_intervento non permesso: ${this.tipo_intervento}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore tipo_intervento non permesso: ${this.tipo_intervento}")
            return false
        }

        if (!(this.tipo_passaggio == "Applicativo")) {
            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore tipo_passaggio non permesso: ${this.tipo_passaggio}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore tipo_passaggio non permesso: ${this.tipo_passaggio}")
            return false
        }

        if (!((this.ambiente == "Prod" && "prod" == clusterType)
                || (this.ambiente == "Rollout" && "preprod" == clusterType)
                || (this.ambiente == "Test" && "test" == clusterType))) {

            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore ambiente non permesso sul tipo cluster ${clusterType}: ${this.ambiente}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore ambiente non permesso sul tipo cluster ${clusterType}: ${this.ambiente}")
            return false
        }
        return true
    }


    boolean canProceedWithRFC(String clusterType, def pipeline) {
        Timestamp now = new Timestamp(System.currentTimeMillis())

        if (!(this.stato_rfc == "Esecuzione")) {
            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore stato_rfc non permesso: ${this.stato_rfc}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore stato_rfc non permesso: ${this.stato_rfc}")
            return false
        }

        if (!(this.tipo_intervento == "Software")) {
            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore tipo_intervento non permesso: ${this.tipo_intervento}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore tipo_intervento non permesso: ${this.tipo_intervento}")
            return false
        }

        if (!(this.tipo_passaggio == "Applicativo")) {
            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore tipo_passaggio non permesso: ${this.tipo_passaggio}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore tipo_passaggio non permesso: ${this.tipo_passaggio}")
            return false
        }

        if (!((this.ambiente == "Prod" && "prod" == clusterType)
                || (this.ambiente == "Rollout" && "preprod" == clusterType)
                || (this.ambiente == "Test" && "test" == clusterType))) {

            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore ambiente non permesso sul tipo cluster ${clusterType}: ${this.ambiente}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Valore ambiente non permesso sul tipo cluster ${clusterType}: ${this.ambiente}")
            return false
        }

        if (!(now.after(this.inizioIntervento))) {
            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Si deve attendere l'inizio della finestra temporale per l'intervento.\nOrario attuale:${now.toString()}, orario inizio finestra temporale per l'intervento: ${this.inizioIntervento.toString()}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. Si deve attendere l'inizio della finestra temporale per l'intervento.\nOrario attuale:${now.toString()}, orario inizio finestra temporale per l'intervento: ${this.inizioIntervento.toString()}")
            return false
        }

        if (!(now.before(this.fineIntervento))) {
            pipeline.echo("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. La finestra temporale per l'intervento è scaduta.\nOrario attuale:${now.toString()}, orario fine finestra temporale per l'intervento: ${this.fineIntervento.toString()}")
            //pipeline.error("Check RFC(codice_rfc: ${this.codice_rfc}) fallito. La finestra temporale per l'intervento è scaduta.\nOrario attuale:${now.toString()}, orario fine finestra temporale per l'intervento: ${this.fineIntervento.toString()}")
            return false
        }
        return true
    }
}