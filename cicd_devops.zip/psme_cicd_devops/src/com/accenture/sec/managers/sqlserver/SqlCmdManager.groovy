package com.accenture.sec.managers.sqlserver


import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.runners.ShRunner
import com.accenture.sec.utils.CommonUtils


class SqlCmdManager implements Serializable {

    private def pipeline
    private String sqlserver
    private String credsId
    private String database
    private boolean isSSL
    private boolean skipSSL
    private boolean skipBasicAuth
    private ShRunner shRunner

    SqlCmdManager(def pipeline, def config) {
        if (pipeline) {
            this.pipeline = pipeline
            this.sqlserver = config.sqlserver.server
            this.database = config.sqlserver.database
            this.credsId = config.sqlserver.credsId
            this.skipBasicAuth = config.sqlserver.skipBasicAuth
            this.shRunner = new ShRunner(pipeline)
        } else {
            StringBuffer buf = new StringBuffer()
            buf = buf.append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore!\nL'oggetto pipeline passato al SqlCmdManager è NULL!")
                    .append(CommonUtils.hrSeparator).append("\n")
            pipeline.echo "${buf.toString()}"
            pipeline.error()
        }

    }

    String executeQuery(def args){
        StringBuffer cmdLIne = new StringBuffer("""sqlcmd -S ${this.sqlserver} -d ${this.database} -s ";" -h -1 """)

        if(args.inputFile!=null && ""!=args.inputFile){
            cmdLIne.append(" -i ${args.inputFile}")
        }
        else if(args.query!=null && ""!=args.query){
            cmdLIne.append(" -Q \"${args.query}\"")
        }
        else this.pipeline.error()

        cmdLIne.append(" -o sql_out.txt")
        String printableCmdLine = cmdLIne.toString()
        if(this.skipBasicAuth == false){
            this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: this.credsId, passwordVariable: 'sqlSPwd', usernameVariable: 'sqlSUsr')]) {
                printableCmdLine = cmdLIne.toString()+" -U ***** -P *****"
                cmdLIne.append(" -U ${this.pipeline.env.sqlSUsr} -P ${this.pipeline.env.sqlSPwd}")
            }
        }
        this.pipeline.echo("Executing cmd as follows:\n${printableCmdLine}")

        RunnerResult result = this.shRunner.execWithStatus([cmd: cmdLIne.toString()])

        String out = this.pipeline.readFile("sql_out.txt")

        if(result.exitCode!=0){
            StringBuffer buf = new StringBuffer()
            buf = buf.append("\n").append(CommonUtils.hrSeparator).append("\n")
                    .append("Errore! Esecuzione di sqlcmd fallita!\nEseguito comando: ${printableCmdLine}\n")
                    .append("sqlcmd exit code: ").append(result.exitCode).append("\n")
                    .append("sqlcmd output: ").append(result.out).append("\n")
                    .append("sqlcmd output file content: \n").append(out).append("\n")
                    .append("sqlcmd err: ").append(result.err).append("\n")
                    .append(CommonUtils.hrSeparator).append("\n")
            this.pipeline.echo("${buf.toString()}")
            out = ""
            this.pipeline.error("${buf.toString()}")
        }
        return out
    }
}
