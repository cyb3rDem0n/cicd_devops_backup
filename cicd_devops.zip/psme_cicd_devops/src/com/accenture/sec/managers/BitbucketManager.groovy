package com.accenture.sec.managers

import com.accenture.sec.runners.CurlRunner
import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.utils.CommonUtils
import groovy.json.JsonOutput
import groovy.json.JsonSlurper


class BitbucketManager implements Serializable {

    private def pullRequestPayload = [
            "title"      : "",
            "description": "",
            "state"      : "OPEN",
            "open"       : true,
            "closed"     : false,

            "fromRef"    : [
                    "id"        : "",
                    "repository": [
                            "slug"   : "",
                            "name"   : "",
                            "project": [
                                    "key": ""
                            ]
                    ]
            ],

            "toRef"      : [
                    "id"        : "",
                    "repository": [
                            "slug"   : "",
                            "name"   : "",
                            "project": [
                                    "key": ""
                            ]
                    ]
            ],
            "locked"     : false,
            "reviewers"  : [
                    [
                            "user": [
                                    "name": "cb-devops-sa"
                            ]
                    ]
            ]
    ]

    private def setTagPayload = [
            "name"      : "",
            "startPoint": "",
            "message"   : ""
    ]

    private def ro_permissionsBranch = [
            "type"      : "read-only",
            "matcher"   : [
                    "id"       : null,
                    "displayId": null,
                    "type"     : [
                            "id"  : "BRANCH",
                            "name": "branch"
                    ],
                    "active"   : true
            ],
            "users"     : [],
            "groups"    : [],
            "accessKeys": []
    ]

    private deletePullRequestPayload = [ "version": null]

    private CurlRunner curlRunner
    private def pipeline

    /**
     * Constructor
     *
     * @param pipeline def object
     */
    BitbucketManager(def pipeline) {
        this.pipeline = pipeline
        this.curlRunner = new CurlRunner(pipeline,false)
    }

    private Object readJSONResponse(RunnerResult curlResult){
        def jsonCurlResponse = null
        if(curlResult.out!=null && ""!= curlResult.out){
            jsonCurlResponse = new JsonSlurper().parseText(curlResult.out)
        }
        else if(curlResult.err!=null && ""!= curlResult.err){
            jsonCurlResponse = new JsonSlurper().parseText(curlResult.err)
        }
        return jsonCurlResponse
    }
    LinkedHashMap<String, Object> pullRequest(LinkedHashMap<String, Object> args){

        LinkedHashMap<String, Object> result = null
        pullRequestPayload.title = "Automated Pull Request from branch release/${args.releaseNumber}"
        pullRequestPayload.fromRef.id = "${args.idFrom}"
        pullRequestPayload.fromRef.repository.slug = "${args.repoNameFrom}"
        pullRequestPayload.fromRef.repository.name = "${args.repoNameFrom}"
        pullRequestPayload.fromRef.repository.project.key = "${args.projectKeyFrom}"
        pullRequestPayload.toRef.id = "${args.idTo}"
        pullRequestPayload.toRef.repository.slug = "${args.repoNameTo}"
        pullRequestPayload.toRef.repository.name = "${args.repoNameTo}"
        pullRequestPayload.toRef.repository.project.key = "${args.projectKeyTo}"


        def payload = JsonOutput.toJson(pullRequestPayload)
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKeyTo}/repos/${args.repoNameTo}/pull-requests",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'POST',
                payload: payload
        ]
        RunnerResult curlResult = this.curlRunner.execWithStatus(curlParams)

        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 201:
                msg = "Pull request ${args.repoNameFrom} from ${args.idFrom} to ${args.repoNameTo} ${args.idTo} successful"
                result = new HashMap<String, Object>()
                result.put("pullRequestId", jsonCurlResponse.id)
                result.put("pullRequestVersion", jsonCurlResponse.version)
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                break
            case 400:
            case 401:
            case 404:
            case 409:
                msg = "Pull request ${args.repoNameFrom} from ${args.idFrom} to ${args.repoNameTo} ${args.idTo} unsuccessful \n"+
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                break
        }
        return result

    }

    LinkedHashMap<String, Object> getPullRequestInfo(Map<String, Object> args){
        LinkedHashMap<String, Object> result = null
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/${args.repoName}/pull-requests/${args.pullRequestId}",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'GET'
        ]
        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                msg = "Pull request info request for ${args.projectKey}/${args.repoName}/${args.pullRequestId}/${args.pullRequestVersion} successful"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                result = new HashMap<String, Object>()
                result.put("pullRequestId", jsonCurlResponse.id)
                result.put("pullRequestVersion", jsonCurlResponse.version)
                break
            case 401:
            case 404:
                msg = "Pull request info request for  ${args.projectKey}/${args.repoName}/${args.pullRequestId}/${args.pullRequestVersion} failed \n" +
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                break
        }
        return result
    }

    int deletePullRequest(Map<String, Object> args){
        int retVal = 1
        deletePullRequestPayload.version = args.pullRequestVersion
        def payload = JsonOutput.toJson(deletePullRequestPayload)

        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/${args.repoName}/pull-requests/${args.pullRequestId}",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'DELETE',
                payload: payload
        ]
        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 204:
                msg = "Delete pull request  ${args.projectKey}/${args.repoName}/${args.pullRequestId}/${args.pullRequestVersion} successful"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 0
                break
            case 401:
            case 404:
                msg = "Delete pull request  ${args.projectKey}/${args.repoName}/${args.pullRequestId}/${args.pullRequestVersion} failed \n" +
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 1
                break
        }
        return retVal

    }

    int approvePullRequest(Map<String, Object> args){
        int retVal = 1
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/${args.repoName}/pull-requests/${args.pullRequestId}/approve",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'POST',
        ]
        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                msg = "Pull request approve for ${args.projectKey}/${args.repoName}/${args.pullRequestId} successful"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 0
                break
            case 400:
            case 401:
            case 404:
            case 409:
                msg = "Pull request approve for ${args.projectKey}/${args.repoName}/${args.pullRequestId} failed \n"+
                        "ERROR: ${jsonCurlResponse.errors.message}\n${curlResult.getErr()}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 1
                break
        }
        return retVal
    }

    int removeApprovalPullRequest(Map<String, Object> args){
        int retVal = 1
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/${args.repoName}/pull-requests/${args.pullRequestId}/approve",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'DELETE',
        ]
        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                msg = "Pull request approval successfully removed for ${args.projectKey}/${args.repoName}/${args.pullRequestId} "
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 0
                break
            case 400:
            case 401:
            case 404:
            case 409:
                msg = "Pull request approval not removed for ${args.projectKey}/${args.repoName}/${args.pullRequestId} \n"+
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 1
                break
        }
        return retVal
    }

    String mergePullRequest(Map<String, Object> args){
        String mergeCommit = null
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/${args.repoName}/pull-requests/${args.pullRequestId}/merge?version=${args.pullRequestVersion}",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'POST'
        ]
        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                msg = "Pull request merge ${args.repoName} from refs/heads/release/${args.releaseNumber} to refs/heads/master successfully executed"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                mergeCommit = jsonCurlResponse.properties.mergeCommit.id
                break
            case 400:
            case 401:
            case 404:
            case 409:
                msg = "Pull request merge ${args.repoName} from refs/heads/release/${args.releaseNumber} to refs/heads/master \n"+
                        "ERROR: ${jsonCurlResponse.errors.message}\n${curlResult.out}\n${curlResult.err}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                break
        }
        return mergeCommit
    }

    String getLatestCommitHash(Map<String, Object> args){
        String retVal = null
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/${args.repoName}/commits?until=deploy&limit=0&start=0",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'POST',
        ]

        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                msg = "Latest commit on ${args.repoName} from refs/heads/release/${args.releaseNumber} read successfully"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = jsonCurlResponse.values.id
                break
            case 400:
            case 401:
            case 404:
                msg = "Can't read latest commit on  ${args.repoName} from refs/heads/release/${args.releaseNumber}\n"+
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                break
        }
        return retVal

    }

    int setTag(Map<String, Object> args){
        int retVal = 1
        setTagPayload.startPoint = "${args.commitId}"
        setTagPayload.name = "${args.releaseNumber}"
        setTagPayload.message = "Versione ${args.releaseNumber}"

        def payload = JsonOutput.toJson(setTagPayload)
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/${args.repoName}/tags",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'POST',
                payload: payload
        ]

        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                msg = "Set Tag on ${args.repoName} successfully executed"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 0
                break
            case 400:
                msg = "Set tag ${args.repoName} unsuccessful\n"+
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 1
                break
        }
        return retVal
    }

    int deleteTag(Map<String, Object> args){
        int retVal = 1
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/${args.repoName}/tags/${args.tag}",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'DELETE'
        ]

        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                msg = "Deleted Tag on ${args.repoName} successfully executed"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "deleteTag: ${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 0
                break
            case 400:
                msg = "Tag ${args.repoName} cannot be deleted\n"+
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 1
                break
        }
        return retVal
    }

    int setReadOnlyBranchPermissions(Map<String, Object> args){
        int retVal = 1
        this.ro_permissionsBranch.matcher.id = "refs/heads/${args.branch}"
        this.ro_permissionsBranch.matcher.displayId = "refs/heads/${args.branch}"


        def payload = JsonOutput.toJson(this.ro_permissionsBranch)
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/branch-permissions/2.0/projects/${args.projectKey}/repos/${args.repoName}/restrictions",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                payload: payload,
                method : 'POST'
        ]
        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                msg = "Restrictions successfully applied on ${args.repoName}  refs/heads/release/${args.releaseNumber}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 0
                break
            case 400:
            case 401:
            case 404:
            case 409:
                msg = "Restrictions not applied on ${args.repoName}  refs/heads/release/${args.releaseNumber}\n"+
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                retVal = 1
                break
        }
        return retVal
    }

    String getCloneUrl(Map<String, Object> args){
        String cloneUrl = null
        def curlParams =[
                url    : "http://git.secreloaded.sec/rest/api/1.0/projects/${args.projectKey}/repos/",
                headers: [
                        "Authorization: Bearer ${args.BITBUCKET_TOKEN}",
                        "Content-Type: application/json",
                ],
                method : 'GET'
        ]
        RunnerResult curlResult = curlRunner.execWithStatus(curlParams)
        def jsonCurlResponse = readJSONResponse(curlResult)
        String msg
        switch(curlResult.exitCode){
            case 200:
                jsonCurlResponse.values.each{ repository ->
                    if(repository.slug == args.repoName){
/*                        repository.links.clone.each{ cloneLink ->
                            if(cloneLink.name == "ssh"){
                                cloneUrl = cloneLink.href
                            }
                        }
                        if (cloneUrl == null){*/
                            repository.links.clone.each{ cloneLink ->
                                if(cloneLink.name == "http" || cloneLink.name == "https"){
                                    cloneUrl = cloneLink.href
                                }
                            }
                        //}
                    }
                }
                msg = "Clone url for repository ${args.repoName} acquired:\n${cloneUrl}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                break
            case 401:
            case 404:
                msg = "Clone url for repository ${args.repoName} not acquired\n"+
                        "ERROR: ${jsonCurlResponse.errors.message}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                this.pipeline.echo "${msg}"
                this.pipeline.echo "${CommonUtils.hrSeparator}"
                break
        }
        return cloneUrl
    }
}
