package com.accenture.sec.managers

import com.accenture.sec.runners.CurlRunner
import com.accenture.sec.runners.ShRunner
import com.accenture.sec.utils.CommonUtils


import java.util.regex.Pattern

/**
 * SonarManager - class to manage Nexus integration with API
 */
class SonarManager implements Serializable {

    private def pipeline
    private String token
    private String sonarURL
    private String taskId

    SonarManager(def pipeline, String sonarURL, String token = null) {
        this.pipeline = pipeline
        this.sonarURL = sonarURL
        this.token = token
    }

    def scanWithMaven(Map args) {
        CommonUtils.checkInputParameters(args, 'sonarProjectKey')
        def token = (args.token ?: this.token)
        def exclusions = ''
        // al momento vengono gestite internamente al pom.xml
//        if (args.exclusions) {
//            exclusions = "-Dsonar.coverage.exclusions=${args.exclusions.join(',')}"
//        }
        def branch = ''
        if(!CommonUtils.isNullOrEmpty(args.branch)){
            branch = "-Dsonar.branch.name=${args.branch}"
            if(!CommonUtils.isNullOrEmpty(args.targetBranch)){
                branch += " -Dsonar.branch.target=${args.targetBranch}"
            }
        }
        def version = !CommonUtils.isNullOrEmpty(args.projectVersion) ? "-Dsonar.projectVersion=${args.projectVersion}" : ''
        def pr = ''
        if(!CommonUtils.isNullOrEmpty(args.prKey)){
            pr = "-Dsonar.pullrequest.key=${args.prKey}"
            !CommonUtils.isNullOrEmpty(args.prBranch) && (pr += " -Dsonar.pullrequest.branch=${args.prBranch}")
            !CommonUtils.isNullOrEmpty(args.prTarget) && (pr += " -Dsonar.pullrequest.base=${args.prTarget}")
        }
        def cmd = "mvn sonar:sonar -Dsonar.projectKey=${args.sonarProjectKey} " +
                "-Dsonar.projectName=${args.sonarProjectName ?: args.sonarProjectKey} " +
                "-Dsonar.host.url=${this.sonarURL} -DskipTests=true -Dsonar.login=${token} " +
                "-Dsonar.sourceEncoding=UTF-8 ${pr} ${branch} ${version} ${exclusions}"
        this.pipeline.echo("Running Sonar Scan with Maven ...")
        (new ShRunner(this.pipeline)).exec(cmd)
        setTaskId()
    }

    def scanWithNpm(Map args) {
        CommonUtils.checkInputParameters(args, 'sonarProjectKey')
        def token = (args.token ?: this.token)
        this.pipeline.sh("npm install sonarqube-scanner@2.5.0 --save-dev")
        //devDependencies --> "sonarqube-scanner": "^2.5.0",
        def inclusions = (args.inclusions ?: 'src/**,server/**')
        def exclusions = (args.exclusions ?: '')
        //def branch = !CommonUtils.isNullOrEmpty(args.branch) ? "'sonar.branch.name': '${args.branch}'," : ''
        def branch = ''
        if(!CommonUtils.isNullOrEmpty(args.branch)){
            branch = "'sonar.branch.name': '${args.branch}',"
            if(!CommonUtils.isNullOrEmpty(args.targetBranch)){
                branch += "\n'sonar.branch.target': '${args.targetBranch}',"
            }
        }
        def pr = ''
        if(!CommonUtils.isNullOrEmpty(args.prKey)){
            pr = "'sonar.pullrequest.key': '${args.prKey}',"
            !CommonUtils.isNullOrEmpty(args.prBranch) && (pr += "\n'sonar.pullrequest.branch': '${args.prBranch}',")
            !CommonUtils.isNullOrEmpty(args.prTarget) && (pr += "\n'sonar.pullrequest.base': '${args.prTarget}',")
        }
        def version = !CommonUtils.isNullOrEmpty(args.projectVersion) ? "'sonar.projectVersion': '${args.projectVersion}'," : ''
        def configFile = """
const sonarqubeScanner = require('sonarqube-scanner');
     sonarqubeScanner({
        serverUrl: '${this.sonarURL}',
        token : "${token}",
        options : {
        'sonar.projectKey': '${args.sonarProjectKey}',
        'sonar.projectName': '${args.sonarProjectName ?: args.sonarProjectKey}',
        'sonar.sourceEncoding': 'UTF-8',
        'sonar.sources': '.',
        ${branch}
        ${pr}
        ${version}
        'sonar.inclusions' : '${inclusions}', // Entry point of your code
        'sonar.exclusions' : '${exclusions}'
        }
     }, () => {});
"""
        this.pipeline.writeFile(file: 'sonar-project.js', text: configFile)
        def JAVA_TOOL_OPTIONS = this.pipeline.env.JAVA_TOOL_OPTIONS
        this.pipeline.env.JAVA_TOOL_OPTIONS = ''
        def cmd = """npm run sonar --if-present"""
        //def cmd = "node sonar-project.js"
        this.pipeline.echo("Running Sonar Scan with NPM ...")
        def shRunner = (new ShRunner(this.pipeline))
        shRunner.exec(cmd)
        setTaskId()
        shRunner.exec('rm -rf sonar-project.js')
        this.pipeline.env.JAVA_TOOL_OPTIONS = JAVA_TOOL_OPTIONS
    }

    private void setTaskId() {
        List reports = ["target/sonar/report-task.txt", ".scannerwork/report-task.txt"]
        def reportPath = null
        for (file in reports) {
            if (this.pipeline.findFiles(glob: file).size() > 0) {
                reportPath = file
                break
            }
        }
        def report = this.pipeline.readFile(file: reportPath)
        def matcher = Pattern.compile(/ceTaskId=(.+)/).matcher(report)
        if (matcher.size() > 0)
            this.taskId = (matcher[-1][1]).toString()
    }

    def waitForQualityGate(boolean isBlocker = false) {
        if (!this.taskId) {
            if(isBlocker){
                throw new SonarManagerException("Sonar QualityGate is blocker but no taskid is stored for scan. Something went wrong.")
            }
            this.pipeline.echo("[SonarManager] WARNING - No taskId stored for SonarQube scan")
            return
//            throw new SonarManagerException("No taskId stored")
        }
        CurlRunner curlRunner = new CurlRunner(this.pipeline, true)
        def cmd = "-u ${this.token}: ${this.sonarURL}/api/ce/task?id=${this.taskId} 2>/dev/null"
        this.pipeline.echo("Waiting for Sonar QualityGate with taskId '${this.taskId}' ...")
        def sonarRes = CommonUtils.parseJson(curlRunner.exec(cmd, true).toString())
        while (!['SUCCESS', 'FAILED', 'CANCELED'].contains(sonarRes.task.status)) {
            this.pipeline.echo("Waiting for Sonar QualityGate with taskId '${this.taskId}' ...")
            this.pipeline.sleep(5)
            sonarRes = CommonUtils.parseJson(curlRunner.exec(cmd, true).toString())
        }

        cmd = "-u ${this.token}: ${this.sonarURL}/api/qualitygates/project_status?analysisId=${sonarRes.task.analysisId} 2>/dev/null"
        def res = CommonUtils.parseJson(curlRunner.exec(cmd, true).toString())

        this.pipeline.echo("Sonar QualityGate state is '${res.projectStatus.status}'")
        def label
        switch (res.projectStatus.status) {
            case 'ERROR':
                label = 'Failed'
                break
            case 'OK':
                label = 'Success'
                break
            case 'NONE':
                label = 'None'
                break
            case 'WARN':
                label = 'Warning'
                break
            default:
                label = res.projectStatus.status
        }
        if(isBlocker && res.projectStatus.status == 'ERROR'){
            throw new SonarManagerException("Sonar QualityGate state is failed and is blocker", [status: res.projectStatus.status, label: label, conditions: res.projectStatus.conditions])
        }
        return [status: res.projectStatus.status, label: label, conditions: res.projectStatus.conditions]
    }

    static def isQualityGateBlocker(List rules, String checkStr){
        boolean isGateBlocker = false
        for (rule in rules) {
            if (rule instanceof Map && rule.regex) {
                isGateBlocker = (checkStr).matches(rule.regex as String)
            }else{
                isGateBlocker = (checkStr == rule)
            }
            if (isGateBlocker)
                break
        }
        return isGateBlocker
    }

    class SonarManagerException extends Exception {

        def qgResult

        SonarManagerException(def message) {
            super(message)
            this.qgResult = null
        }

        SonarManagerException(def message, qgResult) {
            super(message)
            this.qgResult = qgResult
        }
    }

}
