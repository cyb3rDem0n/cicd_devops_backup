package com.accenture.sec.runners

interface IRunner extends Serializable {

    /**
     * Metodo di definizione delle operazioni che il runner dovrà compiere.
     */
    def exec(def args, boolean getOutput)

}