package com.accenture.sec.runners




class ScpRunner implements IRunner {

    def pipeline
    RunnerResult lastResult
    ShRunner shRunner
    def keyFilePath
    def username

    ScpRunner(def pipeline) {
        this(pipeline, false)
    }

    ScpRunner(def pipeline, boolean silent) {
        this.shRunner = new ShRunner(pipeline, silent)
        this.pipeline = pipeline
    }

    def setExistingKeyFile(def keyFilePath, def user){
        this.username = user
        this.keyFilePath = keyFilePath
    }

    def initKeyFile(def credsId, def user) {
        def keyFileName = "private_key_${System.currentTimeMillis()}"
        def userVarName = "user_${System.currentTimeMillis()}"
        this.retry {
            this.pipeline.withCredentials([this.pipeline.sshUserPrivateKey(credentialsId: credsId, keyFileVariable: keyFileName, passphraseVariable: '', usernameVariable: userVarName)]) {
                this.username = (user ?: this.pipeline.env.getProperty(userVarName))
                this.pipeline.sh("""#!/bin/bash
if [[ ! -f ${this.pipeline.env.WORKSPACE}/${credsId} ]]; then
    cp -rf ${this.pipeline.env.getProperty(keyFileName)} ${this.pipeline.env.WORKSPACE}/${credsId}
    chmod 400 ${this.pipeline.env.WORKSPACE}/${credsId}
fi
""")
            }
        }
        this.keyFilePath = "${this.pipeline.env.WORKSPACE}/${credsId}"
    }

    @Override
    Object exec(Object cmd, boolean getOutput) {
        cmd = "${cmd}"
        return this.shRunner.exec(cmd, getOutput)
    }

    RunnerResult execWithStatus(Map args) {
        String cmd = prepareFormatCmd(args)
        RunnerResult result = null
        if (args.credsId) {
            def keyFileName = "private_key_${System.currentTimeMillis()}"
            def userVarName = "user_${System.currentTimeMillis()}"
            this.pipeline.withCredentials([this.pipeline.sshUserPrivateKey(credentialsId: args.credsId, keyFileVariable: keyFileName, passphraseVariable: '', usernameVariable: userVarName)]) {
//                cmd += "-i ${this.pipeline.env.private_key} ${cp}"
//                cmd = String.format(cmd, this.pipeline.env.usr.toString())
                args.user = (args.user ?: this.pipeline.env.getProperty(userVarName))
                cmd = String.format(cmd, this.pipeline.env.getProperty(keyFileName), args.user)
                this.retry {
                    result = this.shRunner.execWithStatus([cmd: cmd, silent: args.silent, errSeparated: args.errSeparated, getOutput: args.getOutput])
                }
            }
        } else if (args.user && args.keyFilePath) {
//            cmd += "-i ${args.keyFilePath} ${cp}"
//            cmd = String.format(cmd.toString(), args.user)
            cmd = String.format(cmd, args.keyFilePath, args.user)
            this.retry {
                result = this.shRunner.execWithStatus([cmd: cmd, silent: args.silent, errSeparated: args.errSeparated, getOutput: args.getOutput])
            }
        } else {
            args.user = (args.user ?: this.username)
            cmd = String.format(cmd, this.keyFilePath, args.user)
            this.retry {
                result = this.shRunner.execWithStatus([cmd: cmd, silent: args.silent, errSeparated: args.errSeparated, getOutput: args.getOutput])
            }
        }
        this.lastResult = result
        return result
    }

    private String prepareFormatCmd(Map args) {
        def cmd = "scp "
        args.options?.each { k, v ->
            cmd += "-o '${k}=${v}' "
        }
        cmd += "-i %s "

        def rmt = args.source.remoteHost ? "%s@${args.source.remoteHost}:" : ""
        if (!args.source.remoteHost && args.source.path instanceof List)
            args.source.path.each { cmd += "${rmt}${it} " }
        else if (args.source.dir) {
            cmd += "-r "
            cmd += "${rmt}${args.source.dir} "
        } else
            cmd += "${rmt}${args.source.path} "
        if (rmt != '' && args.target.remoteHost)
            throw new Exception("Remote2Remote not supported")
        rmt = args.target.remoteHost ? "%s@${args.target.remoteHost}:" : ""
        cmd += "${rmt}${args.target.dir ?: args.target.path} "
        return cmd.toString()
    }

    void execWithException(String cmd, Map args) throws Exception {
        super.execWithException(cmd, args)
    }

    private def retry(callback) {
        Map args = [:]
        args.retryNumber = 15
        args.skipExceptions = [NotSerializableException.class]
        args.skipExceptionsMessage = ['FastPipedInputStream']

        int i = 1
        boolean ok = false
        boolean skip
        Exception exception = null
        while (!ok && (i <= (args.retryNumber as int))) {
            if (ok)
                break
            skip = false
            try {
                callback()
                ok = true
            } catch (Exception e) {
                if (e.getClass() in args.skipExceptions && i <= (args.retryNumber as int)) {
                    args.skipExceptionsMessage.each { msg ->
                        if (e.getMessage().contains(msg as String)) {
                            this.pipeline.echo("${e.getMessage()}\nRetrying ${i}")
                            skip = true
                        }
                    }
                }
                if (!skip) {
                    throw e
                }
                exception = e
            }
            if (ok) break
            i++
            Thread.sleep(((new Random()).nextInt(10) ?: 1) * 1000)
//            this.retry {
//                this.pipeline.sleep((new Random()).nextInt(10) ?: 1)
//            }
        }
        if (!ok && (i > (args.retryNumber as int))) {
            throw exception
        }
    }
}
