package com.accenture.sec.runners

class RunnerResult implements Serializable {
    String out
    String err
    String outFile
    String errFile
    Integer exitCode

    RunnerResult(String out, Integer exitCode) {
        this.out = out
        this.err = null
        this.exitCode = exitCode
    }

    RunnerResult(String out, String err, Integer exitCode) {
        this.out = out
        this.err = err
        this.exitCode = exitCode
    }

    Map toMap() {
        return [exitCode: this.exitCode, outFile: this.outFile, out: this.out, errFile: this.errFile, err: this.err]
    }

}
