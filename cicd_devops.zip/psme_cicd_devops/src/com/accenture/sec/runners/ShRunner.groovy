package com.accenture.sec.runners

import com.accenture.sec.utils.CommonUtils


/**
 * MavenRunner - Class runner for maven command
 */
class ShRunner implements IRunner {

    def pipeline
    RunnerResult lastResult

    boolean silent

    ShRunner(def pipeline) {
        this(pipeline, false)
    }

    ShRunner(def pipeline, boolean silent) {
        this.pipeline = pipeline
        this.silent = silent
    }

    /**
     * Execute the mvn command passing to it the target, options and paramenters defined in args
     *
     * @param args contains all the parameters to be passed to the mvn call
     *              [target: 'clean', options:['-X'], paramenters:['skipTest':true]]
     * @return
     */
    @Override
    Object exec(def cmd, boolean getOutput = false) {
        if (!(cmd instanceof String) && !(cmd instanceof GString))
            throw new IllegalArgumentException("'cmd' argument must be a String")
        !silent && this.pipeline.echo("${cmd}")
        def out = this.pipeline.sh(returnStdout: getOutput, script: """#!/bin/bash -e
            ${cmd}
        """)
        if (getOutput)
            return out.trim()
        return null
    }

    void execWithException(String cmd, Map args = null) throws Exception {
        def outFile = "${cmd.hashCode().abs()}.out.log"
        def errFile = "${cmd.hashCode().abs()}.err.log"
        def redirectErr = args?.errSeparated ? "2> ${errFile}" : "2>&1"
        def redirect = args?.silent ? "> ${outFile} ${redirectErr}" : "${redirectErr} | tee ${outFile}"

        this.pipeline.echo("Running: ${cmd}")
        def status = this.pipeline.sh(script: """#!/bin/bash -e
                ${cmd} ${redirect}
                exit \${PIPESTATUS[0]}
            """, returnStatus: true, returnStdout: false)
        RunnerResult result = new RunnerResult(this.pipeline.readFile(outFile), status)
        if (args?.errSeparated)
            result.err = this.pipeline.readFile(errFile)

        lastResult = result
//        this.pipeline.sh("""#!/bin/bash
//rm -f ${outFile} ${errFile} || true""")
        if (status > 0) {
            throw new Exception("error ${status}")
        }
    }

    RunnerResult execWithStatus(Map args) {
        CommonUtils.checkInputParameters(args, 'cmd')
        def outFile = "${args.cmd.hashCode().abs()}.out.log"
        def errFile = "${args.cmd.hashCode().abs()}.err.log"
        def exitPipe = args?.exitPipe ?: 0
        def redirectErr = args?.errSeparated ? "2> ${errFile}" : "2>&1"
        def redirect = args?.silent ? "> ${outFile} ${redirectErr}" : "${redirectErr} | tee ${outFile}"
        def getOutput = args?.getOutput != null ? args.getOutput : true
        if(!getOutput){
            redirect = ""
        }
        def getErr = args?.getErr != null ? args.getErr : false
        this.pipeline.echo("Running: ${args.cmd}")
        def status = this.pipeline.sh(script: """#!/bin/bash -e
                ${args.cmd} ${redirect}
                exit \${PIPESTATUS[${exitPipe}]}
            """, returnStatus: true, returnStdout: false)
        RunnerResult result = null
        if (getOutput) {
            def out = this.pipeline.readFile(outFile)
            result = new RunnerResult(out as String, status as Integer)
            if (args?.errSeparated && getErr)
                result.err = this.pipeline.readFile(errFile)
        } else {
            result = new RunnerResult(null, status as Integer)
        }
        if(getOutput && !result.out && !result.err) {
            def pwd = this.pipeline.pwd()
            if (args?.errSeparated)
                result.errFile = "${pwd}/${errFile}"
            result.outFile = "${pwd}/${outFile}"
        }

        lastResult = result
//        this.pipeline.sh("""#!/bin/bash \nrm -f ${outFile} ${errFile} || true""")
        return result
    }

}

