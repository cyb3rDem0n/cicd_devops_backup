package com.accenture.sec.runners



class SshRunner implements IRunner {

    def pipeline
    RunnerResult lastResult
    def keyFilePath
    def username

    ShRunner shRunner

    SshRunner(def pipeline) {
        this(pipeline, false)
    }

    SshRunner(def pipeline, boolean silent) {
        this.shRunner = new ShRunner(pipeline, silent)
        this.pipeline = pipeline
        this.keyFilePath = null
        this.username = null
    }

    def setExistingKeyFile(def keyFilePath, def user){
        this.username = user
        this.keyFilePath = keyFilePath
    }

    def initKeyFile(def credsId, def user) {
        def keyFileName = "private_key_${System.currentTimeMillis()}"
        def userVarName = "user_${System.currentTimeMillis()}"
        this.retry {
            this.pipeline.withCredentials([this.pipeline.sshUserPrivateKey(credentialsId: credsId, keyFileVariable: keyFileName, passphraseVariable: '', usernameVariable: userVarName)]) {
                this.username = (user ?: this.pipeline.env.getProperty(userVarName))
                this.pipeline.sh("""#!/bin/bash
if [[ ! -f ${this.pipeline.env.WORKSPACE}/${credsId} ]]; then
    cp -rf ${this.pipeline.env.getProperty(keyFileName)} ${this.pipeline.env.WORKSPACE}/${credsId}
    chmod 400 ${this.pipeline.env.WORKSPACE}/${credsId}
fi
""")
            }
        }
        this.keyFilePath = "${this.pipeline.env.WORKSPACE}/${credsId}"
    }

    @Override
    Object exec(Object cmd, boolean getOutput) {
        cmd = "${cmd}"
        return this.shRunner.exec(cmd, getOutput)
    }

    RunnerResult execWithStatus(Map args) {
        def cmd = "ssh -T "
        args.options?.each { k, v ->
            cmd += "-o '${k}=${v}' "
        }
        def remoteCmd = ""
        def scriptFile = null
        int exitPipe = 0
        if (args.script) {
            exitPipe = 1
            scriptFile = "sshScript-${args.hashCode().abs()}.sh"
            this.retry {
                this.pipeline.sh("#!/bin/bash \nrm -rf ${scriptFile} || true")
                this.pipeline.writeFile(file: scriptFile, text: args.script)
            }
            cmd = "cat ${scriptFile} | ${cmd}"
            //this.pipeline.debug("cat ${scriptFile}:\n${args.script}")
        } else if (args.remoteCmd) {
            remoteCmd = "\"${args.remoteCmd.replaceAll(/\$/, /\\\$/)}\""
            //this.pipeline.debug("remoteCmd:\n${remoteCmd}")
        }
        RunnerResult result = null
        if (args.credsId) {
            def keyFileName = "private_key_${System.currentTimeMillis()}"
            def userVarName = "user_${System.currentTimeMillis()}"
            this.pipeline.withCredentials([this.pipeline.sshUserPrivateKey(credentialsId: args.credsId, keyFileVariable: keyFileName, passphraseVariable: '', usernameVariable: userVarName)]) {
                args.user = (args.user ?: this.pipeline.env.getProperty(userVarName))
                remoteCmd = remoteCmd.replace('{{user}}', args.user)
                cmd += "-i ${this.pipeline.env.getProperty(keyFileName)} ${args.user}@${args.host} ${remoteCmd} "
                this.retry {
                    result = this.shRunner.execWithStatus([cmd: cmd, exitPipe: exitPipe, silent: args.silent, errSeparated: args.errSeparated, getOutput: args.getOutput])
                }
            }
            this.pipeline.debug("${cmd}")
        } else if (args.user && args.keyFilePath) {
            remoteCmd = remoteCmd.replace('{{user}}', args.user)
            cmd += "-i ${args.keyFilePath} ${args.user}@${args.host} ${remoteCmd} "
            this.retry {
                result = this.shRunner.execWithStatus([cmd: cmd, exitPipe: exitPipe, silent: args.silent, errSeparated: args.errSeparated, getOutput: args.getOutput])
            }
        } else {
            args.user = (args.user ?: this.username)
            remoteCmd = remoteCmd.replace('{{user}}', args.user)
            cmd += "-i ${this.keyFilePath} ${args.user}@${args.host} ${remoteCmd} "
            this.retry {
                result = this.shRunner.execWithStatus([cmd: cmd, exitPipe: exitPipe, silent: args.silent, errSeparated: args.errSeparated, getOutput: args.getOutput])
            }
        }
        this.lastResult = result
        //args.script && this.pipeline.sh("#!/bin/bash \nrm -rf ${scriptFile} || true")
        return result
    }

    void execWithException(String cmd, Map args) throws Exception {
        this.shRunner.execWithException(cmd, args)
    }

    private def retry(callback) {
        Map args = [:]
        args.retryNumber = 15
        args.skipExceptions = [NotSerializableException.class]
        args.skipExceptionsMessage = ['FastPipedInputStream']

        int i = 1
        boolean ok = false
        boolean skip
        Exception exception = null
        while (!ok && (i <= (args.retryNumber as int))) {
            if (ok)
                break
            skip = false
            try {
                callback()
                ok = true
            } catch (Exception e) {
                if (e.getClass() in args.skipExceptions && i <= (args.retryNumber as int)) {
                    args.skipExceptionsMessage.each { msg ->
                        if (e.getMessage().contains(msg as String)) {
                            this.pipeline.echo("${e.getMessage()}\nRetrying ${i}")
                            skip = true
                        }
                    }
                }
                if (!skip) {
                    throw e
                }
                exception = e
            }
            if (ok) break
            i++
            Thread.sleep(((new Random()).nextInt(9) + 1) * 1000)
//            this.retry {
//                this.pipeline.sleep((new Random()).nextInt(10) ?: 1)
//            }
        }
        if (!ok && (i > (args.retryNumber as int))) {
            throw exception
        }
    }
}
