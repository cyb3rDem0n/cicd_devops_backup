package com.accenture.sec.runners

import com.accenture.sec.utils.CommonUtils


/**
 * MavenRunner - Class runner for maven command
 */
class CurlRunner implements IRunner {

    def pipeline
    RunnerResult lastResult
    boolean silent

    CurlRunner(def pipeline, boolean silent=false) {
        this.pipeline = pipeline
        this.silent = silent
    }

    /**
     *
     * @return
     */
    @Override
    Object exec(def cmd, boolean getOutput = false) {
        return (new ShRunner(this.pipeline, this.silent)).exec("curl ${cmd}", getOutput)
    }

    /**
     * Execute a curl returning stdout, stderr and http_code in a RunnerResult obj.
     *
     * @param args accept a Map with params for the curl
     *              Accepted: - url [String] (MANDATORY)
     *                        - method [String] (MANDATORY)
     *                        - auth [String] -> [username:password]
     *                        - form [List] -> ['key=value',]
     *                        - headers [List] -> ['Accept: application/json',]
     *                        - payload [String]
     *                        - cacert [String]
     *                        - skipSSL [boolean]
     * @return
     */
    RunnerResult execWithStatus(Map args) {
        CommonUtils.checkInputParameters(args,'url,method')

        def outFile = "out-${args.hashCode().abs()}.log"
        def errFile = "err-${args.hashCode().abs()}.log"

        // Costruisce il comando curl da lanciare
        def cmd = "curl -X ${args.method} -sw '%{http_code}' -o ${outFile} "
        if(args.auth){
            cmd += """-u "${args.auth}" """
        }
        if(args.cacert){
            cmd += "--cacert ${args.cacert} "
        }
        if(args.form){
            args.form.each{ f ->
                cmd += """-F "${f}" """
            }
        }
        if(args.headers){
            args.headers.each{ h ->
                cmd += """-H "${h}" """
            }
        }
        if(args.payload){
            cmd += """--data '${args.payload}' """
        }
        if(args.skipSSL){
            cmd += """-k """
        }
        cmd += """${args.url} 2> ${errFile}"""

        try{
            // Lancia il comando e cattura l'output
            def code = (new ShRunner(this.pipeline, this.silent)).exec(cmd, true)
            // colleziona l'output e l'http_code in un RunnerResult
            RunnerResult result = new RunnerResult(this.pipeline.findFiles(glob: outFile).size() > 0 ? this.pipeline.readFile(outFile):'',
                    code as Integer)
            if(this.pipeline.findFiles(glob: errFile).size() > 0)
                result.err = this.pipeline.readFile(errFile)

            // Imposta lastResult
            lastResult = result

            // Pulisce i file di log
//            this.pipeline.sh("""#!/bin/bash
//rm -f ${outFile} ${errFile} || true""")
            return result
        }catch (Exception e){
            RunnerResult result = new RunnerResult(this.pipeline.findFiles(glob: outFile).size() > 0 ? this.pipeline.readFile(outFile):'',
                    0)
            if(this.pipeline.findFiles(glob: errFile).size() > 0)
                result.err = this.pipeline.readFile(errFile)

            lastResult = result
//            this.pipeline.sh("""#!/bin/bash
//rm -f ${outFile} ${errFile} || true""")
            throw e
        }
    }

}

