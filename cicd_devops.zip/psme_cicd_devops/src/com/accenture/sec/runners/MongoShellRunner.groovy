package com.accenture.sec.runners

import com.accenture.sec.utils.CommonUtils


/**
 * MavenRunner - Class runner for maven command
 */
class MongoShellRunner implements IRunner {

    def pipeline
    RunnerResult lastResult

    MongoShellRunner(def pipeline) {
        this.pipeline = pipeline
    }

    /**
     *
     * @return
     */
    @Override
    Object exec(def args, boolean getOutput) {
        String response = this.pipeline.sh(returnStdout: true, script: """#!/bin/bash -x
mongo ${args.mongoUrl} -u '${args.mongo_user}' -p '${args.mongo_pwd}' --quiet ${args.assert_path}""")
        if(args.isCount){
            int nrecords = Integer.parseInt(response.trim())
            return  nrecords
        }
        else{
            def jsonObj
            jsonObj = this.pipeline.readJSON text: response
            return  jsonObj
        }
    }

}

