package com.accenture.sec.utils.version

import java.util.regex.Pattern

class VersionPattern implements IVersionPattern{

    String version
    String versionPattern
    static ArrayList<VersionElement> versionElements

    /**
     *
     * @param version Versione in forma di stringa
     * @param versionPattern pattern da applicare in formato stringa
     *
     * esempio di pattern \\d+\\.\\d+\\.\\d+-b\\d+ matches 1.1.1-b1
     */
    VersionPattern(String version, String versionPattern, List<String> fields){
        this.version = version
        this.versionPattern = versionPattern
        versionElements = new ArrayList<VersionElement>()
        for(String field: fields){
            versionElements.add(new VersionElement(field))
        }
    }

    /**
     *
     * @param toMatch stringa su cui eseguire il match con versionPattern passato al costruttore
     * @return true se toMatch contiene il pattern cercato
     */
    @Override
    boolean matchesVersion(){
        return Pattern.compile(versionPattern).matcher(this.version).matches();
    }

    /**
     *
     * @return la rappresentazione come Map di version in base agli elementi dichiarati in versionElements
     */
    @Override
    Map<String, Object> versionToMap(){
        Scanner scanner = new Scanner(this.version)
        HashMap versionMap = new HashMap()
        for(VersionElement element : versionElements){
            versionMap.put(element.versionElement, scanner.nextInt())
        }
        return versionMap
    }

    /**
     *
     * @return la rappresentazione come Map di version in base agli elementi dichiarati in versionElements
     */
    @Override
    Version toVersion(){
        Scanner scanner = new Scanner(this.version)
        Version version = new Version()
        for(VersionElement element : versionElements){
            switch(element.versionElement){
                case "major":
                    version.major = scanner.nextInt()
                    break
                case "minor":
                    version.minor = scanner.nextInt()
                    break
                case "fix":
                    version.fix = scanner.nextInt()
                    break
                case "build":
                    version.minor = scanner.nextInt()
                    break
            }
        }
        return version
    }

}
