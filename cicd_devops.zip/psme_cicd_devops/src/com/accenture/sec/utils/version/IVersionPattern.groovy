package com.accenture.sec.utils.version

interface IVersionPattern {

    /**
     *
     * @param toMatch stringa su cui eseguire il match con versionPattern passato al costruttore
     * @return true se toMatch contiene il pattern cercato
     */
    boolean matchesVersion()

    /**
     *
     * @return la rappresentazione come Map di version in base agli elementi dichiarati in versionElements
     */
    Map<String, Object> versionToMap()

    Version toVersion()
}