package com.accenture.sec.utils.version

import java.util.regex.Pattern

class CBVersionPattern extends VersionPattern implements IVersionPattern{

    /**
     *
     * @param version Versione in forma di stringa
     * @param versionPattern pattern da applicare in frmato stringa
     *
     * esempio di pattern R\\d+\\.\\d+\\.\\d+-\\d+ matches R1.1.1-1
     */
    CBVersionPattern(Object version, Object versionPattern, List<String> fields) {
        super(version, versionPattern, fields)
    }
    @Override
    boolean matchesVersion(){
        return super.matchesVersion()
    }

    /**
     *
     * @return la rappresentazione come Map di version in base agli elementi dichiarati in versionElements
     */
    @Override
    Map<String, Object> versionToMap(){
        return super.versionToMap()
    }
}
