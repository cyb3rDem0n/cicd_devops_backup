package com.accenture.sec.utils.version

class Version implements Comparable{
    int major
    int minor
    int fix
    int build

    @Override
    int compareTo(o) {
        if(o == null)
            return 1
        Version v = (Version) o

        if(this.major > v.major){
            return 1
        }
        else if(this.major == v.major){
            if(this.minor > v.minor){
                return 1
            }
            else if(this.minor == v.minor){
                if(this.fix > v.fix){
                    return 1
                }
                else if(this.fix == v.fix){
                    if(this.build > v.build){
                        return 1
                    }
                    else if(this.build == v.build){
                        return 0
                    }
                    else return -1
                }
                else return -1
            }
            else return -1
        }
        else return -1
    }
}
