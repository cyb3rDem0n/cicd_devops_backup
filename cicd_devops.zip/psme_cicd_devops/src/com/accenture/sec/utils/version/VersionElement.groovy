package com.accenture.sec.utils.version

enum VersionElement implements Comparable{
    MAJOR("major"),
    MINOR("minor"),
    FIX("fix"),
    BUILD("build");

    private String element;

    VersionElement(String element) {
        this.element = element;
    }

    String getVersionElement() {
        return element
    }
}
