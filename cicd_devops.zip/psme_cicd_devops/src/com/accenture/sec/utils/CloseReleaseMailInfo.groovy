package com.accenture.sec.utils

class CloseReleaseMailInfo {
    String microserviceName
    String version
    String pullRequestId
    String mergeHash
    String step
    String status
}
