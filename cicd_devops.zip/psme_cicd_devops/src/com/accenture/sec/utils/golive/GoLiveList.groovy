package com.accenture.sec.utils.golive

import com.accenture.sec.utils.Colors


class GoLiveList {

    private static final String[] HEADERS = ["MICROSERVICE", "VERSION", "GO LIVE TIME"]
    ArrayList<GoLiveInfo> goLiveInfos = null;
    private def pipeline = null

    GoLiveList(def pipeline = null) {
        this.pipeline = pipeline
        this.goLiveInfos = new ArrayList<>()
    }

    void add(def microservice, def version) {
        this.goLiveInfos.add(new GoLiveInfo(microservice, version))
    }

    boolean isEmpty(){
        return goLiveInfos.size() == 0
    }

    List<Map> toListMap(){
        if(goLiveInfos.size() == 0)
            return null
        return goLiveInfos.collect {it.toMap()}
    }

    String toString(){
        return toListMap().toString()
    }

    def printGoLiveInfos() {
        def maxes = getInfosRowMaxLengths()

        this.pipeline && this.pipeline.echo("MAXES1:\n${maxes}\n")

        maxes.maxMsNameLength = maxes.maxMsNameLength > HEADERS[0].length() ? maxes.maxMsNameLength : HEADERS[0].length()
        maxes.maxMsVersionLength = maxes.maxMsVersionLength > HEADERS[1].length() ? maxes.maxMsNameLength : HEADERS[1].length()
        maxes.maxTSLength = maxes.maxTSLength > HEADERS[2].length() ? maxes.maxTSLength : HEADERS[2].length()

        this.pipeline && this.pipeline.echo("MAXES2:\n${maxes}\n")
        StringBuffer infoTable = new StringBuffer()

        infoTable = infoTable.append(addHeaders(maxes))
                .append(addInfos(maxes))

        this.pipeline && this.pipeline.echo("${Colors.Bash.BOLD}${Colors.Bash.RED}GO LIVE DELIVERY TABLE${Colors.Bash.NC}\n${infoTable.toString()}\n")
        return "${Colors.Bash.BOLD}${Colors.Bash.RED}GO LIVE DELIVERY TABLE${Colors.Bash.NC}\n${infoTable.toString()}\n"
    }

    private Map getInfosRowMaxLengths(def maxes = null, int index = 0) {
        int liveInfosSize = this.goLiveInfos.size()
        //CASO base non esiste la mappa quindi la creo con i vqalori di default
        if (maxes == null) {
            maxes = [:]
            maxes.maxMsNameLength = 0
            maxes.maxMsVersionLength = 0
            maxes.maxTSLength = 0
        }
        //CASO BASE la lista delle info è vuota o si è arrivati in fondo alla lista
        if (liveInfosSize == 0 || liveInfosSize == index) {
            return maxes
        }

        int thismaxMsNameLength = this.goLiveInfos.get(index).microservice.length()
        int thismaxMsVersionLength = this.goLiveInfos.get(index).version.length()
        int thismaxTSLength = this.goLiveInfos.get(index).timestamp.toString().length()

        maxes.maxMsNameLength = thismaxMsNameLength > maxes.maxMsNameLength ? thismaxMsNameLength : maxes.maxMsNameLength
        maxes.maxMsVersionLength = thismaxMsVersionLength > maxes.maxMsVersionLength ? thismaxMsVersionLength : maxes.maxMsVersionLength
        maxes.maxTSLength = thismaxTSLength > maxes.maxTSLength ? thismaxTSLength : maxes.maxTSLength

        return getInfosRowMaxLengths(maxes, index + 1)
    }

    private StringBuffer buildLineSeparator(int length, StringBuffer buf = null) {
        StringBuffer buffer
        if (buf == null) {
            buffer = new StringBuffer()
        } else buffer = buf

        if (length > 0) {
            buffer = buffer.append("-")
            buffer = buildLineSeparator(length - 1, buffer)
        }
        return buffer
    }

    private StringBuffer buildLineSeparator(def maxes, StringBuffer buf = null) {
        StringBuffer buffer
        if (buf == null) {
            buffer = new StringBuffer()
        } else buffer = buf
        buffer = buffer.append("|")
        maxes.each { k,v ->
            this.pipeline && this.pipeline.echo("maxes --> ${k}: ${v}")
            buffer = buildLineSeparator(v as int, buffer)
            buffer = buffer.append("|")
        }
        return buffer
    }


    private StringBuffer addHeaders(def maxes) {
        StringBuffer buffer = new StringBuffer()
        int liveInfosSize = this.goLiveInfos.size()

        if (liveInfosSize > 0) {
            //4 è il numero di '|' usate come separatore di colonna per la tabella
            int rowLength = (maxes.size() + 1) + maxes.maxMsNameLength + maxes.maxMsVersionLength + maxes.maxTSLength

            buffer = buffer.append(buildLineSeparator(maxes)).append("\n")
            buffer = buffer.append("|").append(Colors.Bash.BOLD).append(Colors.Bash.BLUE).append(HEADERS[0]).append(Colors.Bash.NC)
            int emptySpacesCount = maxes.maxMsNameLength - HEADERS[0].length()
            if (emptySpacesCount > 0) {
                this.pipeline && this.pipeline.echo("\nHEADERS[0] spaces: ${emptySpacesCount}\n")
                buffer = buffer.append(addSpaces(emptySpacesCount))
            }

            buffer = buffer.append("|").append(Colors.Bash.BOLD).append(Colors.Bash.BLUE).append(HEADERS[1]).append(Colors.Bash.NC)
            emptySpacesCount = maxes.maxMsVersionLength - HEADERS[1].length()
            if (emptySpacesCount > 0) {
                this.pipeline && this.pipeline.echo("\nHEADERS[1] spaces: ${emptySpacesCount}\n")
                buffer = buffer.append(addSpaces(emptySpacesCount))
            }

            buffer = buffer.append("|").append(Colors.Bash.BOLD).append(Colors.Bash.BLUE).append(HEADERS[2]).append(Colors.Bash.NC)
            emptySpacesCount = maxes.maxTSLength - HEADERS[2].length()
            if (emptySpacesCount > 0) {
                this.pipeline && this.pipeline.echo("\nHEADERS[2] spaces: ${emptySpacesCount}\n")
                buffer = buffer.append(addSpaces(emptySpacesCount))
            }

            buffer = buffer.append("|").append("\n")
            buffer = buffer.append(buildLineSeparator(maxes)).append("\n")
        }

        return buffer
    }

    private StringBuffer addInfos(def maxes, int index = 0, StringBuffer buf = null) {
        StringBuffer buffer
        int liveInfosSize = this.goLiveInfos.size()
        int rowLength = 4 + maxes.maxMsNameLength + maxes.maxMsVersionLength + maxes.maxTSLength
        if (buf == null) {
            buffer = new StringBuffer()
        } else buffer = buf

        if (liveInfosSize == 0 || liveInfosSize == index) {
            return buffer
        }

        buffer = buffer.append("|").append(Colors.Bash.GREEN).append(this.goLiveInfos.get(index).microservice).append(Colors.Bash.NC)
        int emptySpacesCount = maxes.maxMsNameLength - this.goLiveInfos.get(index).microservice.length()
        if (emptySpacesCount > 0) {
            buffer = buffer.append(addSpaces(emptySpacesCount))
        }
        buffer = buffer.append("|").append(Colors.Bash.GREEN).append(this.goLiveInfos.get(index).version).append(Colors.Bash.NC)

        emptySpacesCount = maxes.maxMsVersionLength - this.goLiveInfos.get(index).version.length()
        if (emptySpacesCount > 0) {
            buffer = buffer.append(addSpaces(emptySpacesCount))
        }

        buffer = buffer.append("|").append(Colors.Bash.GREEN).append(this.goLiveInfos.get(index).timestamp.toString()).append(Colors.Bash.NC)
        emptySpacesCount = maxes.maxTSLength - this.goLiveInfos.get(index).timestamp.toString().length()
        if (emptySpacesCount > 0) {
            buffer = buffer.append(addSpaces(emptySpacesCount))
        }
        buffer = buffer.append("|").append("\n")
        buffer = buffer.append(buildLineSeparator(maxes)).append("\n")
        buffer = addInfos(maxes, index + 1, buffer)

        return buffer
    }


    private StringBuffer addSpaces(int length, StringBuffer buf = null) {
        StringBuffer buffer
        if (buf == null) {
            buffer = new StringBuffer()
        } else buffer = buf

        if (length > 0) {
            buffer = buffer.append(" ")
            buffer = addSpaces(length - 1, buffer)
        }
        return buffer
    }
}
