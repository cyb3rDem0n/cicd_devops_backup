package com.accenture.sec.utils.golive

import java.sql.Timestamp

class GoLiveInfo {
    def microservice
    def version
    Timestamp timestamp

    GoLiveInfo() {}

    GoLiveInfo(def microservice, def version) {
        this.microservice = microservice
        this.version = version
        this.timestamp = new Timestamp(System.currentTimeMillis())
    }

    Map toMap() {
        //get current TimeZone using getTimeZone method of Calendar class
        TimeZone timeZone = Calendar.getInstance().getTimeZone()
        return [Microservice: microservice, Version: version, Timestamp: "${timestamp.toString()} ${timeZone.toZoneId().toString()}".toString()]
    }
}
