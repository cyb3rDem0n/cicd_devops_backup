package com.accenture.sec.utils

import org.apache.commons.lang.StringUtils

class PrintTable implements Serializable {

    def headerColor = null
    def elementColor = null
    def headers = null
    List<Map> list = null

    def printTable(boolean center = false) {
        Set headers = list[0].keySet()
        Map maxsizes = [:]
        def table = "\n"
        String formatStr = "|"
        String formatHeader = "|"
        String formatDelimiter = "|"
        int rowSize = 0
        headers.each { header ->
            int _size = header.size()
            int tmp = list.collect { it.get(header).size() }.max()
            _size = tmp > _size ? tmp : _size
            rowSize += (_size + 3)
            maxsizes.put(header, _size)
            formatStr += elementColor ? " ${elementColor}%-${_size}s${Colors.Bash.NC} |".toString() : " %-${_size}s |".toString()
            formatHeader += headerColor ? " ${headerColor}${Colors.Bash.BOLD}%-${_size}s${Colors.Bash.NC} |".toString() : " %-${_size}s |".toString()
            formatDelimiter += "-%-${_size}s-|".toString()
        }
        rowSize -= 1
        formatStr += "\n"
        formatHeader += "\n"
        formatDelimiter += "\n"
        def tmpList = center ? headers.collect { StringUtils.center(it, maxsizes.get(it)) } : headers
        table += String.format(formatHeader, tmpList.toArray())
        table += getDelimiter(formatDelimiter, headers)
        list.each { el ->
            tmpList = el.values().collect { it as String }
            table += String.format(formatStr, tmpList.toArray())
        }
        table += getDelimiter(formatDelimiter, headers)
//        table += getLongFooter(rowSize)
        return table
    }

    static def printTable(List<Map> list, Map args = null) {
        if (CommonUtils.isNullOrEmpty(list))
            return null
        PrintTable printTable = new PrintTable()
        printTable.list = list
        printTable.headerColor = args?.headerColor
        printTable.elementColor = args?.elementColor

        return printTable.printTable(args?.center ?: false)
    }

    private static String getDelimiter(String formatDelimiter, def headers) {
        return String.format(formatDelimiter, headers.collect { '----' }.toArray()).replace(' ', '-')
    }

    private static String getLongFooter(int size) {
        String formatFooter = "|%${size}s|"
        return String.format(formatFooter, '-').replace(' ', '-')
    }
}
