package com.accenture.sec.utils



class Mailer implements Serializable {
    private def pipeline

    private HashMap<String, Object> mailMessageModel = [
            'SUCCESS' :null,
            'FAILURE' : null,
            'UNSTABLE' : null,
            'ABORTED' : null
    ]
    private HashMap<String, Object> currentEmail = null;

    private HashMap<String, Object> email = [
            subject: null,
            to : null,
            cc : null,
            bcc : null,
            body   : [
                    type: 'text/html',
                    msg : null
            ]
    ]

    Mailer(def pipeline){
        this.pipeline = pipeline
        currentEmail = new HashMap<String, Object>()

    }

    void newEmail(){
        this.currentEmail = new HashMap<String, Object>()
        this.currentEmail.putAll(email)
    }

    void setSubject(String subject){
        this.currentEmail.subject = subject
    }
    void setBodyType(String bodyType){
        this.currentEmail.body.type = bodyType
    }

    void setBodyMsg(String msg){
        this.currentEmail.body.msg = msg
    }

    void setTo(String to){
        this.currentEmail.to = to
    }
    void setCc(String cc){
        this.currentEmail.cc = cc
    }
    void setBcc(String bcc){
        this.currentEmail.bcc = bcc
    }

    void setCurrentEmailForPipelineState(String pipelineState){
        if(['SUCCESS','FAILURE','UNSTABLE','ABORTED'].contains(pipelineState)){
            this.mailMessageModel.put(pipelineState, this.currentEmail)
        }
    }

    void sendMail(){
        String currentState = this.pipeline.currentBuild.currentResult
        if(this.mailMessageModel["${currentState}"].to == null || this.mailMessageModel["${currentState}"].to == "") throw new IllegalArgumentException("Mailer.sendMail(): la property to e' null o vuota ")
        else{
            this.pipeline.mail bcc: this.mailMessageModel["${currentState}"].bcc == null ? '' : this.mailMessageModel["${currentState}"].bcc,
                    mimeType: this.mailMessageModel["${currentState}"].body.type == null ? 'text/html' : this.mailMessageModel["${currentState}"].body.type ,
                    body: this.mailMessageModel["${currentState}"].body.msg == null ? '' : this.mailMessageModel["${currentState}"].body.msg,
                    cc: this.mailMessageModel["${currentState}"].cc == null ? '' : this.mailMessageModel["${currentState}"].cc,
                    from: 'devops-noreply@it.accenture.com',
                    replyTo: '',
                    subject: this.mailMessageModel["${currentState}"].subject == null ? '' : this.mailMessageModel["${currentState}"].subject,
                    to: this.mailMessageModel["${currentState}"].to
        }
    }

}
