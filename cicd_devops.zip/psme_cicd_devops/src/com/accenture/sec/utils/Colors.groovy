package com.accenture.sec.utils

class Colors implements Serializable {

    class Bash implements Serializable{
        static final def RED = '\u001B[31m'
        static final def GREEN = '\u001B[32m'
        static final def BLUE = '\u001B[34m'
        static final def ORANGE = '\u001B[38;5;166m'

        static final def BOLD = '\u001B[1m'

        static final def NC = '\u001B[0m'
    }

}
