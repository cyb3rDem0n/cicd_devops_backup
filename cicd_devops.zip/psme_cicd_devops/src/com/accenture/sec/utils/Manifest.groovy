package com.accenture.sec.utils

import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dto.DeployInfoDTO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.runners.ScpRunner
import com.accenture.sec.runners.SshRunner
import com.accenture.sec.utils.golive.GoLiveList


import java.sql.Connection
import java.util.regex.Matcher
import java.util.regex.Pattern

class Manifest implements Serializable {

    def pipeline
    String wave
    String targetOcpProject
    List<ManifestInfoDTO> manifestInfo
    List<ManifestInfoDTO> currDeployManifestList
    List<ManifestInfoDTO> fullManifestList
    List<ManifestInfoDTO> namespaceManifestInfo
    List<ManifestInfoDTO> vmManifestInfo
    List<ManifestInfoDTO> deployTableManifestInfo
    Map<String, String> dbInfo
    def deployableMap
    def deployStatus = [:]
    GoLiveList goLiveList = new GoLiveList()
    String deployEnv

    Manifest(def pipeline, deployEnv = 'ocp') {
        this.pipeline = pipeline
        this.deployEnv = deployEnv
    }

    void init(Map args) {
        CommonUtils.checkInputParameters(args, 'version,dbInfo')
        CommonUtils.checkInputParameters(args.dbInfo as Map, 'type,host,database,credsId')
        this.dbInfo = args.dbInfo as Map
        pipeline.withCredentials([pipeline.usernamePassword(credentialsId: this.dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
            this.dbInfo.username = pipeline.env.usr
            this.dbInfo.password = pipeline.env.psw
        }

        this.wave = args.version
        this.targetOcpProject = args.env
    }

    List<ManifestInfoDTO> getManifestListFromDb(Map args) {
        CommonUtils.checkInputParameters(args, 'projectPrefix')
        def msgVersion = ''
        if (args.mfVersion == null) {
            this.manifestInfo = this.pipeline.readDBManifest([projectPrefix: "${args.projectPrefix}", wave: this.wave,
                                                              dbInfo       : this.dbInfo])
        } else {
            this.manifestInfo = this.pipeline.readDBManifest([projectPrefix: "${args.projectPrefix}", wave: this.wave, mfVersion: args.mfVersion,
                                                              dbInfo       : this.dbInfo])
            msgVersion = " [${args.mfVersion}] "
        }
        this.pipeline.echo("readDBManifest${msgVersion}: ${ManifestUtils.prettyPrint(this.manifestInfo)}")
        return this.manifestInfo
    }

    List<ManifestInfoDTO> setManifestFromString(String manifest) {
        this.manifestInfo = []
        def tmp = CommonUtils.loadYaml(manifest)
        ManifestInfoDTO dto = null
        tmp.each { k, v ->
            dto = new ManifestInfoDTO()
            dto.microservice = k
            dto.buildNum = v
            this.manifestInfo.add(dto)
        }
        return this.manifestInfo
    }

    Map<String, Object> toDeployableMap(List<ManifestInfoDTO> list, List skip = [], boolean setThis = true) {
        Map<String, Object> deployableMap = [:]
        list?.each { ms ->
            if (!skip?.contains(ms.microservice)) {
                deployableMap.putAll(ms.toMap())
            }
        }
        if (setThis)
            this.deployableMap = deployableMap.clone() as Map
        return deployableMap
    }

    Map<String, String> toSimpleMap(List<ManifestInfoDTO> list, List skip = []) {
        Map map = [:]
        list?.each { ms ->
            if (!skip.contains(ms.microservice))
                map.putAll(ms.toMapForPrint())
        }
        return map
    }
/*
    @Deprecated
    List<ManifestInfoDTO> calculateCurrDeployManifestList(Map ocpInfo, String targetOCPProject, List filter = [], Map ocpFilterMap) {
        this.calculateManifestListFromDeployDBTable(targetOCPProject, filter)
        this.calculateManifestListFromNamespace(ocpInfo, ocpFilterMap)
        this.namespaceManifestInfo.addAll(this.deployTableManifestInfo)
        this.currDeployManifestList = getDiff(this.manifestInfo, this.namespaceManifestInfo)
    }*/

    List<ManifestInfoDTO> calculateCurrDeployManifestList(Map ocpInfo, Map ocpFilterMap, Map vmInfo = null, List filter = []) {
        if (filter) {
            if (vmInfo)
                this.calculateManifestListFromDeployDBTable("${vmInfo.project}-${vmInfo.envname}", filter)
            this.calculateManifestListFromDeployDBTable("${ocpInfo.project}", filter)
        }

        this.calculateManifestListFromNamespace(ocpInfo, ocpFilterMap)
        this.fullManifestList = this.namespaceManifestInfo.clone()
        if (vmInfo) {
            this.calculateManifestListFromVM(vmInfo)
            this.fullManifestList.addAll(this.vmManifestInfo.clone())
        }
        this.deployTableManifestInfo && this.fullManifestList.addAll(this.deployTableManifestInfo)
        this.currDeployManifestList = getDiff(this.manifestInfo, this.fullManifestList)
    }

    @Deprecated
    List<ManifestInfoDTO> calculateCurrDeployManifestListVM(Map vmInfo, List filter = []) {
        this.calculateManifestListFromDeployDBTable("${vmInfo.project}-${vmInfo.envname}", filter)
        this.calculateManifestListFromVM(vmInfo)
        if (this.fullManifestList) {
            this.fullManifestList.addAll(this.vmManifestInfo.clone())
        } else {
            this.fullManifestList = this.vmManifestInfo.clone()
        }
        this.fullManifestList.addAll(this.deployTableManifestInfo)
        this.currDeployManifestList = getDiff(this.manifestInfo, this.fullManifestList)
    }

    static List<ManifestInfoDTO> calculateFullDeployManifestList(List<ManifestInfoDTO> manifest, List<ManifestInfoDTO> envManifest) {
        List<ManifestInfoDTO> ret = null
        if (envManifest == null || envManifest.isEmpty()) {
            ret = manifest.clone() as List<ManifestInfoDTO>
        } else {
            ret = []
        }
        Set list1 = manifest.collect { it.microservice }.toSet()
        Set list2 = envManifest.collect { it.microservice }.toSet()
        list1.addAll(list2)
        def el = null
        list1.each { msName ->
            el = manifest.find { msName == it.microservice }
            if (el == null) {
                el = envManifest.find { msName == it.microservice }
            }
            el && ret.add(el)
        }
        return ret
    }

    List<ManifestInfoDTO> calculateManifestListFromDeployDBTable(String targetProjectEnv, List filter, boolean print = true) {
        if (!this.deployTableManifestInfo)
            this.deployTableManifestInfo = []
        DeployInfoDTO deployInfoDTO
        this.pipeline.echo("Collecting deployed configurations from deploy db table (${targetProjectEnv}) with filter ${filter}...")
        Connection connection = null
        try {
            connection = DataSource.getInstance().setupConnection(this.dbInfo)
            ViewDAO viewDAO = new ViewDAO(connection)
            filter.each {
                deployInfoDTO = viewDAO.getLastDeployInfo(it, targetProjectEnv)
                deployInfoDTO && this.deployTableManifestInfo.add(deployInfoDTO.toManifestInfoDTO())
            }
        } catch (Exception e) {
            throw e
        } finally {
            connection && connection.close()
        }
        print && this.pipeline.echo("Collected current manifest from deploy db table\n${toMap(this.deployTableManifestInfo)}")
        return deployTableManifestInfo
    }

    List<ManifestInfoDTO> calculateManifestListFromNamespace(Map ocpInfo, Map filterMap, boolean print = true) {
        this.namespaceManifestInfo = []
        pipeline.openshift.withCluster(ocpInfo.cluster) {
            pipeline.openshift.withProject(ocpInfo.project) {
                ManifestInfoDTO dto = null
                filterMap.each { k, v ->
                    pipeline.echo("Collecting ${k} from ${ocpInfo.project} with filter ${v}...")
                    if (v.labels) {
                        if (k.toString().toLowerCase() in ['dc', 'deploymentconfig']) {
                            pipeline.openshift.selector(k, v.labels).objects().each { item ->
                                def res = pipeline.openshift.raw("get pods -l deploymentconfig=${item.metadata.name} --field-selector status.phase=Running -o json")
                                if (res.status == 0 && res.actions && res.actions[0].status == 0) {
                                    def pods = CommonUtils.parseJson(res.actions[0].out)
                                    if (pods && pods.kind == 'List')
                                        pods = pods.items
                                    if (CommonUtils.isNullOrEmpty(pods))
                                        return
                                    dto = new ManifestInfoDTO()
                                    dto.microservice = pods[0].metadata.labels.microservice
                                    //dto.version = (item.metadata.labels.version ?: item.spec.template.metadata.labels.version)
                                    dto.buildNum = pods[0].metadata.labels.version
                                    dto.setTarget("ocp")
                                    this.namespaceManifestInfo.add(dto)
                                }
                            }
                        } else if (k.toString().toLowerCase() in ['statefulset']) {
                            pipeline.openshift.selector(k, v.labels).objects().each { item ->
                                dto = new ManifestInfoDTO()
                                dto.microservice = item.metadata.labels.template
                                dto.buildNum = item.metadata.labels.version
                                dto.setTarget("ocp")
                                this.namespaceManifestInfo.add(dto)
                            }
                        }
                    }
                    if (v.names) {
                        try {
                            def sel = pipeline.openshift.selector(k)
                            boolean exist = sel.exists()
                            if (exist) {
                                sel.objects().each {
                                    if (!v.names.contains(it.metadata.name))
                                        return
                                    dto = new ManifestInfoDTO()
                                    dto.microservice = it.metadata.name
                                    dto.buildNum = it.metadata.labels.version
                                    dto.setTarget('ocp')
                                    this.namespaceManifestInfo.add(dto)
                                }
                            }
                        } catch (Exception e) {
                        }
                    }
                }
            }
        }
        print && pipeline.echo("Collected current manifest from ${ocpInfo.project}\n${toMap(this.namespaceManifestInfo)}")
        return this.namespaceManifestInfo
    }

    /**
     *
     * @param pipeline
     * @param vmInfo
     * @param filterMap
     * @param applicationList
     * @param prjPrefix
     * @param print
     * @return
     */
    List<ManifestInfoDTO> calculateManifestListFromVM(Map vmInfo, boolean print = true) {
        this.vmManifestInfo = []
        List<ManifestInfoDTO> singleVmlist = []

        SshRunner sshRunner = new SshRunner(pipeline)
        RunnerResult sshResult

        ManifestInfoDTO dto
        vmInfo.machines.each { singleVm ->
            singleVm.apps.each { application ->

//                def script = """#!/bin/bash -e
//                                cat /opt/${application.appname}/.version
//                             """
                sshResult = sshRunner.execWithStatus([
                        host        : singleVm.host,
                        credsId     : (application.credsId ?: singleVm.keyCredsId),
                        user        : application.username,
                        options     : [StrictHostKeyChecking: 'no'],
//                        script      : script,
                        remoteCmd   : "cat /opt/${application.appname}/.version",
                        getOutput   : true,
                        errSeparated: true
                ])
                if (sshResult.exitCode == 0) {
                    Pattern pattern = Pattern.compile(/(?s).*((api|streaming)-wave\d+-b\d+).*/)
                    Matcher matcher = pattern.matcher(sshResult.getOut())
                    if (matcher.matches() && matcher.size() > 0 && matcher[0].size() > 0) {
                        String version = matcher[0][1]
                        dto = new ManifestInfoDTO()
                        def wave = "${version.trim()}".substring(0, version.trim().lastIndexOf('-'))
                        dto.setWave(wave)
                        dto.setMicroservice(application.appname)
                        dto.setBuildNum("${version.trim()}")
                        dto.setTarget('vm')
                        singleVmlist.add(dto)
                    }
                }
            }
            if (!singleVmlist.isEmpty()) {
                print && pipeline.echo("Collected current deployed applications from ${singleVm.host}\n${ManifestUtils.toMap(singleVmlist)}")
                this.vmManifestInfo.addAll(singleVmlist)
                singleVmlist = []
            }
            print && pipeline.echo("Collected current manifest from all virtual machines\n${toMap(this.vmManifestInfo)}")
        }
        return this.vmManifestInfo
    }

    /**
     * Convert input manifest in a Map
     *
     * @param manifest input manifest list
     * @return a map that is the representation of the input manifest
     */
    static Map<String, Object> toMap(List<ManifestInfoDTO> manifest) {
        if (manifest == null)
            return null
        Map map = [:]
        if (manifest.size() > 0) {
            map << [release: manifest[0]?.getReleaseVersion()]
        }
        manifest.each { ms ->
            map.putAll(ms.toMapForPrint())
        }
        return map
    }

    void setForceRedeploy(boolean forceRedeploy) {
        if (forceRedeploy) {
            this.currDeployManifestList = this.manifestInfo
        }
    }

    /**
     * Calculate the differences between two manifest
     *
     * @param manifest1 input manifest list
     * @param manifest2 input manifest list
     * @return a List of MicroServices different between the 2 manifests
     */
    static List<ManifestInfoDTO> getDiff(List<ManifestInfoDTO> manifest1, List<ManifestInfoDTO> manifest2) {
        List<ManifestInfoDTO> res = []
        manifest1.each { ms ->
            if (!ms.equals(manifest2.find { it.getMicroservice() == ms.getMicroservice() }))
                res.add(ms)
        }
        return res
    }

    void initDeployStatusMap() {
        this.deployableMap.each { k, v ->
            this.deployStatus.put(k, null)
        }
    }

    /**
     * Convert input manifest in a readable YAML string with only few informations
     *
     * @param manifest input manifest list
     * @return a string in YAML format representing the manifest
     */
    static String prettyPrint(List<ManifestInfoDTO> manifest, boolean noHeaders = true) {
        Map<String, Object> map = toMap(manifest)
        if (map == null)
            return null
        if (map.size() == 0)
            return "## Empty Manifest ##"
        String release
        if (!noHeaders) {
            release = map.release ? "## Manifest ${map.release} ##" as String : "## Manifest ##"
        } else release = ""
        Map<String, Object> yaml = [:]
        map.each { key, value ->
            if (key == 'release')
                return
            yaml.put(key, value)
        }
        def strYaml = "${release}\n"
        strYaml += (CommonUtils.dumpYamlAsMap(yaml))
        return strYaml as String
    }

    static List<ManifestInfoDTO> parseFromString(String manifest) {
        List<ManifestInfoDTO> res = []
        def tmp = CommonUtils.loadYaml(manifest)
        ManifestInfoDTO dto = null
        tmp.each { k, v ->
            dto = new ManifestInfoDTO()
            dto.microservice = k
            dto.buildNum = v
            res.add(dto)
        }
        return res
    }

    void removeFromCurrDeployManifestList(String s) {
        ManifestInfoDTO dto = this.getCurrDeployManifestList().find { it.microservice == s }
        if (dto) {
            this.getCurrDeployManifestList().remove(dto)
        }
    }
}
