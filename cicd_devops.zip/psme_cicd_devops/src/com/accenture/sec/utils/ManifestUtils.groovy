package com.accenture.sec.utils

import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dto.DeployInfoDTO
import com.accenture.sec.db.dto.ManifestInfoDTO


import java.sql.Connection

class ManifestUtils implements Serializable {

    static List<ManifestInfoDTO> getManifestListFromDeployDBTable(def pipeline, String envForDeploy, List filter, Map dbInfo, boolean print = true) {
        DeployInfoDTO deployInfoDTO = null
        List<ManifestInfoDTO> list = []
        pipeline.withCredentials([pipeline.usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
            dbInfo.username = pipeline.env.usr
            dbInfo.password = pipeline.env.psw
        }
        pipeline.echo("Collecting deployed configurations from deploy db table (${envForDeploy}) with filter ${filter}...")
        Connection connection = null
        try {
            connection = DataSource.getInstance().setupConnection(dbInfo)
            ViewDAO viewDAO = new ViewDAO(connection)
            filter.each {
                deployInfoDTO = viewDAO.getLastDeployInfo(it, envForDeploy)
                deployInfoDTO && list.add(deployInfoDTO.toManifestInfoDTO())
            }
        } catch (Exception e) {
            throw e
        } finally {
            connection && connection.close()
        }
        print && pipeline.echo("Collected current manifest from deploy db table\n${toMap(list)}")
        return list
    }

    static List<ManifestInfoDTO> getManifestListFromNamespace(def pipeline, Map ocpInfo, Map filterMap, boolean print = true) {
        List<ManifestInfoDTO> list = []

        pipeline.openshift.withCluster(ocpInfo.cluster) {
            pipeline.openshift.withProject(ocpInfo.project) {

                ManifestInfoDTO dto = null
                filterMap.each { k, v ->
                    pipeline.echo("Collecting ${k} from ${ocpInfo.project} with filter ${v}...")
                    if (v.labels) {
                        if(k.toString().toLowerCase() in ['dc', 'deploymentconfig']){
                            pipeline.openshift.selector(k, v.labels).withEach { item ->
                                def pods = item.related('pods').objects().findAll { it.status.phase == 'Running' }
                                if (CommonUtils.isNullOrEmpty(pods))
                                    return
                                dto = new ManifestInfoDTO()
                                dto.microservice = pods[0].metadata.labels.microservice
                                //dto.version = (item.metadata.labels.version ?: item.spec.template.metadata.labels.version)
                                dto.buildNum = pods[0].metadata.labels.version
                                list.add(dto)
                            }
                        }else if(k.toString().toLowerCase() in ['statefulset']){
                            pipeline.openshift.selector(k, v.labels).objects().each { item ->
                                dto = new ManifestInfoDTO()
                                dto.microservice = item.metadata.labels.template
                                dto.buildNum = item.metadata.labels.version
                                list.add(dto)
                            }
                        }
                    }
                    if (v.names) {
                        try {
                            def sel = pipeline.openshift.selector(k)
                            boolean exist = sel.exists()
                            if (exist) {
                                sel.objects().each {
                                    if (!v.names.contains(it.metadata.name))
                                        return
                                    dto = new ManifestInfoDTO()
                                    dto.microservice = it.metadata.name
                                    dto.buildNum = it.metadata.labels.version
                                    list.add(dto)
                                }
                            }
                        } catch (Exception e) {
                        }
                    }
                }
            }
        }
        print && pipeline.echo("Collected current manifest from ${ocpInfo.project}\n${toMap(list)}")
        return list
    }

/*    static List<ManifestInfoDTO> parseFromString(String manifest) {
        List<ManifestInfoDTO> res = []
        def tmp = CommonUtils.loadYaml(manifest)
        ManifestInfoDTO dto = null
        tmp.each { k, v ->
            dto = new ManifestInfoDTO()
            dto.microservice = k
            dto.buildNum = v
            res.add(dto)
        }
        return res
    }*/

    /**
     * Calculate the differences between two manifest
     *
     * @param manifest1 input manifest list
     * @param manifest2 input manifest list
     * @return a List of MicroServices different between the 2 manifests
     */
    static List<ManifestInfoDTO> getDiff(List<ManifestInfoDTO> manifest1, List<ManifestInfoDTO> manifest2) {
        List<ManifestInfoDTO> res = []
        manifest1.each { ms ->
            if (!ms.equals(manifest2.find { it.getMicroservice() == ms.getMicroservice() }))
                res.add(ms)
        }
        return res
    }

    /**
     * Convert input manifest in a Map
     *
     * @param manifest input manifest list
     * @return a map that is the representation of the input manifest
     */
    static Map<String, Object> toMap(List<ManifestInfoDTO> manifest) {
        Map map = [:]
        if (manifest.size() > 0) {
            map << [release: manifest[0]?.getReleaseVersion()]
        }
        manifest.each { ms ->
            map.putAll(ms.toMap())
        }
        return map
    }

    static Map<String, Object> toDeployableMap(List<ManifestInfoDTO> manifest, List skip = []) {
        Map map = [:]
        manifest.each { ms ->
            if (!skip.contains(ms.microservice))
                map.putAll(ms.toMap())
        }
        return map
    }

    /**
     * Convert input manifest in a YAML string
     *
     * @param manifest input manifest list
     * @return a string in YAML format representing the entire manifest
     */
    static String toYaml(List<ManifestInfoDTO> manifest) {
        return CommonUtils.dumpYamlAsMap(toMap(manifest))
    }

    /**
     * Convert input manifest in a readable YAML string with only few informations
     *
     * @param manifest input manifest list
     * @return a string in YAML format representing the manifest
     */
    static String prettyPrint(List<ManifestInfoDTO> manifest, boolean header = true) {
        Map<String, Object> map = toMap(manifest)
        if (map.size() == 0)
            return "## Empty Manifest ##"
        String release = ""
        if(header) {
            release = map.release ? "## Manifest ${map.release.type}:${map.release.version}:${map.release.status} ##" as String : "## Manifest ##"
            release += '\n'
        }
        Map<String, Object> yaml = [:]
        map.each { key, value ->
            if (key == 'release')
                return
            yaml.put(key, value)
        }
        def strYaml = "${release}"
        strYaml += (CommonUtils.dumpYamlAsMap(yaml))
        return strYaml as String
    }

}
