package com.accenture.sec.utils

import com.accenture.sec.managers.amq.AMQPodManager
import com.accenture.sec.managers.amq.AbstractAMQManager

class OpenshiftUtils implements Serializable {

    static def createStatefulSet(def pipeline, Map args) {
        if (args.name.contains('amq')) {
            return amqCreateClusterAndQueues(pipeline, args)
        } else if (args.name.contains('datagrid')) {
            return datagridCreateCluster(pipeline, args)
        }
    }

    static def datagridCreateCluster(def pipeline, Map args) {
        def templates
        def cicdFolder
        if (!args.templates) {
            if (args.filePath.endsWith('.zip')) {
                pipeline.echo("Unzipping '${args.filePath}'...")
                pipeline.sh("""#!/bin/bash -e
                  unzip "${args.filePath}" -d "package-${args.name}/"
                  rm -rf "${args.filePath}"
                """)
                templates = pipeline.findFiles(glob: "package-${args.name}/deployment/templates/*.yaml")
                cicdFolder = '.'
            } else {
                cicdFolder = "${pipeline.env.WORKSPACE}/cicd_devops"
                templates = pipeline.findFiles(glob: "${args.filePath}")
            }
        } else {
            templates = args.templates
            cicdFolder = args.cicdFolder ?: "${pipeline.env.WORKSPACE}/cicd_devops"
        }

        templates.each { template ->
            String name = template.name.replaceAll(/\.yaml/, '')
            pipeline.replaceTokens(name: name, path: "${template.path}", tokenFilePath: "${cicdFolder}/tokens/${pipeline.env.targetProjectOCP}.yaml", notEncode: true)
        }
        // seleziono il cluster
        pipeline.openshift.withCluster(pipeline.env.clusterOCP) {
            pipeline.openshift.withProject(pipeline.env.targetProjectOCP) {
                // ciclo sui template presenti nel repository
                templates.each { template ->

                    // leggo il template del cluster
                    def map = pipeline.readYaml(file: template.path)
                    Map cluster = map.cluster

                    cluster.name = (cluster.name ?: args.name)

                    // Se il cluster non esiste nell'ambiente target lo creo
                    def TEMPLATE_NAME = cluster.template ?: 'openshift//datagrid-service'
                    if (!cluster.image)
                        cluster.image = 'docker-registry.default.svc:5000/openshift/jboss-datagrid73-openshift'
                    if (!cluster.imageVersion)
                        cluster.imageVersion = '1.4'
                    cluster.image = "${cluster.image}:${cluster.imageVersion}"
                    pipeline.echo("Preparing ${TEMPLATE_NAME} parameters for ${template.name}...")

                    // preparo la lista dei parametri da passare al template del cluster AMQ
                    List templateParams = prepareDatagridListTemplateParameter(cluster)
                    // processo il template con i parametri
                    def templateList = pipeline.openshift.process(TEMPLATE_NAME, templateParams as String[])

                    def statefulset = pipeline.openshift.selector("statefulsets", [application: cluster.name])
                    if (!statefulset.exists()) {
                        pipeline.echo("Creating ${TEMPLATE_NAME} ...")
                        // creo le risorse processate dal comando precedente
                        def res = pipeline.openshift.create(templateList)
                        def statefulSet = res.narrow('statefulset')
                        def statefulSetName = statefulSet.name()

                        // imposto un timeout per la pipeline di 20 minuti
                        pipeline.echo("Waiting ${statefulSetName} is fully up...")
                        pipeline.timeout(20) {
                            // Attendo che tutti i pod del cluster sia up
                            pipeline.openshift.selector("statefulset", [application: cluster.name]).untilEach(1) {
                                return (it.object().status.readyReplicas == it.object().status.replicas)
                            }
                        }
                        pipeline.echo("Deploy of ${statefulSetName} completed successfully")
                        // seleziono il service del cluster tramite la label 'application' usata dal template
                        def service = pipeline.openshift.selector("service", [application: cluster.name]).objects().find {
                            !it.metadata.name.contains('-ping')
                        }

                        def passthroughRouteName = "${cluster.name}-hotrod-route"
                        if (!pipeline.openshift.selector("route", passthroughRouteName).exists()) {
                            pipeline.echo("Creating '${passthroughRouteName}' passthrough route ...")
                            // creo le risorse processate dal comando precedente
                            pipeline.openshift.create('route', 'passthrough', passthroughRouteName, '--port=hotrod', "--service ${service.metadata.name}")
                            pipeline.echo("Completed creation of ${passthroughRouteName}")
                        }
                    } else {
//                        def el = templateList.find{ it.kind.toLowerCase() == 'statefulset'}
//                        def result = pipeline.openshift.apply(el, '--overwrite')
//
//                        def previousObject = statefulset.object()
//                        if((previousObject.spec.template.spec.containers.find{it.name == cluster.name}).image != cluster.image){
//                            def selector = pipeline.openshift.selector('pods', [application: cluster.name])
//                            selector.delete('--wait')
//                        }
                        statefulset = pipeline.openshift.selector("statefulsets", [application: cluster.name])
                        if (statefulset.object().spec.replicas != (cluster.replicas as Integer))
                            statefulset.scale("--replicas=${cluster.replicas}")
                    }
                    if (args.version)
                        statefulset.label([version: args.version], "--overwrite")
                }
            }
        }
    }

    static List prepareDatagridListTemplateParameter(Map _map) {
        List templateParams = [
                "-p", "APPLICATION_NAME=${_map.name}",
                "-p", "APPLICATION_USER=${_map.user}",
                "-p", "APPLICATION_PASSWORD=${_map.password}",
                "-p", "NUMBER_OF_INSTANCES=${_map.replicas ?: 1}",
        ]
        _map.storage && templateParams.addAll(["-p", "TOTAL_CONTAINER_STORAGE=${_map.storage}"])
        _map.memory && templateParams.addAll(["-p", "TOTAL_CONTAINER_MEM=${_map.memory}"])
        _map.image && templateParams.addAll(["-p", "IMAGE=${_map.image}"])
        return templateParams
    }

    static def amqCreateClusterAndQueues(def pipeline, Map args) {
        def templates
        def cicdFolder
        if (!args.templates) {
            if (args.filePath.endsWith('.zip')) {
                pipeline.echo("Unzipping '${args.filePath}'...")
                pipeline.sh("""#!/bin/bash -e
                  unzip "${args.filePath}" -d "package-${args.name}/"
                  rm -rf "${args.filePath}"
                """)
                templates = pipeline.findFiles(glob: "package-${args.name}/deployment/templates/*.yaml")
                cicdFolder = '.'
            } else {
                cicdFolder = "${pipeline.env.WORKSPACE}/cicd_devops"
                templates = pipeline.findFiles(glob: "${args.filePath}")
            }
        } else {
            templates = args.templates
            cicdFolder = args.cicdFolder ?: "${pipeline.env.WORKSPACE}/cicd_devops"
        }

        templates.each { template ->
            String name = template.name.replaceAll(/\.yaml/, '')
            pipeline.replaceTokens(name: name, path: "${template.path}", tokenFilePath: "${cicdFolder}/tokens/${pipeline.env.targetProjectOCP}.yaml", notEncode: true)
        }

        pipeline.openshift.withCluster(pipeline.env.clusterOCP) {
            templates.each { template ->
                pipeline.openshift.withProject(pipeline.env.targetProjectOCP) {
                    def map = pipeline.readYaml(file: template.path)
                    Map cluster = map.cluster

                    // Se il cluster non esiste nell'ambiente target lo creo
                    if (!pipeline.openshift.selector("statefulsets", [application: cluster.name]).exists()) {
                        def TEMPLATE_NAME = cluster.template
                        pipeline.echo("Preparing ${TEMPLATE_NAME} parameters for ${template.name}...")
                        // preparo la lista dei parametri da passare al template del cluster AMQ
                        List templateParams = prepareAMQTemplateParameters(cluster)

                        pipeline.echo("Processing ${TEMPLATE_NAME} ...")
                        // processo il template con i parametri
                        def templateList = pipeline.openshift.process(TEMPLATE_NAME, templateParams as String[])

                        // creo le risorse processate dal comando precedente
                        def res = pipeline.openshift.create(templateList)

//                    echo "result: ${res}"
                        def statefulSet = res.narrow('statefulset')
//                    echo "statefulSet: ${statefulSet.asYaml()}"

                        // imposto un timeout per la pipeline di 20 minuti
                        pipeline.echo("Waiting ${statefulSet.name()} is fully up...")
                        pipeline.timeout(20) {
                            // Attendo che tutti i pod del cluster sia up
                            pipeline.openshift.selector("statefulset", [application: cluster.name]).untilEach(1) {
                                return (it.object().status.readyReplicas == it.object().status.replicas)
                            }
                        }
                        pipeline.echo("Deploy of ${statefulSet.name()} completed successfully")
                        if (args.version) {
                            statefulSet.label([version: args.version], "--overwrite")
                        }
                    }

                    // seleziono il service del cluster tramite la label 'app' usata dal template
                    def service = pipeline.openshift.selector("service", [app: cluster.name]).object()

                    pipeline.openshift.selector('pods', [application: cluster.name]).names().each { pod ->
                        pipeline.echo("Creating queues for ${cluster.name} on ${pod} (${template.name})")
                        // istanzio un AMQPodManager per creare le code passandogli in input
                        // il def, l'endpoint per la creazione della coda, il nome di un pod del cluster
                        AbstractAMQManager amqPodManager = new AMQPodManager(pipeline,
                                "${service.metadata.name}.${service.metadata.namespace}.svc.cluster.local", pod)

                        // Cancello tutte le code non presenti nel template
                        // amqPodManager.deleteUnusedQueues(cluster.queues, 'cb-')

                        // ciclo sulle code del cluster definite nel template
                        cluster.queues.each { Map queue ->
                            pipeline.echo("Processing queue ${queue.name} ...")
                            amqPodManager.createQueue(queue)
                        }
                        pipeline.echo("Completed creation of queues")
                    }
                    if (args.version) {
                        pipeline.openshift.selector("statefulsets", [application: cluster.name]).label([version: args.version], "--overwrite")
                    }

                }
            }
        }

    }

    static List prepareAMQTemplateParameters(Map _map) {
        List templateParams = [
                "-p", "APPLICATION_NAME=${_map.name}",
                "-p", "AMQ_PROTOCOL=${_map.protocols}",
                "-p", "AMQ_QUEUES=${_map.initial_queues ?: ''}",
                "-p", "AMQ_ADDRESSES=${_map.addresses ?: ''}",
                "-p", "AMQ_USER=${_map.user}",
                "-p", "AMQ_PASSWORD=${_map.password}",
                "-p", "AMQ_NAME=${_map.name}",
                "-p", "AMQ_CLUSTER_USER=${_map.user_cluster}",
                "-p", "AMQ_CLUSTER_PASSWORD=${_map.password_cluster}",
                "-p", "AMQ_REPLICAS=${_map.replicas ?: 2}",
        ]
        if (_map.require_login != null)
            templateParams.addAll(["-p", "AMQ_REQUIRE_LOGIN=${_map.require_login}"])
        if (_map.extra_args)
            templateParams.addAll(["-p", "AMQ_EXTRA_ARGS=${_map.extra_args}"])
        if (_map.role)
            templateParams.addAll(["-p", "AMQ_ROLE=${_map.role}"])
        if (_map.global_size)
            templateParams.addAll(["-p", "AMQ_GLOBAL_MAX_SIZE=${_map.global_size}"])
        if (_map.volume_size)
            templateParams.addAll(["-p", "VOLUME_CAPACITY=${_map.volume_size}"])
        return templateParams
    }

}

