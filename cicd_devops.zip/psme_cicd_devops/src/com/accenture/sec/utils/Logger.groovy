package com.accenture.sec.utils



class Logger implements Serializable {

    static void log(def pipeline, Map args){
        def msg = parseArgs(args)
        pipeline.echo("${msg}")
    }

    static void error(def pipeline, Map args){
        def msg = parseArgs(args)
        pipeline.error(msg)
    }

    static private def parseArgs(Map args){
        def msg = "#############################################"
        args.each {
            msg += "# ${it.key}:\t${it.value}\n"
        }
        msg += "#############################################"
        return msg
    }

}
