package com.accenture.sec.utils

import com.cloudbees.groovy.cps.NonCPS
import groovy.json.JsonOutput
import groovy.json.JsonSlurperClassic
import hudson.ProxyConfiguration
import hudson.model.Result
import jenkins.model.Jenkins

import org.jenkinsci.plugins.workflow.steps.FlowInterruptedException
import org.yaml.snakeyaml.Yaml

import java.security.InvalidParameterException
import java.sql.Timestamp
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.regex.Matcher
import java.util.regex.Pattern

@Grab('org.yaml:snakeyaml:1.23')

/**
 * Class that implement some CommonUtils
 */
class CommonUtils implements Serializable {

    static final String hrSeparator = "________________________________________________________________________________________________________________________"


    /**
     *
     *
     *
     * @param pattern della forma "yyyyMMddHHmm"
     * @param optArgs mappa di argomenti opzionali
     *              - locale: di tipo Locale (es. Locale.ITALY)
     *              - timezone: di tipo stringa nella forma "Europe/Rome"
     * @return
     */
    static String getCurrentDateString(String pattern, Map optArgs = [:]) {
        DateFormat dateFormat = null
        if (optArgs.locale && optArgs.locale instanceof Locale)
            dateFormat = new SimpleDateFormat(pattern, optArgs.locale as Locale)
        else
            dateFormat = new SimpleDateFormat(pattern)
        if (optArgs.timezone)
            dateFormat.setTimeZone(TimeZone.getTimeZone(optArgs.timezone as String))
        Date date = null
        if (optArgs.date && optArgs.date instanceof Date)
            date = optArgs.date as Date
        else
            date = new Date()
        return dateFormat.format(date)
    }

    static Timestamp getCurrentTimestamp() {
        return (new Timestamp(System.currentTimeMillis()))
    }

    /**
     * Convert a string comma separated in a List
     *
     * @param stringList source string
     * @return List of strings
     */
    static List<String> commaStringToList(String stringList) {
        stringList = stringList ?: ''
        List list = stringList.tokenize(',')
        list.eachWithIndex { String entry, int i ->
            list[i] = entry.trim()
        }
        return list
    }

    /**
     * Check if the requiredParams are in the args Map passed otherwise raise an Exception
     *
     * @param args Map of arguments in input to a function
     * @param requiredParams String comma separated that represent the list of mandatory arguments
     */
    static void checkInputParameters(Map args, String requiredParams) {
        List _list = requiredParams.tokenize(',')
        checkInputParameters(args, _list)
    }

    /**
     * Check if the requiredParams are in the args Map passed otherwise raise an Exception
     *
     * @param args Map of arguments in input to a function
     * @param requiredParams List of mandatory arguments
     */
    static void checkInputParameters(Map args, List requiredParams) {
        requiredParams.each { p ->
            if (!args.containsKey(p) || isNullOrEmpty(args.get(p)))
                throw new InvalidParameterException("Missing input parameter: ${p}")
        }
    }

    static void checkInputParametersOr(Map args, String requiredParams) {
        List _list = requiredParams.tokenize(',')
        checkInputParametersOr(args, _list)
    }

    static void checkInputParametersOr(Map args, List requiredParams) {
        boolean exist = requiredParams.any { !isNullOrEmpty(args.get(it)) }
        if (!exist)
            throw new InvalidParameterException("At least one parameter in ${requiredParams} is required")
    }

    /**
     * Check if the input object is null or empty.
     * Accept String|List|Map
     *
     * @param o the object to be checked
     * @return true if is null or empty, false otherwise
     */
    static boolean isNullOrEmpty(Object o) {
        if (o == null)
            return true
        if (o instanceof String || o instanceof GString) {
            return (o.isEmpty() || o == "null")
        } else {
            try {
                o.getClass().getMethod("isEmpty")
                return o.isEmpty()
            } catch (NoSuchMethodException e) {
            }
        }
        return false
    }

    static boolean isString(Object o) {
        if (o == null)
            return false
        return (o instanceof String || o instanceof GString)
    }

    /**
     *  Like checkInputParameters but accept a Map of mandatory parameters in teh form:
     *  [param1:'String',param2:'List']
     *
     * @param args
     * @param requiredParams
     */
    static void checkInputParametersAndClass(Map args, Map requiredParams) {
        def obj = null
        Class objClass = null
        requiredParams.each { key, type ->
            if (!args.containsKey(key) || isNullOrEmpty(args.get(key)))
                throw new InvalidParameterException("Missing or empty input parameter: ${key}")
            objClass = type instanceof Class ? type : Class.forName(type as String)
            obj = args.get(key)
            if (obj.class != objClass.class) {
                throw new InvalidClassException("Expected class ${type} for ${key}, got ${obj.class}")
            }
        }
    }

    /**
     * Convert a map into a JSON string
     *
     * @param obj input map to be converted in JSON
     * @param pretty if true the JSON is formatted to be printed
     * @return
     */
    static String toJson(def obj, boolean pretty = false) {
        String json = JsonOutput.toJson(obj)
        if (pretty) {
            json = JsonOutput.prettyPrint(json)
        }
        return json
    }

    /**
     * Convert a JSON string in an Object
     *
     * @param json JSON string to be converted
     * @return
     */
    static def parseJson(String json) {
        return new JsonSlurperClassic().parseText(json)
    }

    /**
     * Convert a map into a YAML string
     *
     * @param obj input map to be converted in JSON
     * @return
     */
    static String dumpYamlAsMap(Map obj) {
        return new Yaml().dumpAsMap(obj)
    }

    /**
     * Convert a YAML string in an Object
     *
     * @param yaml YAML string to be converted
     * @return
     */
    static def loadYaml(String yaml) {
        return new Yaml().load(yaml)
    }

    /**
     * Get Jenkins proxy configuration or null
     *
     * @return
     */
    static Map getProxyConfig() {
        ProxyConfiguration proxy = Jenkins.getInstanceOrNull()?.proxy
        return proxy == null ? null : [name: proxy.name, port: proxy.port, noProxyHost: proxy.noProxyHost]
    }

    static String getJobLog(def job) {
        return job.getRawBuild().getLog()
    }

    static String getVersionFromLog(String log) {
        Matcher matcher = Pattern.compile(/.*Applying tag (.*) to image.*/, Pattern.DOTALL).matcher(log)
        if (matcher.matches() && matcher.groupCount() > 0) {
            String version = matcher.group(1)
            return version
        }
        return null
    }

    static String getNexusRepoSpec(def pipeline, Map args) {
        def text = null
        if (args.settingsId) {
            pipeline.configFileProvider([pipeline.configFile(fileId: args.settingsId, targetLocation: 'settings.xml')]) {
                text = pipeline.readFile('settings.xml')
            }
            pipeline.sh("rm -rf settings.xml")
        } else if (args.settingsPath) {
            text = pipeline.readFile(args.settingsPath)
        } else {
            text = pipeline.readFile("${pipeline.env.HOME}/.m2/settings.xml")
        }
//        def repoId = version ==~ /.*-SNAPSHOT$/ ? "snapshots" : "releases"
        def xmlSettings = (new XmlParser()).parseText(text)
        def repoUrl = null
        xmlSettings.profiles.profile.repositories.repository.find { repository ->
            if (repository.id.text() == args.repoId) {
                repoUrl = repository.url.text()
                return true
            }
            return false
        }
        if (!repoUrl)
            return null
        args.layout = (args.layout ?: "default")
        return "${args.repoId}::${args.layout}::${repoUrl}" as String
    }

    static String getKibanaLogUrl(def pipeline = null, def args) {
        if (isNullOrEmpty(args.projectUid)) {
            pipeline.openshift.withCluster(pipeline.env.clusterOCP) {
                args.projectUid = pipeline.openshift.selector('project', args.projectName).object().metadata.uid
            }
        }
        def index = "project.${args.projectName}.${args.projectUid}.*"
        def url = "${args.kibanaUrl}/discover?_g=()&_a=(columns:!(message),filters:!(('\$state':(store:appState),meta:(alias:!n,disabled:!f,index:'${index}',key:kubernetes.container_name,negate:!f,type:phrase,value:${args.dcName}),query:(match:(kubernetes.container_name:(query:${args.dcName},type:phrase))))),index:'${index}',interval:auto,query:(match_all:()),sort:!('@timestamp',desc))"
        return url.toString()
    }

    static String getHtmlCloseVersionInfoTable(ArrayList<CloseReleaseMailInfo> infoList) {
        if (infoList != null && !infoList.isEmpty()) {
            StringBuffer buffer = new StringBuffer()
            buffer.append("<table border='1' border-color='navy' width='80%'>")
            buffer.append("<thead style='background-color: #91c1f7;'>")
            buffer.append("<tr>")
            buffer.append("<th><strong>Status</strong></th>")
            buffer.append("<th><strong>Service name</strong></th>")
            buffer.append("<th><strong>Release version</strong></th>")
            buffer.append("<th><strong>Pull request id</strong></th>")
            buffer.append("<th><strong>Merge commit hash</strong></th>")
            buffer.append("<th><strong>Workflow step</strong></th>")
            buffer.append("</tr>")
            buffer.append("</thead>")

            buffer.append("<tbody>")
            infoList.each { infoRecord ->
                if ("SUCCESS" == infoRecord.status) {
                    buffer.append("<tr style='background-color: #8fd484;'>")
                } else if ("FAILURE" == infoRecord.status) {
                    buffer.append("<tr style='background-color: #fc8787;'>")
                }
                buffer.append("<td>${infoRecord.status}</td>")
                buffer.append("<td>${infoRecord.microserviceName}</td>")
                buffer.append("<td>${infoRecord.version}</td>")
                buffer.append("<td>${infoRecord.pullRequestId}</td>")
                if (infoRecord.mergeHash != null) {
                    buffer.append("<td>${infoRecord.mergeHash}</td>")
                } else buffer.append("<td>&nbsp;</td>")
                buffer.append("<td>${infoRecord.step}</td>")
                buffer.append("</tr>")
            }
            buffer.append("</tbody>")
            buffer.append("</table>")
            return buffer.toString()
        }
        return null
    }

    static void printException(def pipeline, Exception e, boolean printStackTrace = false) {
        String stackTrace
        if (printStackTrace) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            stackTrace = sw.toString()
        }
        String msg =
                "______________________________________________________________________________________\n" +
                        "Exception Class: ${e.getClass().toString()}\n" +
                        "Message: ${e.getMessage()}\n" +
                        "Cause: ${e.getCause()}\n" +
                        (printStackTrace ? ("StackTrace: \n" + stackTrace) : '') +
                        "______________________________________________________________________________________\n"

        pipeline.echo("${msg}\n")
    }

    /**
     * This methods gets the Shared Library Branch used by the pipeline.
     * It is used to understand which config.yaml the pipeline has to use (dev or master).
     */
    @NonCPS
    static String getSharedLibraryBranch(def jobName, def buildNumber) {
        String logContent = Jenkins.getInstanceOrNull()
                .getItemByFullName(jobName)
                .getBuildByNumber(Integer.parseInt(buildNumber))
                .logFile.text

        def matcher = logContent =~ /Loading library SharedPipelines@.*/
        return matcher[0].split('@')[1]
    }

    @NonCPS
    static String getSharedLibraryBranch(def currentBuild) {
        List logLines = currentBuild.rawBuild.getLog().tokenize('\n')
        if (logLines.size() > 100)
            logLines = logLines[0..100]
        String library = logLines.find { it.matches(/.*Loading library SharedPipelines@.*/) }
        return library.tokenize('@')[1]
    }

    @NonCPS
    static Map getCIInfoFromFile(def text) {
        Map ret = [:]
        List lines = text.replace('\r', '').tokenize('\n')
        ['MICROSERVICE_NAME', 'CONTEXT_DIR', 'SOURCE_IMAGE'].each { opt ->
            String str = lines.find { it.matches(/.*${opt}.*/) }.trim()
            Matcher matcher = Pattern.compile(/${opt}[ ]*=[ ]*['"](.*)['"]/).matcher(str)
            matcher.matches() && ret.put(opt, matcher.group(1))
        }
        return ret
    }


    static void abortPipeline(def msg) {
        if (msg)
            println(msg)
        throw new FlowInterruptedException(Result.ABORTED)
    }

    static def getJob(Map args) {
        // def jobName = "CI/springboot-demo-war"
        // def jobBranch = "develop"
        // def jobNumber = 1 // int value
//        if (args.jobBranch) {
//            args.jobName = "${args.jobName}%2F${args.jobBranch}"
//        }

        return Jenkins.getInstanceOrNull().getItemByFullName(args.jobName)
    }
}
