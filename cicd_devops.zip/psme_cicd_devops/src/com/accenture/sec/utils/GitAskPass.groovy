package com.accenture.sec.utils



class GitAskPass implements Serializable{

    private String askPassPath
    private def pipeline
    private Map<String, Object> credentials
    private def askpassScript ="""#!/bin/bash -e
case "\$1" in 
Username*) echo \"USERNAME\" ;;
Password*) echo \"PASSWORD\" ;;
esac
"""

    GitAskPass(def pipeline, Map<String, Object> credentials) {

        this.pipeline = pipeline
        this.credentials = credentials
        def randomUUID = UUID.randomUUID().toString()
        this.askPassPath =  this.pipeline.WORKSPACE + "/${randomUUID}"
    }

    void init(){
        this.pipeline.sh """#!/bin/bash -e
        git config --global user.email "noreply@example.com"
        git config --global user.name "${this.credentials.user}"
        git config --global push.default matching
        """
        this.askpassScript = this.askpassScript.replace("USERNAME", this.credentials.user)
        this.askpassScript = this.askpassScript.replace("PASSWORD", this.credentials.password)
        this.pipeline.writeFile file: "${this.askPassPath}", text: "${this.askpassScript}"
        this.pipeline.sh "chmod +x ${this.askPassPath}"
    }

    void exec(gitCommand) {
        this.pipeline.sh("GIT_ASKPASS=${this.askPassPath} ${gitCommand}")
    }
}
