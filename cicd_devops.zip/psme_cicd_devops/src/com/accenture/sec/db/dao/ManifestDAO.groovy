package com.accenture.sec.db.dao


import com.accenture.sec.db.dto.ManifestDTO

import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException

class ManifestDAO implements Serializable {

    private static final String insertQuery = "INSERT INTO MANIFEST (ID_BUILD,VERSION) VALUES (?, ?)"
    private static final String updateQuery = 'UPDATE MANIFEST SET  ID_BUILD = ?, VERSION = ? WHERE ID = ?'
    private static final String deleteQuery = 'DELETE FROM MANIFEST WHERE ID = ?'
    private static final String getLastInsert = 'SELECT * FROM MANIFEST MF WHERE MF.ID = (SELECT MAX(MF2.ID) FROM MANIFEST MF2)'

    private Connection connection = null

    ManifestDAO(Connection connection) {
        this.connection = connection
    }


    /**
     * Insert into MANIFEST table entry defined by dto
     *
     * @param dto
     * @throws SQLException
     */
    ManifestDTO insert(ManifestDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(insertQuery)
        pstm.setLong(1, dto.getIdBuild())
        pstm.setString(2, dto.getVersion())
        pstm.execute()
        return getLastInsert()

    }

    ManifestDTO getLastInsert(){
        PreparedStatement pstm = this.connection.prepareStatement(getLastInsert)

        ResultSet rs = pstm.executeQuery()
        ManifestDTO dto = null
        if (rs.next()) {
            dto = new ManifestDTO()
            dto.setIdBuild(rs.getLong("ID"))
            dto.setIdBuild(rs.getLong("ID_BUILD"))
            dto.setVersion(rs.getString("VERSION"))
        }

        return dto
    }

    /**
     * Update into MANIFEST table entry defined by dto.id
     *
     * @param dto
     * @throws SQLException
     */
    void update(ManifestDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(updateQuery)
        pstm.setLong(1, dto.getIdBuild())
        pstm.setString(2, dto.getVersion())
        pstm.execute()
    }

    void delete(ManifestDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(deleteQuery)
        pstm.setLong(1, dto.getId())
        pstm.execute()
    }
}
