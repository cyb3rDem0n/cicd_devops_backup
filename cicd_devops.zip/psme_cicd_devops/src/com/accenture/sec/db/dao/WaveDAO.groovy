package com.accenture.sec.db.dao


import com.accenture.sec.db.dto.WaveDTO

import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException

class WaveDAO implements Serializable {

    private static final String insertQuery = 'INSERT INTO WAVE (NAME,VERSION) VALUES (?,?)'
    private static final String updateQuery = 'UPDATE WAVE SET NAME = ? WHERE ID = ?'
    private static final String deleteQuery = 'DELETE FROM WAVE WHERE ID = ?'
    private static final String getWaveByNameIdMsQuery = 'SELECT * FROM WAVE WHERE NAME = ?'
    private static final String getAllWavesQuery = 'SELECT * FROM WAVE'
    private static final String getWaveByIdQuery = 'SELECT * FROM WAVE WHERE ID = ?'
    private static final String getWaveByApplicationContextQuery = 'SELECT * FROM WAVE WHERE NAME LIKE ? ORDER BY VERSION'

    private Connection connection = null

    WaveDAO(Connection connection) {
        this.connection = connection
    }

    /**
     * Insert into DEPLOY table entry defined by dto
     *
     * @param dto
     * @throws SQLException
     */
    void insert(WaveDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(insertQuery)
        pstm.setString(1, dto.getName())
        pstm.setLong(2, dto.getVersion())
        pstm.execute()
    }

    /**
     * Update into DEPLOY table entry defined by dto.id
     *
     * @param dto
     * @throws SQLException
     */
    void update(WaveDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(updateQuery)
        pstm.setString(1, dto.getName())
        pstm.execute()
    }

    WaveDTO insertIfNotExists(WaveDTO dto) {
        WaveDTO wvPresentDTO
        wvPresentDTO = getWaveByName(dto.getName())
        if (!wvPresentDTO) {
            this.insert(dto)
            wvPresentDTO = getWaveByName(dto.getName())
        }
        return wvPresentDTO
    }

    void delete(WaveDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(deleteQuery)
        pstm.setLong(1, dto.getId())
        pstm.execute()
    }

    List<WaveDTO> getAllWavesQuery() throws SQLException {
        WaveDTO wave = null
        List<WaveDTO> waves = new ArrayList<WaveDTO>()
        PreparedStatement pstm = this.connection.prepareStatement(getAllWavesQuery)

        ResultSet rs = pstm.executeQuery()
        while (rs.next()) {
            wave = new WaveDTO()
            wave.setId(rs.getLong('ID'))
            wave.setName(rs.getString('NAME'))
            wave.setVersion(rs.getLong('VERSION'))
            waves.add(wave)
        }

        return waves
    }

    WaveDTO getWaveByName(String waveName) throws SQLException {
        WaveDTO wave = null

        PreparedStatement pstm = this.connection.prepareStatement(getWaveByNameIdMsQuery)
        pstm.setString(1, waveName)
        ResultSet rs = pstm.executeQuery()
        if (rs.next()) {
            wave = new WaveDTO()
            wave.setId(rs.getLong('ID'))
            wave.setName(rs.getString('NAME'))
            wave.setVersion(rs.getLong('VERSION'))
        }

        return wave
    }

    List<WaveDTO> getWaveByApplicationContext(def filterStr) throws SQLException {
        List<WaveDTO> list = []
        WaveDTO wave

        PreparedStatement pstm = this.connection.prepareStatement(getWaveByApplicationContextQuery)
        pstm.setString(1, filterStr as String)
        ResultSet rs = pstm.executeQuery()
        while (rs.next()) {
            wave = new WaveDTO()
            wave.setId(rs.getLong('ID'))
            wave.setName(rs.getString('NAME'))
            wave.setVersion(rs.getLong('VERSION'))
            list.add(wave)
        }

        return list
    }

    List<WaveDTO> getWaveById(long waveId) throws SQLException {
        WaveDTO wave
        List<WaveDTO> listWave = []

        PreparedStatement pstm = this.connection.prepareStatement(getWaveByIdQuery)
        pstm.setLong(1, waveId)
        ResultSet rs = pstm.executeQuery()
        while (rs.next()) {
            wave = new WaveDTO()
            wave.setId(rs.getLong('ID'))
            wave.setName(rs.getString('NAME'))
            wave.setVersion(rs.getLong('VERSION'))
            listWave.add(wave)
        }

        return listWave
    }
}
