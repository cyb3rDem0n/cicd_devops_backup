package com.accenture.sec.db.dao


import com.accenture.sec.db.dto.ReleaseTypeDTO

import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException
@Deprecated
class ReleaseTypeDAO implements Serializable {

    private static final String selectByReleaseTypeCode = "SELECT * FROM RELEASE_TYPE WHERE RELEASE_TYPE.CODE = ?"
    private Connection connection = null

    ReleaseTypeDAO(Connection connection) {
        this.connection = connection
    }

    /**
     * Gets ReleaseTypeDTO from release_type.code
     *
     *
     * @throws SQLException
     */

    ReleaseTypeDTO getByReleaseTypeCode(long code) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(selectByReleaseTypeCode)
        pstm.setLong(1, code)
        ResultSet rs = pstm.executeQuery()
        ReleaseTypeDTO releaseType = null
        if (rs.next()) {
            releaseType = createReleaseTypeDTO(rs)
        }
        return releaseType
    }

    private ReleaseTypeDTO createReleaseTypeDTO(ResultSet rs){
        ReleaseTypeDTO releaseType = new ReleaseTypeDTO()
        releaseType.setCode(rs.getLong('CODE'))
        releaseType.setType(rs.getString('TYPE'))
        return releaseType
    }

}
