package com.accenture.sec.db.dao

import com.accenture.sec.db.dto.MicroserviceDTO
import com.accenture.sec.db.dto.WaveDTO

import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException

class MicroserviceDAO implements Serializable {

    private static final String insertQuery = 'INSERT INTO MICROSERVICE (NAME, ENABLED, DEPLOY_ENV_TARGET) VALUES (?,?,?)'
    private static final String insertQueryWithTarget = 'INSERT INTO MICROSERVICE (NAME, ENABLED, DEPLOY_ENV_TARGET) VALUES (?,?,?)'
    private static final String updateQuery = 'UPDATE MICROSERVICE SET NAME = ?, ENABLED = ? WHERE ID = ?'
    private static final String deleteQuery = 'DELETE FROM MICROSERVICE WHERE ID = ?'
    private static final String getMicroserviceByNameQuery = 'SELECT * FROM MICROSERVICE WHERE NAME = ?'
    private static final String getMicroserviceByIdQuery = 'SELECT * FROM MICROSERVICE WHERE ID = ?'

    private Connection connection = null

    MicroserviceDAO(Connection connection) {
        this.connection = connection
    }

    /**
     * Insert into DEPLOY table entry defined by dto
     *
     * @param dto
     * @throws SQLException
     */
    MicroserviceDTO insert(MicroserviceDTO dto) throws SQLException {
        PreparedStatement pstm = dto.target ? this.connection.prepareStatement(insertQueryWithTarget) : this.connection.prepareStatement(insertQuery)
        pstm.setString(1, dto.getName())
        pstm.setBoolean(2, dto.getEnabled()?dto.getEnabled():true)
        pstm.setString(3, dto.getTarget())
        dto.target && pstm.setString(3, dto.getTarget())
        pstm.execute()
        return getMicroserviceByName(dto.getName())
    }

    /**
     * Update into DEPLOY table entry defined by dto.id
     *
     * @param dto
     * @throws SQLException
     */
    void update(MicroserviceDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(updateQuery)
        pstm.setString(1, dto.getName())
        pstm.setBoolean(2, dto.getEnabled())
        pstm.setLong(3, dto.getId())
        pstm.execute()
    }

    void delete(MicroserviceDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(deleteQuery)
        pstm.setLong(1, dto.getId())
        pstm.execute()
    }

    MicroserviceDTO insertIfNotExists(MicroserviceDTO dto) {
        MicroserviceDTO msPresentDTO
        msPresentDTO = getMicroserviceByName(dto.getName())
        if (msPresentDTO != null) {
            return msPresentDTO
        } else {
            dto = this.insert(dto)
            return dto
        }
    }

    MicroserviceDTO getMicroserviceByName(String msName) throws SQLException {
        MicroserviceDTO microservice = null

        PreparedStatement pstm = this.connection.prepareStatement(getMicroserviceByNameQuery)
        pstm.setString(1, msName)
        ResultSet rs = pstm.executeQuery()
        if (rs.next()) {
            microservice = new MicroserviceDTO()
            microservice.setId(rs.getLong('ID'))
            microservice.setName(rs.getString('NAME'))
            microservice.setEnabled(rs.getBoolean('ENABLED'))
            microservice.setTarget(rs.getString('DEPLOY_ENV_TARGET'))
        }

        return microservice
    }

    List<MicroserviceDTO> getMicroserviceById(long msId) throws SQLException {
        MicroserviceDTO microservice = null

        PreparedStatement pstm = this.connection.prepareStatement(getMicroserviceByIdQuery)
        pstm.setString(1, msId)
        ResultSet rs = pstm.executeQuery()
        if (rs.next()) {
            microservice = new MicroserviceDTO()
            microservice.setId(rs.getLong('ID'))
            microservice.setName(rs.getString('NAME'))
            microservice.setEnabled(rs.getBoolean('ENABLED'))
        }

        return microservice
    }


}
