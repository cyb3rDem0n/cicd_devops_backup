package com.accenture.sec.db.dao

import com.accenture.sec.db.dto.BuildDTO

import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException

class BuildDAO implements Serializable {

    private static final String insertQuery = 'INSERT INTO BUILD (ID_WAVE,ID_MS,BUILD_NUM, DEPS) VALUES (?,?,?,?)'
    private static final String updateQuery = 'UPDATE BUILD SET ID_WAVE = ? , ID_MS = ?, BUILD_NUM = ?, DEPS= ? WHERE ID = ?'
    private static final String deleteQuery = 'DELETE FROM BUILD WHERE ID = ?'
    private static final String getManifestByAll ="SELECT * FROM BUILD WHERE ID_MS = ? AND ID_WAVE = ? AND BUILD_NUM = ?"
    private static final String getManifestByMsBuild ="SELECT * FROM BUILD WHERE ID_MS = ? AND BUILD_NUM = ?"

    private Connection connection = null

    BuildDAO(Connection connection) {
        this.connection = connection
    }


    /**
     * Insert into MANIFEST table entry defined by dto
     *
     * @param dto
     * @throws SQLException
     */
    BuildDTO insert(BuildDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(insertQuery)
        pstm.setLong(1, dto.getIdWave())
        pstm.setLong(2, dto.getIdMs())
        pstm.setString(3, dto.getBuildNum())
        if(dto.getDeps().size() > 0){
            pstm.setString(4, dto.getDeps().join(','))
        }
        else pstm.setString(4, "")
        pstm.execute()
        return getBuildByAllExceptId(dto)
    }

    /**
     * Update into MANIFEST table entry defined by dto.id
     *
     * @param dto
     * @throws SQLException
     */
    void update(BuildDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(updateQuery)
        pstm.setLong(1, dto.getIdWave())
        pstm.setString(2, dto.getIdMs())
        pstm.setString(3, dto.getBuildNum())
        pstm.setString(4, dto.getDeps().join(','))
        pstm.execute()
    }

    void delete(BuildDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(deleteQuery)
        pstm.setLong(1, dto.getId())
        pstm.execute()
    }

    BuildDTO getBuildByAllExceptId(BuildDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(getManifestByAll)
        pstm.setLong(1, dto.getIdMs())
        pstm.setLong(2, dto.getIdWave())
        pstm.setString(3, dto.getBuildNum())
        ResultSet rs = pstm.executeQuery()
        if (rs.next()) {
            dto.setId(rs.getLong("ID"))

            return dto
        }
        return null
    }

    BuildDTO getManifestByMsAndBuild(BuildDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(getManifestByMsBuild)
        pstm.setString(1, dto.getIdMs())
        pstm.setString(2, dto.getBuildNum())
        ResultSet rs = pstm.executeQuery()
        if (rs.next()) {
            dto.setId(rs.getLong("ID"))
            dto.setIdWave(rs.getLong("ID_WAVE"))
            dto.setDeps(rs.getString("DEPS").join(','))
            return dto
        }
        return null
    }
}
