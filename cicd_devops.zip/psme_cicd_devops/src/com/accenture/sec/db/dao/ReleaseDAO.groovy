package com.accenture.sec.db.dao

import com.accenture.sec.db.dto.ReleaseDTO

import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException

class ReleaseDAO implements Serializable {

    private static final String insertQuery = "INSERT INTO RELEASE (MF_VERSION, VERSION, CURR_ENV, ID_WAVE) VALUES (?,?,?,?)"
    private static final String updateQuery = "UPDATE RELEASE SET MF_VERSION = ? , VERSION = ? , CURR_ENV =? , ID_WAVE = ? WHERE ID = ?"
    private static final String deleteQuery = "DELETE FROM RELEASE WHERE RELEASE.ID = ?"

    private static final String selectReleaseQuery ="SELECT * FROM RELEASE WHERE RELEASE.REL_NUM=?"
    private static final String releaseById ="SELECT * FROM RELEASE WHERE RELEASE.ID=?"
    private static final String selectLastInsertReleaseByWaveQuery = "SELECT * FROM RELEASE WHERE MF_VERSION = ? AND CURR_ENV = ? AND ID_WAVE = ? AND ID = (SELECT MAX(R2.ID) FROM RELEASE R2 WHERE R2.MF_VERSION = ? AND R2.CURR_ENV = ? AND R2.ID_WAVE = ? )"
    private Connection connection = null

    ReleaseDAO(Connection connection) {
        this.connection = connection
    }


    /**
     * Insert into RELEASE table entry defined by dto
     *
     * @param dto
     * @throws SQLException
     */
    ReleaseDTO insert(ReleaseDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(insertQuery)
        pstm.setString(1, dto.getMfVersion())
        pstm.setString(2, dto.getVersion())
        pstm.setString(3, dto.getCurrEnv())
        pstm.setLong(4, dto.getIdWave())
        pstm.execute()
        return getLastInsertReleaseByWave(dto.getMfVersion(), dto.getCurrEnv(), dto.getIdWave())
    }

    /**
     * Update into RELEASE table entry defined by dto
     *
     * @param dto
     * @throws SQLException
     */

    void update(ReleaseDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(updateQuery)
        pstm.setString(1, dto.getMfVersion())
        pstm.setString(2, dto.getVersion())
        pstm.setString(3, dto.getCurrEnv())
        pstm.setLong(4, dto.getIdWave())
        pstm.setLong(5, dto.getId())
        pstm.execute()
    }

    void delete(ReleaseDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(deleteQuery)
        pstm.setLong(1, dto.getId())
        pstm.execute()
    }

    /**
     * Get a RELEASE entry from the release id
     *
     * @param releaseId
     * @return
     * @throws SQLException
     */
    ReleaseDTO getLastInsertReleaseByWave(String mfVersion, String currEnv, Long idWave) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(selectLastInsertReleaseByWaveQuery)
        pstm.setString(1, mfVersion)
        pstm.setString(2, currEnv)
        pstm.setLong(3, idWave)
        pstm.setString(4, mfVersion)
        pstm.setString(5, currEnv)
        pstm.setLong(6, idWave)
        ResultSet rs = pstm.executeQuery()
        ReleaseDTO release = null
        if (rs.next()) {
            release = new ReleaseDTO()
            release.setId(rs.getLong("ID"))
            release.setMfVersion(rs.getString("MF_VERSION"))
            release.setVersion(rs.getString("VERSION"))
            release.setCurrEnv(rs.getString("CURR_ENV"))
            release.setIdWave(rs.getLong("ID_WAVE"))
        }
        return release
    }

    /**
     * Get a RELEASE entry from the release number
     *
     * @param releaseNumber
     * @return
     * @throws SQLException
     */
    ReleaseDTO getReleasebyVersion(String version) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(selectReleaseQuery)
        pstm.setString(1, version)
        ResultSet rs = pstm.executeQuery()
        ReleaseDTO release = null
        if (rs.next()) {
            release.setId(rs.getLong('ID'))
            release.setMfVersion(rs.getString('MF_VERSION'))
            release.setVersion(rs.getString('VERSION'))
            release.getCurrEnv(rs.getString('CURR_ENV'))
            release.setIdWave(rs.getLong("ID_WAVE"))
        }
        return release
    }

    ReleaseDTO getReleaseById(String releaseId) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(releaseById)
        pstm.setString(1, releaseId)
        ResultSet rs = pstm.executeQuery()
        ReleaseDTO release = null
        if (rs.next()) {
            release.setId(rs.getLong('ID'))
            release.setMfVersion(rs.getString('MF_VERSION'))
            release.setVersion(rs.getString('VERSION'))
            release.getCurrEnv(rs.getString('CURR_ENV'))
            release.setIdWave(rs.getLong("ID_WAVE"))
        }
        return release
    }

}
