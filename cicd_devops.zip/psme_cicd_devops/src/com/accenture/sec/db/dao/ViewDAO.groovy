package com.accenture.sec.db.dao


import com.accenture.sec.db.dto.DeployInfoDTO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.db.dto.ReleaseInfoDTO
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException

class ViewDAO implements Serializable {

    private static final String getLastDeployInfoQuery = 'SELECT * FROM DEPLOY_INFO DEP_INFO WHERE DEP_INFO.MICROSERVICE = ? AND DEP_INFO.ENV=? AND DEP_INFO.TSTAMP = (SELECT MAX(TSTAMP) FROM DEPLOY_INFO WHERE MICROSERVICE = ? AND ENV=?)'
    private static final String getManifestCollProdQuery = 'SELECT MICROSERVICE, BUILD_NUM, DEPS, TARGET FROM RELEASE_MANIFEST_INFO WHERE MANIFEST_VERSION = ? and WAVE = ? group by (MICROSERVICE, BUILD_NUM, DEPS, TARGET)'
    private static final String getManifestVersionListByWave = 'SELECT DISTINCT(MANIFEST_VERSION) FROM RELEASE_MANIFEST_INFO WHERE WAVE = ? and MANIFEST_VERSION is not null;'
    private static final String getManifestListByWaveAndVersionQuery = 'SELECT * FROM RELEASE_MANIFEST_INFO WHERE WAVE = ? AND MANIFEST_VERSION= ?'
    private static final String getManifestTest = 'SELECT * FROM NEXT_TEST_MF WHERE WAVE = ?'
    private static final String getManifestInfoQuery = "SELECT * FROM RELEASE_MANIFEST_INFO WHERE WAVE = ? AND MICROSERVICE =? AND BUILD_NUM = ? AND ID_BUILD = (SELECT MAX(RMI.ID_BUILD) FROM RELEASE_MANIFEST_INFO RMI WHERE RMI.WAVE = ? AND RMI.MICROSERVICE = ? AND RMI.BUILD_NUM = ?)"
     private static final String getManifestInfoForUpdateDeploy = "SELECT * FROM RELEASE_MANIFEST_INFO WHERE WAVE = ? AND MICROSERVICE =? AND BUILD_NUM = ? AND ID_BUILD = (SELECT MAX(RMI.ID_BUILD) FROM RELEASE_MANIFEST_INFO RMI WHERE RMI.WAVE = ? AND RMI.MICROSERVICE = ? AND RMI.BUILD_NUM = ?) AND ID_MANIFEST = (SELECT MAX(RMI2.ID_MANIFEST) FROM RELEASE_MANIFEST_INFO RMI2 WHERE RMI2.WAVE = ? AND RMI2.MICROSERVICE = ? AND RMI2.BUILD_NUM = ?)"
    private static final String getReleaseAndManifest = 'SELECT * FROM RELEASE REL LEFT JOIN MANIFEST MF ON (REL.MF_VERSION = MF.VERSION) WHERE REL.VERSION = ?'
    private static final String getDeployedByReleaseMsBuildQuery = 'SELECT * FROM RELEASE_MANIFEST_INFO WHERE REL_VERSION = ? AND MICROSERVICE =? AND BUILD_NUM = ?'

    private Connection connection = null

    ViewDAO(Connection connection) {
        this.connection = connection
    }

    DeployInfoDTO getLastDeployInfo(String ms, String env) throws SQLException {
        DeployInfoDTO deployInfo = null

        PreparedStatement pstm = this.connection.prepareStatement(getLastDeployInfoQuery)
        pstm.setString(1, ms)
        pstm.setString(2, env)
        pstm.setString(3, ms)
        pstm.setString(4, env)
        ResultSet rs = pstm.executeQuery()

        if (rs.next()) {
            deployInfo = new DeployInfoDTO()
            deployInfo.setId(rs.getLong('ID_DEPLOY'))
            deployInfo.setWave(rs.getString('WAVE'))
            deployInfo.setMicroservice(rs.getString('MICROSERVICE'))
            deployInfo.setBuildNum(rs.getString('BUILD_NUM'))
            deployInfo.setEnv(rs.getString('ENV'))
            deployInfo.settStamp(rs.getTimestamp('TSTAMP'))
            deployInfo.setTarget(rs.getString('TARGET'))
        }
        return deployInfo
    }

    ManifestInfoDTO getManifestInfo(String wave, String microservice, String buildNum){
        ManifestInfoDTO manifestInfoDTO = null

        PreparedStatement pstm = this.connection.prepareStatement(getManifestInfoQuery)
        pstm.setString(1, wave)
        pstm.setString(2, microservice)
        pstm.setString(3, buildNum)
        pstm.setString(4, wave)
        pstm.setString(5, microservice)
        pstm.setString(6, buildNum)
        ResultSet rs = pstm.executeQuery()

        if (rs.next()) {
            manifestInfoDTO = new ManifestInfoDTO()
            manifestInfoDTO.setIdRelease(rs.getLong('ID_RELEASE'))
            manifestInfoDTO.setIdManifest(rs.getLong('ID_MANIFEST'))
            manifestInfoDTO.setIdBuild(rs.getLong('ID_BUILD'))
            manifestInfoDTO.setIdWave(rs.getLong('ID_WAVE'))
            manifestInfoDTO.setWave(rs.getString('WAVE'))
            manifestInfoDTO.setMicroservice(rs.getString('MICROSERVICE'))
            manifestInfoDTO.setBuildNum(rs.getString('BUILD_NUM'))
            manifestInfoDTO.setMfVersion(rs.getString('MANIFEST_VERSION'))
        }
        return manifestInfoDTO
    }

    ManifestInfoDTO getManifestInfoForUpdateDeploy(String wave, String microservice, String buildNum){
        ManifestInfoDTO manifestInfoDTO = null

        PreparedStatement pstm = this.connection.prepareStatement(getManifestInfoForUpdateDeploy)
        pstm.setString(1, wave)
        pstm.setString(2, microservice)
        pstm.setString(3, buildNum)
        pstm.setString(4, wave)
        pstm.setString(5, microservice)
        pstm.setString(6, buildNum)
        pstm.setString(7, wave)
        pstm.setString(8, microservice)
        pstm.setString(9, buildNum)
        ResultSet rs = pstm.executeQuery()

        if (rs.next()) {
            manifestInfoDTO = new ManifestInfoDTO()
            manifestInfoDTO.setIdRelease(rs.getLong('ID_RELEASE'))
            manifestInfoDTO.setIdManifest(rs.getLong('ID_MANIFEST'))
            manifestInfoDTO.setIdBuild(rs.getLong('ID_BUILD'))
            manifestInfoDTO.setIdWave(rs.getLong('ID_WAVE'))
            manifestInfoDTO.setWave(rs.getString('WAVE'))
            manifestInfoDTO.setMicroservice(rs.getString('MICROSERVICE'))
            manifestInfoDTO.setBuildNum(rs.getString('BUILD_NUM'))
            manifestInfoDTO.setMfVersion(rs.getString('MANIFEST_VERSION'))
        }
        return manifestInfoDTO
    }

    ManifestInfoDTO getDeployedByReleaseAndMs(String releaseVersion, String microservice){
        ManifestInfoDTO manifestInfoDTO = null

        PreparedStatement pstm = this.connection.prepareStatement(getDeployedByReleaseMsBuildQuery)
        pstm.setString(1, releaseVersion)
        pstm.setString(2, microservice)
        ResultSet rs = pstm.executeQuery()

        if (rs.next()) {
            manifestInfoDTO = new ManifestInfoDTO()
            manifestInfoDTO.setIdBuild(rs.getLong('ID_RELEASE'))
            manifestInfoDTO.setWave(rs.getString('REL_VERSION'))
            manifestInfoDTO.setIdManifest(rs.getLong('ID_MANIFEST'))
            manifestInfoDTO.setIdBuild(rs.getLong('ID_BUILD'))
            manifestInfoDTO.setIdWave(rs.getLong('ID_WAVE'))
            manifestInfoDTO.setWave(rs.getString('WAVE'))
            manifestInfoDTO.setMicroservice(rs.getString('MICROSERVICE'))
            manifestInfoDTO.setBuildNum(rs.getString('BUILD_NUM'))
        }
        return manifestInfoDTO
    }

    List<ManifestInfoDTO> getManifestTest(String wave) throws SQLException {
        ManifestInfoDTO manifest
        List<ManifestInfoDTO> listManifest = []
        PreparedStatement pstm = this.connection.prepareStatement(getManifestTest)
        pstm.setString(1, wave)
        ResultSet rs = pstm.executeQuery()
        while (rs.next()) {
            manifest = new ManifestInfoDTO()
            manifest.setIdBuild(rs.getLong("ID_BUILD"))
            manifest.setWave(rs.getString("WAVE"))
            manifest.setMicroservice(rs.getString("MICROSERVICE"))
            manifest.setBuildNum(rs.getString("BUILD_NUM"))
            manifest.setDeps(CommonUtils.commaStringToList(rs.getString("DEPS")))
            manifest.setTarget(rs.getString("TARGET"))
            listManifest.add(manifest)
        }

        return listManifest
    }

    List<ManifestInfoDTO> getManifestCollProd(String wave, String mfVersion) throws SQLException {
        ManifestInfoDTO manifest
        List<ManifestInfoDTO> listManifest = []
        PreparedStatement pstm = this.connection.prepareStatement(getManifestCollProdQuery)
        pstm.setString(1, mfVersion)
        pstm.setString(2, wave)
        ResultSet rs = pstm.executeQuery()
        while (rs.next()) {
            manifest = new ManifestInfoDTO()
            manifest.setMicroservice(rs.getString("MICROSERVICE"))
            manifest.setBuildNum(rs.getString("BUILD_NUM"))
            manifest.setDeps(CommonUtils.commaStringToList(rs.getString("DEPS")))
            manifest.setTarget(rs.getString("TARGET"))
            listManifest.add(manifest)
        }

        return listManifest
    }

    List<String> getManifestVersionListByWave(String wave) throws SQLException {
        String manifestVersion
        List<String> manifestVersionList = []
        PreparedStatement pstm = this.connection.prepareStatement(getManifestVersionListByWave)
        pstm.setString(1, wave)
        ResultSet rs = pstm.executeQuery()
        while (rs.next()) {
            manifestVersion = rs.getString("MANIFEST_VERSION")
            manifestVersionList.add(manifestVersion)
        }

        return manifestVersionList
    }

    List<ManifestInfoDTO> getManifestListByWaveAndVersion(String wave, String mfVersion) throws SQLException {
        ManifestInfoDTO manifestInfoDTO
        List<ManifestInfoDTO> listManifest = []
        PreparedStatement pstm = this.connection.prepareStatement(getManifestListByWaveAndVersionQuery)
        pstm.setString(1, wave)
        pstm.setString(2, mfVersion)
        ResultSet rs = pstm.executeQuery()
        while (rs.next()) {
            manifestInfoDTO = new ManifestInfoDTO()
            manifestInfoDTO.setIdBuild(rs.getLong('ID_RELEASE'))
            manifestInfoDTO.setWave(rs.getString('REL_VERSION'))
            manifestInfoDTO.setIdManifest(rs.getLong('ID_MANIFEST'))
            manifestInfoDTO.setIdBuild(rs.getLong('ID_BUILD'))
            manifestInfoDTO.setIdWave(rs.getLong('ID_WAVE'))
            manifestInfoDTO.setWave(rs.getString('WAVE'))
            manifestInfoDTO.setMicroservice(rs.getString('MICROSERVICE'))
            manifestInfoDTO.setBuildNum(rs.getString('BUILD_NUM'))
            listManifest.add(manifestInfoDTO)
        }

        return listManifest
    }

    ReleaseInfoDTO getManifestByRelease(String releaseVersion){
        PreparedStatement pstm = this.connection.prepareStatement(getReleaseAndManifest)
        pstm.setString(1, releaseVersion)

        ResultSet rs = pstm.executeQuery()
        ReleaseInfoDTO releaseInfoDTO = null
        if (rs.next()) {
            releaseInfoDTO = new ReleaseInfoDTO()
            releaseInfoDTO.setId(rs.getLong("REL.ID"))
            releaseInfoDTO.setMfVersion(rs.getString("REL.MF_VERSION"))
            releaseInfoDTO.setManifestVersion(rs.getString("MF.VERSION"))
            releaseInfoDTO.setReleaseVersion(rs.getString("REL.VERSION"))
            releaseInfoDTO.setCurrEnv(rs.getString("REL.VERSION"))
        }
        return releaseInfoDTO
    }
}
