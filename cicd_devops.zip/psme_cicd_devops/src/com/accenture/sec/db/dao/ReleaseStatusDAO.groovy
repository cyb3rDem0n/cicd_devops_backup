package com.accenture.sec.db.dao

import com.accenture.sec.db.dto.ReleaseStatusDTO


import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException
@Deprecated
class ReleaseStatusDAO implements Serializable {

    private static final String selectByReleaseStatusCode = "SELECT * FROM RELEASE_STATUS WHERE RELEASE_STATUS.CODE = ?"
    private Connection connection = null
    private def pipeline

    ReleaseStatusDAO(Connection connection) {
        this.connection = connection
    }

    /**
     * Gets ReleaseStatusDTO from release_status.code
     *
     *
     * @throws SQLException
     */

    ReleaseStatusDTO getByStatusCode(int code) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(selectByReleaseStatusCode)
        pstm.setInt(1, code)
        ResultSet rs = pstm.executeQuery()
        ReleaseStatusDTO releaseStatus = null
        if (rs.next()) {
            releaseStatus = createReleaseStatusDTO(rs)
        }
        return releaseStatus
    }

    private ReleaseStatusDTO createReleaseStatusDTO(ResultSet rs){
        ReleaseStatusDTO releaseStatus = new ReleaseStatusDTO()
        releaseStatus.setCode(rs.getLong('CODE'))
        releaseStatus.setStatus(rs.getString('STATUS'))
        return releaseStatus
    }

}
