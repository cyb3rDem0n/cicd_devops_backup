package com.accenture.sec.db.dao

import com.accenture.sec.db.dto.DeployDTO
import com.accenture.sec.db.dto.BuildDTO

import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.SQLException

class DeployDAO implements Serializable {

    private static final String insertQuery = 'INSERT INTO DEPLOY (ID_MANIFEST,MS_NAME, BUILD_NUM, ENV, TSTAMP) VALUES (?,?,?,?,?)'
    private static final String updateQuery = 'UPDATE DEPLOY SET ID_MANIFEST = ?, MS_NAME = ?, BUILD_NUM = ?, ENV = ? WHERE ID = ?'
    private static final String deleteQuery = 'DELETE FROM DEPLOY WHERE DEPLOY.ID = ?'
    private static final String getDeploy = 'SELECT * FROM DEPLOY WHERE DEPLOY.MS_NAME = ? AND DEPLOY.BUILD_NUM = ? AND DEPLOY.ENV = ?'
    private Connection connection = null

    DeployDAO(Connection connection) {
        this.connection = connection
    }

    /**
     * Insert into DEPLOY table entry defined by dto
     *
     * @param dto
     * @throws SQLException
     */
    void insert(DeployDTO dto) throws SQLException {
            PreparedStatement pstm = this.connection.prepareStatement(insertQuery)
            pstm.setLong(1, dto.getIdManifest())
            pstm.setString(2, dto.getMicroservice())
            pstm.setString(3, dto.getBuildNum())
            pstm.setString(4, dto.getEnv())
            pstm.setTimestamp(5, dto.gettStamp())
            pstm.execute()
    }

    /**
     * Update into DEPLOY table entry defined by dto.id
     *
     * @param dto
     * @throws SQLException
     */
    void update(DeployDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(updateQuery)
        pstm.setLong(1, dto.getIdManifest())
        pstm.setString(2, dto.getMicroservice())
        pstm.setString(3, dto.getBuildNum())
        pstm.setString(4, dto.getEnv())
        pstm.setLong(5, dto.getId())
        pstm.execute()
    }

    void delete(BuildDTO dto) throws SQLException {
        PreparedStatement pstm = this.connection.prepareStatement(deleteQuery)
        pstm.setLong(1, dto.getId())
        pstm.execute()
    }

/**
     * Get from DEPLOY table all the entries that have the same releaseId
     *
     * @param releaseId filter for the DEPLOY entries
     * @return a List of ManifestDTO representing a deploy
     * @throws SQLException
     */
/*    List<DeployDTO> getDeploy(String ms, String version, String env) throws SQLException {
        DeployDTO deploy = null

        List<DeployDTO> listDeploy = []

        PreparedStatement pstm = this.connection.prepareStatement(getDeploy)
        pstm.setString(1, dto.getMicroservice())
        pstm.setString(2, dto.getVersion())
        pstm.setString(3, dto.getEnvironment())
        ResultSet rs = pstm.executeQuery()
        while (rs.next()) {
            deploy = new DeployDTO()
            deploy = DeployDAO.createDeployDTO(rs)
            listDeploy.add(deploy)
        }

        return listDeploy
    }*/
}
