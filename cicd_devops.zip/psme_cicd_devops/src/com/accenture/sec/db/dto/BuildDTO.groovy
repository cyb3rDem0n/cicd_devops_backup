package com.accenture.sec.db.dto

class BuildDTO implements Serializable {

    Long id
    Long idWave
    Long idMs
    String buildNum
    List<String> deps

    List<String> getDeps() {
        return (deps ?: [])
    }

    boolean equals(o) {
        if (o == null) return false
        if (this.is(o)) return true
        if (getClass() != o.class) return false

        BuildDTO that = (BuildDTO) o

        if (idMs != that.idMs) return false
        if (buildNum != that.buildNum) return false

        return true
    }

    Map toMap(){
        return [id: id, idWave: idWave, idMs: idMs, buildNum: buildNum, deps: deps]
    }

    String toString(){
        return toMap().toString()
    }
}
