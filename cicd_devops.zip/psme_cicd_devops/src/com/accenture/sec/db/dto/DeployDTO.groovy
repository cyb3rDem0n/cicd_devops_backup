package com.accenture.sec.db.dto

import java.sql.Timestamp

class DeployDTO implements Serializable{

    Long id
    Long idManifest
    String microservice
    String buildNum
    String env
    Timestamp tStamp

/*
    boolean equals(o) {
        if (o == null) return false
        if (this.is(o)) return true
        if (getClass() != o.class) return false

        DeployDTO that = (DeployDTO) o

        if (this.microservice != that.microservice) return false
        if (this.version != that.version) return false
        if (this.environment != that.environment) return false
        if (this.tStamp != that.tStamp) return false

        return true
    }

    ManifestDTO toManifestDTO(){
        ManifestDTO dto = new ManifestDTO()
        dto.microservice = this.microservice
        dto.version = this.version
        return dto
    }

    Map toMap() {
        return [(this.microservice): [version: this.version, microservice: this.microservice, environment: this.environment, tStamp: this.tStamp]]
    }

    String toString() {
        return String.format("ManifestDTO: [id: %d, microservice: %s, version: %s, environment: %s, tStamp: %s]", this.id, this.microservice, this.version, this.environment, this.tStamp.toString());
    }*/
}
