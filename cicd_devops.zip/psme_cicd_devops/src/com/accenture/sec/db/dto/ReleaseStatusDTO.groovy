package com.accenture.sec.db.dto
@Deprecated
class ReleaseStatusDTO implements Serializable{

    private long code
    private String status

    ReleaseStatusDTO(){}

    ReleaseStatusDTO(ReleaseStatus releaseStatusType){
        this.code = releaseStatusType.code
        this.status = releaseStatusType.status
    }

    long getCode() {
        return code
    }


    void setCode(long code) {
        this.code = code
    }

    String getStatus() {
        return status
    }


    void setStatus(String status) {
        this.status = status
    }

    void updateFromEnum(ReleaseStatus releaseStatusType){
        this.code = releaseStatusType.code
        this.status = releaseStatusType.status
    }

    String toString() {
        return String.format("ReleaseStatusDTO: [code: %d, status: %s]", this.code, this.status)
    }

    enum ReleaseStatus{

        RELEASE_CANDIDATE(1,'RC'),
        RELEASE_FREEZED(2,'RF'),
        RELEASE(3,'R'),
        RELEASE_ROLLED(4,'RR')

        Long code
        String status

        private ReleaseStatus(Long code, String status) {
            this.code = code
            this.status = status
        }

        static ReleaseStatus fromCode(Long code) {
            ReleaseStatus answer = values().find { it.code == code }
            return answer
        }

        static ReleaseStatus fromStatus(String status) {
            ReleaseStatus answer = values().find { it.status.equalsIgnoreCase(status) }
            return answer
        }
    }
}
