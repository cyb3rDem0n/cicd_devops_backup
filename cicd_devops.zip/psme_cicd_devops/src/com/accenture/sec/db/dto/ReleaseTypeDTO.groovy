package com.accenture.sec.db.dto
@Deprecated
class ReleaseTypeDTO implements Serializable{

    private long code
    private String type

    ReleaseTypeDTO(){}

    ReleaseTypeDTO(ReleaseType releaseType){
        this.code = releaseType.code
        this.type = releaseType.type
    }

    long getCode() {
        return code
    }


    void setCode(long code) {
        this.code = code
    }

    String getType() {
        return type
    }


    void setType(String type) {
        this.type = type
    }

    void updateFromEnum(ReleaseType releaseType){
        this.code = releaseType.code
        this.type = releaseType.type
    }

    String toString() {
        return String.format("ReleaseTypeDTO: [code: %d, type: %s]", this.code, this.type)
    }

    enum ReleaseType{

        MICROSERVICE(1,'MICROSERVICE'),
        CONFLUENT(2,'CONFLUENT'),
        CDC(3,'CDC')

        Long code
        String type

        private ReleaseType(Long code, String type) {
            this.code = code
            this.type = type
        }

        static ReleaseType fromCode(Long code) {
            ReleaseType answer = values().find { it.code == code }
            return answer
        }

        static ReleaseType fromType(String type) {
            ReleaseType answer = values().find { it.type.equalsIgnoreCase(type) }
            return answer
        }
    }
}
