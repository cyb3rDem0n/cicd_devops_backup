package com.accenture.sec.db.dto

class MicroserviceDTO {
    Long id = null
    String name = null
    Boolean enabled = null
    String target

    Map toMap(){
        return [id: id, name: name, enabled: enabled, target: target]
    }

    String toString(){
        return toMap().toString()
    }
}
