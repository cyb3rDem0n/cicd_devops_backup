package com.accenture.sec.db.dto

class ManifestInfoDTO {
    Long idRelease
    Long idBuild
    Long idManifest
    Long idWave
    String releaseVersion
    String wave
    String microservice
    String buildNum
    String mfVersion
    List<String> deps
    String target

    boolean equals(o) {
        if (o == null) return false
        if (this.is(o)) return true
        if (getClass() != o.class) return false

        ManifestInfoDTO that = (ManifestInfoDTO) o

        if (microservice != that.microservice) return false
        if (buildNum != that.buildNum) return false

        return true
    }

    Map toMap() {
        return [(this.microservice): [version: this.buildNum, dependencies: this.deps, target: this.target]]
    }

    Map toMapForPrint() {
        return [(this.microservice): this.buildNum]
    }
}


