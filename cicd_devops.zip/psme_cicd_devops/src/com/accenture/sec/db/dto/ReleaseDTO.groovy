package com.accenture.sec.db.dto

class ReleaseDTO implements Serializable {

    Long id
    Long idWave
    String mfVersion
    String version
    String currEnv
/*
    Map toMap(){
        return [version: this.releaseNumber, status: this.releaseStatus.getStatus(), type: this.releaseType.getType(), isHotfix: this.isHotfix]
    }
*/
    @Override
    String toString() {
        return String.format("ReleaseDTO: [id: %s, idWave: %s, mfVersion: %s version: %s currEnv: %s]",
                this.id == null? "":this.id.toString(), this.idWave == null? "":this.idWave.toString(), this.mfVersion, this.version, this.currEnv)
    }
}
