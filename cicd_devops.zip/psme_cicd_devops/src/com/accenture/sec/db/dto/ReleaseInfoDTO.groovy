package com.accenture.sec.db.dto

class ReleaseInfoDTO implements Serializable {

    Long id
    String mfVersion
    String releaseVersion
    String manifestVersion
    String currEnv
/*
    Map toMap(){
        return [version: this.releaseNumber, status: this.releaseStatus.getStatus(), type: this.releaseType.getType(), isHotfix: this.isHotfix]
    }
*/
    String toString() {
        return String.format("ReleaseDTO: [id: %d, idVersManifest: %d version: %s]",
                this.id, this.mfVersion, this.releaseVersion.toString())
    }
}
