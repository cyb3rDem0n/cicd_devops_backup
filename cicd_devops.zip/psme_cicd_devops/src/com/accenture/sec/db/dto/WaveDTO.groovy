package com.accenture.sec.db.dto

class WaveDTO {
    Long id
    String name
    Long version

    Map toMap(){
        return [id: id, name: name, version: version]
    }

    String toString(){
        return toMap().toString()
    }

}