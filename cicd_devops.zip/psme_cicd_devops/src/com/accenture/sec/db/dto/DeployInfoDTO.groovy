package com.accenture.sec.db.dto

import java.sql.Timestamp

class DeployInfoDTO implements Serializable{

    Long id
    String wave
    String microservice
    String buildNum
    String env
    Timestamp tStamp
    String target

    ManifestInfoDTO toManifestInfoDTO(){
        ManifestInfoDTO dto = new ManifestInfoDTO()
        dto.wave = this.wave
        dto.microservice = this.microservice
        dto.buildNum = this.buildNum
        dto.target = this.target
        return dto
    }

}
