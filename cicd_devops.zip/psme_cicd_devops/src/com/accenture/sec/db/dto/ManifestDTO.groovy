package com.accenture.sec.db.dto

class ManifestDTO {
    Long id
    Long idBuild
    String version
}
