package com.accenture.sec.db

import hudson.util.Secret
import org.jenkinsci.plugins.database.GlobalDatabaseConfiguration
import org.jenkinsci.plugins.database.postgresql.PostgreSQLDatabase
import java.sql.Connection
import java.sql.PreparedStatement

class DataSource implements Serializable {
    /**
     * La connessione al db e' configurata su Jenkins attraverso il Database Plugin e il
     * database-postgresql Plugin
     * */

    private static DataSource instance
    private Map<String, String> changeSchemaDirectives

    private DataSource() {
        changeSchemaDirectives = [:]
    }


    /**
     * Return the DataSource instance
     *
     * @return
     */
    static DataSource getInstance() {
        if (instance == null) {
            instance = new DataSource()
        }
        return instance
    }

    /**
     * Create a new connection to the db if it doesen't exist
     *
     * @param dbInfo Map with info to connect to the bd
     * @return
     */
    Connection setupConnection(Map<String, String> dbInfo) {
        dbInfo.props = dbInfo.props ?: ''
        Connection connection
        switch (dbInfo.type) {
            case 'postgresql':
                if (dbInfo.schema && !dbInfo.props.contains("currentSchema=${dbInfo.schema}")) {
                    dbInfo.props = """${dbInfo.props}
currentSchema=${dbInfo.schema}
"""
                }
                String psqlHost = dbInfo.port == null ? dbInfo.host : "${dbInfo.host}:${dbInfo.port}".toString()
                PostgreSQLDatabase postgreDB = new PostgreSQLDatabase(psqlHost, dbInfo.database, dbInfo.username, (Secret.fromString(dbInfo.password)), dbInfo.props)
                connection = postgreDB.getDataSource().getConnection()
                if (dbInfo.schema) {
                    changeSchemaDirectives[dbInfo.type] = """SET search_path TO "%s"; """
                }
                break
            default:
                throw new Exception("DataSource ERROR: DB type '${dbInfo.type}' non supportato")
                break
        }
        setSchema(connection, dbInfo.type, dbInfo.schema)
        return connection
    }

    void setSchema(Connection connection, String type, String schema) {
        if (!changeSchemaDirectives[type])
            return
        String query = String.format(changeSchemaDirectives[type], schema)
        PreparedStatement pstm = connection.prepareStatement(query)
        pstm.execute()
    }

    String getChangeSchema(String dbType) {
        return dbType ? changeSchemaDirectives.get(dbType) : null
    }

    String getChangeSchema(Map dbInfo) {
        return getChangeSchema(dbInfo.type)
    }

    static Connection getGlobalConnection() throws Exception {
        return GlobalDatabaseConfiguration.get().getDatabase().getDataSource().getConnection()
    }

}

