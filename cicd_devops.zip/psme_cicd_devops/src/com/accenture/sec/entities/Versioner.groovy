package com.accenture.sec.entities

import com.accenture.sec.utils.CommonUtils


import java.util.regex.Matcher
import java.util.regex.Pattern

/**
 * Versioner
 */
class Versioner implements Serializable {

    private Pattern pattern
    private String patternFormat
    private String format

    Versioner(def pattern, String format = null) {
        this.format = format
        this.pattern = pattern instanceof String ? Pattern.compile(pattern) : pattern
        this.patternFormat = format ? null : patternToFormat(pattern)
    }

    private String patternToFormat(def pattern) {
        String str = pattern instanceof String ? pattern : pattern.pattern()
        str = str.replaceAll(/\\\./, '.').replaceAll(/\\-/, '-').replaceAll(/\\\+/, '+')
        str = str.startsWith('^') ? str[1..-1] : str
        str = str.endsWith('$') ? str[0..-2] : str
        return str
    }


    /**
     * Increment version of the current Version based on the increaseType passed in input
     *
     * @param increaseType type of increment MAJOR|MINOR|FIX|BUILD
     */
    protected String increase(List<Integer> versionParts, IncreaseType increaseType) {
        versionParts[increaseType.index] += 1
        int len = versionParts.size()
        for (int i = increaseType.index + 1; i < len; i++) {
            versionParts[i] = 0
        }
//    if(increaseType == IncreaseType.MAJOR)
//      versionParts[IncreaseType.MINOR.index] = 1
        return parsePartsToVersionStr(versionParts)
    }

    String increase(String version, IncreaseType increaseType) {
        return increase(parseVersionToParts(version), increaseType)
    }

    /**
     * Calculate new version based on IncreaseType starting from the max version present in the List versions
     *
     * @param versions List of string versions from which calculate max
     * @param major major version, used to filter versions from
     * @param increaseType type of increment [MAJOR|MINOR|FIX|BUILD]
     * @return
     */
    String nextVersion(List<String> versions, Integer major, IncreaseType increaseType) {
        List<Integer> version = this.max(versions, major)
        String next = null
        if (version != null) {
            next = this.increase(version, increaseType)
        } else if (major != null) {
            next = this.parsePartsToVersionStr([major, 0, 0, 0])
        }
        return next
    }

    /**
     * Calculate max Version from a List of Version|String, filtering from major if not null
     *
     * @param versions List of Version|String from which extract max
     * @param major if not null is used to filter the versions to be checked to calculate max
     * @return return the max Version object
     */
    private List<Integer> max(List<String> versions, Integer major) {
        if (CommonUtils.isNullOrEmpty(versions))
            return null
        String filterPattern = major != null ? pattern.pattern().replaceFirst(/\(\\d\+\)/, major as String) : pattern.pattern()

        boolean found = false
//        String maxVersion = parsePartsToVersionStr([(major ?: 0), 0, 0, 0])
        List<Integer> maxVersion = [(major ?: 0), 0, 0, 0]
        List<Integer> currentVersion = null
        for (String version in versions) {
            if (version == 'latest' || (filterPattern && !version.matches(filterPattern)))
                continue
            currentVersion = parseVersionToParts(version)
            if (compareVersions(currentVersion, maxVersion) == 1) {
                maxVersion = currentVersion
                found = true
            }
        }
        return found ? maxVersion : null
    }

    String maxAsString(List<String> versions, Integer major) {
//        List<Integer> maxVersion = max(versions, major)
//        return parsePartsToVersionStr(maxVersion)
        return parsePartsToVersionStr(max(versions, major))
    }

    /**
     * Parse a String version in a List<Integer> containing all the parts of the version
     *
     * @param version String representing the version number
     * @return a list of parts of the version
     */
    List<Integer> parseVersionToParts(String version) {
        Matcher matcher = pattern.matcher(version)
        if (!matcher.matches())
            throw new VersionerException("Version '${version}' not match /${pattern.pattern()}/")

        List<String> strParts = matcher[0] as List
        strParts.remove(0)
        List<Integer> parts = []
        for (int i = 0; i < strParts.size(); i++) {
            parts.add(i, strParts[i] as Integer)
        }
//        parts = strParts.collect{ it as Integer}
        return parts
    }

    /**
     * Convert a list of version parts into a string using the pattern initialized with init()
     *
     * @param versionParts
     * @return
     */
    String parsePartsToVersionStr(List<Integer> versionParts) {
        String answer = null

        if (this.format && this.format ==~ /.*%[dsc].*/)
            answer = String.format(this.format, versionParts.toArray())
        else {
            versionParts.each {
                answer = this.patternFormat.replaceFirst(/\(\\d\+\)/, (it as String))
            }
        }
        return answer
    }

    int compareVersions(def ver1, def ver2) {
        List<Integer> v1Parts = ver1 instanceof String ? parseVersionToParts(ver1) : ver1
        List<Integer> v2Parts = ver2 instanceof String ? parseVersionToParts(ver2) : ver2
        int length = Math.max(v1Parts.size(), v2Parts.size())
        for (int i = 0; i < length; i++) {
            int v1Part = i < v1Parts.size() ? v1Parts[i] : 0
            int v2Part = i < v2Parts.size() ? v2Parts[i] : 0
            if (v1Part < v2Part)
                return -1
            if (v1Part > v2Part)
                return 1
        }
        return 0
    }

    private class VersionerException extends Exception {
        VersionerException(String msg) {
            super(msg)
        }
    }

}
