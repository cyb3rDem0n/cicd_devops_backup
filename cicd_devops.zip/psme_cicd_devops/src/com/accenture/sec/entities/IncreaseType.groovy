package com.accenture.sec.entities

/**
 * Enum that represent the type of version increment. Can be MAJOR,
 * MINOR, FIX and BUILD. Any of this have an index property that point
 * to the position of the number to be increased in the version number
 */
enum IncreaseType {
    MAJOR(0,'major'), MINOR(1,'minor'), FIX(2,'fix'), BUILD(3,'build')

    Integer index
    String code

    private IncreaseType(Integer index, String code) {
        this.index = index
        this.code = code
    }

    static IncreaseType fromIndex(Integer index) {
        IncreaseType answer = values().find { it.index.equalsIgnoreCase(index) }
        return answer
    }

    static IncreaseType fromString(String type){
        IncreaseType answer
        switch (type.toLowerCase()){
            case 'sprint':
            case 'major':
                answer = MAJOR
            break
            case 'minor':
                answer = MINOR
            break
            case 'fix':
                answer = FIX
            break
            case 'build':
                answer = BUILD
            break
            default:
                throw new Exception("${type.toLowerCase()} is not a valid IncreaseType")
        }
        return answer
    }


}
