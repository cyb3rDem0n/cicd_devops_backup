package com.accenture.sec.entities

import com.accenture.sec.utils.CommonUtils
import hudson.FilePath
import jenkins.model.Jenkins

import org.apache.commons.codec.binary.Base64

class Tokenizer implements Serializable {

    enum Option {
        CLEAN(0, 0b00000),
        NOT_DECODE(1, 0b00001),
        NOT_ENCODE(2, 0b00010),
        NOT_ALL(3, 0b00011),
        DRY_RUN(4, 0b00100)

        Integer index
        int byteCode

        private Option(Integer index, int byteCode) {
            this.index = index
            this.byteCode = byteCode
        }

        static boolean match(int byteCode, Option opt) {
            return ((byteCode & opt.byteCode) == opt.byteCode)
        }
    }

    private def pipeline
    private String nodeName
    private String workspace

    private String tokenFilePath
    private Map tokenMap

    private int option

    private boolean debug

    Tokenizer(def pipeline, String tokenFilePath) {
        this(pipeline)
        this.tokenFilePath = tokenFilePath
    }

    Tokenizer(def pipeline, Map tokenMap) {
        this(pipeline)
        this.tokenMap = tokenMap
    }

    private Tokenizer(def pipeline) {
        this.pipeline = pipeline
        this.option = Option.CLEAN.byteCode
        this.nodeName = pipeline.env['NODE_NAME'].toString()
        this.workspace = pipeline.pwd()
    }

    void setOption(Option option) {
        if (option == null)
            this.option = Option.CLEAN.byteCode
        this.option = (this.option | option.byteCode)

    }

    def process(Map args) {
        CommonUtils.checkInputParameters(args, 'group')
        CommonUtils.checkInputParametersOr(args, 'glob,path,text')
        def files = null
        if (args.path) {
            files = processPath(args.path)
        } else if (args.glob) {
            def tmp = this.pipeline.findFiles(glob: args.glob)
            if (tmp.size() > 0)
                files = tmp.collect { it.path }
        } else if (args.text) {
            return replaceFromText(args.text, _getTokenMap(args.group))
        }
        (this.debug) && this.pipeline.echo("files: ${files}")

        files && replaceAll(files, args.group)
    }

    private def processPath(def path) {
        def files = null
        if (path instanceof String || path instanceof GString) {
            if (!path.startsWith(this.workspace))
                path = this.workspace + '/' + path
            FilePath tmp = new FilePath(Jenkins.getInstanceOrNull()?.getComputer(this.nodeName)?.getChannel(), path.toString())
            if (tmp.exists()) {
                files = tmp
//                if(dir.directory) {
//                    files = dir
//                    this.debug && this.pipeline.echo("dir: ${dir.getRemote()}\nfiles: ${dir.list().collect { it.name }}")
//                }else{
//                    files = [path]
//                }
            }
        } else if (path instanceof List) {
            files = path
        }
        return files
    }

    private Map _getTokenMap(String name = null) {
        if (!this.tokenMap && this.tokenFilePath)
            this.tokenMap = this.pipeline.readYaml(file: this.tokenFilePath)
        return name ? this.tokenMap.get(name, [:]) : this.tokenMap
    }

    private def replaceAll(def filePath, String name) {
        Map tokens = _getTokenMap(name)
        List list = filePath instanceof FilePath ? (filePath.directory ? filePath.list() : [filePath]) : filePath
        list.each { f ->
            if ((filePath instanceof FilePath) && f.getName().matches(/(?ix).*README.*/))
                return
            if (!(filePath instanceof FilePath) && !f.startsWith(this.workspace))
                f = this.workspace + '/' + f
            this.debug && this.pipeline.echo("Processing '${filePath instanceof FilePath ? f.getRemote() : f}' on ${this.nodeName}")
            try {
                replace(f, tokens)
            } catch (MissingTokenException mte) {
                throw new MissingTokenException("Some tokens are missing for '${name}':\n${mte.missingTokens.collect {it.tokenName}.join(', ')}")
            } catch (TokenizerException te) {
                if (te.getMessage() == "No tokens")
                    throw new TokenizerException("No tokens available for '${name}'")
                else
                    throw te
            }
        }
    }

    private void replace(String filePath, Map tokens) {
        FilePath file = new FilePath(Jenkins.getInstanceOrNull()?.getComputer(this.nodeName)?.getChannel(), filePath.toString())
        if (!file.exists())
            throw new TokenizerException("'${file.name}' doesn't exist")
        replace(file, tokens)
    }

    private void replace(FilePath file, Map tokens) {
        String content = null
        InputStream is = null
        try {
            is = file.read()
            content = is.getText()
        } catch (Exception e) {
            throw e
        } finally {
            is && is.close()
        }

        String contentReplaced = replaceFromText(content, tokens)

        if (Option.match(this.option, Option.DRY_RUN))
            return
        (!contentReplaced.equals(content)) && file.write(contentReplaced, null)
    }

    private String replaceFromText(String content, Map tokens) {
        Set placeholders = getPlaceholders(content)
        this.debug && this.pipeline.echo("placeholders: ${placeholders}")
        this.debug && this.pipeline.echo("tokens: ${tokens}")

        List<MissingToken> missingTokens = []
        placeholders.each { placeholder ->
            def value = getVal(tokens, placeholder.toString())
            if (value instanceof MissingToken) {
                this.debug && this.pipeline.echo("missing token: ${placeholder}")
                missingTokens.add(value)
            } else {
                this.debug && this.pipeline.echo("replacing '###${placeholder}###' with value stored")
                content = content.replace(/###${placeholder}###/, value.toString())
            }
        }

        if (missingTokens.size() > 0)
            throw new MissingTokenException(missingTokens)

        return content.toString()
    }

    private def getVal(Map tokens, String placeholder) {
        def value = tokens.get(placeholder, new MissingToken(placeholder))
        if (value instanceof MissingToken)
            return value
        value = value == null ? '' : value.toString()
        if (value.startsWith('eb64->')) {
            value = Option.match(this.option, Option.NOT_ENCODE) ? value.replace('eb64->', '') : new String(Base64.encodeBase64(value.replace('eb64->', '').getBytes()))
        } else if (value.startsWith('db64->')) {
            value = Option.match(this.option, Option.NOT_DECODE) ? value.replace('db64->', '') : new String(Base64.decodeBase64(value.replace('db64->', '').getBytes()))
        }
        return value
    }

    private Set getPlaceholders(String content) {
        List lines = content.tokenize('\n')
        this.debug && this.pipeline.echo("lines: ${lines}")
        return getPlaceholders(lines)
    }

    private Set getPlaceholders(List lines) {
        List tokens = []
        lines.each { l ->
            l = l.toString().replace('\r','')
            this.debug && this.pipeline.echo("line: '${l}'")
            if (l.matches(/[^#]*###[a-zA-Z0-9_.-]+###.*/)) {
                this.debug && this.pipeline.echo("match /[^#]*###[a-zA-Z0-9_.-]+###.*/")
                tokens.addAll(l.findAll(/###[a-zA-Z0-9_.-]+###/).collect { it.replaceAll('###', '') })
                this.debug && this.pipeline.echo("tokens: ${tokens}")
            }
        }
        return tokens.toSet()
    }

    private class MissingToken implements Serializable{
        String tokenName
        MissingToken(String tokenName) { this.tokenName = tokenName }
    }

    private class TokenizerException extends Exception {
        TokenizerException(String msg) {
            super(msg)
        }
    }

    private class MissingTokenException extends Exception {
        List<MissingToken> missingTokens

        MissingTokenException(List<MissingToken> missingTokens) {
            super()
            this.missingTokens = missingTokens
        }

        MissingTokenException(String msg) {
            super(msg)
        }
    }


//    OutputStream os = null
//    if (filePath) {
//        os = (new FilePath(Jenkins.getInstanceOrNull()?.getComputer(this.nodeName)?.getChannel(), filePath)).write()
//    } else {
//        os = this.inputFilePath.write()
//    }

}
