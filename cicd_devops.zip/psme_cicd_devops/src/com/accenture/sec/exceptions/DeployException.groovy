package com.accenture.sec.exceptions

class DeployException extends Exception {

    DeployException(String message) {
        super(message)
    }

    DeployException(GString message) {
        this(message.toString())
    }

}
