package com.accenture.sec.exceptions

class DuplicatedReleaseVersionException extends Exception{

    DuplicatedReleaseVersionException(String message) {
     super(message)
    }

    DuplicatedReleaseVersionException(String message, Throwable cause) {
        super(message, cause)
    }


}
