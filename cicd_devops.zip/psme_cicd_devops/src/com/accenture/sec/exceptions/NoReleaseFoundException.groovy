package com.accenture.sec.exceptions

class NoReleaseFoundException extends Throwable{

    NoReleaseFoundException(String message) {
        super(message)
    }

    NoReleaseFoundException(String message, Throwable cause) {
        super(message, cause)
    }


}
