package com.accenture.sec.api

import com.accenture.sec.utils.CommonUtils
import org.jenkinsci.plugins.credentialsbinding.impl.CredentialNotFoundException



class JiraAPI implements Serializable {

    protected def pipeline
    protected String baseUrl
    protected String credsId
    protected String issueKey

    JiraAPI(def pipeline, String baseUrl, String credsId = null, def issueKey = null) {
        this.pipeline = pipeline
        this.baseUrl = baseUrl
        this.credsId = credsId
        this.issueKey = issueKey
    }

    def getIssuesFromQuery(Map params) {
        def jql = URLEncoder.encode(params.issueQuery, 'UTF-8')
        def apiMap = [
                endpoint   : "search?jql=${jql}",
                requestType: "GET",
                credsId    : (params.credsId ?: this.credsId),
                failOnError: (params.failOnError != null ? params.failOnError : true)
        ]
        def res = callAPI(apiMap)
        return res
    }

    static List filterIssuesFromQueryResult(def queryResult, Map queryFilter) {
        List list = queryResult.issues.findAll { issue ->
            boolean ok = true
            queryFilter.each { key, regex ->
                def el = issue
                key.tokenize('.').each { subKey ->
                    el = el?.get(subKey)
                }
                ok = (ok && (el != null && el.toString().matches(regex as String)))
            }
            return ok
        }
        return list
    }

    def addIssueComment(Map params) {
        String payload = CommonUtils.toJson([
                body: params.message
        ])
        params.issueKey = params.issueKey ?: issueKey
        def apiMap = [
                endpoint   : "issue/${params.issueKey}/comment",
                requestType: "POST",
                credsId    : (params.credsId ?: this.credsId),
                failOnError: (params.failOnError != null ? params.failOnError : true),
                payload    : payload
        ]
        def res = callAPI(apiMap)
        return res
    }

    def changeIssueStatus(Map params) {
        String payload = CommonUtils.toJson([
                update: [
                        comment   : [add: [body: params.message]],
                        transition: [id: params.transitionId]
                ]
        ])
        this.pipeline.echo("PAYLOAD: ${payload}")
        params.issueKey = params.issueKey ?: issueKey
        def apiMap = [
                endpoint   : "issue/${params.issueKey}/transitions",
                requestType: "POST",
                credsId    : (params.credsId ?: this.credsId),
                failOnError: (params.failOnError != null ? params.failOnError : true),
                payload    : payload
        ]
        def res = callAPI(apiMap)
        return res
    }

    protected def callAPI(Map params) {

        CommonUtils.checkInputParameters(params, "endpoint,requestType")

        Map reqMap = [
                validOnErrorCodes: true,
                printOutput      : true,
                failOnError      : false
        ]
        reqMap << params

        def result = null
        try {
            if (reqMap.credsId != null) {
                /*this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: reqMap.credsId,
                        passwordVariable: 'JIRA_TOKEN',
                        usernameVariable: 'JIRA_USER')]) {*/
                reqMap.authentication = reqMap.credsId
                //}
            }
            CommonUtils.checkInputParameters(reqMap, "endpoint,requestType")
            result = execRequest(reqMap)
        } catch (JiraAPIException gae) {
            if (reqMap.failOnError) {
                throw gae
            }
            this.pipeline.echo(" *** WARNING - ${gae}")
            return CommonUtils.parseJson(gae.result.content)
        } catch (CredentialNotFoundException ce) {
            this.pipeline.echo(" *** WARNING - ${ce}")
        } catch (Exception ex) {
            throw ex
        }
        return result
    }


    protected def execRequest(Map params) {
        String validCodes = params.validOnErrorCodes ? "100:599" : "100:399"
        def apiVersion = params.apiVersion ?: 'rest/api/2'
        def requestMap = [
                contentType       : 'APPLICATION_JSON',
                httpMode          : "${params.requestType}",
                //customHeaders     : [[maskValue: true]],
                //ignoreSslErrors   : true,
                validResponseCodes: validCodes,
                url               : "${this.baseUrl}/${apiVersion}/${params.endpoint}"
        ]
        if (params.authentication) {
            requestMap.authentication = params.authentication
        }
        if (params.payload != null) {
            if (params.requestType == 'GET') {
                List tmp = []
                CommonUtils.parseJson(params.payload).each { k, v ->
                    tmp.add("${k}=${v}".toString())
                }
                requestMap.url += "?${tmp.join('&')}".toString()
            } else {
                requestMap.put('requestBody', "${params.payload}")
            }
        }
        if (!params.printOutput) {
            requestMap.put('quiet', true)
        }
        if (params.outputFile != null) {
            requestMap.put('outputFile', "${params.outputFile}")
        }
        this.pipeline.echo "requestMap: ${requestMap}"
        def result = this.pipeline.httpRequest(requestMap)
        if (result.status > 399) {
            throw new JiraAPIException("${result.status} - ${result.content}", result)
        }
        def output = null
        if (result.content) {
            output = CommonUtils.parseJson(result.content)
        }
        return [status: result.status, output: output, content: result.content]
    }

    class JiraAPIException extends Exception {
        def result

        JiraAPIException(String msg, def result) {
            super(msg)
            this.result = result
        }

        JiraAPIException(String msg) {
            super(msg)
            this.result = null
        }
    }
}
