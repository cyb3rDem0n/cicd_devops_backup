package com.accenture.sec.api

import com.accenture.sec.utils.CommonUtils


import org.jenkinsci.plugins.credentialsbinding.impl.CredentialNotFoundException

class BitbucketAPI implements Serializable {

    def pipeline
    String baseUrl
    String projectId
    String credsId

    boolean debug = false

    BitbucketAPI(Map args) {
        this.pipeline = args.pipeline
        this.baseUrl = args.baseUrl
        this.projectId = args.projectId
        this.credsId = args.credsId
    }

    BitbucketAPI(def pipeline, String baseUrl, String projectId = null, String credsId = null) {
        this.pipeline = pipeline
        this.baseUrl = baseUrl
        this.projectId = projectId
        this.credsId = credsId
    }


    def createPullRequest(Map params) {
        def apiMap, res, defReviewers
        boolean deleteSourceBranch = false
        params.projectId = params.projectId ?: projectId

        Map approverInfo = [:]
        if (params.approver) {
            this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: params.approver,
                    passwordVariable: 'BITBUCKET_TOKEN',
                    usernameVariable: 'BITBUCKET_USER')]) {
                approverInfo.token = this.pipeline.env.BITBUCKET_TOKEN
                approverInfo.userName = this.pipeline.env.BITBUCKET_USER
            }
        }

        if (params.sourceRef && !params.sourceBranch) {
            //params.sourceBranch = "automerge/" + UUID.randomUUID().toString()
            params.sourceBranch = "automerge/" + params.sourceRef.toString().replace('/', '-')
            params.branchName = params.sourceBranch
            res = getBranches([
                    projectId : params.projectId,
                    repoName  : params.repoName,
                    credsId   : params.credsId,
                    filterText: params.branchName
            ])
            if (res.size == 0) {
                createBranch(params)
            }
            if (params.automatedMerge) {
                deleteSourceBranch = true
                defReviewers = [[name: approverInfo.userName]]
            }
        }
        if (!params.automatedMerge && !defReviewers) {
            defReviewers = getDefaultReviewers(params)
        }

        this.pipeline.echo("Creating pull request from ${params.sourceBranch} to ${params.targetBranch}")
        Map payloadMap = [
                fromRef    : [id: "refs/heads/${params.sourceBranch}"],
                toRef      : [id: "refs/heads/${params.targetBranch}"],
                title      : "[devops] PR ${params.sourceBranch} --> ${params.targetBranch}",
                description: "Automatic pull request created by Jenkins"
        ]
        if (defReviewers) {
            payloadMap.put('reviewers', defReviewers.collect { [user: [name: it.name]] })
        }

        apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/pull-requests",
                requestType: "POST",
                payload    : CommonUtils.toJson(payloadMap),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : false),
                printOutput: false
        ]
        this.debug && this.pipeline.echo("PR apiMap: ${apiMap}")
        res = callAPI(apiMap)

        if (res.errors) {
            def err = res.errors.find {
                it.exceptionName.contains('EmptyPullRequestException') || it.exceptionName.contains('DuplicatePullRequestException')
            }
            if (!CommonUtils.isNullOrEmpty(err)) {
                this.pipeline.echo("*** SKIPPING: ${err.message}")
                return
            }
        }
        this.debug && this.pipeline.echo("createPullRequest: ${res}")
        def pullRequestId = res.id
        this.pipeline.echo("Created pull request #${pullRequestId}")

        if (!params.automatedMerge)
            return res

        def newParams = [pullRequestId: pullRequestId, pullRequestVersion: res.version]
        newParams << params

        res = getPullRequestStatus(newParams)
        if (res.conflicted) {
            this.pipeline.echo("*** WARNING: There are conflicts. Adding default reviewers")
            defReviewers = getDefaultReviewers(newParams)
            newParams.put('reviewers', defReviewers.collect { it.name })
            res = addReviewers(newParams)
            return res
        } else if (!res.conflicted && !res.canMerge) {
            // serve approvazione
            if (params.approver) {
                newParams << [token: approverInfo.token, userName: approverInfo.userName]
            }
            approvePullRequest(newParams)
        }
        this.pipeline.sleep(1)
        try {
            //newParams.token = null
            def ret = mergePullRequest(newParams)
            if (deleteSourceBranch) {
                deleteBranch(params)
            }
            return ret
        } catch (BitbucketAPIException gae) {
            throw gae
        } catch (Exception e) {
            throw e
        }
    }

    def deletePullRequest(Map params) {
        params.projectId = params.projectId ?: projectId
        this.pipeline.echo("Deleting #${params.pullRequestId}")
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/pull-requests/${params.pullRequestId}",
                requestType: "DELETE",
                payload    : CommonUtils.toJson([version: params.pullRequestVersion]),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        this.pipeline.echo("Deleted #${params.pullRequestId}")
        return res
    }

    def addReviewers(Map params) {
        params.projectId = params.projectId ?: projectId
        def payload = [
                version  : params.pullRequestVersion,
                reviewers: []
        ]
        params.reviewers.each {
            payload.reviewers.add([user: [name: it]])
        }
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/pull-requests/${params.pullRequestId}",
                requestType: "PUT",
                payload    : CommonUtils.toJson(payload),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        this.debug && this.pipeline.echo("addReviewers: ${res}")
        return res
    }

    def getDefaultReviewers(Map params) {
        params.projectId = params.projectId ?: projectId
        def repoId = getRepositoryId(params)
        def apiMap = [
                apiVersion : 'rest/default-reviewers/1.0',
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/reviewers",
                requestType: "GET",
                payload    : CommonUtils.toJson([sourceRepoId: repoId, targetRepoId: repoId, sourceRefId: params.sourceBranch, targetRefId: params.targetBranch]),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        this.debug && this.pipeline.echo("getDefaultReviewers: ${res}")
        return res.isEmpty() ? null : res
    }

    def getRepositoryId(Map params) {
        params.projectId = params.projectId ?: projectId
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}",
                requestType: "GET",
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        this.debug && this.pipeline.echo("getRepositoryId: ${res}")
        return res.id
    }

    def getPullRequestsRelatedToCommit(Map params) {
        params.projectId = params.projectId ?: projectId
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/commits/${params.commit}/pull-requests",
                requestType: "GET",
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        return res
    }
    
    def getPullRequestStatus(Map params) {
        params.projectId = params.projectId ?: projectId
        this.pipeline.echo("Getting pull request #${params.pullRequestId} status")
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/pull-requests/${params.pullRequestId}/merge",
                requestType: "GET",
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        return res
    }

    def mergePullRequest(Map params) {
        params.projectId = params.projectId ?: projectId
        this.pipeline.echo("Merging #${params.pullRequestId} automatically")
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/pull-requests/${params.pullRequestId}/merge",
                requestType: "POST",
                payload    : CommonUtils.toJson([version: params.pullRequestVersion]),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        this.pipeline.echo("Merged #${params.pullRequestId} by jenkins")
        return res
    }

    def closePullRequest(Map params) {
        params.projectId = params.projectId ?: projectId
        this.pipeline.echo("Closing #${params.pullRequestId}")
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/pull-requests/${params.pullRequestId}/decline",
                requestType: "POST",
                payload    : CommonUtils.toJson([version: params.pullRequestVersion]),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        this.pipeline.echo("Closed #${params.pullRequestId}")
        return res
    }

    def getBranches(Map params) {
        params.projectId = params.projectId ?: projectId
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/branches",
                requestType: "GET",
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        if (params.filterText) {
            apiMap.endpoint += "?filterText=${URLEncoder.encode(params.filterText as String, 'UTF-8')}"
        }
        def res = callAPI(apiMap)
        return res
    }

    def createBranch(Map params) {
        params.projectId = params.projectId ?: projectId
        this.pipeline.echo("Creating branch '${params.branchName}' from '${params.sourceRef}'")
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/branches",
                requestType: "POST",
                payload    : CommonUtils.toJson([name: params.branchName, startPoint: params.sourceRef]),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        this.debug && this.pipeline.echo("createBranch apiMap: ${apiMap}")
        def res = callAPI(apiMap)
        this.pipeline.echo("Created branch '${params.branchName}' from '${params.sourceRef}'")
        return res
    }

    def deleteBranch(Map params) {
        params.projectId = params.projectId ?: projectId
        this.pipeline.echo("Deleting branch '${params.branchName}'")
        def apiMap = [
                apiVersion : 'rest/branch-utils/1.0',
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/branches",
                requestType: "DELETE",
                payload    : CommonUtils.toJson([name: "refs/heads/${params.branchName}", dryRun: false]),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        this.pipeline.echo("Deleted branch '${params.branchName}'")
        return res
    }

    def tag(Map params) {
        params.projectId = params.projectId ?: projectId
        this.pipeline.echo("Adding tag '${params.tagName}'")
        def payloadMap = [
                name      : params.tagName,
                startPoint: params.startPoint
        ]
        params.message && payloadMap.put('message', params.message)
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/tags",
                requestType: "POST",
                payload    : CommonUtils.toJson(payloadMap),
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        this.pipeline.echo("Added tag '${params.tagName}'")
        return res
    }

    def getTags(Map params) {
        params.projectId = params.projectId ?: projectId
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/tags",
                requestType: "GET",
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        if(params.orderBy){
            apiMap.endpoint += "?orderBy=${URLEncoder.encode(params.orderBy as String, 'UTF-8')}"
        }else{
            apiMap.endpoint += "?orderBy=MODIFICATION"
        }
        if (params.filterText) {
            apiMap.endpoint += "&filterText=${URLEncoder.encode(params.filterText as String, 'UTF-8')}"
        }
        def res = callAPI(apiMap)
        return res
    }
    /*
    def getRequiredApprovalsPR(Map params) {
        params.projectId = params.projectId ?: projectId
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/pull-requests/${params.pullRequestId}/approvals",
                requestType: "GET",
                credsId    : params.credsId ?: this.credsId,
                failOnError: (params.failOnError != null ? params.failOnError : true),
                printOutput: false
        ]
        def res = callAPI(apiMap)
        return res.approvals_required
    }
*/
    def approvePullRequest(Map params) {
        params.projectId = params.projectId ?: projectId
        this.pipeline.echo("Approving #${params.pullRequestId} automatically")
        Map payloadMap = [
                user    : [name: params.userName],
                approved: true,
                status  : "APPROVED"
        ]
        def apiMap = [
                endpoint   : "projects/${params.projectId}/repos/${params.repoName}/pull-requests/${params.pullRequestId}/participants/${params.userName}",
                requestType: "PUT",
                payload    : CommonUtils.toJson(payloadMap),
                credsId    : params.credsId ?: this.credsId,
                token      : params.token,
                failOnError: (params.failOnError != null ? params.failOnError : true)
        ]
        def res = callAPI(apiMap)
        this.pipeline.echo("Approved #${params.pullRequestId} by ${params.userName}")
        return res
    }

    private def callAPI(Map params) {

        CommonUtils.checkInputParameters(params, "endpoint,requestType")

        Map reqMap = [
                validOnErrorCodes: true,
                printOutput      : true,
                failOnError      : false
        ]
        reqMap << params
        if (!reqMap.apiVersion) {
            reqMap.apiVersion = 'rest/api/1.0'
        }
        def result = null
        try {
            if (reqMap.token == null && reqMap.credsId != null) {
                this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: reqMap.credsId,
                        passwordVariable: 'BITBUCKET_TOKEN',
                        usernameVariable: 'BITBUCKET_USER')]) {
                    reqMap.token = this.pipeline.env.BITBUCKET_TOKEN
                }
            }
            def msg = """Calling endpoint: ${reqMap.apiVersion}/${reqMap.endpoint}
with credsId: ${reqMap.credsId}
"""
            this.debug && this.pipeline.echo(msg)
            CommonUtils.checkInputParameters(reqMap, "endpoint,requestType,token")
            result = execRequest(reqMap)
        } catch (BitbucketAPIException gae) {
            if (reqMap.failOnError) {
                throw gae
            }
            this.pipeline.echo(" *** WARNING - ${gae}")
            return CommonUtils.parseJson(gae.result.content)
        } catch (CredentialNotFoundException ce) {
            this.pipeline.echo(" *** WARNING - ${ce}")
        } catch (Exception ex) {
            throw ex
        }
        return result
    }


    private def execRequest(Map params) {
        String validCodes = params.validOnErrorCodes ? "100:599" : "100:399"
        def requestMap = [
                contentType       : 'APPLICATION_JSON',
                httpMode          : "${params.requestType}",
                customHeaders     : [[maskValue: true, name: 'Authorization', value: "Bearer ${params.token}"]],
                ignoreSslErrors   : true,
                validResponseCodes: validCodes,
                url               : "${this.baseUrl}/${params.apiVersion}/${params.endpoint}"
        ]
        if (params.payload != null) {
            if (params.requestType == 'GET') {
                List tmp = []
                CommonUtils.parseJson(params.payload).each { k, v ->
                    tmp.add("${k}=${v}".toString())
                }
                requestMap.url += "?${tmp.join('&')}".toString()
            } else {
                requestMap.put('requestBody', "${params.payload}")
            }
        }
        if (!params.printOutput) {
            requestMap.put('quiet', true)
        }
        if (params.outputFile != null) {
            requestMap.put('outputFile', "${params.outputFile}")
        }
        def result = this.pipeline.httpRequest(requestMap)
        if (result.status > 299) {
            throw new BitbucketAPIException("${result.status} - ${result.content}", result)
        }
        this.debug && this.pipeline.echo("${result.status} - ${result.content}")
        def output = result.status == 204 ? null : CommonUtils.parseJson(result.content)
        return output
    }

    class BitbucketAPIException extends Exception {
        def result

        BitbucketAPIException(String msg, def result) {
            super(msg)
            this.result = result
        }

        BitbucketAPIException(String msg) {
            super(msg)
            this.result = null
        }
    }
}
