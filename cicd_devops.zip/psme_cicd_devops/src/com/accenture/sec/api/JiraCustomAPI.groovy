package com.accenture.sec.api

import com.accenture.sec.utils.CommonUtils


class JiraCustomAPI extends JiraAPI {

    JiraCustomAPI(def pipeline, String baseUrl, String credsId = null, def issueKey = null) {
        super(pipeline, baseUrl, credsId, issueKey)
    }

    def updateCustomField(Map params){
        String payload = CommonUtils.toJson(params.updates as Map)
        params.issueKey = params.issueKey ?: this.issueKey
        def apiMap = [
                apiVersion: 'rest/scriptrunner/latest',
                endpoint   : "custom/updateCustomField?ISSUE=${params.issueKey}",
                requestType: "POST",
                credsId    : (params.credsId ?: this.credsId),
                failOnError: (params.failOnError != null ? params.failOnError : false),
                payload    : payload
        ]
        def res = callAPI(apiMap)
        return res
    }

    def transition(Map params){
        Map payloadMap = [:]
        params.transitionName && payloadMap.put('transitionName', params.transitionName)
        params.targetStatus && payloadMap.put('targetStatus', params.targetStatus)

        params.issueKey = params.issueKey ?: this.issueKey
        def apiMap = [
                apiVersion: 'rest/scriptrunner/latest',
                endpoint   : "custom/transition?ISSUE=${params.issueKey}",
                requestType: "POST",
                credsId    : (params.credsId ?: this.credsId),
                failOnError: (params.failOnError != null ? params.failOnError : false),
                payload    : CommonUtils.toJson(payloadMap)
        ]
        def res = callAPI(apiMap)
        return res
    }
}
