package com.accenture.sec.rollback



import java.lang.reflect.Method

abstract class Stage {
    protected String name
    protected HashMap<String, Object> parameters
    protected  Rollback rollback
    protected def pipeline

    Stage(def pipeline, String name, HashMap<String, Object> parameters){
        this.name = name
        this.parameters = parameters
        this.rollback = new Rollback()
        this.pipeline = pipeline
    }

    protected abstract Rollback execute()

}
