package com.accenture.sec.rollback

interface IRollbacker {

    Rollback rollback()

    void pushStage(Stage stage)

    Stage popStage()

    void removeAllStages()
}