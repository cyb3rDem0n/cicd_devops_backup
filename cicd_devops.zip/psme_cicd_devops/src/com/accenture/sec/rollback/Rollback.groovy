package com.accenture.sec.rollback

class Rollback {

    enum RollbackStatus {
        SUCCESS, FAILURE
    }

    private RollbackStatus status
    private Exception exception
    private String msg

    RollbackStatus getStatus(){
        return this.status
    }

    void setStatus(RollbackStatus status){
        this.status = status
    }

    Exception getException(){
        return this.exception
    }

    void setException(Exception exception){
        this.exception = exception
    }

    String getMsg(){
        return this.msg
    }

    void setMsg(String msg){
        this.msg = msg
    }

}
