package com.accenture.sec.rollback



class PipelineRollbacker implements IRollbacker{

    private Stack<Stage> rollbackStages = new Stack<Stage>()
    private def pipeline

    PipelineRollbacker(def pipeline){
        this.pipeline = pipeline
    }

    @Override
    Rollback rollback(){
        Rollback rollback = new Rollback()
        Rollback singleRollback = null
        this.pipeline.echo "________________________________________________________\nStarting Rollback"
        while(!rollbackStages.empty()){
            Stage stage = rollbackStages.pop()
            this.pipeline.echo "________________________________________________________"
            this.pipeline.echo "Executing stage:\t${stage.name}"
            singleRollback = stage.execute()
            if(Rollback.RollbackStatus.FAILURE == singleRollback.status){
                String msg ="________________________________________________________\n" +
                        "Errore durante il rollback: \n" +
                        "Rollback stage "+stage.name+" fallito"
                rollback = singleRollback
                this.pipeline.echo(msg)
                break
            }
        }

        if(singleRollback != null && Rollback.RollbackStatus.FAILURE != singleRollback.status){
            String msg ="________________________________________________________\n" +
                    "Rollback di tutti gli stage eseguito"
            rollback.setMsg(msg)
            rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
            this.pipeline.echo(msg)
        }
        return rollback
    }

    @Override
    void pushStage(Stage stage){
        this.rollbackStages.push(stage)
    }

    @Override
    Stage popStage(){
        return this.rollbackStages.pop()
    }

    @Override
    void removeAllStages(){
        this.rollbackStages.removeAllElements()
    }

}
