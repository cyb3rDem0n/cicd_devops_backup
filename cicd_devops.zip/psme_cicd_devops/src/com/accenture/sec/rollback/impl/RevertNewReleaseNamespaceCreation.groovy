package com.accenture.sec.rollback.impl

import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage


class RevertNewReleaseNamespaceCreation extends Stage{

    private def clusterOCP
    private def projectName

    RevertNewReleaseNamespaceCreation(def pipeline, String name, HashMap<String, Object> parameters) {
        super(pipeline, name, parameters)
        this.clusterOCP = this.parameters.clusterOCP
        this.projectName = this.parameters.projectName
    }

    @Override
    protected Rollback execute() {
        def isProjectCreated = false
        try {
            this.pipeline.openshift.withCluster(this.clusterOCP) {
                try {
                    isProjectCreated = this.pipeline.openshift.selector("project", this.projectName).exists()
                } catch (Exception e) {
                    isProjectCreated = false
                }
                if (isProjectCreated) {
                    this.pipeline.openshift.withCluster(this.clusterOCP) {
                        this.pipeline.openshift.withProject(this.projectName) {
                            this.pipeline.openshift.delete("project", this.projectName)
                            this.pipeline.echo "Temporary namespace deleted"
                        }
                    }
                }
            }
            this.rollback.setMsg("Namespace ${this.projectName} eliminato con successo sul cluster ocp ${this.clusterOCP}")
            this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
        }catch(Exception e){
            this.rollback.setMsg("Namespace ${this.projectName} non eliminato sul cluster ocp ${this.clusterOCP}")
            this.rollback.setException(e)
            this.rollback.setStatus(Rollback.RollbackStatus.FAILURE)
        }
        return this.rollback
    }
}
