package com.accenture.sec.rollback.impl

import com.accenture.sec.db.dto.BuildDTO
import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage


class RevertNewReleaseBranches extends Stage {

    private ArrayList<BuildDTO> newReleaseManifestList = null
    private def releaseBranchNumber

    RevertNewReleaseBranches(def pipeline, String name, LinkedHashMap<String, Object> parameters) {
        super(pipeline, name, parameters)
        this.releaseBranchNumber = this.parameters.releaseBranchNumber
        this.newReleaseManifestList = this.parameters.newReleaseManifestList
    }

    @Override
    protected Rollback execute() {

        Rollback singleRollback = new Rollback()
        for (BuildDTO dto : this.newReleaseManifestList) {
            def code =  this.pipeline.sh(returnStdout: true, script: """#!/bin/bash -e
curl -X DELETE -sw '%{http_code}' -H "Authorization: Bearer ${this.parameters.BITBUCKET_TOKEN}" -H "Content-Type: application/json" \
  -d '{"name":"refs/heads/release/${this.releaseBranchNumber}", "dryRun": false}' \
  "http://git.secreloaded.sec/rest/branch-utils/1.0/projects/${this.parameters.BITBUCKET_PRJ}/repos/${dto.getMicroservice()}/branches" 
""")
            String msg
            switch(code){
                case "400" :
                    msg = "Branch release/${this.releaseBranchNumber} non eliminato sul repository ${dto.getMicroservice()}, richiesta non valida"
                    singleRollback.setMsg(msg)
                    singleRollback.setStatus(Rollback.RollbackStatus.FAILURE)
                    break
                case "401" :
                    msg = "Branch release/${this.releaseBranchNumber} non eliminato sul repository ${dto.getMicroservice()}, permessi insufficienti"
                    singleRollback.setMsg(msg)
                    singleRollback.setStatus(Rollback.RollbackStatus.FAILURE)
                    break
                case "204":
                    msg = "Branch release/${this.releaseBranchNumber} eliminato sul repository ${dto.getMicroservice()}"
                    singleRollback.setMsg(msg)
                    singleRollback.setStatus(Rollback.RollbackStatus.SUCCESS)
                    break
            }
            if(singleRollback.getStatus()==Rollback.RollbackStatus.FAILURE){
                this.rollback = singleRollback
                break
            }
        }
        if(singleRollback.getStatus()!=Rollback.RollbackStatus.FAILURE){
            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters}"
            this.rollback.setMsg(msg)
            singleRollback.setStatus(Rollback.RollbackStatus.SUCCESS)
        }
        return this.rollback
    }
}