package com.accenture.sec.rollback.impl

import com.accenture.sec.managers.BitbucketManager
import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage


class RevertPullRequest extends Stage{
    RevertPullRequest(def pipeline, String name, HashMap<String, Object> parameters) {
        super(pipeline, name, parameters)
    }

    @Override
    protected Rollback execute() {
        /*def args =[
                "releaseNumber" : newProdRelease.releaseNumber,
                "releaseVersion" : newProdRelease.releaseNumber,
                "repoName" : dto.microservice,
                "projectKey" : this.parameters.projectKey,
                "BITBUCKET_TOKEN" : "${BITBUCKET_TOKEN}"
        ]*/
        BitbucketManager bbm = new BitbucketManager(this.pipeline)
        int result = bbm.deletePullRequest(this.parameters)
        if(result != 0){
            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} unsuccessful"
            this.rollback.setMsg(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.FAILURE)
        }
        else{
            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} successful"
            this.rollback.setMsg(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
        }
        return this.rollback
    }
}
