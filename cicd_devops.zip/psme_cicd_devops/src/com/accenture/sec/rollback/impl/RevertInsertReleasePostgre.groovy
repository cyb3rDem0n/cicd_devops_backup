package com.accenture.sec.rollback.impl

import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dto.BuildDTO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage


import java.sql.Connection

class RevertInsertReleasePostgre extends Stage{

    private ReleaseDTO prodReleaseDto = null
    private ReleaseDTO newReleaseDto = null
    private ArrayList<BuildDTO> newReleaseManifestList = null
    private Map<String, String> dbInfo = null

    RevertInsertReleasePostgre(def pipeline, String name, LinkedHashMap<String, Object> parameters) {
        super(pipeline, name, parameters)
        this.prodReleaseDto = this.parameters.prodReleaseDto
        this.newReleaseDto = this.parameters.newReleaseDto
        this.newReleaseManifestList = this.parameters.newReleaseManifestList
        this.dbInfo = new HashMap<>()
        this.dbInfo.putAll(this.parameters.dbInfo)
    }

    @Override
    protected Rollback execute() {
        /*Riporto come release attuale la vecchia release*/
        def R = 3 // Released version in prod
        Connection connection = null
        // Recupero username e password della connessione al db e
        // li inserisco nella mappa di configurazione della connessione
        this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: this.dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
            this.dbInfo.username =  this.pipeline.env.usr
            this.dbInfo.password =  this.pipeline.env.psw
        }
        try {
            // Istanzio una connessione al db
            DataSource ds = DataSource.getInstance()
            connection = ds.setupConnection(this.dbInfo)
            ReleaseDAO releaseDAO = new ReleaseDAO(connection)
            releaseDAO.delete(this.newReleaseDto)
            this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
        } catch (Exception e) {
            e.printStackTrace()
            this.pipeline.echo(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.FAILURE)
            this.rollback.setException(e)
            this.rollback.setMsg(msg)
        } finally {
            if (connection != null)
                connection.close()
        }
        return this.rollback
    }
}
