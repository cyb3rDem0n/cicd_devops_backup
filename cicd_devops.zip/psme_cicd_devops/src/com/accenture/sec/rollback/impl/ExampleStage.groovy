package com.accenture.sec.rollback.impl

import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage


class ExampleStage extends Stage{
    ExampleStage(def pipeline, String name, HashMap<String, Object> parameters) {
        super(pipeline, name, parameters)
    }

    @Override
    protected Rollback execute() {
        this.pipeline.echo("Rollbacking stage: " + this.name +"\nParameters: ${parameters}")
        this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
        return this.rollback
    }
}
