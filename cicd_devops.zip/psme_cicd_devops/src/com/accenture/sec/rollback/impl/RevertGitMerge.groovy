package com.accenture.sec.rollback.impl

import com.accenture.sec.managers.BitbucketManager
import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage


class RevertGitMerge extends Stage{
    RevertGitMerge(def pipeline, String name, HashMap<String, Object> parameters) {
        super(pipeline, name, parameters)

    }

    private static final String repoTmpPath = "repo_tmp/"
    @Override
    protected Rollback execute() {

        BitbucketManager bbm = new BitbucketManager(pipeline)
        def args =[
                "repoName" : this.parameters.repoName,
                "projectKey" : this.parameters.projectKey,
                "BITBUCKET_TOKEN" : this.parameters.BITBUCKET_TOKEN
        ]
        String cloneUrl = bbm.getCloneUrl(args)
        String cloneFolder = repoTmpPath.concat(this.parameters.repoName)
        this.pipeline.cloneRepo(this.parameters.gitUser, cloneUrl, this.parameters.branch, [folder: cloneFolder, shallow: false])
        def shScript = """#!/bin/bash -e
git config --global user.email "noreply@example.com"
git config --global user.name "${this.parameters.gitUser}"
cd ${cloneFolder}
IFS=\$'\\n'
git fetch
git pull
commits_array=(\$(git log -2 --pretty=format:"%h"))
HASH='\${commits_array[\${#commits_array[@]}-1]}"
git revert -m 1 "\${HASH}"
git push
unset IFS
rm -rf ${cloneFolder}
"""
        try{
            this.pipeline.sh(returnStdout: true, script: shScript)
            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} successful"
            this.rollback.setMsg(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
        }catch(Exception e){
            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} unsuccessful"
            this.rollback.setMsg(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.FAILURE)
        }
        return this.rollback
    }
}
