package com.accenture.sec.rollback.impl

import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dao.ReleaseStatusDAO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.db.dto.ReleaseStatusDTO
import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage


import java.sql.Connection

class RevertCloseReleaseVersionPostgre extends Stage {

    RevertCloseReleaseVersionPostgre(def pipeline, String name, HashMap<String, Object> parameters) {
        super(pipeline, name, parameters)
    }

    @Override
    protected Rollback execute() {
        /*Riporto come release attuale la vecchia release*/

        def RF = 2 // Release freezed
        def R = 3 // Release in prod

        Connection connection = null
        // Recupero username e password della connessione al db e
        // li inserisco nella mappa di configurazione della connessione
        this.pipeline.withCredentials([this.pipeline.usernamePassword(credentialsId: this.parameters.dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
            this.parameters.dbInfo.username = this.pipeline.env.usr
            this.parameters.dbInfo.password = this.pipeline.env.psw
        }
        try {
            // Istanzio una connessione al db
            DataSource ds = DataSource.getInstance()
            connection = ds.setupConnection(this.parameters.dbInfo)

            // Definisco i DAO per le operazioni sul db
            ReleaseDAO releaseDAO = new ReleaseDAO(connection)
            ReleaseStatusDAO releaseStatusDAO = new ReleaseStatusDAO(connection)

            ReleaseDTO prodReleaseDto = releaseDAO.getCurrentProdRelease((long)this.parameters.RELEASE_TYPE)
            ReleaseDTO oldProdRelease = this.parameters.oldProdRelease

            if(prodReleaseDto != null){
                ReleaseStatusDTO relst = releaseStatusDAO.getByStatusCode(R)
                oldProdRelease.setStatus(relst)
                relst = releaseStatusDAO.getByStatusCode(RF)
                prodReleaseDto.setStatus(relst)
                releaseDAO.startTransaction()
                releaseDAO.update(prodReleaseDto)
                releaseDAO.update(oldProdRelease)
                releaseDAO.commitTransaction()
            }
            connection.commit()

            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} successful"
            this.rollback.setMsg(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)

        } catch (Exception e) {
            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} unsuccessful"
            this.rollback.setMsg(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.FAILURE)
        } finally {
            if (connection != null)
                connection.close()
        }
        return this.rollback
    }
}
