package com.accenture.sec.rollback.impl

import com.accenture.sec.managers.BitbucketManager
import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage


class DeleteGitTag extends Stage{
    DeleteGitTag(def pipeline, String name, HashMap<String, Object> parameters) {
        super(pipeline,name, parameters)

    }

    @Override
    protected Rollback execute() {

        BitbucketManager bbm = new BitbucketManager(this.pipeline)

        def args =[
                "releaseNumber" : this.parameters.releaseNumber,
                "repoName" : this.parameters.repoName,
                "projectKey" : this.parameters.projectKey,
                "BITBUCKET_TOKEN" : "${this.parameters.BITBUCKET_TOKEN}",
                "tag" : this.parameters.tag
        ]

        int result = bbm.deleteTag(args)

        if(result != 0){
            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} unsuccessful"
            this.rollback.setMsg(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.FAILURE)
        }
        else{
            def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} successful"
            this.rollback.setMsg(msg)
            this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
        }
        return this.rollback
    }
}
