package com.accenture.sec.rollback.impl


import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage
import com.accenture.sec.utils.GitAskPass


class RevertNewReleaseTokens extends Stage{

    private GitAskPass askPass

    RevertNewReleaseTokens(def pipeline, String name, HashMap<String, Object> parameters) {
        super(pipeline,name, parameters)
        this.askPass = this.parameters.askpass
    }

    @Override
    protected Rollback execute() {

        try {

            this.pipeline.dir("${this.parameters.repofolder}/tokens") {
                this.pipeline.sh("rm ${this.parameters.tokenFile}")
            }

            this.pipeline.dir("${this.parameters.repofolder}") {
                /*Rimozione del tag remoto*/
                this.askPass.exec("git push --delete origin ${this.parameters.tag}")
                /*Rimozione del tag locale*/
                this.askPass.exec("git push --delete ${this.parameters.tag}")
                this.askPass.exec('git add .')
                this.askPass.exec("git commit -m'Reverted token file ${this.parameters.tokenFile}'")
                this.askPass.exec('git push')

                def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} successful"
                this.rollback.setMsg(msg)
                this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
            }
        }catch(Exception e){
            this.rollback.setMsg("Reverting token file ${this.parameters.tokenFile} unsuccessful")
            this.rollback.setException(e)
            this.rollback.setStatus(Rollback.RollbackStatus.FAILURE)
        }

        return this.rollback
    }
}
