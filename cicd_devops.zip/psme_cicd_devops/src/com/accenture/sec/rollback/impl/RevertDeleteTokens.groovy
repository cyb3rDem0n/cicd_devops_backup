package com.accenture.sec.rollback.impl


import com.accenture.sec.rollback.Rollback
import com.accenture.sec.rollback.Stage
import com.accenture.sec.utils.GitAskPass


class RevertDeleteTokens extends Stage{

    private GitAskPass askPass

    RevertDeleteTokens(def pipeline, String name, HashMap<String, Object> parameters) {
        super(pipeline,name, parameters)
        this.askPass = this.parameters.askpass
    }

    @Override
    protected Rollback execute() {

        try {

            this.pipeline.dir("${this.parameters.repofolder}/tokens") {
                String tkTempl = this.pipeline.readFile(this.parameters.tokenTemplate)
                this.pipeline.writeFile(this.parameters.tokenFile, tkTempl)
            }

            this.pipeline.dir("${this.parameters.repofolder}") {
                String absRepoPath = "${this.pipeline.pwd}"
                int isTag = this.pipeline.sh(returnStdout: true,
                        script: """#
if GIT_DIR=${absRepoPath}/.git git rev-parse ${this.parameters.tag} >/dev/null 2>&1
then 
    return 0
else
    return 1
fi
""")
                /*Se il tag esiste*/
                if(isTag == 0){
                    /*Rimozione del tag remoto*/
                    this.askPass.exec("git push --delete origin ${this.parameters.tag}")
                    /*Rimozione del tag locale*/
                    this.askPass.exec("git push --delete ${this.parameters.tag}")
                }
                this.askPass.exec('git add .')
                this.askPass.exec("git commit -m'Reverted token file ${this.parameters.tokenFile}'")
                this.askPass.exec('git push')

                def msg = "Rollbacked stage: " + this.name +"\nParameters: ${this.parameters} successful"
                this.rollback.setMsg(msg)
                this.rollback.setStatus(Rollback.RollbackStatus.SUCCESS)
            }
        }catch(Exception e){
            this.rollback.setMsg("Reverting token file ${this.parameters.tokenFile} unsuccessful")
            this.rollback.setException(e)
            this.rollback.setStatus(Rollback.RollbackStatus.FAILURE)
        }

        return this.rollback
    }
}
