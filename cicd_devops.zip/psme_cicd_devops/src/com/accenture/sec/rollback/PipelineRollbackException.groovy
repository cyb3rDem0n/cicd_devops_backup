package com.accenture.sec.rollback

class PipelineRollbackException extends Exception{

    PipelineRollbackException(String msg){
        super(msg)
    }

    PipelineRollbackException(Throwable t, String msg){
        super(t, msg)
    }
}
