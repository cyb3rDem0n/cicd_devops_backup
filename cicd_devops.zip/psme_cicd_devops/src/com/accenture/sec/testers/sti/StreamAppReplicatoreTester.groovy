package com.accenture.sec.testers.sti

import com.accenture.sec.runners.CurlRunner
import com.accenture.sec.runners.MongoShellRunner
import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.testers.ITester


class StreamAppReplicatoreTester implements ITester{

    private String tests_path;
    private String kafka_topic_url
    private String mongo_service_url
    private String mongo_user
    private String mongo_pwd
    private def pipeline


    StreamAppReplicatoreTester(def pipeline){
        this.pipeline = pipeline
    }

    @Override
    def exec(Object args) {
        Map<String,Object> map = (Map<String,Object>) args
        this.tests_path = map.get("tests_path")
        this.kafka_topic_url = map.get("kafka_topic_url")
        this.mongo_service_url = map.get("mongo_service_url")
        this.mongo_user = map.get("mongo_user")
        this.mongo_pwd = map.get("mongo_pwd")
        ArrayList tests = getTestList()
        def test_no = 1
        tests.each { testName ->
            def test_path = "${this.tests_path}/${testName}"

            sendKafkaMsg(this.kafka_topic_url, test_path, test_no, testName)
            def mongoResultsMap = readMongoData(this.mongo_service_url, test_path, test_no, testName,this.mongo_user, this.mongo_pwd)
            checkAssert(test_path, test_no, testName, mongoResultsMap)
            test_no++
        }

        this.pipeline.echo """################################################################################
INTEGRATION TEST SUITE COMPLETATA CON SUCCESSO
################################################################################
"""
    }

    private ArrayList getTestList() {
        String text = this.pipeline.sh(returnStdout: true, script: """#!/bin/bash
cd ${tests_path}
find . -maxdepth 1 -type d -printf '%f\\n'""")
        List tests_all = Arrays.asList(text.split("\n"))
        List tests = new ArrayList()
        tests_all.each { testName ->
            if (!".".equals(testName)) {
                tests.add(testName)
            }
        }
        tests
    }

    void sendKafkaMsg(String kafka_topic_url, String test_path, int test_no, String testName){

        def kafka_payload_path = test_path + "/input.json"
        String kafka_payload = this.pipeline.readFile file: kafka_payload_path
        kafka_payload = kafka_payload.trim()

        def reqMap = [
                url    : "${kafka_topic_url}",
                headers: [
                        'Content-Type:application/vnd.kafka.json.v2+json',
                        'Accept:application/vnd.kafka.v2+json'
                ],
                method : 'POST',
                payload: '{"records":[{"value":' + kafka_payload + '}]}'
        ]

        CurlRunner curlRunner = new CurlRunner(this.pipeline)
        RunnerResult res = curlRunner.execWithStatus(reqMap)
        if (res.exitCode != 200) {
            String msg = "################################################################################\n" +
                    "INTEGRATION TEST FALLITO: Impossibile inviare il messaggio sul topic\n" +
                    "Test No. ${test_no}\n"+
                    "Test Name: ${testName}\n"+
                    "Parametri di chiamata:\n" +
                    "${reqMap}\n" +
                    "Kafka Proxy Rest Response:\n" +
                    "${res}\n" +
                    "################################################################################\n";
            this.pipeline.echo """${msg}"""
            throw new Exception(msg)
        } else {
            String msg = "################################################################################\n" +
                    "INFO: Messaggio inviato correttamente sul topic\n" +
                    "Test No. ${test_no}\n"+
                    "Test Name: ${testName}\n"+
                    "Parametri di chiamata:\n" +
                    "${reqMap}\n" +
                    "Kafka Proxy Rest Response:\n" +
                    "${res}\n" +
                    "################################################################################\n";
            this.pipeline.echo """${msg}"""
        }
    }

    Map<String, Object> readMongoData(String mongo_service_url, String test_path, int test_no, String testName, String mongo_user, String mongo_pwd){
        def paramMap = [
                'mongoUrl'   : "${mongo_service_url}",
                'mongo_user' : "${mongo_user}",
                'mongo_pwd'  : "${mongo_pwd}",
                'assert_path': test_path + "/assert_query_count.js",
                'isCount'    : true
        ]

        int nrecords = 0
        int times = 5
        long timeout = 8
        MongoShellRunner mongoRunner = new MongoShellRunner(this.pipeline)
        while (nrecords == 0) {
            sleep(timeout)
            nrecords = mongoRunner.exec(paramMap, true)
            if (times == 0 && nrecords == 0) {
                String msg ="################################################################################\n" +
                        "INTEGRATION TEST FALLITO: Nessun dato sul server mongo\n" +
                        "Test No. ${test_no}\n" +
                        "Test Name: ${testName}\n" +
                        "Mongodb url: ${paramMap.mongoUrl}\n" +
                        "################################################################################"
                this.pipeline.echo """${msg}"""
                throw new Exception(msg)
            }
            times--
        }

        if (nrecords == 0) {
            String msg ="################################################################################\n" +
                    "INTEGRATION TEST FALLITO: Nessun dato sul server mongo\n" +
                    "Test No. ${test_no}\n" +
                    "Test Name: ${testName}\n" +
                    "Mongodb url: ${paramMap.mongoUrl}\n" +
                    "################################################################################"
            this.pipeline.echo """${msg}"""
            throw new Exception(msg)
        }

        paramMap.assert_path = test_path + "/assert_query.js"
        paramMap.isCount = false
        def mongoResults = mongoRunner.exec(paramMap, true)

        def mongoResultsMap = [
                'nrecords'   : nrecords,
                'mongoResults' : mongoResults,
        ]
        return mongoResultsMap
    }


    void checkAssert(String test_path, int test_no, String testName, Map<String, Object> mongoResultsMap){
        def assert_path = test_path + "/assert.json"
        def assertJSONObj = this.pipeline.readJSON file: assert_path
        if(assertJSONObj.size() != mongoResultsMap.mongoResults.size()){
            String msg ="################################################################################\n" +
                    "INTEGRATION TEST FALLITO: Numero record ricevuti diverso da quanto atteso\n" +
                    "Test No. ${test_no}\n" +
                    "Test Name: ${testName}\n" +
                    "Numero risultati ricevuti: ${mongoResultsMap.mongoResults.size()}\n" +
                    "Numero risultati attesi: ${assertJSONObj.size()}\n" +
                    "################################################################################"
            this.pipeline.echo """${msg}"""
            throw new Exception(msg)
        }

        for(int k = 0; k < assertJSONObj.size(); k++){
            this.pipeline.echo "##############################################\nChecking data:\n" +
                    " ${mongoResultsMap.mongoResults[k]}\n\nagainst:\n${assertJSONObj[k]}"
            assert assertJSONObj[k] == mongoResultsMap.mongoResults[k]
        }
        this.pipeline.echo """################################################################################
INTEGRATION TEST ASSERT VERIFICATO CON SUCCESSO:
Test No. ${test_no}
Test Name: ${testName}
################################################################################
"""
    }
}
