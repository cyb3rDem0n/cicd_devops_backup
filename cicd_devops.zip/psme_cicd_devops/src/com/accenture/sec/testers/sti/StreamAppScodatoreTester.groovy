package com.accenture.sec.testers.sti

import com.accenture.sec.runners.CurlRunner
import com.accenture.sec.runners.MongoShellRunner
import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.testers.ITester


class StreamAppScodatoreTester implements ITester{

    private String tests_path;
    private String mongo_service_url
    private String mongo_user
    private String mongo_pwd
    private def pipeline


    StreamAppScodatoreTester(def pipeline){
        this.pipeline = pipeline
    }

    @Override
    def exec(Object args) {
        Map<String,Object> map = (Map<String,Object>) args
        this.tests_path = map.get("tests_path")
        this.mongo_service_url = map.get("mongo_service_url")
        this.mongo_user = map.get("mongo_user")
        this.mongo_pwd = map.get("mongo_pwd")
        ArrayList tests = getTestList()
        def test_no = 1
        tests.each { testName ->
            def test_path = "${this.tests_path}/${testName}"
            writeMongoData(this.mongo_service_url, test_path, this.mongo_user, this.mongo_pwd)
            def mongoResultsMap = readMongoData(this.mongo_service_url, test_path, test_no, testName,this.mongo_user, this.mongo_pwd)
            checkAssert(test_path, test_no, testName, mongoResultsMap)
            test_no++
        }

        this.pipeline.echo """################################################################################
INTEGRATION TEST SUITE COMPLETATA CON SUCCESSO
################################################################################
"""
    }

    private ArrayList getTestList() {
        String text = this.pipeline.sh(returnStdout: true, script: """#!/bin/bash
cd ${tests_path}
find . -maxdepth 1 -type d -printf '%f\\n'""")
        List tests_all = Arrays.asList(text.split("\n"))
        List tests = new ArrayList()
        tests_all.each { testName ->
            if (!".".equals(testName)) {
                tests.add(testName)
            }
        }
        tests
    }

    void writeMongoData(String mongo_service_url, String test_path, String mongo_user, String mongo_pwd){
        def paramMap = [
                'mongoUrl'   : "${mongo_service_url}",
                'mongo_user' : "${mongo_user}",
                'mongo_pwd'  : "${mongo_pwd}",
                'assert_path': test_path + "/insertTestData.js",
                'isCount'    : true
        ]

        int nrecords = 0
        int times = 5
        long timeout = 5
        MongoShellRunner mongoRunner = new MongoShellRunner(this.pipeline)
        mongoRunner.exec(paramMap, true)
    }

    Map<String, Object> readMongoData(String mongo_service_url, String test_path, int test_no, String testName, String mongo_user, String mongo_pwd){
        def paramMap = [
                'mongoUrl'   : "${mongo_service_url}",
                'mongo_user' : "${mongo_user}",
                'mongo_pwd'  : "${mongo_pwd}",
                'assert_path': test_path + "/assert_query_count.js",
                'isCount'    : true
        ]

        int nrecords = 0
        int times = 5
        long timeout = 5
        MongoShellRunner mongoRunner = new MongoShellRunner(this.pipeline)
        while (nrecords == 0) {
            sleep(timeout)
            nrecords = mongoRunner.exec(paramMap, true)
            times--
            if (times == 0 && nrecords == 0) {
                String msg ="################################################################################\n" +
                        "INTEGRATION TEST FALLITO: Nessun dato sul server mongo\n" +
                        "Test No. ${test_no}\n" +
                        "Test Name: ${testName}\n" +
                        "Mongodb url: ${paramMap.mongoUrl}\n" +
                        "################################################################################"
                this.pipeline.echo """${msg}"""
                throw new Exception(msg)
            }
        }

        paramMap.assert_path = test_path + "/assert_query.js"
        paramMap.isCount = false
        def mongoResults = mongoRunner.exec(paramMap, true)

        def mongoResultsMap = [
                'nrecords'   : nrecords,
                'mongoResults' : mongoResults,
        ]
        return mongoResultsMap
    }


    void checkAssert(String test_path, int test_no, String testName, Map<String, Object> mongoResultsMap){
        def assert_path = test_path + "/assert.json"
        def assertJSONObj = this.pipeline.readJSON file: assert_path
        boolean isSingleRecord = mongoResultsMap.get("isSingleRecord")
        def mongoResults = mongoResultsMap.get("mongoResults")

        //if (isSingleRecord) {
        //    def jsonMongoDocument = mongoResults.get(0)
        //    this.pipeline.assert assertJSONObj == jsonMongoDocument
        //}
        //else{
        if(assertJSONObj.length != nrecords){
            String msg ="################################################################################\n" +
                    "INTEGRATION TEST FALLITO: Numero record ricevuti diverso da quanto atteso\n" +
                    "Test No. ${test_no}\n" +
                    "Test Name: ${testName}\n" +
                    "Mongodb url: ${paramMap.mongoUrl}\n" +
                    "Numero risultati ricevuti: ${nrecords}\n" +
                    "Numero risultati attesi: ${assertJSONObj.length}\n" +
                    "################################################################################"
            this.pipeline.echo """${msg}"""
            throw new Exception(msg)
        }

        for(int k = 0; k < nrecords; k++){
            assert assertJSONObj[k] == mongoResults[k]
        }
        //}
        this.pipeline.echo """################################################################################
INTEGRATION TEST ASSERT VERIFICATO CON SUCCESSO:
Test No. ${test_no}
Test Name: ${testName}
################################################################################
"""
    }
}
