package com.accenture.sec.testers

import com.accenture.sec.runners.CurlRunner
import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.utils.CommonUtils


import java.util.regex.Matcher
import java.util.regex.Pattern

class SoapUIRestTester implements ITester{

    def pipeline

    CurlRunner curlRunner

    SoapUIRestTester(def pipeline){
        this.pipeline = pipeline
        curlRunner = new CurlRunner(pipeline)
    }

    private void prepareOptions(List options=null){
        if(!options){
            options = ['-f/tmp/','-M','-j','-A','-r']
        }
        def cmd = """#!/bin/bash
cat >options <<EOL
${options.join('\n')}
EOL
"""
        this.pipeline.sh(cmd)
    }

    private def prepareProperties(Map properties=null){
        if(!properties){
            return
        }
        def props = ""
        properties.each { k,v ->
            props += "${k}=${v}\n"
        }
        def file = "${properties.hashCode()}.properties"
        def cmd = """#!/bin/bash
cat >${file} <<EOL
${props}
EOL
"""
        this.pipeline.sh(cmd)
        return file
    }

    @Override
    def exec(Object args) {
        CommonUtils.checkInputParameters(args,'url,projectFile')
        prepareOptions(args.options)
        def reqMap = [
                url: args.url,
                method: 'POST',
                form: [
                        "project=@${args.projectFile}",
                        "option=@options"
                ]
        ]
        if(!CommonUtils.isNullOrEmpty(args.globalProperties)){
            def file = prepareProperties(args.globalProperties)
            reqMap.form.add("properties=@${file}")
        }
        if(!CommonUtils.isNullOrEmpty(args.projectProperties)){
            def file = prepareProperties(args.projectProperties)
            reqMap.form.add("project_properties=@${file}")
        }
        RunnerResult res = curlRunner.execWithStatus(reqMap)
        Map ret
        try{
            ret = parseResult(res.out)
        }catch(Exception e){
            throw new SoapUITesterException("Error in SoapUI response:\n${res.out}")
        }

        ret.err = res.err
        ret.returnCode = res.exitCode
        return ret
    }

    private static Map parseResult(String out){
        Map result = [returnCode:0, testCases:[total: 0, success: 0, failed: 0], assertions:[total:0, success:0, failed:0], out: out]
        Matcher m
//        m = Pattern.compile(/Receiving response: HTTP\/1\.1 (\d{3})/).matcher(out)
//        result.returnCode = m[0][1] as Integer

        m = Pattern.compile(/Total TestCases: (\d+) \((\d+) failed\)/).matcher(out)
        result.testCases.total = m[0][1] as Integer
        result.testCases.failed = m[0][2] as Integer
        result.testCases.success = result.testCases.total - result.testCases.failed

        m = Pattern.compile(/Total Request Assertions: (\d+)/).matcher(out)
        result.assertions.total = m[0][1] as Integer

        m = Pattern.compile(/Total Failed Assertions: (\d+)/).matcher(out)
        result.assertions.failed = m[0][1] as Integer

        result.assertions.success = result.assertions.total - result.assertions.failed
        return result
    }

    private class SoapUITesterException extends Exception{
        SoapUITesterException(def msg){
            super(msg)
        }
    }

}
