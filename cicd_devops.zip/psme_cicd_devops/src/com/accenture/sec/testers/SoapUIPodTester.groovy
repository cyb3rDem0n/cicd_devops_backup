package com.accenture.sec.testers

import com.accenture.sec.utils.CommonUtils


import java.util.regex.Matcher
import java.util.regex.Pattern

class SoapUIPodTester implements ITester{

    private def pipeline
    private def openshift
    private String podName
    private String bin

    SoapUIPodTester(def pipeline, String podName, String bin=null){
        this(pipeline, pipeline.openshift, podName, bin)
    }

    SoapUIPodTester(def pipeline, def openshift, String podName, String bin=null){
        this.pipeline = pipeline
        this.openshift = openshift
        this.podName = podName
        this.bin = bin ?: '/opt/SoapUI/bin'
    }

    private def prepareCmd(Map args){
        List options = args.options ?: ['-f/tmp/','-M','-j','-A','-r']
        def properties = []
        args.properties?.each{ k,v ->
            properties.addAll(prepareProperties(k,v))
        }
        args.testSuite && options.add("-s'${args.testSuite}'")
        args.testCase && options.add("-c'${args.testCase}'")
        def cmd = "${this.bin}/testrunner.sh "
        cmd += options.join(' ')
        cmd += ' '
        cmd += properties.join(' ')
        cmd += ' '

        cmd += args.projectFile

        return cmd
    }

    private List prepareProperties(String type, Map properties){
        List ret = []
        String prefix = null
        switch (type.toLowerCase()){
            case 'global':
                prefix='G'
                break
            case 'project':
                prefix='P'
                break
            case 'system':
                prefix='D'
                break
        }
        String format = "-%s%s=%s"
        properties.each { k,v ->
            ret.add(String.format(format,prefix,k,v))
        }
        return ret
    }

    def copyFiles(def sourceDir, def targetDir, def remote){
        if(remote=='target')
            openshift.rsync("${sourceDir}/","${this.podName}:${targetDir}/")
        else if(remote == 'source')
            openshift.rsync("${this.podName}:${sourceDir}/","${targetDir}/")
    }

    @Override
    def exec(Object args) {
        CommonUtils.checkInputParameters(args,'projectFile')
        def cmd = prepareCmd(args)
        def res = openshift.exec("${this.podName}","--", cmd)
        println(res.actions[0].out)
        Map ret
        try{
            ret = parseResult(res.actions[0].out)
        }catch(Exception e){
            throw new SoapUITesterException("Error in SoapUI response:\n${res.actions[0].out}")
        }

        ret.err = res.actions[0].err
        ret.returnCode = res.actions[0].status
        return ret
    }

    private static Map parseResult(String out){
        Map result = [returnCode:0, testCases:[total: 0, success: 0, failed: 0], assertions:[total:0, success:0, failed:0], out: out]
        Matcher m
//        m = Pattern.compile(/Receiving response: HTTP\/1\.1 (\d{3})/).matcher(out)
//        result.returnCode = m[0][1] as Integer

        m = Pattern.compile(/Total TestCases: (\d+) \((\d+) failed\)/).matcher(out)
        result.testCases.total = m[0][1] as Integer
        result.testCases.failed = m[0][2] as Integer
        result.testCases.success = result.testCases.total - result.testCases.failed

        m = Pattern.compile(/Total Request Assertions: (\d+)/).matcher(out)
        result.assertions.total = m[0][1] as Integer

        m = Pattern.compile(/Total Failed Assertions: (\d+)/).matcher(out)
        result.assertions.failed = m[0][1] as Integer

        result.assertions.success = result.assertions.total - result.assertions.failed
        return result
    }

    private boolean isError(def result) {
        return (result.status != 0 || result.actions[0].status != 0 || (result.actions[0].err != '' && result.actions[0].out == ''))
    }

    private class SoapUITesterException extends Exception{
        SoapUITesterException(def msg){
            super(msg)
        }
    }

}
