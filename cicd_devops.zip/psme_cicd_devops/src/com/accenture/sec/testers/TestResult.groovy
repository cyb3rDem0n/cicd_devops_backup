package com.accenture.sec.testers

import com.accenture.sec.utils.CommonUtils

class TestResult implements Serializable {
    private String path
    private String testKind
    private Map result
    private Set testsFailed
    private String resultFolder

    TestResult(def path, def kind) {
        this.path = path
        this.result = [:]
        this.testKind = kind as String
        this.testsFailed = []
    }

    TestResult(def kind) {
        this(null, kind)
    }

    void setTestResult(def test, Map res) {
        result.put(test, res)
    }

    void setTestResult(def test, Integer total, Integer success, Integer failed = null) {
        Map _map = [total: total, success: success]
        failed && (_map.failed = failed)
        setTestResult(test, _map)
    }

    void setResultFolder(def folder) {
        this.resultFolder = folder.toString()
    }

    void addFailed(def failedTest) {
        if (CommonUtils.isNullOrEmpty(failedTest))
            return
        if (failedTest instanceof List)
            testsFailed.addAll(failedTest)
        else
            testsFailed.add(failedTest)
    }

    List getFailed() {
        return testsFailed
    }

    List getFailedWithKind() {
        return testsFailed.collect { "#${testKind}#${it}" }
    }

    boolean isFailed() {
        return testsFailed.size() > 0
    }

    Map toMap() {
        Map ret = [:]
        ret.put(this.testKind, result)
        return ret
    }

    String prettyPrint() {
        if (this.result.size() == 0)
            return ""
        def str = this.path ? "*** ${this.path}#${this.testKind} ***\n" : "*** ${this.testKind} ***\n"
        int indent = this.result.keySet().max { it.size() }.size() + 2
        String format = "%-${indent}s: %s/%s".toString()
        this.result.each { test, res ->
            String success = res.success == null ? 'NA' : (res.success as String)
            String total = res.total == null ? 'NA' : (res.total as String)
            str += sprintf(format, test, success, total) + "\n"
        }
        return str.toString()
    }
}
