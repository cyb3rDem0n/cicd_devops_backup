package com.accenture.sec.testers

interface ITester extends Serializable {

    def exec(def args)
}
