def call(def contextDir) {
    def ret = ['total': 0, 'success': 0, 'exception': false]
    try {
        timeout(5) {
            sh """#!/bin/bash
                echo "Unit Test"
                cd ${WORKSPACE}/${contextDir}
                npm run test-headless 2>&1 | tee test.log
                exit \${PIPESTATUS[0]}
            """
        }
    } catch (Exception ex) {
        ret.exception = true
    } finally {
        def log = readFile file: "${contextDir}/test.log"
        def failed = 0
        def success = 0
        def groups = (log =~ /(\d+) FAILED/)
        if (groups.size() > 0) {
            failed = groups[-1][1] as Integer
        }
        groups = (log =~ /(\d+) SUCCESS/)
        if (groups.size() > 0) {
            success = groups[-1][1] as Integer
        }
        ret.total = failed + success
        ret.success = success
        //if(ret.exception == true)
        //	 sleep 10000
    }
    return ret
}
