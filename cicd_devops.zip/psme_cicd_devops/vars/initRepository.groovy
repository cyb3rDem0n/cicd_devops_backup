import com.accenture.sec.utils.CommonUtils

def call(Map args) {

    CommonUtils.checkInputParameters(args, 'projectName,repoType,msType,webHooksConfig')

    if(args.repoType=='Microservice'){
        CommonUtils.checkInputParameters(args, 'msTech,targetEnv')
    }

    def config = [

            library:[
                    apiservices: [
                            pipeline : 'CI_SpringBoot_Library',
                            teamsWebhook: args.webHooksConfig.apiservices.teamsWebhook
                    ],
                    datastreaming:[
                            pipeline :'CI_SpringBoot_Library',
                            teamsWebhook: args.webHooksConfig.datastreaming.teamsWebhook
                    ]
            ],
            microservice:[
                    apiservices  : [
                            pipeline :[
                                    springboot: [
                                            openshift: 'CI_SpringBoot'
                                    ],
                                    nodejs: [
                                            openshift: 'CI_NodeJS'
                                    ]
                            ],
                            teamsWebhook: args.webHooksConfig.apiservices.teamsWebhook
                    ],
                    datastreaming: [

                            pipeline    : [
                                    springboot:[
                                            openshift: 'CI_Confluent',
                                            vm: 'CI_Java_VM'
                                    ]
                            ],
                            teamsWebhook: args.webHooksConfig.datastreaming.teamsWebhook
                    ]
            ]


    ]

    def teamsWebhook = "${args.msType}".toLowerCase().indexOf("apiservices") ?
            config.get("${args.repoType}".toLowerCase()).get("apiservices").teamsWebhook :
            config.get("${args.repoType}".toLowerCase()).get("datastreaming").teamsWebhook

    def pipelineName = "${args.repoType}" == "Library" ?
                "${args.msType}".toLowerCase().indexOf("apiservices") ?
                        config.get("${args.repoType}".toLowerCase()).get("apiservices").pipeline
                        :
                        config.get("${args.repoType}".toLowerCase()).get("datastreaming").pipeline
            :
            config.get("${args.repoType}".toLowerCase()).get("${args.msType}".toLowerCase()).pipeline.get("${args.msTech}".toLowerCase()).get("${args.targetEnv}".toLowerCase())

    def vmServiceName = args.repoType=='Microservice' && args.msType=='DataStreaming' && args.targetEnv == 'VM' ? "${args.projectName}".substring("${args.projectName}".indexOf("cb-streaming-") + ("cb-streaming-".length())):
            args.repoType=='Microservice' && args.msType=='ApiService' && args.targetEnv == 'VM' ? "${args.projectName}".substring("${args.projectName}".indexOf("cb-") + ("cb-".length())) : null
    switch(args.repoType){
        case 'Library':
            initRepo([
                    projectName: args.projectName,
                    teamsWebhook: teamsWebhook,
                    type: config.get("${args.repoType}".toLowerCase()),
                    pipelineName: pipelineName,
                    target: "${args.repoType}".toLowerCase()
            ],)
            break
        case 'Microservice':
            if(args.targetEnv=='Openshift'){
                initRepo([
                        projectName: args.projectName,
                        teamsWebhook: teamsWebhook,
                        type: config.get("${args.repoType}".toLowerCase()).get("${args.msType}"),
                        pipelineName: pipelineName,
                        target: "${args.targetEnv}".toLowerCase()
                ])
            }
            else if(args.targetEnv=='VM'){
                initRepo([
                        projectName: args.projectName,
                        teamsWebhook: teamsWebhook,
                        type: config.get("${args.repoType}".toLowerCase()).get("${args.msType}"),
                        pipelineName: pipelineName,
                        target: "${args.targetEnv}".toLowerCase(),
                        vmServiceName: vmServiceName
                ])
            }
            break
    }


}


private void initRepo(Map args){
    echo("args.target: ${args.target}")
    switch(args.target){
        case 'openshift':
            echo("args.projectName: ${args.projectName}")
            dir(args.projectName) {
                sh("""
pwd
echo "Preparing DevOps files to fill ${args.projectName} repository"
mkdir -p deployment/templates
mkdir -p deployment/database
mkdir -p tests
mkdir -p sources/${args.projectName}

cat >info.yaml <<EOF
currentRelease: 1
dependencies: null
teamsChannelNotification:
  CI:
    - '${args.teamsWebhook}'
sonarqube:
  project_key: '${args.projectName}'
EOF


cat >ci.jenkinsfile <<EOF
@Library('SharedPipelines') _

${args.pipelineName} {
    MICROSERVICE_NAME = '${args.projectName}'
    CONTEXT_DIR = 'sources/${args.projectName}'
}
EOF

touch deployment/templates/README.md
touch sources/${args.projectName}/README.md
touch tests/README.md
""")
                String msTemplate = libraryResource("ms_creation_templates/ms_template.yaml")
                msTemplate = msTemplate.replace('%MS_NAME%', args.projectName as String)
                writeFile(file: "deployment/templates/${args.projectName}_template.yaml", text: msTemplate)

            }
            break
        case 'vm':
            dir(args.projectName) {

                sh("""
echo "Preparing DevOps files to fill ${args.projectName}'s repository"
mkdir -p deployment/conf
mkdir -p deployment/scripts
mkdir -p deployment/secrets
mkdir -p sources/${args.projectName}

cat > deployment/scripts/${args.vmServiceName}.sh <<EOF
#!/bin/sh
TSTAMP=\$(date '+%Y%m%d%H%M%S')
JAR="/opt/${args.projectName}/${args.projectName}.jar"
JAVA_OPTS="-XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/opt/tmp/heapdump-${args.projectName}-\$TSTAMP.bin"

start () {
  echo "java \$JAVA_OPTS  -jar \$JAR --spring.config.location=classpath:/application.properties,file:///opt/${args.projectName}/conf/${args.vmServiceName}.properties,file:///opt/${args.projectName}/secrets/credentials.properties"
  java \$JAVA_OPTS -jar \$JAR --spring.config.location=classpath:/application.properties,file:///opt/${args.projectName}/conf/${args.vmServiceName}.properties,file:///opt/${args.projectName}/secrets/credentials.properties
}

stop () {
        echo "Shutting down replicatore-anagrafe"
        curl -X POST localhost:9011/actuator/shutdown
        EXIT_CODE=\$?
        if [ "\$EXIT_CODE" == "0" ]; then
          echo "waiting till 20 secs for gracefull shutdown"
          if [ ! -z "\$(ps -ef | grep java | grep ${args.projectName})" ]; then
            sleep 20
          fi

          IS_STILL_UP=\$(ps -ef | grep java | grep ${args.projectName})
          if [ -z "\$IS_STILL_UP" ]; then
            pkill -15 -f '${args.projectName}'
            sleep 20
            if [ ! -z "\$(ps -ef | grep java | grep ${args.projectName})" ]; then
            echo "Shutdown FAILED"
            exit 1
            fi
          fi
        else
          echo "curl failed to shutdown"
          exit 1
        fi
}

for i in "\$@"
do
        case \$i in
                -h|--help)
                  echo ""
                  echo "  replicatore-anagrafe - Help"
                  echo "          eseguibile per l'avvio e lo stop del servizio replicatore-anagrafe"
                  echo "          Syntax: replicatore-anagrafe start|stop|restart"
                  exit 0
                  ;;

                stop)
                  stop
                  ;;

                start)
                  start
                  ;;

                *)
                  echo "Parametro \$i non riconosciuto"
                  exit 1
                ;;
        esac
done
EOF

cat > deployment/conf/${args.vmServiceName}.properties <<EOF
# -------------------------------------------------
# FEIGN CLIENT CONFIG
# -------------------------------------------------

#feign.client.config.default.connectTimeout: 50000000
#feign.client.config.default.readTimeout: 50000000
#feign.client.config.default.loggerLevel: basic

# -------------------------------------------------
# MONGO CONFIG
# -------------------------------------------------

#spring.data.mongodb.authentication-database=sec
spring.data.mongodb.database=###SEC_MONGODB_DATABASE###
spring.data.mongodb.jdbc.url=###SEC_MONGODB_JDBC_URL###
spring.data.mongodb.username=###SEC_MONGODB_USERNAME###
spring.data.mongodb.collection=###SEC_MONGODB_COLLECTION###

# -------------------------------------------------
# SPRING KAFKA CONFIG
# -------------------------------------------------
spring.cloud.stream.bindings.input.destination=###SEC_KAFKA_TOPICS###
spring.cloud.stream.kafka.streams.binder.brokers=###SEC_KAFKA_BK_LIST###

spring.cloud.stream.kafka.binder.autoCreateTopics=true
spring.cloud.stream.kafka.binder.replicationFactor=3


# -------------------------------------------------
# KAFKA Authorization
# -------------------------------------------------

spring.cloud.stream.kafka.streams.binder.configuration.security.protocol=SASL_SSL
spring.cloud.stream.kafka.streams.binder.configuration.sasl.mechanism=PLAIN
spring.cloud.stream.kafka.streams.binder.configuration.ssl.truststore.location=###CERTIFICATE_PATH###
spring.cloud.stream.kafka.streams.binder.configuration.ssl.keystore.location=###CERTIFICATE_PATH###

# -------------------------------------------------
# Application Configuration
# -------------------------------------------------
application.mock=false
application.streaming.mongo.monitoring=false

server.port=###PORT###
spring.application.name=###NAME_APP###
spring.cloud.stream.bindings.input.consumer.concurrency=1
application.streaming.mongo.custom.field={}
#application.streaming.mongo.custom.field={REFACTOR: '1'}

# -------------------------------------------------
# Logging Configuration
# -------------------------------------------------

logging.config=classpath:${args.vmServiceName}-logback.xml

logging.level.root=###LOG_LEVEL###
logging.level.QUERY=###QUERY_LOG_LEVEL###
logging.level.PERFOMANCE=###PERFORMANCE_LOG_LEVEL###
logging.level.PERFOMANCE_DETAILS=###PERFORMANCE_DETAILS_LOG_LEVEL###
EOF

cat > deployment/secrets/credentials.properties <<EOF
# -------------------------------------------------
# MONGO CONFIG
# -------------------------------------------------

spring.data.mongodb.username=###SEC_MONGODB_USERNAME###
spring.data.mongodb.password=###SEC_MONGODB_PASSWORD###

application.mongo.dbUri=mongodb://###SEC_MONGODB_USERNAME###:###SEC_MONGODB_PASSWORD###@###SEC_MONGODB_JDBC_URL###

# -------------------------------------------------
# KAFKA Authorization
# -------------------------------------------------

spring.cloud.stream.kafka.streams.binder.configuration.sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required \\
    username=\\"###SEC_KAFKA_BROKER_USERNAME###\\" \\
    password=\\"###SEC_KAFKA_BROKER_PASSWORD###\\";

spring.cloud.stream.kafka.streams.binder.configuration.ssl.truststore.password=###SEC_KAFKA_SSL_TRUSTSTORE_PASSWORD###
spring.cloud.stream.kafka.streams.binder.configuration.ssl.keystore.password=###SEC_KAFKA_SSL_KEYSTORE_PASSWORD###
spring.cloud.stream.kafka.streams.binder.configuration.ssl.key.password=###SEC_KAFKA_SSL_KEY_PASSWORD###
EOF

cat >info.yaml <<EOF
currentRelease: 1
dependencies: null
teamsChannelNotification:
  CI:
    - '${args.teamsWebhook}'
sonarqube:
  project_key: '${args.projectName}'
EOF


cat >ci.jenkinsfile <<EOF
@Library('SharedPipelines') _

${args.pipelineName} {
    MICROSERVICE_NAME = '${args.projectName}'
    CONTEXT_DIR = 'sources/${args.projectName}'
}
EOF

touch deployment/README.md
touch sources/${args.projectName}/README.md
""")

            }
            break
        case 'library':
            dir(args.projectName) {
                sh("""
echo "Preparing DevOps files to fill ${args.projectName}'s repository"

mkdir -p sources/${args.projectName}

cat >info.yaml <<EOF
currentRelease: 1
dependencies: null
teamsChannelNotification:
  CI:
    - '${args.teamsWebhook}'
sonarqube:
  project_key: '${args.projectName}'
EOF


cat >ci.jenkinsfile <<EOF
@Library('SharedPipelines') _

${args.pipelineName} {
    MICROSERVICE_NAME = '${args.projectName}'
    CONTEXT_DIR = 'sources/${args.projectName}'
}
EOF

touch sources/${args.projectName}/README.md
""")
            }
            break
    }
}

