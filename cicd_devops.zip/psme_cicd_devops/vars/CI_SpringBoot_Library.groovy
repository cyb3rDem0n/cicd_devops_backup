import com.accenture.sec.managers.SonarManager
import com.accenture.sec.utils.Colors

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def CONTEXT_DIR = pipelineParams.CONTEXT_DIR

    def webhook = null
    def pom = null
    def config = null
    def info = null
    def newVersion = null

    def resultTests = ['unit': ['total': 0, 'success': 0], 'component': ['total': 0, 'success': 0]]
    def altDeploymentRepository

    SonarManager sonarManager = null


    pipeline {
        agent {
            label 'maven-ci'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '15', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }

        stages {

            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {
                            info = getInfo()
                            config = loadEnvVariables(
                                    "CI",
                                    [
                                            notificationMail: params.NOTIFICATION_MAIL,
                                            releaseType     : "MICROSERVICE",
                                            clusterType     : 'test'
                                    ]
                            )
                            webhook = info.teamsChannelNotification.CI

                            env.nexusRepo = "${env.currentBranch}" == 'develop' ? config.nexus.library.maven.repository.snapshot : config.nexus.library.maven.repository.release

                            pom = readMavenPom(file: "${CONTEXT_DIR}/pom.xml")

                            echo("POM:\n${pom}")

                            newVersion = pom.version
                            if ("${env.currentBranch}" == "develop" && !(pom.version ==~ /.*-SNAPSHOT/)) {
                                echo("${Colors.Bash.ORANGE}WARNING: Branch develop accepts only pom with SNAPSHOT version${Colors.Bash.NC}")
                                newVersion = "${pom.version}-SNAPSHOT"

                            } else if ("${env.currentBranch}" == "master" && pom.version ==~ /.*-SNAPSHOT/) {
                                echo("${Colors.Bash.ORANGE}WARNING: Branch master can't accept pom with SNAPSHOT version${Colors.Bash.NC}")
                                newVersion = pom.version.replace("-SNAPSHOT", "")
                            }
                            if (newVersion != pom.version) {
                                sh("""#!/bin/bash
                                    mvn versions:set -DnewVersion=${newVersion} -f ${CONTEXT_DIR}/pom.xml
                                """)
                            }
                            echo "Artifact ID: ${pom.artifactId}"
                            echo "Version: ${newVersion}"
                            echo "Group ID: ${pom.groupId}"
                            echo "Packaging: ${pom.packaging}"

                            // Prepare Slave
                            sh """#!/bin/bash -e
                git config --global user.email "noreply@example.com"
                git config --global user.name "${env.gitUser}"
              """
                        }
                    }
                }
            }

            stage('Build App') {
                steps {
                    script {
                        ansiColor('xterm') {
                            buildMaven("${CONTEXT_DIR}")
                        }
                    }
                }
            }

            stage('Unit Test') {
                steps {
                    script {
                        ansiColor('xterm') {
                            def ret = unitTestMaven("${CONTEXT_DIR}")
                            resultTests.unit.total = ret.total
                            resultTests.unit.success = ret.success
                            if (ret.exception) {
                                error("Unit test falliti")
                            }
                        }
                    }
                }
            }

			stage('Sonar Test') {
                when { expression { !(env.isFeature.toBoolean()) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            if(!info.sonarqube?.project_key){
                                error("${Colors.Bash.RED}${Colors.Bash.BOLD}sonarqube.project_key is not present in info.yaml file${Colors.Bash.NC}")
                            }
                            withCredentials([string(credentialsId: env.sonarTokenCredsId, variable: 'login_id')]) {
                                sonarManager = new SonarManager(this, env.sonarURL, env.login_id)
                            }
                            dir(CONTEXT_DIR) {
                                sonarManager.scanWithMaven([sonarProjectKey: info.sonarqube.project_key, branch: env.currentBranch])
                            }
                        }
                    }
                }
            }

            stage('Archive artifact') {
                steps {
                    script {
                        ansiColor('xterm') {
                            dir(CONTEXT_DIR) {
                                def repoId = env.currentBranch == 'develop' ? 'maven-snapshots' : 'maven-release'
                                altDeploymentRepository = "${repoId}::default::${env.nexusURL}/repository/${env.nexusRepo}/"

//                                sh """
//                                    mvn source:jar
//                                """
//                                def filePath = sh(returnStdout: true, script: """#!/bin/bash -e
//                                  ls target/*.${pom.packaging} | grep -v sources
//                                """).trim()
//                                def sourcesFilePath = sh(returnStdout: true, script: """#!/bin/bash -e
//                                  ls target/*.${pom.packaging} | grep sources
//                                """).trim()
//                                def sources = sourcesFilePath ? "-Dsources='${sourcesFilePath}'" : ''
//
//                                sh """
//                                    mvn deploy:deploy-file -DgroupId=${pom.groupId} -DartifactId=${pom.artifactId} -Dversion=${newVersion} -DgeneratePom=true -Dpackaging=${pom.packaging} -DrepositoryId=${repoId} -Durl=${env.nexusURL}/repository/${env.nexusRepo} -Dfile='${filePath}' ${sources}
//                                """

                                sh """
                                    mvn source:jar jar:jar deploy:deploy -DaltDeploymentRepository=${altDeploymentRepository} | tee upload.log
                                """

                                def tagVersion = newVersion
                                if ("${env.currentBranch}" == "develop") {
                                    tagVersion = sh(returnStdout: true, script: """#!/bin/bash -e
                                        grep "Uploaded .*${pom.artifactId}-[0-9.-]*\\.jar.*" upload.log | sed 's/.*${pom.artifactId}-\\([0-9.-]*\\)\\.jar.*/\\1/g' | tail -n1 
                                    """).trim()
                                }
                                tagVersion && tagRepository(env.gitUser, env.msRepoURL, env.commitId, tagVersion)

                            }
                        }
                    }
                }
            }

        }


        post {
            always {
                deleteDir()
                script {
                    def result = currentBuild.currentResult
                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    def mailMessages = [
                            'SUCCESS': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
<p>Upload libreria ${pom.artifactId}:${newVersion} su Nexus completata con successo</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]],
                            'FAILURE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
<p>Upload libreria ${pom.artifactId}:${newVersion} su Nexus fallito</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]]]
                    notifyMail(env.committerEmail, mailMessages, currentBuild.currentResult)

                    def infoMap = ['Commit ID': env.commitId, 'Committer': env.committer, 'Commit Message': env.commitMessage.replace('\r', '').replace('\n', '<br>'), 'Library': "${pom.artifactId}:${newVersion}", 'Nexus Repo': "${env.nexusRepo}", 'Nexus Group': "${pom.groupId}", 'ACTIONS': [['name': 'View Commit', 'url': "${env.gitURL}/projects/${env.gitProject}/repos/${env.msRepoName}/commits/${env.commitId}"]]]
                    def qg = null
                    if (sonarManager) {
                        qg = sonarManager.waitForQualityGate()
                    }
                    if (qg) {
                        infoMap.put('Quality Gate', qg.label)
                    }

                    webhook.each {
                        notifyTeams(result, "Upload libreria ${pom.artifactId}:${newVersion} su Nexus completata con successo", it, infoMap)
                    }
                }
            }
        }
    }
}
