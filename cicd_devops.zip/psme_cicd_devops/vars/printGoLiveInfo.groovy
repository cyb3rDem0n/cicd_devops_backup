import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.PrintTable

def call(Object goLiveList) {
    return call([goLiveList: goLiveList, headerColor: Colors.Bash.GREEN, elementColor: Colors.Bash.BLUE])
}

def call(Map args) {
    if (CommonUtils.isNullOrEmpty(args?.goLiveList))
        return null
    def table = PrintTable.printTable(args.goLiveList.toListMap(), args)
    echo(table)
    return table
}


