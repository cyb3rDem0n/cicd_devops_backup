def call(def msg) {
    if(env.DEBUG == 'true'){
        echo("${msg}")
    }
}