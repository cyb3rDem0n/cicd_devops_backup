package deprecated

import com.accenture.sec.entities.IncreaseType
import com.accenture.sec.entities.Versioner
import com.accenture.sec.managers.NexusManager

def call(body) {

    // evaluate the body block, and collect configuration into the object
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def config = null
    NexusManager nxMgr = null
    def MICROSERVICE_NAME = pipelineParams.MICROSERVICE_NAME ? pipelineParams.MICROSERVICE_NAME : "kafka-config"
    def webhook = null

    env.isFeature = 'false'

    pipeline {

        agent {
            label 'maven-ci'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '15', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }

        stages {


            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('gnome-terminal') {
                            env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                            info = getInfo()
                            webhook = info.teamsChannelNotification.CI
                            config = loadEnvVariables(
                                    "CI",
                                    [
                                            notificationMail: params.NOTIFICATION_MAIL,
                                            releaseType     : "KAFKA",
                                            clusterType     : 'test'
                                    ]
                            )
                            echo "Calculating new version from repository tags..."
                            // calcolo la nuova versione partendo dai tag su repository (non esistono immagini buildate)
                            List<String> tags = sh(returnStdout: true, script: 'git tag').trim().tokenize('\n').collect {
                                it.trim()
                            }
                            List<String> versions = []
                            if (tags != null) {
                                versions = tags.findAll { it ==~ /${env.releaseNumber}-b\d+/ }
                            }
                            // definizione del pattern della versione
                            String versionPattern = config.version?.pattern ?: /${env.releaseNumber}-b(\d+)/
                            String versionFormat = config.version?.format ?: /${env.releaseNumber}-b%d/
                            Versioner versioner = new Versioner(versionPattern, versionFormat)
                            def newVersion = versioner.nextVersion(versions, null, IncreaseType.MAJOR)
                            if (newVersion == null)
                                newVersion = "${env.releaseNumber}-b1"
                            env.buildTag = newVersion
                            echo "New version: ${env.buildTag}"

                            sh """#!/bin/bash -e
                                git config --global user.email "noreply@example.com"
                                git config --global user.name "${env.gitUser}"
                            """
                        }
                    }
                }
            }
            stage('Create kafka topics') {
                //when { expression { false } }
                steps {
                    script {
                        ansiColor('gnome-terminal') {
                            
                            def result = applyKafkaConfig([type: "CI"])
                            if(result?.configApplied){
                                // crea pacchetto zip dei file necessari al deploy dal repo git
                                def filePath = createArtifact(null, 'package', "${MICROSERVICE_NAME}", env.buildTag)
                                echo "Generated artifact ${filePath}"
                                def map = [
                                        'groupId'       : "${env.nexusArtifactGroupId}",
                                        'artifactId'    : "${MICROSERVICE_NAME}",
                                        'packageVersion': env.buildTag,
                                        'packaging'     : 'zip']
                                // faccio l'upload dell'artefatto generato
                                echo "Uploading artifact to nexus repository '${env.nexusArtifactRepo}' with gav ${map}..."
                                nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)
                                nxMgr.upload(env.nexusArtifactRepo, filePath, map)
                                // taggo il repository sul commit arrivato in input con il numero della versione
                                echo "Tagging git repository with version ${env.buildTag}"
                                tagRepository(env.gitUser, env.msRepoURL, env.commitId, env.buildTag)
                            }
                        }
                    }
                }
            }

            stage('Update Manifest') {
                when { expression { return env.releaseNumber != null } }
                steps {
                    script {
                        echo("Updating '${env.releaseNumber}' manifest for ${MICROSERVICE_NAME}")
                        Map<String, String> dbInfo = [:]
                        dbInfo.putAll(config.manifest.db)

                        updateDBManifest(
                                [
                                    waveName: env.releaseNumber,
                                    msName: MICROSERVICE_NAME,
                                    msBuildNum: env.buildTag,
                                    msDeps: "",
                                    dbInfo: dbInfo
                                ]
                        )
                    }
                }
            }

        }

        post {
            always {
                deleteDir()
                script {
                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    def result = currentBuild.currentResult
                    if (result == 'ABORTED')
                        return

                    def mailMessages = [
                            'SUCCESS': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
           <p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${
                                                env.targetProjectOCP
                                            }</p>
           <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                           """]],
                            'FAILURE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
           <p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} fallito in ambiente ${
                                                env.targetProjectOCP
                                            }</p>
           <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                           """]]]
                    if (!(env.isFeature.toBoolean()) || (env.isFeature.toBoolean() && result != 'SUCCESS'))
                        //notifyMail(env.committerEmail, mailMessages, result)


                    def teamsMessages = [
                            'SUCCESS' : "Il microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo",
                            'FAILURE' : "Fallito aggiornamento manifest di Release Candidate ${env.releaseNumber} per il microservizio ${MICROSERVICE_NAME} versione ${env.buildTag}",
                            'UNSTABLE': "Il microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo\n\nAlcuni test sono falliti"]

                    def infoMap = [
                            'Commit ID'     : "${env.commitId}",
                            'Committer'     : "${env.committer}",
                            'Commit Message': env.commitMessage.replace('\r', '').replace('\n', '<br>'),
                            'Path'          : "${env.chainPath}",
                            //'Project'       : "${env.targetProjectOCP}",
                            'Microservice'  : "${MICROSERVICE_NAME}",
                            //'Unit Test'     : "${resultTests.unit.success}/${resultTests.unit.total}",
                            'SUCCESS'       : ['Version Tag': "${env.buildTag}"],
                            'ACTIONS'       : [
                                    ['name': 'View Commit', 'url': "${env.gitURL}/projects/${env.gitProject}/repos/${env.msRepoName}/commits/${env.commitId}"]
                            ]
                    ]

                    if (!(env?.isFeature?.toBoolean())) {
                        webhook.each {
                            //notifyTeams(result, teamsMessages, it, infoMap)
                        }
                    }
                }
            }
        }
    }
}