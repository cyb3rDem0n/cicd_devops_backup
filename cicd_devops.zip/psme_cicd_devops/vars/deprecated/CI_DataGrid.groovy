package deprecated

import com.accenture.sec.entities.IncreaseType
import com.accenture.sec.entities.Versioner
import com.accenture.sec.managers.NexusManager
import com.accenture.sec.utils.OpenshiftUtils

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def NAME = pipelineParams.NAME ? pipelineParams.NAME : "datagrid-service"

    def TEMPLATE_NAME = null

    env.targetProjectOCP = null
    env.CICDProjectOCP = null
    env.clusterOCP = null


    def webhook = null
    def config = null

    def templates = null

    def skipDeploy = true


    NexusManager nxMgr = null

    pipeline {
        agent {
            label 'maven-ci'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '15', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }


        stages {

            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {
                            echo "Getting pipelines config from file..."
                            info = getInfo()
                            config = loadEnvVariables(
                                    "CI",
                                    [
                                            notificationMail: params.NOTIFICATION_MAIL,
                                            releaseType     : "MICROSERVICE",
                                            clusterType     : 'test'
                                    ]
                            )
                            webhook = info.teamsChannelNotification.CI

                            nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)

                            echo "Calculating new version from repository tags..."
                            // calcolo la nuova versione partendo dai tag su repository (non esistono immagini buildate)
                            List<String> tags = sh(returnStdout: true, script: 'git tag').trim().tokenize('\n').collect {
                                it.trim()
                            }
                            List<String> versions = tags.findAll { it ==~ /${env.releaseNumber}-b\d+/ }

                            String versionPattern = /${env.releaseNumber}-b(\d+)/
                            String versionFormat = /${env.releaseNumber}-b%d/
                            Versioner versioner = new Versioner(versionPattern, versionFormat)
                            def newVersion = versioner.nextVersion(versions, null, IncreaseType.fromString('build'))
                            if (newVersion == null)
                                newVersion = "${env.releaseNumber}-b1"
                            env.buildTag = newVersion
                            echo "New version: ${env.buildTag}"


                            // Prepare Slave
                            sh """#!/bin/bash -e
                                git config --global user.email "noreply@example.com"
                                git config --global user.name "${env.gitUser}"
                            """

                            echo "Collecting all the yaml template files in deployment/templates/ ..."
                            templates = findFiles(glob: "deployment/templates/*.yaml")
                        }
                    }
                }
            }


            stage('Archive artifact') {
                steps {
                    script {
                        ansiColor('xterm') {
                            // crea pacchetto zip dei file necessari al deploy dal repo git
                            def filePath = createArtifact(null, 'package', NAME, env.buildTag)
                            echo "Generated artifact ${filePath}"
                            def map = [
                                    'groupId'       : env.nexusArtifactGroupId,
                                    'artifactId'    : NAME,
                                    'packageVersion': env.buildTag,
                                    'packaging'     : 'zip']
                            // faccio l'upload dell'artefatto generato
                            echo "Uploading artifact to nexus repository '${env.nexusArtifactRepo}' with gav ${map}..."
                            nxMgr.upload(env.nexusArtifactRepo, filePath, map)
                            // taggo il repository sul commit arrivato in input con il numero della versione
                            echo "Tagging git repository with version ${env.buildTag}"
                            tagRepository(env.gitUser, env.msRepoURL, env.commitId, env.buildTag)
                        }
                    }
                }
            }


            stage('Deployment preparation test') {
                when { expression { skipDeploy } }
                steps {
                    script {
                        ansiColor('xterm') {

                            // testo che i token per cb-test esistano e che il replace non vada in fallimento
                            def targetProject = "cb-test-${env.releaseNumber}"
                            templates.each { template ->
                                String name = template.name.replaceAll(/\.yaml/, '')
                                def replaceTokensMap = [
                                        path         : template.path,
                                        tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${targetProject}.yaml",
                                        microservice : name,
                                        dryrun       : true,
                                        notEncode    : true
                                ]
                                replaceTokens(replaceTokensMap)
                            }

                        }
                    }
                }
            }


            stage('Deploy Datagrid') {
                when { expression { !skipDeploy } }
                steps {
                    script {
                        ansiColor('xterm') {

                            OpenshiftUtils.datagridCreateCluster(this, [name: NAME, templates: templates, version: env.buildTag])
                        }
                    }
                }
            }

            stage('Update Manifest') {
                when { expression { return (env.releaseNumber != null) } }
                steps {
                    script {
                        echo("Updating '${env.releaseNumber}' manifest for ${NAME}")
                        Map<String, String> dbInfo = [:]
                        dbInfo.putAll(config.manifest.db)

                        updateDBManifest(releaseNumber: env.releaseNumber,
                                releaseType: 'MICROSERVICE',
                                permittedReleaseStatus: ['RC'],
                                msName: NAME,
                                msVersion: env.buildTag,
                                msDeps: (info.dependencies ?: info.dependences),
                                target: (info.target ?: 'ocp'),
                                dbInfo: dbInfo)
                    }
                }
            }

        }

        post {
            always {
                deleteDir()
//                script {
//                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
//                    result = currentBuild.currentResult
//                    if (failedTests.size() > 0 && stat.deployed)
//                        result = 'UNSTABLE'
//                    mailMessages = [
//                            'SUCCESS' : [
//                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
//                                    'body'   : [
//                                            'type': 'text/html',
//                                            'msg' : """
//<p>Deploy del microservizio ${NAME} versione ${env.buildTag} effettuato con successo in ambiente ${
//                                                env.targetProjectOCP
//                                            }</p>
//<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
//                """]],
//                            'FAILURE' : [
//                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
//                                    'body'   : [
//                                            'type': 'text/html',
//                                            'msg' : """
//<p>Deploy del microservizio ${NAME} versione ${env.buildTag} fallito in ambiente ${env.targetProjectOCP}</p>
//<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
//                """]],
//                            'UNSTABLE': [
//                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] instabile",
//                                    'body'   : [
//                                            'type': 'text/html',
//                                            'msg' : """
//<p>Deploy del microservizio ${NAME} versione ${env.buildTag} effettuato con successo in ambiente ${
//                                                env.targetProjectOCP
//                                            } ma alcuni test sono falliti</p>
//<p>${failedTests}</p>
//<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
//                """]]]
//                    notifyMail(env.committerEmail, mailMessages, result)
//
//                    teamsMessages = [
//                            'SUCCESS' : "Deploy del microservizio ${NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}",
//                            'FAILURE' : "Deploy del microservizio ${NAME} versione ${env.buildTag} fallito in ambiente ${env.targetProjectOCP}",
//                            'UNSTABLE': "Deploy del microservizio ${NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}\n\nAlcuni test sono falliti"]
//
//                    infoMap = ['Commit ID': env.commitId, 'Commit Message': env.commitMessage, 'Committer': env.committer, 'Path': "${env.chainPath}", 'Project': "${env.targetProjectOCP}", 'Microservice': "${NAME}", 'Unit Test': "${resultTests.unit.success}/${resultTests.unit.total}", 'Component Test': "${resultTests.component.success}/${resultTests.component.total}", 'SUCCESS': ['Version Tag': "${env.buildTag}"], 'ACTIONS': [['name': 'View Commit', 'url': "https://###bitbucket_url###/projects/###bitbucket_project###/repos/${env.msRepoName}/commits/${env.commitId}"]]]
//                    if (failedTests.size() > 0)
//                        infoMap.put('Failed tests', "${failedTests}")
//                    webhook.each {
//                        notifyTeams(result, teamsMessages, it, infoMap)
//                    }
//                }
            }
        }

    }

}