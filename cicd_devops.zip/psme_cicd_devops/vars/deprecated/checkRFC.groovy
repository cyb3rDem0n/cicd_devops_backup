package deprecated

import com.accenture.sec.managers.sqlserver.RFCDto
import com.accenture.sec.managers.sqlserver.SqlCmdManager
import com.accenture.sec.utils.CommonUtils

def call(Map args) {
    //CommonUtils.checkInputParameters(args, "method, codiceRFC, sqlcmdCfg, clusterType")
    echo "args: ${args}"
    switch (args.method){
        case "validateRFC":
            echo "starting validate"
            return validateRFC(args)
            break
        case "canProceedWithRFC":
            echo "starting canProceed"
            return canProceedWithRFC(args)
            break
    }

}

def validateRFC(Map args){

    SqlCmdManager sqlCmdManager = new SqlCmdManager(this, args.sqlcmdCfg)
    String query = libraryResource("${args.sqlcmdCfg.sqlserver.queryFile}")

    query = query.replaceAll("#COD_RFC#", "${args.codiceRFC}")
    String csv = sqlCmdManager.executeQuery( query: query )
    def records = csv.split("\n")

    if (records?.size() > 1){
        StringBuffer buf = new StringBuffer()
        buf = buf.append("\n").append(CommonUtils.hrSeparator).append("\n")
                .append("Errore! Trovato più di un record per il check RFC (ambiente:${args.clusterType}.\n")
                .append("records: ").append("${records}").append("\n")
                .append(CommonUtils.hrSeparator).append("\n")
        echo("${buf.toString()}")
        error("${buf.toString()}")
    }

    if (records?.size() == 0){
        StringBuffer buf = new StringBuffer()
        buf = buf.append("\n").append(CommonUtils.hrSeparator).append("\n")
                .append("Errore! Nessun record trovato per il check RFC\nControllare che sia corretto il codice RFC '${args.codiceRFC}'")
                .append(CommonUtils.hrSeparator).append("\n")
        echo("${buf.toString()}")
        error("${buf.toString()}")
    }
    String[] values = records[0].split(';')

    echo "values: ${values}"
    RFCDto dto = new RFCDto(values, this)
    return [continueRFC: dto.canProceedWithRFC(args.clusterType, this), rfcdto: dto]
}

def canProceedWithRFC(Map args){
    SqlCmdManager sqlCmdManager = new SqlCmdManager(this, args.sqlcmdCfg)
    String query = libraryResource("${args.sqlcmdCfg.sqlserver.queryFile}")

    query = query.replaceAll("#COD_RFC#", "${args.codiceRFC}")
    String csv = sqlCmdManager.executeQuery( query: query )
    def records = csv.split("\n")

    if (records?.size() > 1){
        StringBuffer buf = new StringBuffer()
        buf = buf.append("\n").append(CommonUtils.hrSeparator).append("\n")
                .append("Errore! Trovato più di un record per il check RFC (ambiente:${args.clusterType}.\n")
                .append("records: ").append("${records}").append("\n")
                .append(CommonUtils.hrSeparator).append("\n")
        echo("${buf.toString()}")
        error("${buf.toString()}")
    }

    if (records?.size() == 0){
        StringBuffer buf = new StringBuffer()
        buf = buf.append("\n").append(CommonUtils.hrSeparator).append("\n")
                .append("Errore! Nessun record trovato per il check RFC\nControllare che sia corretto il codice RFC '${args.codiceRFC}'")
                .append(CommonUtils.hrSeparator).append("\n")
        echo("${buf.toString()}")
        error("${buf.toString()}")
    }
    String[] values = records[0].split(';')

    echo "values: ${values}"
    RFCDto dto = new RFCDto(values, this)
    return [continueRFC: dto.isValidRFC(args.clusterType,this), rfcdto: dto]
}





