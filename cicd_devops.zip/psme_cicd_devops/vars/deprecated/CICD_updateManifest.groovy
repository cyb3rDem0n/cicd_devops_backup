import com.accenture.sec.managers.NexusManager

def call(body){
  def pipelineParams = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = pipelineParams
  body()

  def microservices = [:]
  def UPDATE_TYPE = pipelineParams.UPDATE_TYPE
  def manifest = null

  def webhook = null
  def notificationManifest = null




  NexusManager nxMgr = null

  pipeline {
    agent {
      label 'maven'
    }

    options {
      disableConcurrentBuilds()
      timeout(time: 60, unit: 'MINUTES')
    }

    parameters {
      string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
      string(name: 'MICROSERVICE_NAME', defaultValue: '', description: 'Insert name of the microservice that you want to update in manifest')
      string(name: 'VERSION', defaultValue: '', description: 'Insert version for the microservice above you want to promote in manifest')
    }
    
    stages{
      
      stage('Check input'){
        steps{
          script{
            ansiColor('xterm'){

              if("${MICROSERVICE_NAME}" == "" || "${VERSION}" == ""){
                error("MICROSERVICE_NAME and VERSION parameters are mandatory")
              }

              config = loadEnvVariables("CD", [
                      releaseType: 'MICROSERVICE',
                      clusterType: 'test']
              )
              webhook = config.teamsChannelNotification.CD['MICROSERVICE'][UPDATE_TYPE]
              // env.clusterOCP = config.ocp.cluster
              // env.CICDProjectOCP = config.ocp.project.cicd

              nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)

              env.msName = "${MICROSERVICE_NAME}"
              def tags = null
              openshift.withCluster("${env.clusterOCP}") {
                openshift.withProject("${env.CICDProjectOCP}") {
                  def sel = openshift.selector("is", "${env.msName}")
                  if(sel.count() > 0){
                    tags = sel.object()
                    tags = tags.spec.tags
                  }
                }
              }
              if(tags){
                def found = false
                for(tag in tags){
                  if(tag.name == "${VERSION}"){
                    found = true
                    break
                  }
                }
                if(!found){
                  error("Immagine ${env.msName}:${VERSION} non trovata")
                }
              }else{
                error("Nessuna immagine per ${env.msName}")
              }
              env.manifestFile = config.manifest.file[UPDATE_TYPE]
            }
          }
        }
      }

      stage('Check prerequisites'){
        steps{
          script{
            ansiColor('xterm'){
              microservices.put(env.msName,["version":"${VERSION}"])
              def err = null
              echo "Controllo ${env.msName}..."
              def filePath = nxMgr.download(env.nexusArtifactRepo,[groupId: env.nexusArtifactGroupId, artifactId: env.msName, packageVersion: params.VERSION, packaging: 'zip'], "tmp")
              sh """#!/bin/bash -e
                unzip "${filePath}" -d "${WORKSPACE}/tmp/"
                rm -rf ${filePath}
              """

              if(fileExists('tmp/pom.xml')){
                def pom = readMavenPom file: "tmp/pom.xml"
                pom.getDependencies().each{ dep ->
                  if(dep.version && dep.version ==~ /.*SNAPSHOT/){
                    error("${env.msName}-${VERSION} è stato compilato con dipendenze 'SNAPSHOT'\n${dep}")
                  }
                }
              }

              def info = readYaml file: 'tmp/info.yaml'
              def dep = info.dependences ?: info.dependencies
              microservices[env.msName].put('dependencies', dep)
              sh """#!/bin/bash
                cd "${WORKSPACE}" && rm -rf "${WORKSPACE}/tmp"
              """
            }
          }
        }
      }

      stage('Update Manifest'){
        steps{
          script{
            ansiColor('xterm'){
              lock('devops_repo'){
                withCredentials([usernameColonPassword(credentialsId: env.gitUser, variable: 'creds')]) {
                  sh """
                    mkdir -p tmp_repo
                    git clone --depth 1 -b master https://${creds}@###bitbucket_url###/scm/###bitbucket_project###/jrv_cicd_devops.git tmp_repo/ && cd tmp_repo
                    git config --global user.email "noreply@example.com"
                    git config --global user.name "${env.gitUser}"
                    git config --global push.default simple
                  """
                }
                manifest = readYaml file: "tmp_repo/manifest/${env.manifestFile}"
                echo "\u001B[34mCurrent MANIFEST:\u001B[0m\n${manifest}\n"
                
                manifest[env.msName] = microservices[env.msName]
                echo "\u001B[32mNew MANIFEST:\u001B[0m\n${manifest}\n"

                sh "rm -rf tmp_repo/manifest/${env.manifestFile}"
                writeYaml file: "tmp_repo/manifest/${env.manifestFile}", data: manifest

                sh """#!/bin/bash
                  cd tmp_repo
                  git add manifest/${env.manifestFile}
                """
                def code = sh (returnStatus: true, script: """
                  cd tmp_repo
                  git commit -m "Aggiornato ${env.manifestFile}"
                """)

                if(code == 0){
                  sh """#!/bin/bash -e
                    cd tmp_repo
                    git push origin
                  """
                } else {
                  println('MANIFEST già aggiornato')
                }
              }
              notificationManifest = createReadableManifest(manifest)
            }
          }
        }
      }

    }

    post {
      always {
        deleteDir()
        script {
          env.JOB_NAME = env.JOB_NAME.replaceAll('%2F','/')
          manifestTitle = UPDATE_TYPE == 'FIX' ? 'HotFix Manifest' : 'Release Candidate Manifest'
          subTitle = UPDATE_TYPE == 'FIX' ? 'MANIFEST F' : 'MANIFEST RC'
          mailMessages = [
            'SUCCESS':[
              'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
              'body':[
                'type': 'text/html',
                'msg': """
<p>Aggiornamento ${manifestTitle} con versione ${VERSION} per microservizio ${MICROSERVICE_NAME} effettuato con successo</p>
<div>${subTitle} aggiornato:</div>
<pre style="display: block; color: #333; font-family: Monaco,Menlo,Consolas,&quot;Courier New&quot;,monospace; padding: 5px; font-size: 10px; word-break: break-all; word-wrap: break-word; white-space: pre-wrap; background-color: #f5f5f5; border: 1px solid #ccc; border-radius: 4px;">
${notificationManifest}
</pre>
                """]],
            'FAILURE':[
              'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
              'body':[
                'type': 'text/html',
                'msg': """
<p>Aggiornamento ${manifestTitle} con versione ${VERSION} per microservizio ${MICROSERVICE_NAME} fallito</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]]]
            notifyMail("${NOTIFICATION_MAIL}", mailMessages, currentBuild.currentResult)

            def infoMap = null
            wrap([$class: 'BuildUser']) {
              chainPath = UPDATE_TYPE == 'FIX' ? 'HotFix Path' : 'Release Path'
              teamsMessages = [
              'SUCCESS': "Aggiornamento ${manifestTitle} con versione ${VERSION} per microservizio ${MICROSERVICE_NAME} effettuato con successo",
              'FAILURE': "Aggiornamento ${manifestTitle} con versione ${VERSION} per microservizio ${MICROSERVICE_NAME} fallito"]
              infoMap = ['Triggered by': "${env.BUILD_USER}", 'Path': "${chainPath}", 'SUCCESS': ['Microservice':"${MICROSERVICE_NAME}", 'Version': "${VERSION}", 'SECTIONS':[['activityTitle': "${manifestTitle}", 'activityText': "<pre>${notificationManifest}</pre>", "markdown": false]]]]
            }
            webhook.each{
              notifyTeams(currentBuild.currentResult, teamsMessages, it, infoMap)
            }
        }
      }
    }
    
  }
}