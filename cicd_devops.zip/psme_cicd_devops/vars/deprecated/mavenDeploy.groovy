def call(def map=null){
    sh """#!/bin/bash -e
    echo "Deploying Artifact ..."
    echo "mvn deploy:deploy-file -DskipTests=true -DgeneratePom=false -DrepositoryId=nexus-sec -Durl=http://nexus.secreloaded.sec/repository/test_maven -DpomFile=${WORKSPACE}/${map.contextDir}/pom.xml -Dfile=${WORKSPACE}/${map.contextDir}/target/${map.artifactId}-${map.packageVersion}.jar"
    mvn deploy:deploy-file -DskipTests=true -DgeneratePom=false -DrepositoryId=nexus-sec -Durl=http://nexus.secreloaded.sec/repository/test_maven -DpomFile=${WORKSPACE}/${map.contextDir}/pom.xml -Dfile=${WORKSPACE}/${map.contextDir}/target/${map.artifactId}-${map.packageVersion}.jar
  """
}