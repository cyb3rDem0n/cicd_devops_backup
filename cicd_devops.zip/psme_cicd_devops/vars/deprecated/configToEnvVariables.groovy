import com.accenture.sec.utils.CommonUtils

def call(Map args){
    CommonUtils.checkInputParameters(args,'configPath')
    def config = readYaml file: "${args.configPath}"
    args.releaseType = args.releaseType ?: "MICROSERVICE"
    args.clusterType = args.clusterType ?: "test"
    
    env.clusterOCP = config.ocp[args.clusterType].cluster
    env.clusterCredsId = config.ocp[args.clusterType].credsId
    env.CICDProjectOCP = config.ocp[args.clusterType].project.cicd
    if (args.stage && args.step) {
        env.targetProjectOCP = config.ocp[args.clusterType].project[args.stage][args.releaseType][args.step]
    }

    env.gitURL = config.svc.url
    env.gitProject = config.svc.project

    env.sonarURL = config.sonarqube.url
    env.nexusURL = config.nexus.url
    env.nexusArtifactRepo = config.nexus.artifact.repository
    env.nexusArtifactGroupId = config.nexus.artifact.group

    env.seleniumServer = config.selenium.url
    return config
}

/*
def call(def configPath, def cicdChain, def chain, def releaseType="MICROSERVICE") {
    // Get configs
    config = readYaml file: "${configPath}"

    env.clusterOCP = config.ocp.cluster

    env.CICDProjectOCP = config.ocp.project.cicd
    if (cicdChain && chain) {
        env.targetProjectOCP = config.ocp.project[cicdChain][releaseType][chain]
    }
    env.sonarURL = config.sonarqube.url
    env.nexusURL = config.nexus.url
    env.nexusArtifactRepo = config.nexus.artifact.repository
    env.nexusArtifactGroupId = config.nexus.artifact.group

    env.seleniumServer = config.selenium.url

    return config
}
*/
