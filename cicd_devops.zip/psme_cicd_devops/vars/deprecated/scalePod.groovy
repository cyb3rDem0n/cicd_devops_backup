package deprecated

def call(def openshift, def dcName, def replica){
  if(openshift.selector('dc', "${dcName}").object().spec.replicas != replica){
    println("Scaling ${dcName} to ${replica}...")
    res = openshift.selector('dc', "${dcName}").scale("--replicas=${replica}")
    if(replica != 0){
      sleep(5)
      _continue = true
      while(_continue){
        _continue = false
        try{
          openshift.selector("dc", "${dcName}").related('pods').withEach{
            if(it.object().status.phase != "Running")
              _continue = true
          }
        }catch(Exception e){
          if(!e.toString().contains("Unable to retrieve object"))
            throw e
          _continue = true
        }
      }
    }
    println(res.out)
  }
}