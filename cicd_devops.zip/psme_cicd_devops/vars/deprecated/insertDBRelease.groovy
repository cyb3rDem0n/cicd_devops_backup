package deprecated

import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.BuildDAO
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dao.ReleaseStatusDAO
import com.accenture.sec.db.dao.ReleaseTypeDAO
import com.accenture.sec.db.dto.BuildDTO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.db.dto.ReleaseStatusDTO
import com.accenture.sec.db.dto.ReleaseTypeDTO
import com.accenture.sec.exceptions.DuplicatedReleaseVersionException
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args)throws DuplicatedReleaseVersionException{
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args,'releaseNumber,releaseType')
    Map<String, String> dbInfo = [:]
    dbInfo.putAll(args.dbInfo)
    CommonUtils.checkInputParameters(dbInfo,'type,host,database,credsId')
    def releaseNumber = args.releaseNumber
    long releaseType = args.releaseType
    int RC = 1 //Release Candidate
    int AR = 4 //Archived Release
    LinkedHashMap responseMap
    echo("Inserting release")
    Connection connection = null
    ArrayList<BuildDTO> newReleaseManifestList;
    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione
    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        // Definisco i DAO per le operazioni sul db
        ReleaseDAO releaseDAO = new ReleaseDAO(connection)
        BuildDAO manifestDAO = new BuildDAO(connection)
        ReleaseTypeDAO releaseTypeDAO = new ReleaseTypeDAO(connection)
        ReleaseStatusDAO releaseStatusDAO = new ReleaseStatusDAO(connection)

        ReleaseDTO duplicatedDto = releaseDAO.getFromReleaseNumber(releaseNumber, releaseType)
        if(duplicatedDto != null){
            throw new DuplicatedReleaseVersionException("Insert new Release Version: nuova versione gia' presente su database")
        }
        //Definisco il dto della nuova release
        ReleaseDTO newRelease = new ReleaseDTO();
        newRelease.setIsHotfix(false)
        newRelease.setReleaseNumber(releaseNumber)
        ReleaseTypeDTO rt = releaseTypeDAO.getByReleaseTypeCode((long)releaseType)
        newRelease.setReleaseType(rt)
        ReleaseStatusDTO relst = releaseStatusDAO.getByStatusCode(RC)
        newRelease.setStatus(relst)
        //Trovo la release in prod e recupero tutti i manifest di quella release
        ReleaseDTO prodRelease = releaseDAO.getCurrentProdRelease((long)releaseType)
        if(prodRelease == null) {
            echo "#################################################################\nNessuna versione correntemente in produzione"
            throw new Exception("Nessuna versione correntemente in produzione")
        }
        //esecuzione insert release
        newRelease = releaseDAO.insert(newRelease)
        try{
            connection.setAutoCommit(false)
            releaseDAO.startTransaction()
            ArrayList<BuildDTO> manifestList = manifestDAO.getManifest(prodRelease.getId())
            newReleaseManifestList = new ArrayList<BuildDTO>()
            for(BuildDTO prodDto : manifestList){
                BuildDTO dto = new BuildDTO()
                dto.setMicroservice(prodDto.microservice)
                dto.setVersion(prodDto.version)
                dto.setDeps(prodDto.deps)
                dto.setRelease(newRelease)
                dto = manifestDAO.insertOrUpdate(dto)
                echo"#############################################################################\nInserito manifest ${dto.getMicroservice()} per nuova release candidate"
                newReleaseManifestList.add(dto)
            }

            releaseDAO.commitTransaction()
            connection.commit()
        }catch (Exception e) {
            connection.rollback()
            throw e
        }

        responseMap =[
                prodReleaseDto : prodRelease,
                newReleaseDto : newRelease,
                newReleaseManifestList : newReleaseManifestList,
                dbInfo : dbInfo
        ]

    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }

    return responseMap
}