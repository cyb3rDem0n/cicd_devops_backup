import com.accenture.sec.testers.TestResult
import com.accenture.sec.testers.SoapUIRestTester
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.Logger

def call(Map args) {
    CommonUtils.checkInputParameters(args, 'kind,url,glob')
    echo "Preparing to run ${args.kind} tests ..."
    def testList = findFiles(glob: args.glob)

    // conta i file come singoli test
    // resultTests.component.total += testList.size()
    def failed = false
    Map result
    TestResult testResult = new TestResult(args.kind)
    if(testList.size() == 0){
        echo "No ${args.kind} test to run found with glob: '${args.glob}'"
        return testResult
    }
    SoapUIRestTester soapUITester = new SoapUIRestTester(this)
    try {
        testList.each { testFile ->
            echo "Running ${testFile.name} ..."
            def outFolder = "/tmp/results/${testFile.name.replace('.xml','')}"
            def reqMap = [
                    url        : args.url,
                    projectFile: "${testFile.path}",
                    //options    : ['-A', '-M', '-J', '-f/tmp/results/', '-r']
                    options    : ['-M', '-J', "-f${outFolder}/", '-r']
            ]
            if (args.projectProperties) {
                reqMap << [projectProperties: args.projectProperties]
            }
            if (args.globalProperties) {
                reqMap << [globalProperties: args.globalProperties]
            }
            def input = ""
            if(findFiles(glob: testFile.path.replace('.xml','.csv'))){
                input = readFile(file: testFile.path.replace('.xml','.csv'))
                input = input.replaceAll(/\n/,/\\\n/)
            }
            def outputFilePath = "${outFolder}/${testFile.name.replace('.xml','-out.csv')}"
            if(reqMap.globalProperties){
                reqMap.globalProperties.putAll([input: input, outputPath: outputFilePath])
            }else{
                reqMap << [globalProperties: [input: input, outputPath: outputFilePath]]
            }
            result = soapUITester.exec(reqMap)
            !CommonUtils.isNullOrEmpty(result.out) && echo("${result.out}")
            !CommonUtils.isNullOrEmpty(result.err) && echo("${result.err}")
            switch (result.returnCode) {
                case 200:
                    // incrementa il numero di successi
//                    resultTests.component.success += 1
                    echo "Test ${testFile.name} completed successfully"
                    break
                case 550:
                    failed = true
                    echo "Test ${testFile.name} failed"
                    testResult.addFailed(testFile.name)
                    break
                default:
                    echo "SoapUI server error"
                    break
            }
            testResult.setTestResult(testFile.name, result.testCases.total, result.testCases.success)
//            testResult.increaseTotal(result.testCases.total)
//            testResult.increaseSuccess(result.testCases.success)
        }
    } catch (Exception e) {
        Logger.error(this, [TEST: 'SoapUI', KIND: args.kind, EXCEPTION: e.getClass(), MESSAGE: e.getMessage(), STACKTRACE: e.getStackTrace()])
    }

    if (args.exportResult && args.ocpManager && !CommonUtils.isNullOrEmpty(args.podName)) {
        echo "Exporting ${args.kind} test results from ${args.podName} ..."
        def resultFolder = "${args.kind}-result/"
        sh """#!/bin/bash
            mkdir -p ${resultFolder}
        """
        args.ocpManager.rsync("${args.podName}:/tmp/results/", "${resultFolder}")
        testResult.setResultFolder(resultFolder)
        echo "Test results exported in ${resultFolder}"
    }

    return testResult

}
