import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.runners.ShRunner
import com.accenture.sec.utils.Colors

def call(def contextDir) {
    def ret = ['total': 0, 'success': 0, 'exception': false]

    timeout(5) {
        dir(contextDir) {
            echo("${Colors.Bash.BLUE}Unit Test${Colors.Bash.NC}")
            RunnerResult result = (new ShRunner(this)).execWithStatus([cmd: "npm run test-headless --if-present"])

            int failed = 0
            int success = 0
            def groups = (result.out =~ /(\d+) FAILED/)
            if (groups.size() > 0) {
                failed = groups[-1][1] as Integer
            }
            groups = (result.out =~ /(\d+) SUCCESS/)
            if (groups.size() > 0) {
                success = groups[-1][1] as Integer
            }
            ret.total = failed + success
            ret.success = success

            (result.exitCode != 0) && (ret.exception = true)
        }
    }
    return ret
}