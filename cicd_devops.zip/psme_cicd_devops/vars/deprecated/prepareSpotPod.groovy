package deprecated

def call(def openshift, def dcName, def templatePath="jrv_cicd_devops/templates/newman_template.yaml", def msProject=""){
  def pod = null
  // def dcName = "${msProject}-${podSpotName}-${microservice}"
  def dc = openshift.process("-f ${templatePath}","-p=NAME=${dcName}","-p=PROJECT=${msProject}")[0]
  def sel = openshift.selector("dc","${dcName}")
  if(!sel.exists()){
    openshift.create(dc)
    echo "Created dc/${dcName}"
  }else{
    def result = openshift.apply(dc)
    echo "Updated dc/${dcName}"
  }
  timeout(5) {
    openshift.selector("dc","${dcName}").scale("--replicas=1")
    def rollout = openshift.selector("dc", "${dcName}").rollout()
    rollout.status()
    openshift.selector("dc", "${dcName}").related('pods').untilEach(1) {
      return (it.object().status.phase == "Running")
    }
  }
  def pods = openshift.selector("dc","${dcName}").related('pods').objects()
  for(p in pods){
    if(p.status.phase == "Running"){
      pod = p.metadata.name
      break;
    }
  }
  return pod
}