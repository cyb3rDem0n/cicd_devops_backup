package deprecated

import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ManifestDAO
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dao.WaveDAO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.db.dto.ReleaseInfoDTO
import com.accenture.sec.db.dto.ManifestDTO
import com.accenture.sec.db.dto.WaveDTO
import com.accenture.sec.entities.IncreaseType
import com.accenture.sec.entities.Versioner
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args, List<ManifestInfoDTO> manifestList = []) {
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'env,dbInfo,wave,clusterType,changedMf')

    // Masking username & password
    args.dbInfo.username = null
    args.dbInfo.password = null

    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = initDBInfo(args)
    Connection connection = null
    def newVersion = null
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo("Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}")

        ManifestDAO manifestDAO = new ManifestDAO(connection)
        ManifestDTO manifestDTO
        ViewDAO viewDAO = new ViewDAO(connection)
        ReleaseDAO releaseDAO = new ReleaseDAO(connection)

        if(args.clusterType == 'test' || (args.clusterType == 'collaudo' && (args.changedMf!=null && args.changedMf==true))){
            if (CommonUtils.isNullOrEmpty(manifestList))
                return
            List<String> manifestVersions = viewDAO.getManifestVersionListByWave("${args.wave}")
            if(manifestVersions.isEmpty()){
                manifestVersions = ['v0']
            }
            String versionPattern = /v(\d+)/
            String versionFormat = /v%d/
            Versioner versioner = new Versioner(versionPattern, versionFormat)

            newVersion = versioner.nextVersion(manifestVersions, null, IncreaseType.MAJOR)
            if (newVersion == null){
                newVersion = "v1"
            }

            manifestList.each { info ->
                    echo ("""getManifestInfo("${args.wave}", "${info.microservice}", "${info.buildNum}") """)
                    ManifestInfoDTO manifestInfoDTO = viewDAO.getManifestInfo("${args.wave}", "${info.microservice}", "${info.buildNum}")
                    manifestDTO = new ManifestDTO()
                    manifestDTO.setIdBuild(manifestInfoDTO.getIdBuild())
                    manifestDTO.setVersion("${newVersion}")
                    manifestDTO = manifestDAO.insert(manifestDTO)
            }
        }

        if(args.clusterType != 'test'){
            ReleaseDTO releaseDTO = new ReleaseDTO()
            WaveDAO waveDAO = new WaveDAO(connection)
            WaveDTO waveDTO = waveDAO.getWaveByName("${args.wave}")

            if(args.clusterType=='collaudo' && (args.changedMf!=null && args.changedMf==true)){
                releaseDTO.setMfVersion(manifestDTO.getVersion())
            }
            else {
                releaseDTO.setMfVersion("${args.mfVersion}")
            }
            releaseDTO.setIdWave(waveDTO.getId())
            releaseDTO.setCurrEnv("${args.clusterType}")
            if(args.clusterType == 'prod'){
                releaseDTO.setVersion("${args.releaseNumber}")
            }
            echo("releaseDAO.insert: ${releaseDTO.toString()}")
            releaseDTO = releaseDAO.insert(releaseDTO)

            if (releaseDTO == null){
                error("""Release: "${args.releaseNumber}" errore durante l'inserimento nel database devops""")
            }
        }

    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
    return newVersion
}

private Map initDBInfo(Map args) {
    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = args.dbInfo as Map
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione

    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    return dbInfo
}
