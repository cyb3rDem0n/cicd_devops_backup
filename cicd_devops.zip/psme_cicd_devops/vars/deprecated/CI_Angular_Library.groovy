import com.accenture.sec.managers.NexusManager

def call(body) {
  // evaluate the body block, and collect configuration into the object
  def pipelineParams = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = pipelineParams
  body()

  def MICROSERVICE_NAME = null
  def CONTEXT_DIR = pipelineParams.CONTEXT_DIR

  env.targetProjectOCP = null
  env.CICDProjectOCP = null
  env.clusterOCP = null

  def webhook = null
  def packageInfo = null
  def packageVersion = null

  def resultTests = ['unit': ['total':0,'success':0], 'component': ['total':0,'success':0]]

  NexusManager nxMgr = null

  pipeline {
    agent {
      label 'nodejs'
    }

    options {
      disableConcurrentBuilds()
      timeout(time: 60, unit: 'MINUTES')
    }

    parameters {
      string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
    }


    stages {

      stage('Preliminary steps'){
        steps{
          script{
            ansiColor('xterm'){
              info = getInfo()
              config = loadEnvVariables(
                      "CI",
                      [
                              notificationMail: params.NOTIFICATION_MAIL,
                              releaseType     : "MICROSERVICE",
                              clusterType     : 'test'
                      ]
              )
              webhook = info.teamsChannelNotification.CI

              nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)

              env.nexusRepo = "${env.currentBranch}" == 'develop' ? config.nexus.library.npm.repository.snapshot : config.nexus.library.npm.repository.release

              packageInfo = readJSON file: "${CONTEXT_DIR}/package.json"
              packageVersion = "${packageInfo.version}"

              if("${env.currentBranch}" == "develop"){
                newVersion = "${packageVersion}-${env.shortCommitId}"
                sh """
                  cd "${WORKSPACE}/${CONTEXT_DIR}"
                  npm version ${newVersion}
                """
                packageVersion = newVersion
              }

              echo "Package name: ${packageInfo.name}"
              echo "Version: ${packageVersion}"

              // Prepare Slave
              sh """#!/bin/bash -e
                git config --global user.email "noreply@example.com"
                git config --global user.name "${env.gitUser}"

                npm i -g @angular/cli@6.2.7
              """
            }
          }
        }
      }

      stage('Build Library') {
        steps {
          script {
            ansiColor('xterm'){
              sh """#!/bin/bash -e
                cd ${WORKSPACE}/${CONTEXT_DIR}
                
                echo "\nDownloading dependencies...\n"
                echo "\u001B[34mnpm i\u001B[0m\n"
                npm i
                cat package.json

                echo "\nBuilding Library..."
                echo "\u001B[34m npm run build:ux:lib \u001B[0m\n"
                npm run build:ux:lib | tee build.log
                exit \${PIPESTATUS[0]}
              """
            }
          }
        }
      }

      stage('Static Tests (parallel)'){
        parallel{
          stage('Sonar Test') {
            when{expression{false}}
            steps {
              script {
                ansiColor('xterm'){
                  sonarTestWithMaven("${CONTEXT_DIR}","http://sonarqube:9000")
                }
              }
            }
          }
          stage('Unit Test') {
            when{expression{false}}
            steps {
              script {
                ansiColor('xterm'){
                  ret = unitTestKarma("${CONTEXT_DIR}")
                  resultTests.unit.total = ret.total
                  resultTests.unit.success = ret.success
                  if(ret.exception){
                    error("Unit test falliti")
                  }
                }
              }
            }
          }
        }
      }

      stage('Archive artifact') {
        steps {
          script {
            ansiColor('xterm'){
              fileName = sh (returnStdout: true, script: """#!/bin/bash -e
              tail -1 ${CONTEXT_DIR}/build.log
              """).trim()
              nxMgr.upload(env.nexusArtifactRepo, fileName)
            }
          }
        }
      }

    }

    post {
      always {
        deleteDir()
        script {
          env.JOB_NAME = env.JOB_NAME.replaceAll('%2F','/')
          mailMessages = [
            'SUCCESS':[
              'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
              'body':[
                'type': 'text/html',
                'msg': """
<p>Upload libreria ${packageInfo.name}:${packageVersion} su Nexus completata con successo</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]],
            'FAILURE':[
              'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
              'body':[
                'type': 'text/html',
                'msg': """
<p>Upload libreria ${packageInfo.name}:${packageVersion} su Nexus fallito</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]]]
            notifyMail(env.committerEmail, mailMessages, currentBuild.currentResult)
        }
      }
      success {
        script{
          if(env.currentBranch == 'master'){
            infoMap = ['Commit ID': env.commitId, 'Commit Message': env.commitMessage, 'Committer': env.committer, 'Library': "${packageInfo.name}:${packageVersion}", 'Nexus Repo': "${env.nexusRepo}", 'ACTIONS':[['name':'View Commit','url':"https://###bitbucket_url###/projects/###bitbucket_project###/repos/${env.msRepoName}/commits/${env.commitId}"]]]
            webhook.each{
              notifyTeams("Build Success", "Upload libreria ${packageInfo.name}:${packageVersion} su Nexus completata con successo", it, infoMap)
            }
          }
        }
      }
    }
  }

}
