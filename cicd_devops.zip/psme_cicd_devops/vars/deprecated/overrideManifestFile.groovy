package deprecated

def call(def credentialsId, def sourceManifest, def targetManifest){

  lock('devops_repo'){
    withCredentials([usernameColonPassword(credentialsId: credentialsId, variable: 'creds')]) {
      sh """
        mkdir -p tmp_repo
        git clone --depth 1 -b master https://${creds}@###bitbucket_url###/scm/###bitbucket_project###/jrv_cicd_devops.git tmp_repo/ && cd tmp_repo

        git config --global push.default simple

        rm -rf manifest/${targetManifest}
        cp -rf manifest/${sourceManifest} manifest/${targetManifest}

        git add manifest/${targetManifest}
      """
      code = sh (returnStatus: true, script: """
          cd tmp_repo
          git commit -m "Aggiornato ${targetManifest}"
        """)
      if(code == 0){
        sh """#!/bin/bash -e
          cd tmp_repo
          git push origin
        """
      } else {
        println('MANIFEST già aggiornato')
      }
    }
  }
  def manifest = readYaml file: "tmp_repo/manifest/${targetManifest}"
  sh """#!/bin/bash -e
    rm -rf tmp_repo
  """
  return manifest
}