package deprecated

def call(def credentialsId, def repoURL, def commit){
  repoURL = repoURL.replaceAll('https://','')
  withCredentials([usernameColonPassword(credentialsId: credentialsId, variable: 'creds')]) {
    repoURL = "https://${creds}@${repoURL}"
    sh """#!/bin/bash
      cd /tmp
      git clone ${repoURL} tmp_repo
    """
  }
  def branch = sh (returnStdout: true, script: "cd /tmp/tmp_repo && git branch --contains ${env.commitId} | grep \\* | sed 's/\\*[ ]*//'").trim()
  sh """
    cd /tmp/tmp_repo && git branch --contains ${env.commitId}
  """
  sh """#!/bin/bash
    cd ${WORKSPACE}
    rm -rf /tmp/tmp_repo
  """
  return branch
}