package deprecated

def call(def manifest){
  // crea readable manifest
  def tmp = manifest.clone()
  tmp.remove('version')
  tmp.each{
    v = it.value.version
    tmp[it.key] = v
  }
  writeYaml file: "readableManifest.yaml", data: tmp
  notificationManifest = readFile file: "readableManifest.yaml"
  return notificationManifest
}