package deprecated

import java.util.regex.Pattern

def call(def contextDir, def sonarURL, def sonarLOGIN, def sonarProjectKey){
    dir(contextDir){
        sh """#!/bin/bash -e
            echo "Sonar Test"
            echo "mvn sonar:sonar -Dsonar.projectKey=${sonarProjectKey} -Dsonar.host.url=${sonarURL} -DskipTests=true -Dsonar.login=${sonarLOGIN}"
            mvn sonar:sonar -Dsonar.projectKey=${sonarProjectKey} -Dsonar.projectName=${sonarProjectKey} -Dsonar.host.url=${sonarURL} -DskipTests=true -Dsonar.login=${sonarLOGIN}    
        """
        def report = readFile(file: 'target/sonar/report-task.txt')
        def taskUrl = getTaskUrl(report)
        if (taskUrl)
            env.sonarTaskUrl = taskUrl
    }

//    for(def key in report.tokenize('\n')){
//        if(key.tokenize('=')[0] == 'ceTaskUrl')
//            env.sonarTaskUrl = key.tokenize('=')[1]
//        else if(key.tokenize('=')[0] == 'ceTaskId')
//            env.sonarTaskId = key.tokenize('=')[1]
//    }
}

private String getTaskUrl(def report){
    def matcher = Pattern.compile(/ceTaskUrl=(https?:\/\/.+)/).matcher(report)
    if (matcher.size() > 0)
        return (matcher.group(1)).toString()
    return null
}