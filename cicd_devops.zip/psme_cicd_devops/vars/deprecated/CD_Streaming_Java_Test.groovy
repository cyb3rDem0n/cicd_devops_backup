package deprecated

import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.managers.Deployer
import com.accenture.sec.managers.NexusManager
import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.Manifest
import com.accenture.sec.utils.golive.GoLiveInfo
import com.accenture.sec.utils.golive.GoLiveList

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def pipelineParams = [:]
    def servicesURL = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    env.manifestFile = null
    env.chain = pipelineParams.TYPE

    env.clusterOCP = null
    env.targetProjectOCP = null

    def notificationManifest = null
    Manifest manifest = null
    List deployGroupsList = []

    def webhook = null
    def resultTests = ['e2e': ['selenium': ['total': 0, 'success': 0], 'postman': ['total': 0, 'success': 0]], 'noregr': ['selenium': ['total': 0, 'success': 0], 'postman': ['total': 0, 'success': 0]]]
    def failedTests = []
    def browsers = null
    def postmanData = null
    def config = null

    def stat = ['env': false, 'test': false]

    NexusManager nxMgr = null
    def doDeploy = true

    pipeline {
        agent {
            label 'cd-test-maven'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '3', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'WAVE', description: 'Define release number to be deployed')
            booleanParam(name: 'FORCE_REDEPLOY', defaultValue: false, description: 'If true force redeploy of all MS in manifest')
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
            //text(name: 'EXCLUSIONS', defaultValue: '', description: 'Microservices to exclude from CD process')
        }


        stages {

            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {
                            config = loadEnvVariables("CD", [
                                    step       : env.chain,
                                    releaseType: 'CONFLUENT',
                                    clusterType: 'dev']
                            )
                            env.e2eRepoURL = config.e2e_repo_url
                            webhook = config.teamsChannelNotification.CD['CONFLUENT'][env.chain]
                            //Da cambiare con nuova funzione di lettura
                            //env.manifestFile = config.manifest[env.chain]
                            browsers = config.selenium.browsers
                            nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)
                            if (CommonUtils.isNullOrEmpty(params.WAVE)) {
                                error("WAVE parameter is mandatory")
                            }
                            env.targetProjectOCP = "${env.targetProjectOCP}-${params.WAVE}"
                            // Niente test e2e per ora
                            // cloneRepo(env.gitUser, env.e2eRepoURL, 'master', [folder: 'e2eTests', shallow: true])
                            cloneRepo(config.svc.token.noprod.credsId, "${env.gitUrl}/scm/${config.svc.token.noprod.project}/${config.svc.token.noprod.repoName}.git", "master", [folder: 'tokens', shallow: true])

                            // Prepare Slave
                            // sh """#!/bin/bash -e
                            //   git config --global user.email "noreply@example.com"
                            //   git config --global user.name "${env.gitUser}"
                            //   npm i -g selenium-side-runner@3.5.9
                            // """
                            sh """#!/bin/bash -e
                git config --global user.email "noreply@example.com"
                git config --global user.name "${env.gitUser}"
              """
                            echo """
              ------------------------------------------------
              Path: ${env.chain}
              Release Selected: ${params.WAVE}
              Project: ${env.targetProjectOCP}
              ------------------------------------------------
              """
                        }
                    }
                }
            }

            stage('Process Manifest') {
                steps {
                    script {
                        ansiColor('xterm') {
                            //sostituire con nuova versione della lettura del manifest
                            //manifest = readYaml file: "manifest/${env.manifestFile}"
                            // SERVE PER LEGGERE IL FILE CONFIG.YAML
                            // Map<String, String> dbInfo = [:]
                            //DA USARE QUANDO SI LEGGE IL CONFIG.YAML
                            // dbInfo.putAll(config.manifest.db)

                            manifest = new Manifest(this)
                            manifest.init([version: "${params.WAVE}", dbInfo: config.manifest.db, env: "${env.targetProjectOCP}"])
                            manifest.getManifestListFromDb([projectPrefix: "${config.svc.project.toLowerCase()}"])

                            config.vm.dev.project = config.vm.project
                            config.vm.dev.appPrefix = config.vm.appPrefix
                            config.vm.dev.tokenfile = "${config.vm.project}-test-${params.WAVE}.yaml"

                            def filterMap = [
                                    dc: [labels: [app: config.ocp.filter.appLabel]]
                            ]
                            manifest.calculateCurrDeployManifestList([cluster: env.clusterOCP, project: env.targetProjectOCP], filterMap, config.vm?.dev as Map)
                            manifest.setForceRedeploy(params.FORCE_REDEPLOY)

//                            //Se il namespace e' vuoto lo imposto con quanto selezionato da db
//                            if(manifest.getNamespaceManifestInfo().isEmpty()){
//                                manifest.setCurrDeployManifestList(manifest.getManifestInfo())
//                            }
                            List fullManifest = Manifest.calculateFullDeployManifestList(manifest.getCurrDeployManifestList(), manifest.getNamespaceManifestInfo())
                            fullManifest.addAll(Manifest.calculateFullDeployManifestList(manifest.getCurrDeployManifestList(), manifest.getVmManifestInfo()))

                            deployGroupsList = Deployer.createDeployGroupList(manifest.toDeployableMap(fullManifest, [], false))
                            echo "Processing the following manifest:\n${Manifest.prettyPrint(manifest.getCurrDeployManifestList())}\n"
                            //notificationManifest = Manifest.prettyPrint(manifest.getCurrDeployManifestList(), true)
                            notificationManifest = Manifest.prettyPrint(manifest.getManifestInfo(), true)
                            doDeploy = manifest.getCurrDeployManifestList().size() > 0
                        }
                    }
                }
            }

            stage("Deploy in Test Env") {
                when { expression { doDeploy } }
                steps {
                    script {
                        ansiColor('xterm') {
                            List skipList = ["cb-streaming-replicatore"]
                            manifest.toDeployableMap(manifest.getCurrDeployManifestList(), skipList)
                            manifest.initDeployStatusMap()
                            def deployStages = Deployer.createDeployStages(this, nxMgr, deployGroupsList, config.vm.dev, servicesURL, [doMigration: false], manifest.getDeployableMap(), [deployStatus: manifest.getDeployStatus(), skipList: [], goLiveList: manifest.getGoLiveList(), force: params.FORCE_REDEPLOY])
                            //DEBUG
/*                            manifest.getCurrDeployManifestList().each{ ms ->
                                manifest.getDeployStatus().put(ms.microservice, true)
                                ((GoLiveList) manifest.getGoLiveList()).add(ms.microservice, ms.buildNum)
                            }
                            echo("deployStages:\n${deployStages}")
                            echo("manifest.getDeployStatus():\n${manifest.getDeployStatus()}")*/
                            //printGoLiveInfo(manifest?.getGoLiveList())
                            //END DEBUG
                            Deployer.executeDeploy(this, deployStages)
                            stat.deployed = true
                        }
                    }
                }
            }

        }

        post {
            always {
                deleteDir()
                script {
                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    boolean postException = false
                    def result = currentBuild.currentResult
                    if (failedTests.size() > 0 && stat.env)
                        result = 'UNSTABLE'

                    def failed = manifest?.getDeployStatus().findAll { it.value == false }?.keySet()
                    def notDeployed = manifest?.getDeployStatus().findAll { it.value == null }?.keySet()
                    def success = manifest?.getDeployStatus().findAll { it.value == true }?.keySet()
                    boolean deployedOcp = manifest.getManifestInfo().find{it.target == 'ocp'}.collect().size() > 0
                    boolean deployedVm = manifest.getManifestInfo().find{it.target == 'vm'}.collect().size() > 0
                    def newManifestVersion = null

                    try {
                        if (doDeploy) {
                            if (failed?.size() > 0) {
                                failed.each { entry ->
                                    ManifestInfoDTO manifestInfoDTO = manifest.getNamespaceManifestInfo().find { dto ->
                                        dto.microservice == entry
                                    }
                                    ManifestInfoDTO current = manifest.getCurrDeployManifestList().find { currEntry ->
                                        currEntry.microservice == entry
                                    }
                                    if (manifestInfoDTO != null) {
                                        current.setWave(manifestInfoDTO.getWave())
                                        current.setIdBuild(manifestInfoDTO.getIdBuild())
                                        current.setIdWave(manifestInfoDTO.getIdWave())
                                        current.setBuildNum(manifestInfoDTO.getBuildNum())
                                    }
                                }

                                notDeployed.each { entry ->
                                    ManifestInfoDTO manifestInfoDTO = manifest.getNamespaceManifestInfo().find { dto ->
                                        dto.microservice == entry
                                    }
                                    ManifestInfoDTO current = manifest.getManifestInfo().find { currEntry ->
                                        currEntry.microservice == entry
                                    }
                                    if (manifestInfoDTO != null) {
                                        current.setWave(manifestInfoDTO.getWave())
                                        current.setIdBuild(manifestInfoDTO.getIdBuild())
                                        current.setIdWave(manifestInfoDTO.getIdWave())
                                        current.setBuildNum(manifestInfoDTO.getBuildNum())
                                    }
                                }
                            }


                            newManifestVersion = insertNewManifest(
                                    [
                                            projectPrefix: "${config.svc.project.toLowerCase()}",
                                            dbInfo       : config.manifest.db,
                                            wave         : params.WAVE,
                                            clusterType  : 'test',
                                            changedMf    : false as Boolean
                                    ],
                                    manifest.getManifestInfo())
                            if(newManifestVersion){
                                echo("${Colors.Bash.GREEN}Created new manfiest version: ${Colors.Bash.BLUE}${newManifestVersion}${Colors.Bash.NC}")
                            }

                            if (success?.size() > 0) {
                                GoLiveList goLiveListVm = new GoLiveList(this)
                                for( GoLiveInfo goLiveInfo: manifest?.getGoLiveList().getGoLiveInfos()){
                                    for(ManifestInfoDTO dto: manifest?.getManifestInfo()){
                                        if(dto.microservice == goLiveInfo.microservice && dto.target=='vm')
                                            goLiveListVm.getGoLiveInfos().add(goLiveInfo)
                                    }
                                }

                                GoLiveList goLiveListOcp = new GoLiveList(this)
                                for( GoLiveInfo goLiveInfo: manifest?.getGoLiveList().getGoLiveInfos()){
                                    for(ManifestInfoDTO dto: manifest?.getManifestInfo()){
                                        if(dto.microservice == goLiveInfo.microservice && dto.target=='ocp')
                                            goLiveListOcp.getGoLiveInfos().add(goLiveInfo)
                                    }
                                }

                                /*
                                 TODO: Migliorare in Groovy Style e sostituire ai for precedenti al momento restituisce WARNING: error in post groovy.lang.MissingMethodException: No signature of method: java.util.ArrayList.toListMap() is applicable for argument types: () values: [] Possible solutions: toList(), asList()
                                 */
/*                                def goLiveListVm = manifest?.getGoLiveList().getGoLiveInfos().findAll { el->
                                    manifest?.getManifestInfo().find{ ms -> ms.microservice==el.microservice}.target=='vm'
                                }

                                def goLiveListOcp = manifest?.getGoLiveList().getGoLiveInfos().findAll { el->
                                    manifest?.getManifestInfo().find{ ms -> ms.microservice==el.microservice}.target=='ocp'
                                }*/


                                //DEBUG: printGoLiveInfo(goLiveListVm)

                                updateDBDeploy([
                                        env          : config.vm.dev.envname,
                                        projectPrefix: config.vm.project,
                                        dbInfo       : config.manifest.db,
                                        wave         : params.WAVE
                                ], goLiveListVm)

                                //DEBUG printGoLiveInfo(goLiveListOcp)
                                updateDBDeploy([
                                        env          : "${env.targetProjectOCP}",
                                        projectPrefix: "${config.svc.project.toLowerCase()}",
                                        dbInfo       : config.manifest.db,
                                        wave         : params.WAVE,
                                        logicEnv     : 'test'
                                ], goLiveListOcp)
                            }
                            printGoLiveInfo(manifest?.getGoLiveList())
                        }

                    } catch (Exception e) {
                        echo("${Colors.Bash.ORANGE}WARNING: error in post\n${e.toString()}${Colors.Bash.NC}")
                        postException = true
                        if (result != 'FAILURE')
                            result = 'UNSTABLE'
                    }


                    def manifestTitle = env.chain == 'FIX' ? 'HotFix Manifest' : 'Release Candidate Manifest'
                    def mailMessages = [
                            'SUCCESS' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : '']],
                            'FAILURE' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : '']],
                            'UNSTABLE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] instabile",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : '' ]]]

                    if(deployedOcp){
                        mailMessages.SUCCESS.body.msg += """
<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """
                        mailMessages.FAILURE.body.msg += """
<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} fallito</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """
                        mailMessages.UNSTABLE.body.msg += """
<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo ma test automatizzati falliti</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """
                    }

                    if(deployedVm){
                        mailMessages.SUCCESS.body.msg += """
<p>Deploy ambiente ${config.vm.dev.envname} da ${manifestTitle} effettuato con successo</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """
                        mailMessages.FAILURE.body.msg += """
<p>Deploy ambiente ${config.vm.dev.envname} da ${manifestTitle} fallito</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """
                        mailMessages.UNSTABLE.body.msg += """
<p>Deploy ambiente ${config.vm.dev.envname} da ${manifestTitle} effettuato con successo ma test automatizzati falliti</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """
                    }

                    // Invio della mail solo se è stato deployato qualcosa (se la diff ha trovato differenze da deployare)
                    if (doDeploy) {
                        notifyMail("${NOTIFICATION_MAIL}", mailMessages, result)
                    }
                    def chainPath = env.chain == 'FIX' ? 'HotFix Path' : 'Release Path'

                    def user
                    wrap([$class: 'BuildUser']) {
                        user = env.BUILD_USER
                        if (CommonUtils.isNullOrEmpty(user))
                            user = "Scheduler"
                    }

                    def teamsMessages = ['SUCCESS' : "",
                                        'FAILURE' : "",
                                        'UNSTABLE': ""]
                    if (doDeploy) {
                        if(deployedOcp){
                            teamsMessages.SUCCESS += "<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo<p>"
                            teamsMessages.FAILURE += "<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} fallito<p>"
                            teamsMessages.UNSTABLE += "<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo ma test automatizzati falliti<p>"
                            postException && teamsMessages.put('UNSTABLE', "Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo ma fallito allineamento manifest su DB interno.")
                        }
                        if(deployedVm){
                            teamsMessages.SUCCESS += "Deploy ambiente ${config.vm.dev.envname} da ${manifestTitle} effettuato con successo"
                            teamsMessages.FAILURE += "Deploy ambiente ${config.vm.dev.envname} da ${manifestTitle} fallito"
                            teamsMessages.UNSTABLE += "Deploy ambiente ${config.vm.dev.envname} da ${manifestTitle} effettuato con successo ma test automatizzati falliti"
                            postException && teamsMessages.put('UNSTABLE', "Deploy ambiente ${config.vm.dev.envname} da ${manifestTitle} effettuato con successo ma fallito allineamento manifest su DB interno.")
                        }
                    } else {
                        if(deployedOcp){
                            teamsMessages.SUCCESS += "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}."
                            teamsMessages.FAILURE += "Errore nella pipeline"
                            teamsMessages.UNSTABLE += "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}. Test automatizzati falliti"
                            postException && teamsMessages.put('UNSTABLE', "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}. Errore nelle post-operazioni della pipeline")
                        }
                        if(deployedVm){
                            teamsMessages.SUCCESS += "Nessuna modifica per ${manifestTitle} in ambiente ${config.vm.dev.envname}."
                            teamsMessages.FAILURE += "Errore nella pipeline"
                            teamsMessages.UNSTABLE += "Nessuna modifica per ${manifestTitle} in ambiente ${config.vm.dev.envname}. Test automatizzati falliti"
                            postException && teamsMessages.put('UNSTABLE', "Nessuna modifica per ${manifestTitle} in ambiente ${config.vm.dev.envname}. Errore nelle post-operazioni della pipeline")
                        }
                    }

                    def infoMap = ['Triggered by'    : "${user}",
                                   'Path'            : "${chainPath}",
                                   'Project'         : "",
                                   'Manifest Version': (!notificationManifest ? 'NA' : (newManifestVersion ?: 'Stessa del precedente deploy')),
                                   'Wave'            : "${params.WAVE}",
                                   'SECTIONS'        : [],
                                   'ACTIONS'         : []
                                   ]

                   if(deployedOcp){
                        infoMap.Project+= "${env.targetProjectOCP}"
                        infoMap.ACTIONS.add(['name': 'View Environment', 'url': "https://openshift.dv.seccloud.internal:8443/console/project/${env.targetProjectOCP}/browse/deployments"])
                    }
                    if(deployedVm){
                        infoMap.Project+= infoMap.Project=="" ? "${config.vm.dev.envname}" : " / ${config.vm.dev.envname}"
                    }
                    if (doDeploy) {
                        if (success) {
                            infoMap['SECTIONS'].add(['activityTitle': "Deployed services", 'activityText': "<pre>${Manifest.prettyPrint(manifest?.getCurrDeployManifestList()?.findAll { it.microservice in success }, true)}</pre>", "markdown": false])
                        }
                        (failed) && infoMap.put('Failed deploy', "${failed}")
                        (notDeployed) && infoMap.put('Not deployed', "${notDeployed}")
                    }
                    if (notificationManifest)
                        infoMap['SECTIONS'].add(['activityTitle': "Richiesto deploy del seguente ${manifestTitle}", 'activityText': "<pre>${notificationManifest}</pre>", "markdown": false])

                    if (failedTests.size() > 0)
                        infoMap.put('Failed tests', "${failedTests}")

                    if (doDeploy) {
                        webhook.each {
                            notifyTeams(result, teamsMessages, it, infoMap)
                        }
                    }
                }
            }
        }

    }
}