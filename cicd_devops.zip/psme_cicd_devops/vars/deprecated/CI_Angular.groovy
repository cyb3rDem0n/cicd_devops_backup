import com.accenture.sec.managers.NexusManager

def call(body) {
  // evaluate the body block, and collect configuration into the object
  def pipelineParams = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = pipelineParams
  body()

  def MICROSERVICE_NAME = pipelineParams.MICROSERVICE_NAME
  def CONTEXT_DIR = pipelineParams.CONTEXT_DIR
  def SOURCE_IMAGE = pipelineParams.SOURCE_IMAGE ? pipelineParams.SOURCE_IMAGE : "openshift/httpd:2.4"

  env.targetProjectOCP = null
  env.CICDProjectOCP = null
  env.clusterOCP = null

  def webhook = null
  def resultTests = ['unit': ['total':0,'success':0], 'component': ['total':0,'success':0]]
  def failedTests = []
  def browsers = null
  def config = null
  
  def stat = [deployed: false, tested: false]

  NexusManager nxMgr = null

  pipeline {
    agent {
      label 'nodejs'
    }

    options {
      disableConcurrentBuilds()
      timeout(time: 60, unit: 'MINUTES')
    }

    parameters {
      string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
    }


    stages {

      stage('Preliminary steps'){
        steps{
          script{
            ansiColor('xterm') {
              info = getInfo()
              config = loadEnvVariables(
                      "CI",
                      [
                              microservice    : MICROSERVICE_NAME,
                              notificationMail: params.NOTIFICATION_MAIL,
                              releaseType     : "MICROSERVICE",
                              clusterType     : 'test'
                      ]
              )
              webhook = info.teamsChannelNotification.CI
              browsers = config.selenium.browsers

              nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)

              // Prepare Slave
              sh """#!/bin/bash -e
                git config --global user.email "noreply@example.com"
                git config --global user.name "${env.gitUser}"

                npm i -g @angular/cli@6.2.7 selenium-side-runner@3.5.9
              """
            }
          }
        }
      }

      stage('Build App') {
        steps {
          script {
            ansiColor('xterm') {
              buildAngular("${CONTEXT_DIR}")
            }
          }
        }
      }

      stage('Static Tests (parallel)'){
        parallel{
          stage('Sonar Test') {
            when{expression{false}}
            steps {
              script {
                ansiColor('xterm'){
                  sonarTestWithMaven("${CONTEXT_DIR}","http://sonarqube:9000")
                }
              }
            }
          }
          stage('Unit Test') {
            steps {
              script {
                ansiColor('xterm'){
                  ret = unitTestKarma("${CONTEXT_DIR}")
                  resultTests.unit.total = ret.total
                  resultTests.unit.success = ret.success
                  if(ret.exception){
                    error("Unit test falliti")
                  }
                }
              }
            }
          }
        }
      }

      stage('Build Image') {
        steps {
          script {
            ansiColor('xterm'){
              sh """
                # shopt -s dotglob nullglob
                rm -rf ${WORKSPACE}/oc-build
                mv ${WORKSPACE}/${CONTEXT_DIR}/dist/jarvis-application ${WORKSPACE}/oc-build
                mv ${WORKSPACE}/${CONTEXT_DIR}/.htaccess ${WORKSPACE}/oc-build/
              """
              openshift.withCluster(env.clusterOCP) {
                openshift.withProject(env.CICDProjectOCP) {
                  buildImage(openshift, "${MICROSERVICE_NAME}", "${SOURCE_IMAGE}", env.buildTag)
                }
              }
              tagRepository(env.gitUser, env.msRepoURL, env.commitId, env.buildTag)
            }
          }
        }
      }

      stage('Archive artifact') {
        steps {
          script {
            ansiColor('xterm'){
              filePath = createArtifact("${CONTEXT_DIR}", 'package', "${MICROSERVICE_NAME}", env.buildTag)
              map = [
                'groupId': "${env.nexusArtifactGroupId}", 
                'artifactId': "${MICROSERVICE_NAME}", 
                'packageVersion': env.buildTag, 
                'packaging': 'zip']
              nxMgr.upload(env.nexusArtifactRepo, filePath, map)
            }
          }
        }
      }

      stage('Replace tokens'){
        steps{
          script{
            ansiColor('xterm'){
              def replaceTokensMap = [
                      path         : "deployment/templates/",
                      tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${env.targetProjectOCP}.yaml",
                      microservice : MICROSERVICE_NAME
              ]
              replaceTokens(replaceTokensMap)
            }
          }
        }
      }

      stage('Deploy DB Changes'){
        when {
          expression {
            return findFiles(glob: "deployment/database/V*__*.sql").size() > 0
          }
        }
        steps{
          script{
            ansiColor('xterm'){
              dbMigration('flyway', [
                      migrationFolder: "deployment",
                      tokenFilePath  : "tokens/${env.targetProjectOCP}.yaml",
                      msName         : MICROSERVICE_NAME,
                      clean          : false
              ])
            }
          }
        }
      }

      stage('Deploy App'){
        steps{
          script{
            ansiColor('xterm'){
              openshift.withCluster(env.clusterOCP) {
                openshift.withProject(env.targetProjectOCP) {
                  env.service_url = deployApp(openshift, "${MICROSERVICE_NAME}", env.buildTag)
                  stat.deployed = true
                }
              }
            }
          }
        }
      }

      stage('Smoke&Component Test'){
        when {
          expression {
            return (
              findFiles(glob: "jrv_cicd_devops/smoketest/*.side").size() > 0 
              || 
              findFiles(glob: "tests/component/*.side").size() > 0)
          }
        }
        steps{
          script{
            ansiColor('xterm'){
              def parallelStages = [:]
              def testList = null
              
              sh """#!/bin/bash
                rm -rf ${WORKSPACE}/side/ && mkdir -p ${WORKSPACE}/side/
              """
              ['firefox'].each{
                def browser = it
                parallelStages["${browser}"] = {
                  stage("Smoke test on ${browser} Node"){
                    def dcName = config.selenium.get(browser).dcName
                    def browserMap = config.selenium.get(browser)
                    def configFile = prepareSideConfigFile(browser, env.seleniumServer, env.service_url, browserMap)
                    try{
                      sh """#!/bin/bash -e
                        mkdir -p ${WORKSPACE}/side/${browser}
                        cp ${WORKSPACE}/jrv_cicd_devops/smoketest/*.side ${WORKSPACE}/side/${browser}/
                      """
                      scalePod(openshift, dcName, 1)
                      waitSeleniumNodeToBeReady(openshift, [dc: dcName, check: 'The node is registered to the hub and ready to use'], [dc: "selenium-hub", check: "Selenium Grid hub is up and running"])
                      testList = findFiles(glob: "side/${browser}/*.side")
                      testList.each{ testFile ->
                        def status = sh (returnStatus: true, script: """#!/bin/bash -e
                          cd ${WORKSPACE}/side/${browser}
                          selenium-side-runner ${testFile.name} --config-file ${configFile}
                        """)
                        if(status != 0){
                          error("${testFile.name} failed")
                        }
                      }                     
                    } catch(Exception e) {
                      throw e
                    } finally {
                      scalePod(openshift, dcName, 0)
                    }
                  }
                }
              }

              if(findFiles(glob: "jrv_cicd_devops/smoketest/*.side").size() > 0){
                lock('Selenium'){
                  openshift.withCluster() {
                    openshift.withProject('jarvis-1389-cicd') {
                      echo "Running smoke test on: ${env.service_url}"
                      parallel parallelStages
                    }
                  }
                }
              }else{
                echo "No smoke test"
              }

              sh """#!/bin/bash
                rm -rf ${WORKSPACE}/side/ && mkdir -p ${WORKSPACE}/side/
              """
              browsers.each{
                def browser = it
                parallelStages["${browser}"] = {
                  stage("Component test on ${browser} Node"){
                    def dcName = config.selenium.get(browser).dcName
                    def browserMap = config.selenium.get(browser)
                    def configFile = prepareSideConfigFile(browser, env.seleniumServer, env.host, browserMap)
                    try{
                      sh """#!/bin/bash -e
                        mkdir -p ${WORKSPACE}/side/${browser}
                        cp ${WORKSPACE}/tests/component/*.side ${WORKSPACE}/side/${browser}/
                      """
                      testList = findFiles(glob: "side/${browser}/*.side")
                      resultTests.component.total += testList.size()
                      scalePod(openshift, dcName, 1)
                      waitSeleniumNodeToBeReady(openshift, [dc: dcName, check: 'The node is registered to the hub and ready to use'], [dc: "selenium-hub", check: "Selenium Grid hub is up and running"])
                      def failed = false
                      testList.each{ testFile ->
                        def status = sh (returnStatus: true, script: """#!/bin/bash -e
                          cd ${WORKSPACE}/side/${browser}
                          selenium-side-runner ${testFile.name} --config-file ${configFile}
                        """)
                        if(status != 0){
                          failed = true
                          failedTests.add("component--${browser}--${testFile.name}")
                        }else {
                          resultTests.component.success += 1
                        }
                      }
                      if(failed)
                        error("Alcuni component tests sono falliti")
                    } catch(Exception e) {
                      throw e
                    }
                  }
                }
              }

              if(findFiles(glob: "tests/component/*.side").size() > 0){
                lock('Selenium'){
                  openshift.withCluster() {
                    openshift.withProject('jarvis-1389-cicd') {
                      echo "Running component tests on: ${env.host}"
                      try{
                        parallel parallelStages
                      } catch (Exception e){
                        error("${e.getMessage()}\n${failedTests}")
                      } finally {
                        browsers.each{ browser ->
                          scalePod(openshift, config.selenium.get(browser).dcName, 0)
                        }
                      }
                    }
                  }
                }
              }else{
                echo "No component tests"
              }
              
            }
          }
        }
      }

    }

    post {
      always {
        deleteDir()
        script {
          env.JOB_NAME = env.JOB_NAME.replaceAll('%2F','/')
          result = currentBuild.currentResult
          if(failedTests.size() > 0 && stat.deployed)
            result = 'UNSTABLE'
          mailMessages = [
            'SUCCESS':[
              'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
              'body':[
                'type': 'text/html',
                'msg': """
<p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]],
            'FAILURE':[
              'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
              'body':[
                'type': 'text/html',
                'msg': """
<p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} fallito in ambiente ${env.targetProjectOCP}</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]],
            'UNSTABLE':[
              'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] instabile",
              'body':[
                'type': 'text/html',
                'msg': """
<p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP} ma alcuni test sono falliti</p>
<p>${failedTests}</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]]]
            notifyMail(env.committerEmail, mailMessages, result)

            teamsMessages = [
              'SUCCESS': "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}",
              'FAILURE': "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} fallito in ambiente ${env.targetProjectOCP}",
              'UNSTABLE': "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}\n\nAlcuni test sono falliti"]

            infoMap = ['Commit ID': env.commitId, 'Commit Message': env.commitMessage, 'Committer': env.committer, 'Path': "${env.chainPath}", 'Project': "${env.targetProjectOCP}", 'Microservice': "${MICROSERVICE_NAME}", 'Unit Test': "${resultTests.unit.success}/${resultTests.unit.total}", 'Component Test': "${resultTests.component.success}/${resultTests.component.total}", 'SUCCESS': ['Version Tag': "${env.buildTag}"], 'ACTIONS':[['name':'View Commit','url':"https://###bitbucket_url###/projects/###bitbucket_project###/repos/${env.msRepoName}/commits/${env.commitId}"]]]
            if(failedTests.size() > 0)
              infoMap.put('Failed tests',"${failedTests}")
            webhook.each{
              notifyTeams(result, teamsMessages, it, infoMap)
            }
        }
      }
    }
  }

}