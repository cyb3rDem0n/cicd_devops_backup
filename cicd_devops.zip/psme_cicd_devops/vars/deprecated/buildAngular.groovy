def call(def contextDir){
  sh """#!/bin/bash -e
    cd ${WORKSPACE}/${contextDir}
    echo "\nDownloading dependencies...\n"
    echo "\u001B[34mnpm i\u001B[0m\n"
    npm i
    cat package.json
    echo "\nBuilding App...\n"
    echo "\u001B[34mng build --prod\u001B[0m\n"
    ng build --prod
  """
}