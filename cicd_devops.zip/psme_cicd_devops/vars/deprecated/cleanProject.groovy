def call(def openshift, def filterLabel){
  println("Cleanup ${openshift.project()}")
  println("Deleting all resources with ${filterLabel}...")
  def ret = openshift.delete("all", "-l ${filterLabel}", "--ignore-not-found=true")
  print(ret.out)

  def secrets = openshift.selector("secret")
  if(secrets.count() > 0){
    println("Deleting all secrets starts with jrv...")
    secrets.withEach {
      if(it.name() ==~ /^secrets\/jrv\..*$/){
        print(it.delete().out)
      }
    }
  }

}