package deprecated

import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.db.dto.ReleaseStatusDTO
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args){
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args,'releaseNumber,releaseType,newReleaseStatus,dbInfo')
    Map<String, String> dbInfo = [:]
    dbInfo.putAll(args.dbInfo)
    CommonUtils.checkInputParameters(dbInfo,'type,host,database,credsId')

    echo("Updating release")
    Connection connection = null

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione
    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo "Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}"

        // Definisco i DAO per le operazioni sul db
        ReleaseDAO releaseDAO = new ReleaseDAO(connection)

        // Recupero la release e controllo che esista
        ReleaseDTO release = releaseDAO.getFromReleaseNumber(args.releaseNumber as String, args.releaseType as String)
        if(release == null)
            throw new Exception("No manifest available for ${args.releaseNumber}")

        // Controllo se lo stato della release è già aggiornato
        if(release.getStatus().getStatus() == args.newReleaseStatus){
            echo("Selected release has already status '${args.newReleaseStatus}'")
            return
        }
        echo("Selected release -> ${release.toString()}")

        // Aggiorno lo stato della release
        release.getStatus().updateFromEnum(ReleaseStatusDTO.ReleaseStatus.fromStatus(args.newReleaseStatus as String))
        releaseDAO.update(release)

    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
}