package deprecated

def call(def contextDir, def packagePath, def packageName, def packageVersion) {

    sh """#!/bin/bash -e
    cd ${WORKSPACE}
    mkdir -p ${packagePath}
    cp -r deployment/ tests/ ${packagePath}
    echo "${packageVersion}" > ${packagePath}/IMAGE_TAG
    if [[ -f ${WORKSPACE}/${contextDir}/pom.xml ]]; then
      cp -r ${WORKSPACE}/${contextDir}/pom.xml ${packagePath}/
    fi
    cp info.yaml ${packagePath}/
    cp -r ${WORKSPACE}/${contextDir}/target/*.jar ${packagePath}/
    cd ${packagePath}
    zip -r ${packageName}.zip *
  """
    return "${WORKSPACE}/${packagePath}/${packageName}.zip"
}