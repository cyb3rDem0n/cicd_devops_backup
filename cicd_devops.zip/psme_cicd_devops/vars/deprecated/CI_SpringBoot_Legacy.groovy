import com.accenture.sec.managers.NexusManager
import com.accenture.sec.managers.OpenshiftAdminManager
import com.accenture.sec.testers.SoapUIRestTester
import com.accenture.sec.utils.CommonUtils

def call(body) {
    // evaluate the body block, and collect configuration into the object , elabora gli attributi definiti all'interno del jenkinsfile presente nel repo con il codice applicativo
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def MICROSERVICE_NAME = pipelineParams.MICROSERVICE_NAME
    def CONTEXT_DIR = pipelineParams.CONTEXT_DIR
    def SOURCE_IMAGE = pipelineParams.SOURCE_IMAGE ? pipelineParams.SOURCE_IMAGE : "openjdk-11-rhel7:latest"
    def YAML_FILE = "config.yaml"


    env.targetProjectOCP = null
    env.CICDProjectOCP = null
    env.clusterOCP = null



    def webhook = null
    def resultTests = ['unit': ['total': 0, 'success': 0], 'component': ['total': 0, 'success': 0]]
    def failedTests = []
    def stat = [deployed: false, tested: false]
    def config = null
    def info = null

    NexusManager nxMgr = null

    pipeline {
        /* agent any*/
        agent
                {
                    label 'maven'
                }

        /*tools {
            maven 'Maven3.6.1'
            jdk 'JDK8'
        }*/
        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '15', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }

        stages {

            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {
                            info = getInfo()
                            config = loadEnvVariables(
                                    "CI",
                                    [
                                            microservice    : MICROSERVICE_NAME,
                                            notificationMail: params.NOTIFICATION_MAIL,
                                            releaseType     : "MICROSERVICE",
                                            clusterType     : 'test'
                                    ]
                            )
                            webhook = info.teamsChannelNotification.CI

                            nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)

                            // Prepare Slave
                            sh """#!/bin/bash -e
                git config --global user.email "noreply@example.com"
                git config --global user.name "${env.gitUser}"
              """
                        }
                    }
                }
            }

            stage('Build App') {
                steps {
                    script {
                        ansiColor('xterm') {
                            buildMaven("${CONTEXT_DIR}")
                        }
                    }
                }
            }

            stage('Unit Test') {
                steps {
                    script {
                        ansiColor('xterm') {
                            def ret = unitTestMaven("${CONTEXT_DIR}")
                            resultTests.unit.total = ret.total
                            resultTests.unit.success = ret.success
                            if (ret.exception) {
                                error("Unit test falliti")
                            }
                        }
                    }
                }
            }

            stage('Sonar Test') {
                when { expression { !(env.isFeature.toBoolean()) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            sonarTestWithMaven("${CONTEXT_DIR}", env.sonarURL, info.sonarqube.login_id, info.sonarqube.project_key)
                        }
                    }
                }
            }


            stage('Build Image') {
                when { expression { !(env.isFeature.toBoolean()) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            sh """                    
                      rm -rf ${WORKSPACE}/oc-build && mkdir -p ${WORKSPACE}/oc-build/deployments
                      mv ${WORKSPACE}/${CONTEXT_DIR}/target/*.[wj]ar ${WORKSPACE}/oc-build/deployments/
                    """
                            openshift.withCluster(env.clusterOCP) {
                                openshift.withProject(env.CICDProjectOCP) {
                                    //openshift.logLevel(9)
                                    buildImage(openshift, "${MICROSERVICE_NAME}", "${SOURCE_IMAGE}", env.buildTag, ['binary': true, 'from_dir': true, 'dir': 'oc-build'])
                                }
                            }
                            tagRepository(env.gitUser, env.msRepoURL, env.commitId, env.buildTag)
                        }
                    }
                }
            }

            stage('Archive artifact') {
                when { expression { !(env.isFeature.toBoolean()) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            filePath = createArtifact("${CONTEXT_DIR}", 'package', "${MICROSERVICE_NAME}", env.buildTag)
                            map = [
                                    'groupId'       : "${env.nexusArtifactGroupId}",
                                    'artifactId'    : "${MICROSERVICE_NAME}",
                                    'packageVersion': env.buildTag,
                                    'packaging'     : 'zip']
                            nxMgr.upload(env.nexusArtifactRepo, filePath, map)
                        }
                    }
                }
            }

            stage('Replace tokens') {
                when { expression { !(env.isFeature.toBoolean()) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            def replaceTokensMap = [
                                    path         : "deployment/templates/",
                                    tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${env.targetProjectOCP}.yaml",
                                    microservice : MICROSERVICE_NAME
                            ]
                            replaceTokens(replaceTokensMap)
                        }
                    }
                }
            }


            stage('Deploy App') {
                when { expression { !(env.isFeature.toBoolean()) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            openshift.withCluster(env.clusterOCP) {

                                openshift.withProject(env.targetProjectOCP) {
                                    env.service_url = deployApp(openshift, "${MICROSERVICE_NAME}", env.buildTag)
                                    //env.service_url = openshift.process("-f ${templatesPath}/${MICROSERVICE_NAME}_template.yaml","-p=IMAGE_TAG=${version}")
                                    stat.deployed = true
                                }
                            }
                        }
                    }
                }
            }

            stage('Service Tests') {
                when {
                    expression {
                        return (!(env.isFeature.toBoolean())
                                &&
                                findFiles(glob: "tests/component/*.xml").size() > 0
                        )
                    }
                }
                steps{
                    script{
                        ansiColor('xterm'){

                            OpenshiftAdminManager ocpAdmMng = new OpenshiftAdminManager(this)

                            echo "Preparing ondemand pod for service tests"
                            /**
                             * Il pod viene creato nel namespace target
                             * che viene creato ondemand al run di questa pipeline
                             */
//                            def testToolNamespace = env.CICDProjectOCP
                            def testToolNamespace = env.targetProjectOCP

//                            def dcName = "${env.targetProjectOCP}-soapui-${MICROSERVICE_NAME}"
                            def dcName = "soapui"
                            openshift.withCluster(env.clusterOCP) {
                                openshift.withProject(testToolNamespace) {
                                    def resources = ocpAdmMng.createOndemandPod('cicd_devops/templates/soapui_template.yaml',[parameters:[
                                            NAME: dcName,
                                            PROJECT: env.targetProjectOCP
                                    ]])
                                    // def testResultFiles = []
                                    def testList = findFiles(glob: "tests/component/*.xml")

                                    // conta i file come singoli test
//                                    resultTests.component.total += testList.size()
                                    def failed = false
                                    Map result
                                    SoapUIRestTester soapUITester = new SoapUIRestTester(this)
                                    try{
                                        testList.each{ testFile ->
                                            def reqMap = [
                                                    url: "http://${dcName}.${testToolNamespace}.svc.cluster.local:3000/",
                                                    projectFile: "${testFile.path}",
                                                    options: ['-A','-r']
                                            ]
                                            result = soapUITester.exec(reqMap)
                                            switch (result.returnCode){
                                                case 200:
                                                    // incrementa il numero di successi
//                                                    resultTests.component.success += 1
                                                    break
                                                case 550:
                                                    failed = true
                                                    failedTests.add("service--${testFile.name}")
                                                    break
                                                default:
                                                    echo "SoapUI server error"
                                                    break
                                            }
                                            resultTests.component.total += result.testCases.total
                                            resultTests.component.success += result.testCases.success
                                            echo "${result.out}"
                                            echo "${result.err}"
                                        }
                                        if(failed)
                                            error("Alcuni service test sono falliti")
                                    }catch (Exception e){
                                        error("${e.getMessage()}\n${failedTests}")
                                    }finally{
                                        ocpAdmMng.scalePod(dcName, 0)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            /*stage('Smoke&Component Tests'){
              when {
                expression {
                  return (
                    !(env.isFeature.toBoolean())
                    &&
                    (findFiles(glob: "cicd_devops/smoketest/springboot*.json").size() > 0
                    ||
                    findFiles(glob: "tests/component/*.json").size() > 0))
                }
              }
              steps{
                script{
                  ansiColor('xterm'){
                    echo "\nPreparing test pod"
                    def componentTestResultFile = null
                    def smokeTestResultFile = null

                    def dcName = "${env.targetProjectOCP}-newman-${MICROSERVICE_NAME}"
                    openshift.withCluster(env.clusterOCP) {
                      openshift.withProject(env.CICDProjectOCP) {
                        def pod = prepareSpotPod(openshift, dcName, 'jrv_cicd_devops/templates/newman_template.yaml', env.targetProjectOCP)

                        echo "\nRunning tests on ${pod}"
                        try{
                          map = [
                            'testsFolder': "${WORKSPACE}/jrv_cicd_devops/smoketest",
                            'testFilter': "springboot*.json",
                            'testParameters': [['url': "${env.service_url}"]]
                          ]
                          smokeTestResultFile = runNewmanTestOnPod(openshift, pod, 'Smoke Test', map)

                          def testResultFiles = []
                          testList = findFiles(glob: "tests/component/*.json")
                          if(testList.size() > 0){
                            resultTests.component.total += testList.size()
                            def failed = false
                            testList.each{ testFile ->
                              map = [
                                'testsFolder': "${WORKSPACE}/tests/component",
                                'testFilter': "${testFile.name}",
                                'testParameters': [['url': "${env.service_url}"]]
                              ]
                              try{
                                res = runNewmanTestOnPod(openshift, pod, 'Component Test', map)
                                resultTests.component.success += 1
                                testResultFiles.add(res)
                              }catch (Exception ex){
                                println(ex)
                                failed = true
                                failedTests.add("component--${testFile.name}")
                              }
                            }
                            if(failed)
                              error("Alcuni component test sono falliti")
                          }else{
                            echo "No component tests"
                          }
                        } catch(Exception e) {
                          error("${e.getMessage()}\n${failedTests}")
                        } finally {
                          scalePod(openshift, dcName, 0)
                        }
                      }
                    }
                    // if(smokeTestResultFile){
                    //   step([$class: 'JUnitResultArchiver', testResults: smokeTestResultFile])
                    // }
                    // if(componentTestResultFile){
                    //   step([$class: 'JUnitResultArchiver', testResults: componentTestResultFile"])
                    // }
                  }
                }
              }
            }*/


            stage('Update Manifest') {
                when { expression { return (!(env.isFeature.toBoolean()) && !CommonUtils.isNullOrEmpty(env.releaseNumber)) } }
                steps {
                    script {
                        echo("Updating '${env.releaseNumber}' manifest for ${MICROSERVICE_NAME}")
                        Map<String, String> dbInfo = [:]
                        dbInfo.putAll(config.manifest.db)
                        boolean skipUpdate = false
                        if (fileExists("${CONTEXT_DIR}/pom.xml")) {
                            echo("Checking version of dependencies in pom . . .")
                            def pom = readMavenPom file: "${CONTEXT_DIR}/pom.xml"
                            pom.getDependencies().each { dep ->
                                if (dep.version && dep.version ==~ /.*SNAPSHOT/) {
                                    echo("${MICROSERVICE_NAME}:${env.buildTag} was builded with 'SNAPSHOT' dependencies\n${dep}")
                                    skipUpdate = true
                                    return
                                }
                            }
                        }
                        if (!skipUpdate)
                            updateDBManifest(releaseNumber: env.releaseNumber,
                                    releaseType: 'MICROSERVICE',
                                    permittedReleaseStatus: ['RC', 'RF'],
                                    msName: MICROSERVICE_NAME,
                                    msVersion: env.buildTag,
                                    msDeps: (info.dependencies ?: info.dependences),
                                    dbInfo: dbInfo)
                    }
                }
            }

        }

        post {
            always {
                deleteDir()
                script {
                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    def result = currentBuild.currentResult
                    if (failedTests.size() > 0 && stat.deployed)
                        result = 'UNSTABLE'
                    def mailMessages = [
                            'SUCCESS' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]],
                            'FAILURE' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} fallito in ambiente ${env.targetProjectOCP}</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]],
                            'UNSTABLE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] instabile",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} completato con successo in ambiente ${env.targetProjectOCP} ma alcuni test sono falliti</p>
       <p>${failedTests}</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]]]
                    if (!(env.isFeature.toBoolean()) || result != 'SUCCESS')
                        notifyMail(env.committerEmail, mailMessages, result)

                    def teamsMessages = [
                            'SUCCESS' : "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}",
                            'FAILURE' : "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} fallito in ambiente ${env.targetProjectOCP}",
                            'UNSTABLE': "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}\n\nAlcuni test sono falliti"]

                    def infoMap = ['Commit ID': env.commitId, 'Commit Message': env.commitMessage, 'Committer': env.committer, 'Path': "${env.chainPath}", 'Project': "${env.targetProjectOCP}", 'Microservice': "${MICROSERVICE_NAME}", 'Unit Test': "${resultTests.unit.success}/${resultTests.unit.total}", 'SUCCESS': ['Version Tag': "${env.buildTag}"], 'ACTIONS': [['name': 'View Commit', 'url': "${env.gitURL}/projects/${env.gitProject}/repos/${env.msRepoName}/commits/${env.commitId}"], ['name': 'View Static Code Analysis', 'url': "${env.sonarURL}/dashboard?id=${info.sonarqube.project_key}"]]]
                    if (failedTests.size() > 0)
                        infoMap.put('Failed tests', "${failedTests}")
                    if (!(env.isFeature.toBoolean())) {
                        webhook.each {
                            notifyTeams(result, teamsMessages, it, infoMap)
                        }
                    }
                }
            }
        }

    }
}
