package deprecated

import com.accenture.sec.managers.SonarManager
import com.accenture.sec.managers.NexusManager
import com.accenture.sec.runners.CurlRunner
import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.testers.ITester
import com.accenture.sec.testers.sti.StreamAppCaricatoreTester
import com.accenture.sec.testers.sti.StreamAppReplicatoreTester
import com.accenture.sec.testers.sti.StreamAppScodatoreTester
import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.CommonUtils

def call(body) {
    // evaluate the body block, and collect configuration into the object , elabora gli attributi definiti all'interno del jenkinsfile presente nel repo con il codice applicativo
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def MICROSERVICE_NAME = pipelineParams.MICROSERVICE_NAME
    def CONTEXT_DIR = pipelineParams.CONTEXT_DIR
    def SOURCE_IMAGE = pipelineParams.SOURCE_IMAGE ? pipelineParams.SOURCE_IMAGE : "openshift/openjdk18-openshift:latest"
    def ONLY_SONAR = pipelineParams.ONLY_SONAR ? pipelineParams.ONLY_SONAR : false

    env.targetProjectOCP = null
    env.CICDProjectOCP = null
    env.clusterOCP = null
    env.isFeature = 'false'

    def webhook = null
    def resultTests = ['unit': ['total': 0, 'success': 0], 'component': ['total': 0, 'success': 0]]
    def failedTests = []
    def stat = [deployed: false, tested: false]
    def config = null
    def info = null

    def qg = null

    NexusManager nxMgr = null

    /*Nome del namespace temporaneo*/
    def ocTempProjectName = "cb-dev-streaming-${MICROSERVICE_NAME.hashCode().abs()}"
    def kafka_topic_url
/*    Map tokensYaml
    Map allTokensYaml*/
    def cicd_devops_token_path = "cicd_devops/tokens"
    String applicationType = ""
    def doDeploy = true

    SonarManager sonarManager = null

    pipeline {
        /* agent any*/
        agent {
            label 'maven-ci'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '15', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }

        stages {
            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {

                            info = getInfo()
                            applicationType = info.applicationType
                            config = loadEnvVariables(
                                    "CI",
                                    [
                                            microservice    : MICROSERVICE_NAME,
                                            notificationMail: params.NOTIFICATION_MAIL,
                                            releaseType     : "CONFLUENT",
                                            clusterType     : 'test'
                                    ]
                            )
                            kafka_topic_url = config.kafka.test.broker.url
                            ocTempProjectName = "${env.targetProjectOCP}-${MICROSERVICE_NAME.hashCode().abs()}"
                            webhook = info.teamsChannelNotification.CI
                            /*allTokensYaml = readYaml file: "${WORKSPACE}/${cicd_devops_token_path}/${env.targetProjectOCP}.yaml"
                            tokensYaml = allTokensYaml.get(MICROSERVICE_NAME)*/
                            doDeploy = "REPLICATORE".equals(applicationType) || "SCODATORE".equals(applicationType) || "CARICATORE".equals(applicationType)
                            //temporanemente disabilitati i service test. Si attende risoluzione ticket 166 (https://jira.pp.seccloud.internal/browse/SEC-166)
                            doDeploy = false
                            nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)

                            // Prepare Slave
                            sh """#!/bin/bash -e
                git config --global user.email "noreply@example.com"
                git config --global user.name "${env.gitUser}"
              """
                        }
                    }
                }
            }

            stage('Build App') {
                steps {
                    script {
                        ansiColor('xterm') {
                            buildMaven("${CONTEXT_DIR}")
                        }
                    }
                }
            }

            stage('Unit Test') {
                steps {
                    script {
                        ansiColor('xterm') {
                            def ret = unitTestMaven("${CONTEXT_DIR}")
                            resultTests.unit.total = ret.total
                            resultTests.unit.success = ret.success
                            if (ret.exception) {
                                error("Unit test falliti")
                            }
                        }
                    }
                }
            }

            stage('Sonar Test') {
                when { expression { info.sonarqube?.project_key } }
                steps {
                    script {
                        ansiColor('xterm') {
                            withCredentials([string(credentialsId: env.sonarTokenCredsId, variable: 'login_id')]) {
                                sonarManager = new SonarManager(this, env.sonarURL, env.login_id)
                            }
                            dir(CONTEXT_DIR) {
                                sonarManager.scanWithMaven([sonarProjectKey: info.sonarqube.project_key, branch: env.currentBranch, projectVersion: env.buildTag])
                            }

//                            boolean isGateBlocker = SonarManager.isQualityGateBlocker(config.sonarqube.qgBlockRules as List, env.currentBranch as String)
//                            if (isGateBlocker) {
//                                try {
//                                    qg = sonarManager.waitForQualityGate(true)
//                                } catch (Exception e) {
//                                    qg = e.getQgResult()
//                                    error("${Colors.Bash.RED}${e.getMessage()}:${Colors.Bash.NC}\n${CommonUtils.toJson(e.getQgResult(), true)}")
//                                }
//                            }

                        }
                    }
                }
            }

            stage('Build Image') {
                when { expression { !ONLY_SONAR } }
                steps {
                    script {
                        ansiColor('xterm') {
                            sh """                    
                      rm -rf ${WORKSPACE}/oc-build && mkdir -p ${WORKSPACE}/oc-build/deployments
                      ls ${WORKSPACE}/${CONTEXT_DIR}/target
                      mv ${WORKSPACE}/${CONTEXT_DIR}/target/*.[wj]ar ${WORKSPACE}/oc-build/deployments/
                    """
                            openshift.withCluster(env.clusterOCP) {
                                openshift.withProject(env.CICDProjectOCP) {
                                    //openshift.logLevel(9)
                                    buildImage(openshift, "${MICROSERVICE_NAME}", "${SOURCE_IMAGE}", env.buildTag, ['binary': true, 'from_dir': true, 'dir': 'oc-build'])
                                }
                            }
                            tagRepository(env.gitUser, env.msRepoURL, env.commitId, env.buildTag)
                        }
                    }
                }
            }

            stage('Archive artifact') {
                when { expression { !ONLY_SONAR } }
                steps {
                    script {
                        ansiColor('xterm') {
                            filePath = createArtifact("${CONTEXT_DIR}", 'package', "${MICROSERVICE_NAME}", env.buildTag)
                            map = [
                                    'groupId'       : "${env.nexusArtifactGroupId}",
                                    'artifactId'    : "${MICROSERVICE_NAME}",
                                    'packageVersion': env.buildTag,
                                    'packaging'     : 'zip']
                            nxMgr.upload(env.nexusArtifactRepo, filePath, map)
                        }
                    }
                }
            }

            stage('Deployment preparation test') {
                when { expression { !ONLY_SONAR } }
                steps {
                    script {
                        ansiColor('xterm') {

                            def targetProject = "cb-test-${env.releaseNumber}"
                            echo "Testing existing token for ${targetProject}"
                            echo("""tokenFilePath: ${env.WORKSPACE}/cicd_devops/tokens/${targetProject}.yaml """)
                            def replaceTokensMap = [
                                    path         : "deployment/templates/",
                                    tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${targetProject}.yaml",
                                    microservice : MICROSERVICE_NAME,
                                    dryrun       : true
                            ]
                            replaceTokens(replaceTokensMap)
                            if (!doDeploy) {
                                echo "Dryrun of the deploy in ${targetProject}..."
                                openshift.withCluster(env.clusterOCP) {
                                    deployApp(openshift, "${MICROSERVICE_NAME}", env.buildTag, [dryrun: true])
                                }
                                echo "Complete Dryrun of deploy in ${targetProject}"
                            }
                        }
                    }
                }
            }

            /*           stage('Service Test - Temporary namespace creation') {
                           when {
                               expression { doDeploy && !ONLY_SONAR }
                           }
                           steps {
                               script {
                                   ansiColor('xterm') {
                                       def isProjectCreated = false
                                       openshift.withCluster(env.clusterOCP) {
                                           try {
                                               isProjectCreated = openshift.selector("project", ocTempProjectName).exists()
                                           } catch (Exception e) {
                                               isProjectCreated = false
                                           }
                                           if (!isProjectCreated) {
                                               openshift.newProject(ocTempProjectName)
                                               saccount = "system:serviceaccount:${ocTempProjectName}:default"
                                               //CREA PROGETTO
                                               // Aggiunge permessi a gruppi ed utenti
                                               sh """oc policy add-role-to-group admin "CN=copybanking_bitbucket_admins,CN=users,DC=secreloaded,DC=sec" -n ${
                                                   ocTempProjectName
                                               }"""
                                               sh """oc policy add-role-to-user admin "CN=Konrad Poznanski,CN=Users,DC=secreloaded,DC=sec" -n ${
                                                   ocTempProjectName
                                               }"""
                                               //Aggiunge permesso image-pull sc default di $projectName su namespace Ci-Cd
                                               sh """oc policy add-role-to-user system:image-puller ${saccount} -n ${
                                                   env.CICDProjectOCP
                                               }"""
                                           }
                                       }
                                   }
                               }
                           }
                       }*/

/*            stage('Service Test - Starting temporary Mongodb instance') {
                when {
                    expression { doDeploy && !ONLY_SONAR }
                }
                steps {
                    script {
                        ansiColor('xterm') {
                            openshift.withCluster(env.clusterOCP) {
                                openshift.withProject(ocTempProjectName) {
                                    boolean isPodCreated
                                    try {
                                        isPodCreated = openshift.selector("dc", "mongodb").exists()
                                    } catch (Exception e) {
                                        isPodCreated = false
                                    }

                                    if (!isPodCreated) {
                                        def templateList = openshift.process("openshift//mongodb-ephemeral", "-p", "MONGODB_USER=${((String) tokensYaml.SEC_MONGODB_USERNAME).substring(6)}",
                                                "-p", "MONGODB_PASSWORD=${((String) tokensYaml.SEC_MONGODB_PASSWORD).substring(6)}", "-p", "MONGODB_ADMIN_PASSWORD=adminpwd", "MONGODB_DATABASE=${tokensYaml.SEC_MONGODB_DATABASE}")
                                        // creo le risorse processate dal comando precedente
                                        def res = openshift.create(templateList)
                                        timeout(10) {
                                            // Attendo che tutti i pod del cluster sia up
                                            res.narrow("dc").related("pods").untilEach(1) {
                                                return (it.object().status.phase == "Running")
                                            }
                                        }
                                    }
                                }
                            }
                            String msg = "################################################################################\n" +
                                    "INTEGRATION TEST : Istanza di Mongodb creata con successo\n" +
                                    "################################################################################\n";
                            echo """${msg}"""
                        }
                    }
                }
            }*/

/*            stage('Service Test - Create temporary Confluent topic') {
                when {
                    expression { doDeploy && !ONLY_SONAR }
                }
                steps {
                    script {
                        ansiColor('xterm') {
                            sh "kafka-topics.sh --delete --if-exists --topic ${tokensYaml.SEC_KAFKA_TOPICA} --zookeeper 10.16.50.54:2181"
                            def retries = 5
                            def timeout = 8
                            def failure = false
                            String result
                            ArrayList<String> resultlist
                            while (retries > 0) {

                                result = sh(returnStdout: true, script: """#!/bin/bash -e 
                                        curl -X GET http://confcn2-mi1:8082/topics
                                        """)
                                result = result.substring(1)
                                resultlist = Arrays.asList(result)
                                if (resultlist.contains("${tokensYaml.SEC_KAFKA_TOPICA}")) {
                                    echo """#######################################################
Kafka topic ${tokensYaml.SEC_KAFKA_TOPICA} non ancora eliminato. Tentativi restanti $retries.
"""
                                    if (retries - 1 < 1) {
                                        failure = true
                                        break;
                                    }
                                } else {
                                    echo """#######################################################
Kafka topic ${tokensYaml.SEC_KAFKA_TOPICA} eliminato. Tentativi restanti $retries.
"""
                                    break;
                                }
                                retries--
                            }
                            if (failure) {
                                String msg = "\n#######################################################\n" +
                                        "Errore, impossibile eliminare il topic ${tokensYaml.SEC_KAFKA_TOPICA}\n" +
                                        "Ultimo controllo:\n" +
                                        "curl -X GET http://confcn2-mi1:8082/topics\n" +
                                        "\n$result\n"

                                echo """$msg"""
                                throw new Exception(msg)
                            }
                            sh "kafka-topics.sh --create --if-not-exists --topic ${tokensYaml.SEC_KAFKA_TOPICA} --zookeeper 10.16.50.54:2181 --partitions 1 --replication-factor 1"
                        }
                    }
                }
            }*/

/*            stage('Service Test - Deploy Stream app') {
                when {
                    expression { doDeploy && !ONLY_SONAR }
                }
                steps {
                    script {
                        ansiColor('xterm') {
                            def replaceTokensMap = [
                                    path         : "deployment/templates/",
                                    tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${env.targetProjectOCP}.yaml",
                                    microservice : MICROSERVICE_NAME
                            ]
                            replaceTokens(replaceTokensMap)
                            openshift.withCluster(env.clusterOCP) {
                                openshift.withProject(ocTempProjectName) {
                                    env.service_url = deployApp(openshift, "${MICROSERVICE_NAME}", env.buildTag)
                                    //env.service_url = openshift.process("-f ${templatesPath}/${MICROSERVICE_NAME}_template.yaml","-p=IMAGE_TAG=${version}")
                                    stat.deployed = true
                                }
                            }
                        }
                    }
                }
            }*/

            /*           stage('Service Test - Test execution') {
                           when {
                               expression { doDeploy && !ONLY_SONAR }
                           }
                           steps {
                               script {
                                   ansiColor('xterm') {
                                       def tests_path = "${WORKSPACE}/tests/servicetest"
                                       def map
                                       ITester streamAppTester
                                       if ("REPLICATORE".equals(applicationType)) {
                                           map = [
                                                   'tests_path'       : "${tests_path}",
                                                   'kafka_topic_url'  : "${kafka_topic_url}/${((String) tokensYaml.SEC_KAFKA_TOPICA)}",
                                                   'mongo_user'       : "${((String) tokensYaml.SEC_MONGODB_USERNAME).substring(6)}",
                                                   'mongo_pwd'        : "${((String) tokensYaml.SEC_MONGODB_PASSWORD).substring(6)}",
                                                   'mongo_service_url': "\"mongodb://${tokensYaml.SEC_MONGODB_HOST}:${tokensYaml.SEC_MONGODB_PORT}/${tokensYaml.SEC_MONGODB_DATABASE}\""]

                                           streamAppTester = new StreamAppReplicatoreTester(this)
                                       } else if ("SCODATORE".equals(applicationType)) {
                                           map = [
                                                   'tests_path'       : "${tests_path}",
                                                   'mongo_user'       : "${((String) tokensYaml.SEC_MONGODB_USERNAME).substring(6)}",
                                                   'mongo_pwd'        : "${((String) tokensYaml.SEC_MONGODB_PASSWORD).substring(6)}",
                                                   'mongo_service_url': "\"mongodb://${tokensYaml.SEC_MONGODB_HOST}:${tokensYaml.SEC_MONGODB_PORT}/${tokensYaml.SEC_MONGODB_DATABASE}\""]

                                           streamAppTester = new StreamAppScodatoreTester(this)
                                       } else if ("CARICATORE".equals(applicationType)) {
                                           map = [
                                                   'tests_path'       : "${tests_path}",
                                                   'mongo_user'       : "${((String) tokensYaml.SEC_MONGODB_USERNAME).substring(6)}",
                                                   'mongo_pwd'        : "${((String) tokensYaml.SEC_MONGODB_PASSWORD).substring(6)}",
                                                   'mongo_service_url': "\"mongodb://${tokensYaml.SEC_MONGODB_HOST}:${tokensYaml.SEC_MONGODB_PORT}/${tokensYaml.SEC_MONGODB_DATABASE}\""]

                                           streamAppTester = new StreamAppCaricatoreTester(this)
                                       }
                                       streamAppTester.exec(map)
                                   }
                               }
                           }
                       }*/

            stage('Update Manifest') {
                when { expression { return (env.releaseNumber != null && !ONLY_SONAR) } }
                steps {
                    script {
                        echo("Updating '${env.releaseNumber}' manifest for ${MICROSERVICE_NAME}")
                        Map<String, String> dbInfo = [:]
                        dbInfo.putAll(config.manifest.db)
                        boolean skipUpdate = false
                        if (fileExists("${CONTEXT_DIR}/pom.xml")) {
                            echo("Checking version of dependencies in pom . . .")
                            def pom = readMavenPom file: "${CONTEXT_DIR}/pom.xml"
                            pom.getDependencies().each { dep ->
                                if (dep.version && dep.version ==~ /.*SNAPSHOT/) {
                                    echo("WARNING: ${MICROSERVICE_NAME}:${env.buildTag} was builded with 'SNAPSHOT' dependencies\n${dep}")
                                    skipUpdate = true
                                    return
                                }
                            }
                        }
                        if (!skipUpdate)
                            updateDBManifest(
                                    [
                                            waveName  : env.releaseNumber,
                                            msName    : MICROSERVICE_NAME,
                                            msBuildNum: env.buildTag,
                                            msDeps    : (info.dependencies ?: info.dependences),
                                            target    : (info.target ?: 'ocp'),
                                            dbInfo    : dbInfo
                                    ]
                            )
                    }
                }
            }

        }

        post {
            always {
                deleteDir()
                script {

                    def result = currentBuild.currentResult
                    if (result == 'ABORTED')
                        return

                    /*Cancellazione project openshift temporaneo*/
                    if (doDeploy) {
                        def isProjectCreated = false
                        openshift.withCluster(env.clusterOCP) {
                            try {
                                isProjectCreated = openshift.selector("project", ocTempProjectName).exists()
                            } catch (Exception e) {
                                isProjectCreated = false
                            }
                            if (isProjectCreated) {
                                openshift.withCluster(env.clusterOCP) {
                                    openshift.withProject(ocTempProjectName) {
                                        openshift.delete("project", ocTempProjectName)
                                        echo "Temporary namespace deleted"
                                    }
                                }
                            }
                        }
                    }

                    if (sonarManager && !qg) {
                        qg = sonarManager.waitForQualityGate()
                    }

                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    if (failedTests.size() > 0 && stat.deployed)
                        result = 'UNSTABLE'
                    def mailMessages = [
                            'SUCCESS' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${
                                                env.releaseNumber
                                            } con successo</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]],
                            'FAILURE' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} non è stato aggiunto al manifest di Release Candidate ${env.releaseNumber}</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]],
                            'UNSTABLE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] instabile",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo\\n\\nAlcuni test sono falliti</p>
       <p>${failedTests}</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]]]
                    //notifyMail(env.committerEmail, mailMessages, result)

                    def teamsMessages = [
                            'SUCCESS' : "Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo",
                            'FAILURE' : "Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} non è stato aggiunto al manifest di Release Candidate ${env.releaseNumber}",
                            'UNSTABLE': "Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo\n\nAlcuni test sono falliti"]

                    def infoMap = [
                            'Commit ID'     : env.commitId,
                            'Committer'     : env.committer,
                            'Commit Message': env.commitMessage.replace('\r', '').replace('\n', '<br>'),
                            'Path'          : "${env.chainPath}",
                            'Servizio'      : "${MICROSERVICE_NAME}",
                            'Unit Test'     : "${resultTests.unit.success}/${resultTests.unit.total}",
                            'SUCCESS'       : ['Version Tag': "${env.buildTag}"], 'ACTIONS': [['name': 'View Commit', 'url': "${env.gitURL}/projects/${env.gitProject}/repos/${env.msRepoName}/commits/${env.commitId}"]]]
                    if (info?.sonarqube) {
                        infoMap['ACTIONS'].add(['name': 'View Static Code Analysis', 'url': "${env.sonarURL}/dashboard?id=${info.sonarqube.project_key}&branch=${env.currentBranch.replace('/','%2F')}"])
                    }
                    if (qg) {
                        infoMap.put('Quality Gate', qg.label)
                    }
                    if (failedTests.size() > 0)
                        infoMap.put('Failed tests', "${failedTests}")
                    webhook.each {
                        notifyTeams(result, teamsMessages, it, infoMap)
                    }
                }
            }
        }
    }
}
