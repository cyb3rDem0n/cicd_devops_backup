import com.accenture.sec.managers.NexusManager

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def MICROSERVICE_NAME = pipelineParams.MICROSERVICE_NAME
    def CONTEXT_DIR = pipelineParams.CONTEXT_DIR
    def SOURCE_IMAGE = pipelineParams.SOURCE_IMAGE ? pipelineParams.SOURCE_IMAGE : "openshift/httpd:2.4"

    env.targetProjectOCP = null
    env.CICDProjectOCP = null
    env.clusterOCP = null

    def webhook = null
    def resultTests = ['unit': ['total': 0, 'success': 0], 'component': ['total': 0, 'success': 0]]
    def failedTests = []
    def info = null

    def stat = [deployed: false, tested: false]

    NexusManager nexusManager = null

    pipeline {
        agent {
            label 'maven-ci'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
        }

        parameters {
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }

        stages {

            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {
                            info = getInfo()
                            config = loadEnvVariables(
                                    "CI",
                                    [
                                            microservice    : MICROSERVICE_NAME,
                                            notificationMail: params.NOTIFICATION_MAIL,
                                            releaseType     : "MICROSERVICE",
                                            clusterType     : 'test'
                                    ]
                            )
                            webhook = info.teamsChannelNotification.CI

                            // Prepare Slave
                            sh """#!/bin/bash -e
                                git config --global user.email "noreply@example.com"
                                git config --global user.name "${env.gitUser}"
                            """
                        }
                    }
                }
            }

            stage('Build Image') {
                steps {
                    script {
                        ansiColor('xterm') {
                            sh """#!/bin/bash
                                mkdir -p oc-build
                                echo "" > oc-build/index.html
                            """
                            openshift.withCluster(env.clusterOCP) {
                                openshift.withProject(env.CICDProjectOCP) {
                                    buildImage(openshift, MICROSERVICE_NAME, SOURCE_IMAGE, env.buildTag, ['binary': true, 'from_dir': true, 'dir': 'oc-build'])
                                }
                            }
                            tagRepository(env.gitUser, env.msRepoURL, env.commitId, env.buildTag)
                        }
                    }
                }
            }

            stage('Archive artifact') {
                steps {
                    script {
                        ansiColor('xterm') {
                            def filePath = createArtifact(CONTEXT_DIR, 'package', MICROSERVICE_NAME, env.buildTag)
                            def map = [
                                    'groupId'       : env.nexusArtifactGroupId,
                                    'artifactId'    : MICROSERVICE_NAME,
                                    'packageVersion': env.buildTag,
                                    'packaging'     : 'zip']
                            nexusManager = new NexusManager(this, env.nexusURL, env.nexusUser)
                            nexusManager.upload(env.nexusArtifactRepo, filePath, map)
                        }
                    }
                }
            }

            stage('Deployment preparation test') {
                steps {
                    script {
                        ansiColor('xterm') {

                            def targetProject = "cb-test"
                            echo "Checking tokens exists for ${targetProject} namespace..."
                            def replaceTokensMap = [
                                    path         : "deployment/templates/",
                                    tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${targetProject}.yaml",
                                    microservice : MICROSERVICE_NAME,
                                    dryrun       : true
                            ]
                            replaceTokens(replaceTokensMap)
                            echo "Dryrun of the deploy in ${targetProject}..."
                            if (!doDeploy) {
                                openshift.withCluster(env.clusterOCP) {
                                    deployApp(openshift, MICROSERVICE_NAME, env.buildTag, [dryrun: true])
                                }
                                echo "Complete Dryrun of deploy in ${targetProject}"
                            }
                        }
                    }
                }
            }

//      stage('Deploy App'){
//          steps {
//              script {
//                  ansiColor('xterm') {
//                      openshift.withCluster(env.clusterOCP) {
//                          openshift.withProject(env.targetProjectOCP) {
//                              def replaceTokensMap = [
//                                    path         : "deployment/templates/",
//                                    tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${env.targetProjectOCP}.yaml",
//                                    microservice : MICROSERVICE_NAME
//                            ]
//                            replaceTokens(replaceTokensMap)
//                              env.service_url = deployApp(openshift, "${MICROSERVICE_NAME}", env.buildTag)
//                              stat.deployed = true
//                          }
//                      }
//                  }
//              }
//          }
//      }

        }

        post {
            always {
                deleteDir()
                script {
                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    def result = currentBuild.currentResult
                    if (failedTests.size() > 0 && stat.deployed)
                        result = 'UNSTABLE'
                    def mailMessages = [
                            'SUCCESS' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
<p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]],
                            'FAILURE' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
<p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} fallito in ambiente ${env.targetProjectOCP}</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]],
                            'UNSTABLE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
<p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP} ma alcuni test sono falliti</p>
<p>${failedTests}</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]]]
                    notifyMail(env.committerEmail, mailMessages, result)

                    def teamsMessages = [
                            'SUCCESS' : "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}",
                            'FAILURE' : "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} fallito in ambiente ${env.targetProjectOCP}",
                            'UNSTABLE': "Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${env.targetProjectOCP}\n\nAlcuni test sono falliti"]

                    def infoMap = ['Commit ID': env.commitId, 'Commit Message': env.commitMessage, 'Committer': env.committer, 'Path': "${env.chainPath}", 'Project': "${env.targetProjectOCP}", 'Microservice': "${MICROSERVICE_NAME}", 'Unit Test': "${resultTests.unit.success}/${resultTests.unit.total}", 'Component Test': "${resultTests.component.success}/${resultTests.component.total}", 'SUCCESS': ['Version Tag': "${env.buildTag}"], 'ACTIONS': [['name': 'View Commit', 'url': "https://###bitbucket_url###/projects/###bitbucket_project###/repos/${env.msRepoName}/commits/${env.commitId}"]]]
                    if (failedTests.size() > 0)
                        infoMap.put('Failed tests', "${failedTests}")
                    webhook.each {
                        notifyTeams(result, teamsMessages, it, infoMap)
                    }
                }
            }
        }

    }
}