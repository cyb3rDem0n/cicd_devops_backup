import com.accenture.sec.utils.CommonUtils

def call(def contextDir, def packagePath, def packageName, def packageVersion, def destEnv = "ocp") {

    def retValue
    switch(destEnv){
        case "ocp":
            retValue = createArtifactOCP([
                contextDir: contextDir,
                packageName: packageName,
                packageVersion : packageVersion,
                packagePath: packagePath
            ])
            break
        case "vm":
            retValue = createArtifactVM([
                    contextDir: contextDir,
                    packageName: packageName,
                    packageVersion : packageVersion,
                    packagePath: packagePath
            ])
            break

    }

    return retValue
}

/**
 * Creazione artefatto per deploy su Virtual Machine
 * @param args
 * @return
 */
private def createArtifactVM(Map args) {

    sh """#!/bin/bash -e
        cd ${WORKSPACE}
        mkdir -p ${args.packagePath}
        cp -r deployment/ ${args.packagePath}
        cp info.yaml ${args.packagePath}/
    """
    if (!CommonUtils.isNullOrEmpty(args.contextDir)){
            sh """#!/bin/bash -e
            mv ${WORKSPACE}/${args.contextDir}/target/${args.packageName}.jar ${args.packagePath}/ && true
        """
        sh """#!/bin/bash -e
            if [[ -f ${WORKSPACE}/${args.contextDir}/pom.xml ]]; then
              cp -r ${WORKSPACE}/${args.contextDir}/pom.xml ${args.packagePath}/
            fi
        """
    }

    sh """#!/bin/bash -e
        cd ${args.packagePath}
        zip -r ${args.packageName}.zip *
    """

    return "${WORKSPACE}/${args.packagePath}/${args.packageName}.zip"
}

/**
 * Creazione artefatto per deploy su Openshift
 * @param args
 * @return
 */
private def createArtifactOCP(Map args) {

    sh """#!/bin/bash -e
        cd ${WORKSPACE}
        mkdir -p ${args.packagePath}
        cp -r deployment/ ${args.packagePath}
        cp -r tests/ ${args.packagePath} || true
        echo "${args.packageVersion}" > ${args.packagePath}/IMAGE_TAG
        cp info.yaml ${args.packagePath}/
    """
    if (!CommonUtils.isNullOrEmpty(args.contextDir)){
        sh """#!/bin/bash -e
            if [[ -f ${WORKSPACE}/${args.contextDir}/pom.xml ]]; then
              cp -r ${WORKSPACE}/${args.contextDir}/pom.xml ${args.packagePath}/
            fi
        """
    }

    sh """#!/bin/bash -e
        cd ${args.packagePath}
        zip -r ${args.packageName}.zip *
    """

    return "${WORKSPACE}/${args.packagePath}/${args.packageName}.zip"
}