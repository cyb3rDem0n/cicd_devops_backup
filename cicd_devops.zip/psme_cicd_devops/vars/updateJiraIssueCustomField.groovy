import com.accenture.sec.api.JiraCustomAPI
import com.accenture.sec.utils.CommonUtils

def call(Map args) {
    if(CommonUtils.isNullOrEmpty(args.issueKey))
        return
    CommonUtils.checkInputParameters(args, ["jiraConfig", "issueKey", "updates"])

    JiraCustomAPI jiraAPI = new JiraCustomAPI(this, args.jiraConfig.url, args.jiraConfig.credsId)
    def result = jiraAPI.updateCustomField([issueKey: args.issueKey, updates: args.updates])
    if (result.status > 399) {
        echo("There was an error updating customFields on Jira for isssue #${args.issueKey}, rest Jira endpoint returned:\nstatus: ${result.status}\nmessage: ${result.message}\n${result.error}")
    }
    echo("CustomFields successfully updated on Jira issue #${args.issueKey} by jenkins")
}


