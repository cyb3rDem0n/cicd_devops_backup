def call(def receiver, def subject, def body, def sender = 'devops-noreply@it.accenture.com') {
    if (!receiver || receiver == "")
        return
    if (subject instanceof Map && (body instanceof String && ['SUCCESS', 'FAILURE', 'UNSTABLE', 'ABORTED'].contains(body))) {
        def state = body
        if (state == 'ABORTED')
            return
        body = subject.get(state).body
        subject = subject.get(state).subject
    }

    try {
        mail bcc: '',
                mimeType: body.type,
                body: body.msg,
                cc: '', from: sender, replyTo: '', subject: subject, to: "${receiver}"
    } catch (Exception e) {
        echo("WARN: Unable to sent mail notification\n\tReason: ${e.getMessage()}")
    }

}
