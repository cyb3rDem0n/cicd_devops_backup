def call(body) {
    call([:], body)
}

def call(Map args, body) {
    args.retryNumber = args.retryNumber ?: 15
    args.skipExceptions = args.skipExceptions ?: [NotSerializableException.class]
    args.skipExceptionsMessage = args.skipExceptionsMessage ?: ['FastPipedInputStream']

    int i = 1
    boolean ok = false
    boolean retry
    Exception exception = null
    while (!ok && (i <= (args.retryNumber as int))) {
        retry = false
        try {
            body()
            ok = true
        } catch (Exception e) {
            if (e.getClass() in args.skipExceptions && i <= (args.retryNumber as int)) {
                args.skipExceptionsMessage.each { msg ->
                    if (e.getMessage().contains(msg)) {
                        println("${e.getMessage()}\nRetrying ${i}")
                        retry = true
                    }
                }
            }
            if (!retry) {
                throw e
            }
            exception = e
        }
        if (ok) break
        i++
//        Thread.sleep(((new Random()).nextInt(9) + 1) * 1000)
        Thread.sleep(1000)
    }
    if (!ok && (i > (args.retryNumber as int))) {
        throw exception
    }
}
