import com.accenture.sec.utils.Colors

def call(def contextDir, def debug=false) {
    def debugOption = ''
    if(debug){
        debugOption = '-dd'
    }
    dir(contextDir){
        sh """#!/bin/bash -e
            echo "\nDownloading dependencies...\n"
            rm -rf package-lock.json || true
            
            echo "${Colors.Bash.BLUE}npm install${Colors.Bash.NC}\n"
            npm install ${debugOption}
            echo "\nBuilding Application...\n"
            echo "${Colors.Bash.BLUE}npm run build:jenkins${Colors.Bash.NC}\n"
            npm run build:jenkins
            pwd
            ls
        """
    }


//    def nodeJson = readJSON(file: "${WORKSPACE}/${contextDir}/package.json")
//    def defaultProject = nodeJson.defaultProject
//    return nodeJson.projects[defaultProject].architect.build.options.outputPath
}
