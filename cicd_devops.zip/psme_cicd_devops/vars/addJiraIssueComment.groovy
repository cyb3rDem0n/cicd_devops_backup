import com.accenture.sec.api.JiraAPI
import com.accenture.sec.utils.CommonUtils

def call(Map args) {
    if(CommonUtils.isNullOrEmpty(args.issueKey))
        return
    CommonUtils.checkInputParameters(args, ["jiraConfig", "issueKey", "message"])
    echo("Requesting adding comment on Jira issue #${args.issueKey} automatically")
    JiraAPI jiraAPI = new JiraAPI(this, args.jiraConfig.url, args.jiraConfig.credsId)
    def result = jiraAPI.addIssueComment([issueKey: args.issueKey, message: args.message])
    if (result.status != 201) {
        echo("There was an error adding Comment on Jira for isssue #${args.issueKey}, rest Jira endpoint returned:\n${result.status}\n${result.content}")
    }
    echo("Comment successfully added on Jira isssue #${args.issueKey} by jenkins")
}


