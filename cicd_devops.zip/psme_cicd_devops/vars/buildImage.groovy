import com.accenture.sec.utils.CommonUtils

def call(def openshift, def microservice, def imageStream, def version, def map = ['binary': true, 'from_dir': true, 'dir': 'oc-build']) {

    opt = ''
    if (map.from_dir) {
        opt = "--from-dir=${map.dir}"
    }
    // source=''
    // if(map.source){
    //   source="${map.source}"
    // }

    echo "Using project ${openshift.project()} in cluster with url ${openshift.cluster()}"
    def bc = openshift.selector("bc", "${microservice}")
    if (bc.exists()) {
        List stream = imageStream.tokenize('/')
        def from
        if(stream.size() == 1){
            from = $/{\"name\":\"${stream[0]}\"}/$
        }else if(stream.size() == 2){
            from = $/{\"namespace\":\"${stream[0]}\",\"name\":\"${stream[1]}\"}/$
        }
        if(bc.object().spec.strategy.sourceStrategy.from.name != stream[1]){
            echo "Updating buildconfig ${microservice}..."
            bc.patch($/"{\"spec\":{\"strategy\":{\"sourceStrategy\":{\"from\":${from}}}}}"/$)
        }
    } else {
        echo "Creating buildconfig ${microservice}..."
        openshift.newBuild("--name=${microservice}", "--image-stream=${imageStream}", "--binary=${map.binary}")
    }

    if (map.resources) {
        def str = CommonUtils.toJson(map.resources).replace(/"/, /\"/)
        def patchStr = $/"{\"spec\":{\"resources\":${str}}}"/$
        openshift.selector("bc", "${microservice}").patch(patchStr)
    }

    if (map.env) {
        List envList = []
        map.env.each { k, v ->
            envList.add($/{\"name\":\"${k}\",\"value\":\"${v}\"}/$)
        }
        def patchStr = $/"{\"spec\":{\"strategy\":{\"sourceStrategy\":{\"env\":[${envList.join(',')}]}}}}"/$
        openshift.selector("bc", "${microservice}").patch(patchStr)
    }

    echo "Creating image for ${microservice}..."
    def ret = openshift.selector("bc", "${microservice}").startBuild("${opt}", "--wait=true")
    echo "Created image: ${ret.object().status.outputDockerImageReference}"

    def sha = ret.object().status.output.to.imageDigest
    echo "Applying tag ${version} to image..."
    ret = openshift.tag("${openshift.project()}/${microservice}@${sha}", "${openshift.project()}/${microservice}:${version}")
    echo "${ret.actions[0].out}"

}
