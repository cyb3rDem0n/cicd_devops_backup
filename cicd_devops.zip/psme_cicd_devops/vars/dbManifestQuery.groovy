import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.WaveDAO
import com.accenture.sec.utils.CommonUtils
import com.cloudbees.groovy.cps.NonCPS

import java.sql.Connection

def call(Map<String, Object> args) {
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'dbInfo,query')
    Map<String, String> dbInfo = [:]
    dbInfo.putAll(args.dbInfo)
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')
    Connection connection = null

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione
    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }

    def result = null
    Map query = args.query as Map
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo "Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}"

        switch (query.entity) {
            case 'wave':
                WaveDAO waveDAO = new WaveDAO(connection)
                switch(query.type){
                    case 'getWaveByApplicationContext':
                        result = waveDAO.getWaveByApplicationContext(query.queryArgs[0] as String)
                        break
                }
                break
        }
    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
    return result
}

@NonCPS
static def invokeMethod(Class _class, def obj, String methodName, Object[] methodArgs){
    // Si può usare così ma sembra non funzionare in jenkins
    // result = invokeMethod(WaveDAO, waveDAO, query.type as String, query.queryArgs.toArray() as Object[])
    def method = _class.getDeclaredMethods().find { it.name == methodName}
    return method.invoke(obj, methodArgs)
}
