import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args, def target='ocp') {
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'dbInfo,wave')
    Map<String, String> dbInfo = [:]
    dbInfo.putAll(args.dbInfo)
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    echo("Reading manifest ...")
    List<ManifestInfoDTO> manifest = null
    Connection connection = null

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione
    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo "Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}"
        ViewDAO viewDAO = new ViewDAO(connection)
        if(args.mfVersion == null){
            manifest = viewDAO.getManifestTest(args.wave as String)
        }
        else {
            manifest = viewDAO.getManifestCollProd(args.wave  as String, args.mfVersion  as String)
/*            ReleaseDAO releaseDAO = new ReleaseDAO()
            ReleaseDTO release = releaseDAO.getReleasebyVersion(args.releaseNumber as String)
            echo("Selected release -> ${release.toString()}")*/
        }
    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
    return manifest
}

