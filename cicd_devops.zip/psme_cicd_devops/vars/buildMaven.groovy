def call(def contextDir, boolean debug=false) {
    def debugStr = debug ? '-X' :''
    sh """#!/bin/bash -e
    echo "\nBuilding App...\n"
    echo -e "mvn clean install -Dmaven.test.skip=true\n"
    cd ${WORKSPACE}/${contextDir}
    mvn -version
	mvn clean install -Dmaven.test.skip=true -U ${debugStr}
"""

}
