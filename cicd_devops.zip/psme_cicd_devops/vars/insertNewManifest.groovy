import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ManifestDAO
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dao.WaveDAO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.db.dto.ReleaseInfoDTO
import com.accenture.sec.db.dto.ManifestDTO
import com.accenture.sec.db.dto.WaveDTO
import com.accenture.sec.entities.IncreaseType
import com.accenture.sec.entities.Versioner
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args, List<ManifestInfoDTO> manifestList) {
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'dbInfo,wave,clusterType,changedMf')
    if (CommonUtils.isNullOrEmpty(manifestList))
        return

    // Masking username & password
    args.dbInfo.username = null
    args.dbInfo.password = null

    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = initDBInfo(args)
    Connection connection = null
    // In test args.mfVersion == null, non viene passato, in collaudo è la versione del manifest che viene passata alla pipeline da Jira
    def mfVersion = args.mfVersion
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo("Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}")

        ManifestDAO manifestDAO = new ManifestDAO(connection)
        ManifestDTO manifestDTO
        ViewDAO viewDAO = new ViewDAO(connection)

        //Per Test la versione del manifest viene sempre calcolata nuova (args.mfVersion == null)
        //Per Collaudo la versione viene calcolata solo se il manifest, sulla description del ticket, è stato modificato
        if(args.clusterType == 'test' || (args.clusterType == 'collaudo' && (args.changedMf!=null && args.changedMf==true))){

            List<String> manifestVersions = viewDAO.getManifestVersionListByWave("${args.wave}")
            if(manifestVersions.isEmpty()){
                manifestVersions = ['v0']
            }
            String versionPattern = /v(\d+)/
            String versionFormat = /v%d/
            Versioner versioner = new Versioner(versionPattern, versionFormat)

            mfVersion = versioner.nextVersion(manifestVersions, null, IncreaseType.MAJOR)
            if (mfVersion == null){
                mfVersion = "v1"
            }

            manifestList.each { info ->
                    //echo ("""getManifestInfo("${args.wave}", "${info.microservice}", "${info.buildNum}") """)
                    ManifestInfoDTO manifestInfoDTO = viewDAO.getManifestInfo("${args.wave}", "${info.microservice}", "${info.buildNum}")
                    manifestDTO = new ManifestDTO()
                    manifestDTO.setIdBuild(manifestInfoDTO.getIdBuild())
                    manifestDTO.setVersion("${mfVersion}")
                    manifestDTO = manifestDAO.insert(manifestDTO)
            }
        }

    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
    return mfVersion
}

private Map initDBInfo(Map args) {
    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = args.dbInfo as Map
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione

    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    return dbInfo
}
