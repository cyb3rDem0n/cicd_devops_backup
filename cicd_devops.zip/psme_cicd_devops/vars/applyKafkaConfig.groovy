import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dto.DeployInfoDTO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.managers.NexusManager
import com.accenture.sec.managers.kafka.KafkaManager
import com.accenture.sec.managers.kafka.KafkaTopic
import com.accenture.sec.managers.kafka.TopicConfigProperty
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.golive.GoLiveList

import java.sql.Connection

def call(Map args, GoLiveList goLiveList = null ) {
    CommonUtils.checkInputParameters(args, 'type')
    def kafkaConfigYaml = null
    if (args.type == "CI") {
        try {
            echo "\nLettura configurazione topics\n"
            kafkaConfigYaml = readYaml file: "deployment/templates/kafka-topic-config-template.yaml"

        } catch (Exception e) {
            error("Il file kafka-topic-config-template.yaml e' malformato")
        }
        return [configApplied: true]
    } else if (args.type == "CD") {
        echo ("Controllo configurazione Kafka")
        CommonUtils.checkInputParameters(args, ['kafkaConfigBuild', 'nxMgr', 'releaseNumber', 'execEnv'])
        if(goLiveList == null){
            error("Step applyKafkaConfig: goLiveList è null!!")
        }
        ManifestInfoDTO kafkaConfigBuild = args.kafkaConfigBuild

        NexusManager nxMgr = args.nxMgr
        def dbInfo = args.dbInfo
        CommonUtils.checkInputParameters(args.dbInfo as Map, 'type,host,database,credsId')
        DeployInfoDTO deployInfoDTO = null

        withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
            dbInfo.username = env.usr
            dbInfo.password = env.psw
            DataSource ds = DataSource.getInstance()
            Connection connection = ds.setupConnection(dbInfo)
            try {
                ViewDAO viewDAO = new ViewDAO(connection)
                ManifestInfoDTO manifestInfoDTO
                deployInfoDTO = viewDAO.getLastDeployInfo("kafka-config", "${args.kafkaConfig.envForDeploy}")
                if (deployInfoDTO == null) {
                    deployInfoDTO = new DeployInfoDTO()
                    deployInfoDTO.microservice = "kafka-config"
                    if("$args.execEnv" == 'dev')
                        deployInfoDTO.buildNum = "${args.releaseNumber}-b0"
                    else{
                        manifestInfoDTO = viewDAO.getDeployedByReleaseAndMs("${args.releaseNumber}", "kafka-config")
                        deployInfoDTO.buildNum = """${manifestInfoDTO.getWave()}-b0"""
                    }

                }
            } finally {
                connection && connection.close()
            }
        }

        if ("${deployInfoDTO.buildNum}" != "${kafkaConfigBuild.buildNum}"){
            def filePath = nxMgr.download(env.nexusArtifactRepo, [groupId: env.nexusArtifactGroupId, artifactId: "${kafkaConfigBuild.microservice}", packageVersion: "${kafkaConfigBuild.buildNum}", packaging: 'zip'], "package-${kafkaConfigBuild.microservice}")
            sh """#!/bin/bash -e
                  mkdir kafka-config
                  unzip "${filePath}" -d "${WORKSPACE}/kafka-config/"
               """
            dir("${WORKSPACE}/kafka-config") {
                def argsList = [
                        kafkaConfig    : args.kafkaConfig,
                        kafkaConfigYaml: kafkaConfigYaml,
                        cfgVersion     : kafkaConfigBuild.buildNum,
                        dbInfo         : dbInfo
                ]
                applyConfig(argsList, goLiveList)
            }
            return true
        }
        else return false
    }
}

private applyConfig(Map args, GoLiveList goLiveList)  {
    def kafkaConfigYaml = args.kafkaConfigYaml
    def parallelStages = [:]
    if (kafkaConfigYaml == null) {
        echo "\nLettura della configurazione dei topic dal package scaricato da Nexus\n"
        kafkaConfigYaml = readYaml file: "deployment/templates/kafka-topic-config-template.yaml"
    }

    echo "\nCreazione manager per kafka cli e kafka rest proxy client\n"
    String old_kafka_opts = env.KAFKA_OPTS
    env.KAFKA_OPTS += " -Xms1g -Xmx2g"
    KafkaManager kafkaManager = new KafkaManager(this, args.kafkaConfig)
    echo "\nInizializzazione sicurezza per kafka cli e kafka rest proxy client\n"
    kafkaManager.initSecurity()
    echo "\nRecupero la lista dei topic da Zookeeper ...\n"

    //Lista generale dei topic letta da zookeeper che hanno per prefisso l'enviroment
    List<String> envZKTopics = kafkaManager.listTopics()

    int k = 0
    StringBuffer buf = new StringBuffer("Lista Topic letta da Rest Proxy con prefisso '${args.kafkaConfig.envForDeploy}':\n[ ")
    for (String t : envZKTopics) {
        if (k < envZKTopics.size() - 1)
            buf = buf.append("${t},\n")
        else buf = buf.append("${t}\n")
        k++
    }
    buf = buf.append(" ]\n")
    echo "${buf.toString()}"


    //Lista dei topic letti da template
    List topics = kafkaConfigYaml.topics != null ? kafkaConfigYaml.topics : new ArrayList<>()
    buf = new StringBuffer("Topic letti dalla configurazione presente su Nexus:\n[ ")
    k = 0
    topics.each { topic ->
        if (k < topics.size() - 1)
            buf = buf.append("${topic.name},\n")
        else buf = buf.append("${topic.name}\n")
        k++
    }
    buf = buf.append(" ]\n")
    echo "${buf.toString()}"

    if (!topics.isEmpty()) {
        echo "\nInizio Analisi dei singoli topic \n"
        topics.each { topic ->
            if (topic.name != null && "" != "${topic.name}") {
                KafkaTopic kTopic = new KafkaTopic("${args.kafkaConfig.envForDeploy}-${topic.name}")
                if (topic.config?.compressionType != null) {
                    kTopic.setCompressionType("${topic.config.compressionType}")
                }
                if (topic.config?.cleanupPolicy != null) {
                    kTopic.setCleanupPolicy("${topic.config.cleanupPolicy}")
                }
                if (topic.config?.deleteRetentionMs != null) {
                    kTopic.setDeleteRetentionMs("${topic.config.deleteRetentionMs}")
                }
                if (topic.config?.fileDeleteDelayMs != null) {
                    kTopic.setFileDeleteDelayMs("${topic.config.fileDeleteDelayMs}")
                }
                if (topic.config?.flushMs != null) {
                    kTopic.setFlushMs("${topic.config.flushMs}")
                }
                if (topic.config?.followerReplicationThrottledReplicas != null) {
                    kTopic.setFollowerReplicationThrottledReplicas("${topic.config.followerReplicationThrottledReplicas}")
                }
                if (topic.config?.indexIntervalBytes != null) {
                    kTopic.setIndexIntervalBytes("${topic.config.indexIntervalBytes}")
                }
                if (topic.config?.leaderReplicationThrottledReplicas != null) {
                    kTopic.setLeaderReplicationThrottledReplicas("${topic.config.leaderReplicationThrottledReplicas}")
                }
                if (topic.config?.maxMessageBytes != null) {
                    kTopic.setMaxMessageBytes("${topic.config.maxMessageBytes}")
                }
                if (topic.config?.messageDownconversionEnable != null) {
                    kTopic.setMessageDownconversionEnable("${topic.config.messageDownconversionEnable}")
                }
                if (topic.config?.messageFormatVersion != null) {
                    kTopic.setMessageFormatVersion("${topic.config.messageFormatVersion}")
                }
                if (topic.config?.messageTimestampDifferenceMaxMs != null) {
                    kTopic.setMessageTimestampDifferenceMaxMs("${topic.config.messageTimestampDifferenceMaxMs}")
                }
                if (topic.config?.compressionType != null) {
                    kTopic.setMessageTimestampType("${topic.config.messageTimestampType}")
                }
                if (topic.config?.minCleanableDirtyRatio != null) {
                    kTopic.setMinCleanableDirtyRatio("${topic.config.minCleanableDirtyRatio}")
                }
                if (topic.config?.minCompactionLagMs != null) {
                    kTopic.setMinCompactionLagMs("${topic.config.minCompactionLagMs}")
                }
                if (topic.config?.minInsyncReplicas != null) {
                    kTopic.setMinInsyncReplicas("${topic.config.minInsyncReplicas}")
                }
                if (topic.config?.preallocate != null) {
                    kTopic.setPreallocate("${topic.config.preallocate}")
                }
                if (topic.config?.retentionBytes != null) {
                    kTopic.setRetentionBytes("${topic.config.retentionBytes}")
                }
                if (topic.config?.retentionMs != null) {
                    kTopic.setRetentionMs("${topic.config.retentionMs}")
                }
                if (topic.config?.segmentBytes != null) {
                    kTopic.setSegmentBytes("${topic.config.segmentBytes}")
                }
                if (topic.config?.segmentIndexBytes != null) {
                    kTopic.setSegmentIndexBytes("${topic.config.segmentIndexBytes}")
                }
                if (topic.config?.segmentJitterMs != null) {
                    kTopic.setSegmentJitterMs("${topic.config.segmentJitterMs}")
                }
                if (topic.config?.segmentMs != null) {
                    kTopic.setSegmentMs("${topic.config.segmentMs}")
                }
                if (topic.config?.uncleanLeaderElectionEnable != null) {
                    kTopic.setUncleanLeaderElectionEnable("${topic.config.uncleanLeaderElectionEnable}")
                }
                if (topic.config?.flushMessages != null) {
                    kTopic.setFlushMessages("${topic.config.flushMessages}")
                }
                if (topic.create?.partitions != null) {
                    kTopic.setPartitions("${topic.create.partitions}")
                }
                if (topic.create?.replicationFactor != null) {
                    kTopic.setReplicationFactor("${topic.create.replicationFactor}")
                }

                String envZKTopic = envZKTopics.find { it == "${kTopic.getName().trim()}" }
                parallelStages["KAFKA-CONFIG-${kTopic.getName().trim()}"] = {
                    stage("KAFKA-CONFIG-${kTopic.getName().trim()}") {
                        if (envZKTopic != null) {
                            echo "Nella lista topic letta da Zookeeper c'è un match per la configurazione del topic: ${kTopic.getName().trim()}"
                            //Leggo configurazione del topic in esecuzione e lo confronto con quello del template
                            echo "\nControllo se ci sono variazioni per la configurazione del topic ${kTopic.getName().trim()}\n"
                            def config = kafkaManager.getTopicConfig("${kTopic.getName().trim()}")
                            echo "Configurazione letta da zookeper per il topic: ${kTopic.getName().trim()}\n\n${config}"
                            //Se la configurazione non e' cambiata "configProperties" sara' vuoto
                            //echo "Partizioni da nexus: ${kTopic.getPartitions()}\n\n${config.partitions.size()}"
                            ArrayList<TopicConfigProperty> configProperties = kTopic.getConfigChanged(config, "${config.partitions.size()}")
                            if (!configProperties.isEmpty()) {
                                echo "Sulla configurazione letta da Nexus sono state trovate variazioni rispetto alla configurazione ricevuta da Zookeeper per il topic ${kTopic.getName().trim()}\nChiamata ad ALTER TOPIC per cambiare le seguenti properties del topic ${kTopic.getName().trim()}: \n${configProperties.toString()}"
                                kafkaManager.alterTopic(kTopic, configProperties)
                            } else echo "Sulla configurazione letta da Nexus non sono state trovate variazioni rispetto alla configurazione ricevuta da Zookeeper per il topic ${kTopic.getName().trim()}\n"
                        } else {
                            //CREATE
                            echo "Chiamata a CREATE TOPIC per generare il topic ${kTopic.getName().trim()} con le seguenti properties: \n${kTopic.toString()}"
                            kafkaManager.createTopic(kTopic)
                        }
                    }
                }
            }
        }

    } else echo "\nLa configurazione dei topic scaricata dal repository Nexus è vuota!.\n"

    if (!parallelStages.isEmpty()) {
        try {
            stage("Deploy kafka-config") {
                parallel parallelStages
            }
        } catch (Exception e) {
            throw e
        }

        echo "Applico configurazione deploy kafka al database devops"
        goLiveList.add("kafka-config",args.cfgVersion)
    } else echo "Nessuna variazione nella configurazione Kafka"

    env.KAFKA_OPTS = old_kafka_opts
    echo "Fine controllo configurazione Kafka"
}

