import com.accenture.sec.utils.CommonUtils

def call(def contextDir) {
    def ret = ['total': 0, 'success': 0, 'exception': false]
    try {
        sh """#!/bin/bash
      echo "JUnit Test"
      cd ${WORKSPACE}/${contextDir}
      mvn test org.jacoco:jacoco-maven-plugin:report 2>&1 | tee test.log
      #mvn test 2>&1 | tee test.log
      exit \${PIPESTATUS[0]}
    """
    } catch (Exception ex) {
        CommonUtils.printException(this, ex)
        ret.exception = true
    } finally {
        def log = readFile(file: "${contextDir}/test.log")
        def groups = (log =~ /Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+)/)
        if (groups.size() > 0) {
            run = groups[-1][1] as Integer
            failure = groups[-1][2] as Integer
            errors = groups[-1][3] as Integer
            skipped = groups[-1][4] as Integer
            total = run - skipped
            success = total - (failure + errors)
            ret.total = total
            ret.success = success
        }
    }
    return ret
}