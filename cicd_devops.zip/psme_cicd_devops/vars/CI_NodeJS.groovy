import com.accenture.sec.managers.NexusManager
import com.accenture.sec.managers.OpenshiftAdminManager
import com.accenture.sec.managers.SonarManager
import com.accenture.sec.testers.TestResult
import com.accenture.sec.utils.CommonUtils

def call(body) {
    // evaluate the body block, and collect configuration into the object , elabora gli attributi definiti all'interno del jenkinsfile presente nel repo con il codice applicativo
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def MICROSERVICE_NAME = pipelineParams.MICROSERVICE_NAME
    def CONTEXT_DIR = pipelineParams.CONTEXT_DIR
    def SOURCE_IMAGE = pipelineParams.SOURCE_IMAGE ? pipelineParams.SOURCE_IMAGE : "openshift/nodejs:10"

    env.isFeature = 'false'
    env.createdNamespace = 'false'

    def webhook = null
    def resultTests = ['unit': ['total': 0, 'success': 0], 'component': ['total': 0, 'success': 0]]
    TestResult componentResult = null
    def failedTests = []
    def stat = [deployed: false, tested: false]
    def config = null
    def info = null

    boolean isFeature = (env.BRANCH_NAME ==~ /^feature\/.+$/)
    boolean isPR = !CommonUtils.isNullOrEmpty(env.CHANGE_ID)

    def msTokens = null
    def baseNamespace = null
    def doDeploy = false

    OpenshiftAdminManager ocpAdmMng = null
    SonarManager sonarManager = null
    NexusManager nxMgr = null

    pipeline {
        agent {
            label 'nodejs'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '15', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }

        stages {

            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {

                            info = getInfo()
                            config = loadEnvVariables(
                                    "CI",
                                    [
                                            microservice    : MICROSERVICE_NAME,
                                            notificationMail: params.NOTIFICATION_MAIL,
                                            releaseType     : "MICROSERVICE",
                                            clusterType     : 'test'
                                    ]
                            )
                            webhook = info.teamsChannelNotification.CI
                            baseNamespace = env.targetProjectOCP

                            nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)

                            // Prepare Slave
                            withCredentials([usernamePassword(credentialsId: env.gitUser, passwordVariable: 'psw', usernameVariable: 'usr')]) {
                                sh """#!/bin/bash -e
                                    git config --global user.email "noreply-jenkins@snam.it"
                                    git config --global user.name "${env.usr}"
                                    npm install -g npm@latest
                                """
                            }
                        }
                    }
                }
            }

            stage('Build App') {
                steps {
                    script {
                        ansiColor('xterm') {
                            buildNodeJS(CONTEXT_DIR)
                        }
                    }
                }
            }

            stage('Unit Test') {
                steps {
                    script {
                        ansiColor('xterm') {
                            def ret = unitTestNpm(CONTEXT_DIR)
                            resultTests.unit.total = ret.total
                            resultTests.unit.success = ret.success
                            if (ret.exception) {
                                error("Unit test falliti")
                            }
                        }
                    }
                }
            }

            stage('Sonar Test') {
                when { expression { info.sonarqube?.project_key } }
                steps {
                    script {
                        ansiColor('xterm') {
                            withCredentials([string(credentialsId: env.sonarTokenCredsId, variable: 'login_id')]) {
                                sonarManager = new SonarManager(this, env.sonarURL, env.login_id)
                            }
                            dir(CONTEXT_DIR) {
                                if(info.sonarqube.exclusions && info.sonarqube.exclusions instanceof List)
                                    info.sonarqube.exclusions = info.sonarqube.exclusions.join(',')
                                Map sonarMap = [
                                        sonarProjectKey: info.sonarqube.project_key,
                                        exclusions: info.sonarqube.exclusions
                                ]
                                if (isPR) {
                                    sonarMap.putAll([prKey: env.CHANGE_ID, prBranch: env.CHANGE_BRANCH, prTarget: env.CHANGE_TARGET])
                                } else {
                                    if (isFeature) {
                                        def parentBranch = sh(returnStdout: true, script: '''#!/bin/bash
git show-branch -a --date-order | grep '*' | grep -v "$(git rev-parse --abbrev-ref HEAD)" | grep 'release' | head -n1 | sed 's@.*\\[\\(origin/\\)\\?\\(.*\\)\\].*@\\2@' | sed 's/[\\^~].*//'
''').trim().replace('\n','')
                                        sonarMap.putAll([targetBranch: parentBranch])
                                    }
                                    sonarMap.putAll([branch: env.currentBranch, projectVersion: env.buildTag])
                                }
                                sonarManager.scanWithNpm(sonarMap)
                            }
                        }
                    }
                }
            }


            stage('Build Image') {
                when { expression { !(isFeature || isPR) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            sh """      
                                rm -rf ${WORKSPACE}/oc-build
                                mv ${WORKSPACE}/${CONTEXT_DIR}/dist/out ${WORKSPACE}/oc-build
                                if [[ -d "${WORKSPACE}/${CONTEXT_DIR}/node_modules" && ! -d "${WORKSPACE}/oc-build/node_modules" ]]; then
                                    mv ${WORKSPACE}/${CONTEXT_DIR}/node_modules ${WORKSPACE}/oc-build/
                                fi
                                # sed -i '/"build"[ ]*:.*/d' ${WORKSPACE}/oc-build/package.json
                            """
                            openshift.withCluster(env.clusterOCP) {
                                openshift.withProject(env.CICDProjectOCP) {
                                    buildImage(openshift, "${MICROSERVICE_NAME}", "${SOURCE_IMAGE}", env.buildTag, [binary: true, from_dir: true, dir: 'oc-build', env: [NPM_MIRROR: "${env.nexusURL}/repository/sec-npm-public/"]])
                                }
                            }
                            tagRepository(env.gitUser, env.msRepoURL, env.commitId, env.buildTag)
                        }
                    }
                }
            }

            stage('Archive artifact') {
                when { expression { !(isFeature || isPR) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            def filePath = createArtifact("${CONTEXT_DIR}", 'package', "${MICROSERVICE_NAME}", env.buildTag)
                            def map = [
                                    'groupId'       : "${env.nexusArtifactGroupId}",
                                    'artifactId'    : "${MICROSERVICE_NAME}",
                                    'packageVersion': env.buildTag,
                                    'packaging'     : 'zip']
                            nxMgr.upload(env.nexusArtifactRepo, filePath, map)
                        }
                    }
                }
            }

            stage('Deployment preparation test') {
                when { expression { !(isFeature || isPR) } }
                steps {
                    script {
                        ansiColor('xterm') {

                            def targetProject = "cb-test-${env.releaseNumber}"

                            echo "Checking tokens exists for ${targetProject} namespace..."
                            def replaceTokensMap = [
                                    path         : "deployment/templates/",
                                    tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${targetProject}.yaml",
                                    microservice : MICROSERVICE_NAME,
                                    dryrun       : true
                            ]
                            replaceTokens(replaceTokensMap)
                            if (!doDeploy) {
                                echo "Dryrun of the deploy in ${targetProject}..."

                                openshift.withCluster(env.clusterOCP) {
                                    deployApp(openshift, "${MICROSERVICE_NAME}", env.buildTag, [dryrun: true])
                                }
                                echo "Completed Dryrun of deploy in ${targetProject}"
                            }
                        }
                    }
                }
            }


            stage('Create dynamic namespace') {
                when { expression { doDeploy && !(isFeature || isPR) } }
                steps {
                    script {
                        ansiColor('xterm') {
                            ocpAdmMng = new OpenshiftAdminManager(this, openshift)
                            env.targetProjectOCP = "cb-dev-${MICROSERVICE_NAME.hashCode().abs()}"
                            ocpAdmMng.withCluster(env.clusterOCP) {
                                boolean isProjectCreated
                                try {
                                    isProjectCreated = ocpAdmMng.selector("project", env.targetProjectOCP).exists()
                                } catch (Exception e) {
                                    isProjectCreated = false
                                }
                                if (!isProjectCreated) {
                                    Map addRoleTo = [user: [[role: "admin", who: ["CN=Gabriele Lagana,CN=Users,DC=secreloaded,DC=sec", "CN=Konrad Poznanski,CN=Users,DC=secreloaded,DC=sec"]]]]
                                    ocpAdmMng.createProject(env.targetProjectOCP, [cicdProject: env.CICDProjectOCP, addRoleTo: addRoleTo])
                                }
                                def uid = ocpAdmMng.selector('project', env.targetProjectOCP).object().metadata.uid
                                env.kibanaLog = CommonUtils.getKibanaLogUrl([kibanaUrl: config.kibana.url, projectName: env.targetProjectOCP, projectUid: uid, dcName: MICROSERVICE_NAME])
                            }
                            env.createdNamespace = 'true'

                            /**
                             * Inserire il deploy degli stub e dei componenti necessari a contorno
                             * da definire nel file info.yaml (forse XD)
                             */
                        }
                    }
                }
            }


            stage('Deploy App') {
                when { expression { doDeploy && !(isFeature || isPR) } }
                steps {
                    script {
                        ansiColor('xterm') {

                            def replaceTokensMap = [
                                    path         : "deployment/templates/",
                                    tokenFilePath: "${env.WORKSPACE}/cicd_devops/tokens/${baseNamespace}.yaml",
                                    microservice : MICROSERVICE_NAME,
                                    dryrun       : true
                            ]
                            replaceTokens(replaceTokensMap)
                            msTokens = readYaml(file: "cicd_devops/tokens/${baseNamespace}.yaml")
                            msTokens = msTokens.get(MICROSERVICE_NAME)

                            openshift.withCluster(env.clusterOCP) {
                                openshift.withProject(env.targetProjectOCP) {
                                    env.service_url = deployApp(openshift, "${MICROSERVICE_NAME}", env.buildTag, [timeout: [time: 60, unit: 'SECONDS'], ignoreTimeout: true])
                                    stat.deployed = true
                                }
                            }
                        }
                    }
                }
            }

            stage('Service Tests') {
                when {
                    expression {
                        return (doDeploy
                                &&
                                !(isFeature || isPR)
                                &&
                                findFiles(glob: "tests/component/*.xml").size() > 0
                        )
                    }
                }
                steps {
                    script {
                        ansiColor('xterm') {

                            echo "Preparing ondemand pod for service tests"
                            /**
                             * Il pod viene creato nel namespace target
                             * che viene creato ondemand al run di questa pipeline
                             */
//                            def testToolNamespace = env.CICDProjectOCP
                            def testToolNamespace = env.targetProjectOCP

//                            def dcName = "${env.targetProjectOCP}-soapui-${MICROSERVICE_NAME}"
                            def dcName = "soapui"
                            ocpAdmMng.withCluster(env.clusterOCP) {
                                ocpAdmMng.withProject(testToolNamespace) {
                                    def podName = ocpAdmMng.createOndemandPod('cicd_devops/templates/soapui_template.yaml', [parameters: [
                                            NAME   : dcName,
                                            PROJECT: env.targetProjectOCP
                                    ]])

                                    try {
                                        // Lancio i test di tipo gateway
                                        componentResult = runSoapUITestOnPod([
                                                folder          : "tests/component/",
                                                kind            : "component",
                                                globalProperties: [:],
                                                exportResult    : true,
                                                ocpManager      : ocpAdmMng,
                                                podName         : podName
                                        ])
                                        failedTests.addAll(componentResult.getFailedWithKind())

                                    } catch (Exception e) {
                                        error("${e.getMessage()}\n${failedTests}")
                                    } finally {
                                        ocpAdmMng.scalePod(dcName, 0)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            stage('Update Manifest') {
                when {
                    expression {
                        return (!(isFeature || isPR) && !CommonUtils.isNullOrEmpty(env.releaseNumber))
                    }
                }
                steps {
                    script {
                        echo("Updating '${env.releaseNumber}' manifest for ${MICROSERVICE_NAME}")
                        Map<String, String> dbInfo = [:]
                        dbInfo.putAll(config.manifest.db)
                        boolean skipUpdate = false
                        if (fileExists("${CONTEXT_DIR}/pom.xml")) {
                            echo("Checking version of dependencies in pom . . .")
                            def pom = readMavenPom file: "${CONTEXT_DIR}/pom.xml"
                            pom.getDependencies().each { dep ->
                                if (dep.version && dep.version ==~ /.*SNAPSHOT/) {
                                    echo("${MICROSERVICE_NAME}:${env.buildTag} was builded with 'SNAPSHOT' dependencies\n${dep}")
                                    skipUpdate = true
                                    return
                                }
                            }
                        }
                        if (!skipUpdate)
                            updateDBManifest(
                                    [
                                            waveName  : env.releaseNumber,
                                            msName    : MICROSERVICE_NAME,
                                            msBuildNum: env.buildTag,
                                            msDeps    : (info.dependencies ?: info.dependences),
                                            target    : (info.target ?: 'ocp'),
                                            dbInfo    : dbInfo
                                    ]
                            )
                    }
                }
            }

        }

        post {
            always {
                deleteDir()
                script {
                    // Cancello il namespace generato dinamicamente
                    def result = currentBuild.currentResult
                    if (result == 'ABORTED')
                        return

                    if (doDeploy && env.createdNamespace.toBoolean()) {
                        ocpAdmMng.withCluster(env.clusterOCP) {
                            ocpAdmMng.deleteProject(env.targetProjectOCP, [cicdProject: env.CICDProjectOCP])
                        }
                    }

                    def qg = null
                    if (sonarManager) {
                        qg = sonarManager.waitForQualityGate()
                    }

                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    if (failedTests.size() > 0 && stat.deployed)
                        result = 'UNSTABLE'
                    def mailMessages = [
                            'SUCCESS' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} effettuato con successo in ambiente ${
                                                env.targetProjectOCP
                                            }</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]],
                            'FAILURE' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} fallito in ambiente ${
                                                env.targetProjectOCP
                                            }</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]],
                            'UNSTABLE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] instabile",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Deploy del microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} completato con successo in ambiente ${
                                                env.targetProjectOCP
                                            } ma alcuni test sono falliti</p>
       <p>${failedTests}</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]]]
                    if (((isFeature || isPR) && result != 'SUCCESS') || !(isFeature || isPR) ) {
                        notifyMail(env.committerEmail, mailMessages, result)
                    }


                    def teamsMessages = [
                            'SUCCESS' : "Il microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo",
                            'FAILURE' : "Fallito aggiornamento manifest di Release Candidate ${env.releaseNumber} per il microservizio ${MICROSERVICE_NAME} versione ${env.buildTag}",
                            'UNSTABLE': "Il microservizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo\n\nAlcuni test sono falliti"]

                    def infoMap = [
                            'Commit ID'     : "${env.commitId}",
                            'Commit Message': "${env.commitMessage}",
                            'Committer'     : "${env.committer}",
                            'Path'          : "${env.chainPath}",
                            //'Project'       : "${env.targetProjectOCP}",
                            'Microservice'  : "${MICROSERVICE_NAME}",
                            'Unit Test'     : "${resultTests.unit.success}/${resultTests.unit.total}",
                            'SUCCESS'       : ['Version Tag': "${env.buildTag}"],
                            'ACTIONS'       : [
                                    ['name': 'View Commit', 'url': "${env.gitURL}/projects/${env.gitProject}/repos/${env.msRepoName}/commits/${env.commitId}"]
                                    // ['name': 'View Kibana Log', 'url': "${env.kibanaLog}"]
                            ]
                    ]
                    if (info?.sonarqube) {
                        infoMap['ACTIONS'].add(['name': 'View Static Code Analysis', 'url': "${env.sonarURL}/dashboard?id=${info.sonarqube.project_key}&branch=${env.currentBranch.replace('/','%2F')}"])
                    }
                    componentResult && infoMap.put('Component Test', componentResult.prettyPrint())
                    qg && infoMap.put('Quality Gate', qg.label)

                    if (failedTests.size() > 0)
                        infoMap.put('Failed tests', "${failedTests}")
                    if (!(isFeature || isPR)) {
                        webhook.each {
                            notifyTeams(result, teamsMessages, it, infoMap)
                        }
                    }
                }
            }
        }

    }
}
