def call(def openshift, def node, def selenium=null){
  if(selenium){
    echo "Checking ${selenium.dc} is up"
    dcSelenium = openshift.selector('dc', selenium.dc)
    timeout(5){
      while(!dcSelenium.related('pods').logs().out.contains(selenium.check)){
        sleep(5)
      }
    }
  }
  echo "Checking ${node.dc} is up"
  dcNode = openshift.selector('dc', node.dc)
  timeout(5){
    sleep(15)
    while(!dcNode.related('pods').logs('--tail=1').out.contains(node.check)){
      sleep(5)
    }
  }
}