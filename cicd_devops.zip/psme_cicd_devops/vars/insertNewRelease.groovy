import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ManifestDAO
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dao.WaveDAO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.db.dto.ReleaseInfoDTO
import com.accenture.sec.db.dto.ManifestDTO
import com.accenture.sec.db.dto.WaveDTO
import com.accenture.sec.entities.IncreaseType
import com.accenture.sec.entities.Versioner
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args) {
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'dbInfo,wave,clusterType,changedMf')

    // Masking username & password
    args.dbInfo.username = null
    args.dbInfo.password = null

    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = initDBInfo(args)
    Connection connection = null
    def newVersion = null
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo("Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}")

        ManifestDTO manifestDTO
        ReleaseDAO releaseDAO = new ReleaseDAO(connection)

        if(args.clusterType != 'test'){
            ReleaseDTO releaseDTO = new ReleaseDTO()
            WaveDAO waveDAO = new WaveDAO(connection)
            WaveDTO waveDTO = waveDAO.getWaveByName("${args.wave}")

            releaseDTO.setMfVersion("${args.mfVersion}")
            releaseDTO.setIdWave(waveDTO.getId())
            releaseDTO.setCurrEnv("${args.clusterType}")
            if(args.clusterType == 'prod'){
                releaseDTO.setVersion("${args.releaseNumber}")
            }
            echo("releaseDAO.insert: ${releaseDTO.toString()}")
            releaseDTO = releaseDAO.insert(releaseDTO)

            if (releaseDTO == null){
                error("""Release: "${args.releaseNumber}" errore durante l'inserimento nel database devops""")
            }
        }

    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
    return newVersion
}

private Map initDBInfo(Map args) {
    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = args.dbInfo as Map
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione

    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    return dbInfo
}
