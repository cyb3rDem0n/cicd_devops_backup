def call(def openshift, def dcName, def replica){
  if(openshift.selector('dc', "${dcName}").object().spec.replicas != replica)
    openshift.selector('dc', "${dcName}").scale("--replicas=${replica}")
  if(replica != 0){
    sleep(5)
    openshift.selector("dc", "${dcName}").related('pods').untilEach(1) {
      return (it.object().status.phase == "Running")
    }
  }
}