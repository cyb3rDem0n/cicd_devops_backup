import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.MicroserviceDAO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.db.dto.MicroserviceDTO
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args) {
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'dbInfo,imagesList')
    List imagesList = args.imagesList
    List redefinedImagesList = []
    Map<String, String> dbInfo = args.dbInfo.clone() as Map
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    echo("Reading manifest ...")
    Connection connection = null

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione
    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo "Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}"
        MicroserviceDAO microserviceDAO = new MicroserviceDAO(connection)

		 echo "IMAGE_LIST: ${imagesList}" //here
        
      	imagesList.each { image ->
             echo("image: ${image}") //here
            def imageName = "${image}".tokenize(':')[0]
            if (args.diffManifestList != null) {
                echo("find ${imageName}: ${args.diffManifestList.find { it.microservice == imageName }}")
            }
            if (args.diffManifestList != null && !args.diffManifestList.find { it.microservice == imageName }) {
                return
            }
            MicroserviceDTO dto = microserviceDAO.getMicroserviceByName(imageName)
          	echo("dto: ${dto.toString()}") //here
            if (dto.target == 'ocp') {
                redefinedImagesList.add(image)
            }
        }
    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
    return redefinedImagesList
}

