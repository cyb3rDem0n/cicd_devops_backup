import groovy.json.JsonOutput

def call(def openshift, def pod, def testLabel, def map) {
    echo "\n${testLabel}"
    // map = ['testsFolder':'','testFilter':'','testParameters':[[:]]]
    def podFolder = "/tmp/${map.testsFolder.tokenize('/').pop()}"
    def resultFile = null
    openshift.exec("${pod}", "--", "mkdir", "-p", "${podFolder}")

    def testFile
    dir("${map.testsFolder}") {
        testFile= sh(returnStdout: true, script: """#!/bin/bash
            ls ${map.testFilter} 2>/dev/null
         """).trim()
    }

    if (testFile != "") {
        if (!map.testParameters instanceof ArrayList) {
            map.testParameters = [map.testParameters]
        }
        def json = JsonOutput.toJson(map.testParameters)
        writeFile(file: "${map.testsFolder}/data.json", text: json)

        openshift.rsync("${map.testsFolder}/", "${pod}:${podFolder}/")
        ret = openshift.exec("${pod}", "--", "newman", "run", "${podFolder}/${testFile}", "-d ${podFolder}/data.json", "--reporters junit,cli", "--reporter-junit-export='${podFolder}/${testFile}-report.xml'")
        println(ret.out)
        openshift.rsync("${pod}:${podFolder}/${testFile}-report.xml", "${map.testsFolder}/")
        resultFile = "${map.testsFolder}/${testFile}-report.xml"
    } else {
        echo "No ${testLabel}s available"
    }
    return resultFile
}