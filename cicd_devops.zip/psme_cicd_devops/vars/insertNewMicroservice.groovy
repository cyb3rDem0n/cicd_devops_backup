import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.MicroserviceDAO
import com.accenture.sec.db.dto.MicroserviceDTO
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args) {
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'dbInfo,microserviceName,target')

    // Masking username & password
    args.dbInfo.username = null
    args.dbInfo.password = null

    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = initDBInfo(args)
    Connection connection = null

    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo("Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}")

        MicroserviceDTO microserviceDTO = new MicroserviceDTO()
        microserviceDTO.name = args.microserviceName
        microserviceDTO.target = args.target
        microserviceDTO.enabled = true
        microserviceDTO.target = args.target

        microserviceDTO = (new MicroserviceDAO(connection)).insertIfNotExists(microserviceDTO)
        echo("Inserted -> ${microserviceDTO.toString()}")

    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
}

private Map initDBInfo(Map args) {
    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = args.dbInfo as Map
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione

    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    return dbInfo
}
