import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.DeployDAO
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dto.DeployDTO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.golive.GoLiveList

import java.sql.Connection

def call(Map<String, Object> args, List<ManifestInfoDTO> manifestInfo) {
    if (CommonUtils.isNullOrEmpty(manifestInfo))
        return
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'mfVersion,wave,dbInfo')

    // Masking username & password
    args.dbInfo.username = null
    args.dbInfo.password = null

    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = initDBInfo(args)

    Connection connection = null
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo("Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}")

        /*ReleaseInfoDTO releaseInfoDTO = null*/
        ViewDAO viewDAO = new ViewDAO(connection)
        List<ManifestInfoDTO> mfVersionList = viewDAO.getManifestListByWaveAndVersion("${args.wave}", "${args.mfVersion}")

        boolean changed = false
        //Controlla che il manifest passato, in confronto con quello su db abbia i microservizi con la stessa versione o microservizi in più
        mfVersionList.each{ dbmfInfo->
            boolean found = false
            manifestInfo.each{ mfInfo ->
                if(mfInfo.microservice == dbmfInfo.microservice){
                    found = true
                    if(mfInfo.buildNum != dbmfInfo.buildNum){
                        changed = true
                    }
                }
            }
            if(!found){
                changed = true
            }

        }
        //Controlla che che il manifest passato non abbia microservizi in meno rispetto al db
/*        if (!changed){
            manifestInfo.each{ mfInfo ->
                boolean found = false
                mfVersionList.each{  dbmfInfo ->
                    if(mfInfo.microservice == dbmfInfo.microservice){
                        found = true
                    }
                }
                if(!found){
                    changed = true
                }
            }
        }*/

        return changed
    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
}

private Map initDBInfo(Map args) {
    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = args.dbInfo as Map
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione

    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    return dbInfo
}
