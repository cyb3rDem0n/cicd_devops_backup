import com.accenture.sec.runners.RunnerResult
import com.accenture.sec.runners.ShRunner
import com.accenture.sec.utils.Colors
import com.cloudbees.groovy.cps.NonCPS

def call(def contextDir) {
    def ret = ['total': 0, 'success': 0, 'exception': false]

    timeout(5) {
        dir(contextDir) {
            echo("${Colors.Bash.BLUE}Unit Test${Colors.Bash.NC}")
            RunnerResult result = (new ShRunner(this)).execWithStatus([cmd: "npm run test --if-present"])
            ret.putAll(parseOutput(result.out))

            (result.exitCode != 0) && (ret.exception = true)
        }
    }
    return ret
}

@NonCPS
private def parseOutput(def log){
    Map ret = [success:0,total:0]
    def groups
    if(log.toString().matches(/.*Test Suites:.*/)){
        groups = (log =~ /Test Suites: (\d+) passed, (\d+) total/)
        if (groups.matches() && groups.groupCount() > 1) {
            ret.success = groups[-1][1] as Integer
            ret.total = groups[-1][2] as Integer
        }
    }else{
        int failed = 0
        int success = 0
        groups = (log =~ /(\d+) FAILED/)
        if (groups.size() > 0) {
            failed = groups[-1][1] as Integer
        }
        groups = (log =~ /(\d+) SUCCESS/)
        if (groups.size() > 0) {
            success = groups[-1][1] as Integer
        }
        ret.total = failed + success
        ret.success = success
    }
    return ret
}