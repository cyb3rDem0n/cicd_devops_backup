import com.accenture.sec.utils.CommonUtils
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import jenkins.model.Jenkins

def call(def result, def message, def webhook, def additionalInfo = [:]) {
    def color = null
    def msg = message instanceof LinkedHashMap ? message.get(result) : message
    def status = null
    if (result == 'ABORTED')
        return
    switch (result) {
        case 'Build Success':
            status = result
            color = "#008000"
            break
        case 'Build Failed':
            status = result
            color = "#FF0000"
            break
        case 'SUCCESS':
            status = result
            color = "#008000"
            break
        case 'FAILURE':
            status = result
            color = "#FF0000"
            break
        case 'UNSTABLE':
            status = result
            color = "#FFA420"
            break
        case 'ABORTED':
            status = 'Build Aborted'
            color = "#A9A9A9"
            msg = "Build aborted by user"
            break
        default:
            msg = ""
            color = "#0076D7"
            break
    }
    def startTime = (new Date(currentBuild.startTimeInMillis)).toString()
    def duration = new Date(currentBuild.duration).format("HH:mm:ss.SSS")

    def payload = """
{
    "@type": "MessageCard",
    "@context": "http://schema.org/extensions",
    "themeColor": "${color}",
    "summary": "${status}",
    "sections": [{
        "activityTitle": "Message from ${env.JOB_NAME}, Build #${env.BUILD_NUMBER}",
        "activityText": "${msg}",
        "activityImage": "",
        "facts": [{
            "name": "Status",
            "value": "${status}"
        }, {
            "name": "Start Time",
            "value": "${startTime}"
        }, {
            "name": "Duration",
            "value": "${duration} (h:m:s.ms)"
		}],
        "markdown": false
    }],
    "potentialAction": [{
        "@type": "OpenUri",
        "name": "View Build",
        "targets": [
            { "os": "default", "uri": "${env.RUN_DISPLAY_URL}" }
        ]
    }]
}"""

    payload = new JsonSlurper().parseText(payload)
    additionalInfo.each {
        if (['SUCCESS', 'FAILURE', 'UNSTABLE'].contains(it.key) && it.key == result) {
            it.value.each { v ->
                if (v.key == "SECTIONS") {
                    v.value.each { sec ->
                        payload.sections.add(sec)
                    }
                } else if (v.key == "ACTIONS") {
                    v.value.each { act ->
                        payload.potentialAction.add(['@type': 'OpenUri', 'name': act.name, 'targets': [['os': 'default', 'uri': act.url]]])
                    }
                } else {
                    payload.sections[0].facts.add(['name': v.key, 'value': v.value])
                }
            }
        } else if (it.key == "SECTIONS") {
            it.value.each { sec ->
                payload.sections.add(sec)
            }
        } else if (it.key == "ACTIONS") {
            it.value.each { act ->
                payload.potentialAction.add(['@type': 'OpenUri', 'name': act.name, 'targets': [['os': 'default', 'uri': act.url]]])
            }
        } else if (!['SUCCESS', 'FAILURE', 'UNSTABLE'].contains(it.key)) {
            payload.sections[0].facts.add(['name': it.key, 'value': it.value])
        }
    }
    // try{
    //     cause = currentBuild.getBuildCauses()[0].shortDescription
    //     payload.sections[0].facts.add(['name': 'Remarks', 'value': cause])
    // }catch(Exception e){}
    payload = JsonOutput.toJson(payload)

    Map proxy = CommonUtils.getProxyConfig()
    println("Notify Teams channel")
    def res = null
    try {
        def map = [
                httpMode       : 'POST',
                acceptType     : 'APPLICATION_JSON',
                contentType    : 'APPLICATION_JSON',
                url            : "${webhook}",
                requestBody    : payload,
                quiet          : false,
                ignoreSslErrors: true
        ]
        proxy && (map.put('httpProxy', "${proxy.name}:${proxy.port}"))
        res = httpRequest(map)
    } catch (Exception e) {
        println(e)
    }
    finally {
        // println(res.status)
    }

}