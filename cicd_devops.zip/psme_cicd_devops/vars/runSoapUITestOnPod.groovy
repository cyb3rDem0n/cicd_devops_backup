import com.accenture.sec.testers.SoapUIPodTester
import com.accenture.sec.testers.TestResult
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.Logger

def call(Map args) {
    CommonUtils.checkInputParameters(args, 'kind,folder,podName')
    echo "Preparing to run ${args.kind} tests ..."
    def testList = findFiles(glob: "${args.folder}*.xml")

    // conta i file come singoli test
    // resultTests.component.total += testList.size()
    def failed = false
    Map result
    TestResult testResult = new TestResult(args.kind)
    if (testList.size() == 0) {
        echo "No ${args.kind} test to run found with glob: '${args.glob}'"
        return testResult
    }
    SoapUIPodTester soapUIPodTester = args.ocpManager ? (new SoapUIPodTester(this, args.ocpManager, args.podName.toString())) : (new SoapUIPodTester(this, args.podName.toString()))
    soapUIPodTester.copyFiles(args.folder, '/tmp/', 'target')

    testList.each { testFile ->
        try {
            echo "Running ${testFile.name} ..."
            def outFolder = "/tmp/results/${testFile.name.replace('.xml', '')}"
            def reqMap = [
                    projectFile: "/tmp/${testFile.name}",
                    options    : ['-M', '-J', "-f${outFolder}", '-r'],
                    properties : [:]
            ]
            if (args.projectProperties) {
                reqMap.properties << [project: args.projectProperties]
            }
            if (args.globalProperties) {
                reqMap.properties << [global: args.globalProperties]
            }
            def inputFilePath = ""
            if (findFiles(glob: testFile.path.replace('.xml', '.csv'))) {
                inputFilePath = "/tmp/${testFile.name.replace('.xml', '.csv')}"
            }
            def outputFilePath = "${outFolder}/${testFile.name.replace('.xml', '-out.csv')}"
            if (reqMap.properties.global) {
                reqMap.properties.global.putAll([inputPath: inputFilePath, outputPath: outputFilePath])
            } else {
                reqMap.properties << [global: [inputPath: inputFilePath, outputPath: outputFilePath]]
            }
            result = soapUIPodTester.exec(reqMap)
            !CommonUtils.isNullOrEmpty(result.out) && echo("${result.out}")
            !CommonUtils.isNullOrEmpty(result.err) && echo("${result.err}")
            if (result.returnCode > 0) {
                failed = true
                echo "Test ${testFile.name} failed"
                testResult.addFailed(testFile.name)
            } else {
                echo "Test ${testFile.name} completed successfully"
            }
            testResult.setTestResult(testFile.name, result.testCases.total, result.testCases.success)
        } catch (Exception e) {
            failed = true
            echo "Test ${testFile.name} failed"
            testResult.addFailed(testFile.name)
            testResult.setTestResult(testFile.name, null, null)
            CommonUtils.printException(this, e, false)
            //Logger.log(this, [TEST: 'SoapUI', KIND: args.kind, EXCEPTION: e.getClass(), MESSAGE: e.getMessage(), STACKTRACE: e.getStackTrace()])
        }
    }

    if (args.exportResult) {
        echo "Exporting ${args.kind} test results from ${args.podName} ..."
        def resultFolder = "${args.kind}-result/"
        sh """#!/bin/bash
            mkdir -p ${resultFolder}
        """
        soapUIPodTester.copyFiles('/tmp/results/', "${resultFolder}", 'source')
        testResult.setResultFolder(resultFolder)
        echo "Test results exported in ${resultFolder}"
    }

    return testResult

}
