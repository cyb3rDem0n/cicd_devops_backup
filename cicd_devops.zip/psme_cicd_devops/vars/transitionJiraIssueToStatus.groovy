import com.accenture.sec.api.JiraCustomAPI
import com.accenture.sec.utils.CommonUtils

def call(Map args) {
    if(CommonUtils.isNullOrEmpty(args.issueKey))
        return
    CommonUtils.checkInputParameters(args, ["jiraConfig", "targetStatus"])
    CommonUtils.checkInputParametersOr(args, ["issueKey", "issueQuery"])
    JiraCustomAPI jiraAPI = new JiraCustomAPI(this, args.jiraConfig.url, args.jiraConfig.credsId)

    args.processAll = args.processAll ?: false

    List jiraIssues = []
    args.failOnError || (args.failOnError = false)
    if (args.issueQuery) {
        def res = jiraAPI.getIssuesFromQuery([issueQuery: args.issueQuery])
        res = res.output
        if (res.total > 0) {
            def list
            if (args.issueQueryFilter) {
                list = jiraAPI.filterIssuesFromQueryResult(res, args.issueQueryFilter as Map)
            } else {
                list = res.issues
            }
            if (args.processAll) {
                jiraIssues = list.collect { it.key }
            } else {
                if (list.size() > 1) {
                    echo("Found more than one Issue with specified query")
                    if (args.failOnError)
                        throw new Exception("*** transitionJiraIssueToStatus -> Found more than one Issue with specified query:\n${args.issueQuery}")
                } else {
                    args.issueKey = list[0].key
                    jiraIssues.add(args.issueKey)
                }
            }
        } else {
            echo("No Issue found with specified query")
            return
        }
    } else {
        jiraIssues.add(args.issueKey)
    }

    jiraIssues.each { issueKey ->
        def result = jiraAPI.transition([issueKey: issueKey, targetStatus: args.targetStatus])
        if (result.status > 399) {
            echo("There was an error changing status on Jira for isssue #${issueKey}, rest Jira endpoint returned:\nstatus: ${result.status}\nmessage: ${result.message}\n${result.error}")
        }
        echo("Transition to status '${args.targetStatus}' completed successfully on Jira issue #${issueKey} by jenkins")
        if (args.comment) {
            result = jiraAPI.addIssueComment([issueKey: issueKey, message: args.comment])
            if (result.status > 399) {
                echo("There was an error adding a comment on Jira for isssue #${issueKey}, rest Jira endpoint returned:\n${result.status}\n${result.content}")
            }
            echo("Comment successfully added on Jira issue #${issueKey} by jenkins")
        }
    }
}


