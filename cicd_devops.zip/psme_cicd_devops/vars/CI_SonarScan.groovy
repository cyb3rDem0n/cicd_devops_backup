import com.accenture.sec.managers.SonarManager
import com.accenture.sec.testers.TestResult
import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.CommonUtils

def call(body) {
    // evaluate the body block, and collect configuration into the object , elabora gli attributi definiti all'interno del jenkinsfile presente nel repo con il codice applicativo
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def MICROSERVICE_NAME = pipelineParams.MICROSERVICE_NAME
    def CONTEXT_DIR = pipelineParams.CONTEXT_DIR

    env.isFeature = 'false'
    env.createdNamespace = 'false'


    def webhook = null
    def resultTests = ['unit': ['total': 0, 'success': 0], 'component': ['total': 0, 'success': 0]]
    TestResult componentResult = null
    def failedTests = []
    def stat = [deployed: false, tested: false]
    def config = null
    def info = null

    boolean isFeature = (env.BRANCH_NAME ==~ /^feature\/.+$/)
    boolean isPR = !CommonUtils.isNullOrEmpty(env.CHANGE_ID)

    SonarManager sonarManager = null

    pipeline {
        agent {
            label 'nodejs'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '15', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        stages {
            stage('Unit Test') {
                when { expression { false } }
                steps {
                    script {
                        ansiColor('xterm') {
                            def ret = unitTestKarma(CONTEXT_DIR)
                            resultTests.unit.total = ret.total
                            resultTests.unit.success = ret.success
                            resultTests.unit.exception = ret.exception
                            if (ret.exception) {
                                error("Unit test falliti")
                            }
                        }
                    }
                }
            }

            stage('Sonar Test') {
                when { expression { info.sonarqube?.project_key } }
                steps {
                    script {
                        ansiColor('xterm') {
                            //if (!info.sonarqube?.project_key) {
                                //error("${Colors.Bash.RED}${Colors.Bash.BOLD}sonarqube.project_key is not present in info.yaml file${Colors.Bash.NC}")
                            //}
                            withCredentials([string(credentialsId: env.sonarTokenCredsId, variable: 'login_id')]) {
                                sonarManager = new SonarManager(this, env.sonarURL, env.login_id)
                            }
                            dir(CONTEXT_DIR) {
                                if (info.sonarqube.exclusions && info.sonarqube.exclusions instanceof List)
                                    info.sonarqube.exclusions = info.sonarqube.exclusions.join(',')
                                Map sonarMap = [
                                        sonarProjectKey: info.sonarqube.project_key,
                                        exclusions     : info.sonarqube.exclusions
                                ]
                                if (isPR) {
                                    sonarMap.putAll([prKey: env.CHANGE_ID, prBranch: env.CHANGE_BRANCH, prTarget: env.CHANGE_TARGET])
                                } else {
                                    if (isFeature) {
                                        def parentBranch = sh(returnStdout: true, script: '''#!/bin/bash
git show-branch -a --date-order | grep '*' | grep -v "$(git rev-parse --abbrev-ref HEAD)" | grep 'release' | head -n1 | sed 's@.*\\[\\(origin/\\)\\?\\(.*\\)\\].*@\\2@' | sed 's/[\\^~].*//'
''').trim().replace('\n', '')
                                        sonarMap.putAll([targetBranch: parentBranch])
                                    }
                                    sonarMap.putAll([branch: env.currentBranch, projectVersion: env.buildTag])
                                }
                                sonarManager.scanWithNpm(sonarMap)
                            }
                        }
                    }
                }
            }

                    }
                }
            }
