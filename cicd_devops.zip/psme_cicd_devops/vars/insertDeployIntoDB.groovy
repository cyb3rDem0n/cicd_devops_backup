def call(def credentialsId, def server, def db, def microservice, def project, def version){
  // ('jenkins-dbuser','172.25.220.6\\SNSM1389D0,1971','JARVIS-DEVOPS')
  withCredentials([usernamePassword(credentialsId: credentialsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
      sh """
        sqlcmd -S ${server} -d ${db} -U ${usr} -P ${usr} -Q "INSERT INTO dbo.Deployments(microservice,environment,version,deployed_on) VALUES('${microservice}','${project}','${version}',DEFAULT);"
      """
  }
}