def call(def credentialsId, def url, def branch, def ext = null) {
    def extensions = [[$class: 'CheckoutOption', timeout: 2], [$class: 'CloneOption', noTags: false, reference: '', shallow: false, timeout: 2]]
    ext.each { e ->
        switch (e.key) {
            case 'folder':
                extensions.add([$class: 'RelativeTargetDirectory', relativeTargetDir: e.value])
                break
            case 'shallow':
                if (e.value) {
                    extensions.find { it.get('$class') == 'CloneOption' }.putAll([depth: 0, shallow: true])
//                    extensions.add([$class: 'CloneOption', depth: 0, noTags: false, reference: '', shallow: true])
                }
                break
        }
    }
    extensions.add([$class: 'LocalBranch', localBranch: branch])
    retry(3){
        checkout(poll: false, scm: [$class: 'GitSCM', branches: [[name: branch]], doGenerateSubmoduleConfigurations: false, extensions: extensions, submoduleCfg: [], userRemoteConfigs: [[credentialsId: credentialsId, url: url]]])
    }
}