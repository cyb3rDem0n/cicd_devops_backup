def call(def browser, def seleniumServer, def baseURL, def browserConfig=[:]){

  def sideConfig = [
    'server': seleniumServer,
    'baseUrl': baseURL,
    'capabilities': [
      'browserName': browser
    ],
    'timeout': 60000
  ]
  if(browserConfig.insecure){
    sideConfig.capabilities.put('acceptInsecureCerts', true)
    sideConfig.capabilities.put('acceptSslCerts', true)
  }

  switch(browser){
    case 'chrome':
      sideConfig.capabilities.putAll(['goog:chromeOptions':['args': ['--verbose']]])
      if(browserConfig.insecure)
        sideConfig.capabilities.get('goog:chromeOptions').args.add('--ignore-certificate-errors')
      if(browserConfig.headless)
        sideConfig.capabilities.get('goog:chromeOptions').args.add('--headless')
    break
    case 'firefox':
      sideConfig.capabilities.putAll(['moz:firefoxOptions':['log': ['level': 'trace']]])
      if(browserConfig.headless)
        sideConfig.capabilities.get('moz:firefoxOptions').put('args', ['-headless'])
    break
  }

  sh """#!/bin/bash
    rm -rf "${WORKSPACE}/side/${browser}" && mkdir -p "${WORKSPACE}/side/${browser}"
  """

  writeYaml file: "${WORKSPACE}/side/${browser}/${browser}.side.yml", data: sideConfig
  return "${WORKSPACE}/side/${browser}/${browser}.side.yml"
}