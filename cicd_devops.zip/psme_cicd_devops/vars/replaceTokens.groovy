import com.accenture.sec.entities.Tokenizer
import com.accenture.sec.utils.CommonUtils

/**
 * Vecchia versione con parametri posizionali che utilizza lo script python
 *
 * @param devopsFolder
 * @param path
 * @param tokenfile
 * @param microservice
 * @param map
 * @return
 */
def call(def devopsFolder, def path, def tokenfile, def microservice, def map=[:]) {
    def scriptPath = "${devopsFolder}/scripts"
    def tokensPath = "${devopsFolder}/tokens"

    def opt = map.onlyOneFile ? "--file" : "--directory"
    def notEncode = map.notEncode ? "--not-encode" : ""
    def notDecode = map.notDecode ? "--not-decode" : ""
    def dryrun = map.dryrun ? "--dry-run" : ""

    sh """#!/bin/bash -X
        python ${scriptPath}/replace_tokens.py ${opt} "${path}" --tokenfile "${tokensPath}/${tokenfile}" -m ${microservice} ${notEncode} ${notDecode} ${dryrun}
    """

}

/**
 * Nuova implementazione con Tokenizer
 *
 * @param args
 * @return
 */
def call(Map args) {
    CommonUtils.checkInputParametersOr(args, 'path,text,glob')
    CommonUtils.checkInputParametersOr(args, 'project,tokenFilePath,tokens')
    CommonUtils.checkInputParametersOr(args, 'name,group,microservice')

    Map tokens = null
    if(args.project){
        String stringTokens = libraryResource("tokens/${args.project}.yaml")
        tokens = readYaml(text: stringTokens)
    }else if(args.tokenFilePath){
        tokens = readYaml(file: args.tokenFilePath)
    }else if(args.tokens){
        tokens = args.tokens
    }

    Tokenizer tokenizer = new Tokenizer(this, tokens)
    args.notEncode && tokenizer.setOption(Tokenizer.Option.NOT_ENCODE)
    args.notDecode && tokenizer.setOption(Tokenizer.Option.NOT_DECODE)
    args.dryRun && tokenizer.setOption(Tokenizer.Option.DRY_RUN)

    if (!args.group)
        args.group = args.name ?: args.microservice
    
    return tokenizer.process(args)
}
