import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.CommonUtils

def call(body) {
    call(false, body)
}

def call(boolean color, body) {
    call("Stage '${STAGE_NAME}'", color, body)
}

def call(def msg, body) {
    call(msg, false, body)
}


def call(def msg, boolean color, body) {
    if (CommonUtils.isNullOrEmpty(env.TERM) && color) {
        ansiColor('xterm'){
            printTime(msg, color, body)
        }
    } else {
        printTime(msg, color, body)
    }
}

private void printTime(def msg, boolean color, body) {
    long startTime = System.currentTimeMillis()
    body()
    long endTime = System.currentTimeMillis()
    long elapsedTime = endTime - startTime
    def _msg = "${msg} execution time: ${elapsedTime / 1000}s"
    if (color)
        _msg = "${Colors.Bash.BLUE}${_msg}${Colors.Bash.NC}"
    echo("${_msg}")
}