import com.accenture.sec.entities.IncreaseType
import com.accenture.sec.entities.Versioner
import com.accenture.sec.managers.NexusManager
import com.accenture.sec.managers.SonarManager
import com.accenture.sec.testers.ITester
import com.accenture.sec.testers.sti.StreamAppCaricatoreTester
import com.accenture.sec.testers.sti.StreamAppReplicatoreTester
import com.accenture.sec.testers.sti.StreamAppScodatoreTester
import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.GitAskPass

def call(body) {
    // evaluate the body block, and collect configuration into the object , elabora gli attributi definiti all'interno del jenkinsfile presente nel repo con il codice applicativo
    def pipelineParams = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    def MICROSERVICE_NAME = pipelineParams.MICROSERVICE_NAME
    def CONTEXT_DIR = pipelineParams.CONTEXT_DIR
    def SOURCE_IMAGE = pipelineParams.SOURCE_IMAGE ? pipelineParams.SOURCE_IMAGE : "openshift/openjdk18-openshift:latest"
    def ONLY_SONAR = pipelineParams.ONLY_SONAR ? pipelineParams.ONLY_SONAR : false

    env.targetProjectOCP = null
    env.CICDProjectOCP = null
    env.clusterOCP = null
    env.isFeature = 'false'

    def webhook = null
    def resultTests = ['unit': ['total': 0, 'success': 0], 'component': ['total': 0, 'success': 0]]
    def failedTests = []
    def stat = [deployed: false, tested: false]
    def config = null
    def info = null

    NexusManager nxMgr = null

    /*Nome del namespace temporaneo*/
    def ocTempProjectName = "cb-dev-streaming-${MICROSERVICE_NAME.hashCode().abs()}"
    SonarManager sonarManager = null

    pipeline {
        /* agent any*/
        agent {
            label 'maven-ci'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '15', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }

        stages {
            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {

                            info = getInfo()
                            config = loadEnvVariables(
                                    "CI",
                                    [
                                            microservice    : MICROSERVICE_NAME,
                                            notificationMail: params.NOTIFICATION_MAIL,
                                            releaseType     : "CONFLUENT",
                                            clusterType     : 'test'
                                    ]
                            )
                            ocTempProjectName = "${env.targetProjectOCP}-${MICROSERVICE_NAME.hashCode().abs()}"
                            webhook = info.teamsChannelNotification.CI
                            nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)
                            GitAskPass askpass
                            withCredentials([usernamePassword(credentialsId: env.gitUser, passwordVariable: 'password', usernameVariable: 'user')]) {
                                askpass = new GitAskPass(this, [user: "${user}", password: "${password}"])
                                askpass.init()
                            }
                            try {
                                askpass.exec("git fetch --tags >/dev/null 2>&1")
                            } catch (Exception e) {
                                echo("${Colors.Bash.RED}${Colors.Bash.BOLD}ERROR Impossibile effettuare il fetch dei tag per il repository${Colors.Bash.NC}:\n${Colors.Bash.RED}${e.toString()}${Colors.Bash.NC}")
                                currentBuild.currentResult = 'FAILURE'
                            }
                            echo "Calculating new version from repository tags..."
                            List<String> tags = sh(returnStdout: true, script: 'git tag').trim().tokenize('\n').collect {
                                it.trim()
                            }

                            List<String> versions = tags.findAll { it ==~ /${env.releaseNumber}-b\d+/ }
                            echo "tags: \n${tags} \nreleaseNumber:\n${env.releaseNumber}\nversions:${versions}"
                            // definizione del pattern della versione
                            String versionPattern = /${env.releaseNumber}-b(\d+)/
                            String versionFormat = /${env.releaseNumber}-b%d/
                            Versioner versioner = new Versioner(versionPattern, versionFormat)
                            def newVersion = versioner.nextVersion(versions, null, IncreaseType.MAJOR)
                            if (newVersion == null)
                                newVersion = "${env.releaseNumber}-b1"
                            env.buildTag = newVersion
                            echo "New version: ${env.buildTag}"

                            // Prepare Slave
                            sh """#!/bin/bash -e
                git config --global user.email "noreply@example.com"
                git config --global user.name "${env.gitUser}"
              """
                        }
                    }
                }
            }

            stage('Build App') {
                steps {
                    script {
                        ansiColor('xterm') {
                            buildMaven("${CONTEXT_DIR}")
                        }
                    }
                }
            }

            stage('Unit Test') {
                steps {
                    script {
                        ansiColor('xterm') {
                            def ret = unitTestMaven("${CONTEXT_DIR}")
                            resultTests.unit.total = ret.total
                            resultTests.unit.success = ret.success
                            if (ret.exception) {
                                error("Unit test falliti")
                            }
                        }
                    }
                }
            }

            stage('Sonar Test') {
                when { expression { !(env.isFeature.toBoolean()) && info.sonarqube?.project_key } }
                steps {
                    script {
                        ansiColor('xterm') {
                            withCredentials([string(credentialsId: env.sonarTokenCredsId, variable: 'login_id')]) {
                                sonarManager = new SonarManager(this, env.sonarURL, env.login_id)
                            }
                            dir(CONTEXT_DIR) {
                                sonarManager.scanWithMaven([sonarProjectKey: info.sonarqube.project_key, branch: env.currentBranch])
                            }
                        }
                    }
                }
            }


            stage('Archive artifact') {
                when { expression { !ONLY_SONAR } }
                steps {
                    script {
                        ansiColor('xterm') {
                            tagRepository(env.gitUser, env.msRepoURL, env.commitId, env.buildTag)
                            def filePath = createArtifact("${CONTEXT_DIR}", 'package', "${MICROSERVICE_NAME}", env.buildTag, 'vm')
                            def map = [
                                    'groupId'       : "${env.nexusArtifactGroupId}",
                                    'artifactId'    : "${MICROSERVICE_NAME}",
                                    'packageVersion': env.buildTag,
                                    'packaging'     : 'zip']
                            nxMgr.upload(env.nexusArtifactRepo, filePath, map)
                        }
                    }
                }
            }

            stage('Update Manifest') {
                when { expression { return (env.releaseNumber != null && !ONLY_SONAR) } }
                steps {
                    script {
                        echo("Updating '${env.releaseNumber}' manifest for ${MICROSERVICE_NAME}")
                        Map<String, String> dbInfo = [:]
                        dbInfo.putAll(config.manifest.db)
                        boolean skipUpdate = false
                        if (fileExists("${CONTEXT_DIR}/pom.xml")) {
                            echo("Checking version of dependencies in pom . . .")
                            def pom = readMavenPom file: "${CONTEXT_DIR}/pom.xml"
                            pom.getDependencies().each { dep ->
                                if (dep.version && dep.version ==~ /.*SNAPSHOT/) {
                                    echo("WARNING: ${MICROSERVICE_NAME}:${env.buildTag} was builded with 'SNAPSHOT' dependencies\n${dep}")
                                    skipUpdate = true
                                    return
                                }
                            }
                        }
                        if (!skipUpdate)
                            updateDBManifest(
                                    [
                                            waveName  : env.releaseNumber,
                                            msName    : MICROSERVICE_NAME,
                                            msBuildNum: env.buildTag,
                                            msDeps    : (info.dependencies ?: info.dependences),
                                            target    : (info.target ?: 'vm'),
                                            dbInfo    : dbInfo
                                    ]
                            )
                    }
                }
            }

        }

        post {
            always {
                deleteDir()
                script {

                    def result = currentBuild.currentResult
                    if (result == 'ABORTED')
                        return

                    def qg = null
                    if (sonarManager) {
                        qg = sonarManager.waitForQualityGate()
                    }

                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    if (failedTests.size() > 0 && stat.deployed)
                        result = 'UNSTABLE'
                    def mailMessages = [
                            'SUCCESS' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${
                                                env.releaseNumber
                                            } con successo</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]],
                            'FAILURE' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} non è stato aggiunto al manifest di Release Candidate ${env.releaseNumber}</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]],
                            'UNSTABLE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] instabile",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
       <p>Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo\\n\\nAlcuni test sono falliti</p>
       <p>${failedTests}</p>
       <p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                       """]]]
                    notifyMail(env.committerEmail, mailMessages, result)

                    def teamsMessages = [
                            'SUCCESS' : "Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo",
                            'FAILURE' : "Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} non è stato aggiunto al manifest di Release Candidate ${env.releaseNumber}",
                            'UNSTABLE': "Il servizio ${MICROSERVICE_NAME} versione ${env.buildTag} è stato aggiunto al manifest di Release Candidate ${env.releaseNumber} con successo\n\nAlcuni test sono falliti"]

                    def infoMap = [
                            'Commit ID'     : env.commitId,
                            'Commit Message': env.commitMessage,
                            'Committer'     : env.committer,
                            'Path'          : "${env.chainPath}",
                            'Servizio'      : "${MICROSERVICE_NAME}",
                            'Unit Test'     : "${resultTests.unit.success}/${resultTests.unit.total}",
                            'SUCCESS'       : ['Version Tag': "${env.buildTag}"], 'ACTIONS': [['name': 'View Commit', 'url': "${env.gitURL}/projects/${env.gitProject}/repos/${env.msRepoName}/commits/${env.commitId}"]]]
                    if (info?.sonarqube) {
                        infoMap['ACTIONS'].add(['name': 'View Static Code Analysis', 'url': "${env.sonarURL}/dashboard?id=${info.sonarqube.project_key}&branch=${env.currentBranch.replace('/','%2F')}"])
                    }
                    if (qg) {
                        infoMap.put('Quality Gate', qg.label)
                    }
                    if (failedTests.size() > 0)
                        infoMap.put('Failed tests', "${failedTests}")
                    webhook.each {
                        notifyTeams(result, teamsMessages, it, infoMap)
                    }
                }
            }
        }
    }
}
