import com.accenture.sec.api.BitbucketAPI
import com.accenture.sec.entities.IncreaseType
import com.accenture.sec.entities.Versioner
import com.accenture.sec.utils.CommonUtils
import com.cloudbees.groovy.cps.NonCPS


def call(def microservice, def notificationMail, Map config) {
    //def BRANCH_NAME = "master" //da elimianre perchè definito a livello di pipeline multibranch su jenkins
    // Get current commit id
    env.msRepoURL = sh(returnStdout: true, script: 'git config --get remote.origin.url').trim()
    if (!env.msRepoURL.toLowerCase().contains(env.gitProject.toLowerCase())) {
        env.gitProject = env.msRepoURL.replace("${env.gitUrl}/scm/", '').tokenize('/')[0]
    }
    env.msRepoName = sh(returnStdout: true, script: 'basename -s .git `git config --get remote.origin.url`').trim()
    env.commitId = sh(returnStdout: true, script: 'git rev-parse HEAD').trim()
    env.shortCommitId = sh(returnStdout: true, script: 'git rev-parse --short HEAD').trim()
    env.currentBranch = "${env.BRANCH_NAME}"
    env.chain = null
    def newVersionType = null
    env.isFeature = false
    boolean isFeature = false
    boolean isPR = false

    env.newVersionType = 'build'
    switch (env.currentBranch) {
        case ~/^develop$/:
            env.chain = "RELEASE"
            env.chainPath = "Release"
//            newVersionType = "minor"
            break
        case ~/^hotfix\/.*$/:
            env.chain = "FIX"
            env.chainPath = "Hot Fix"
//            newVersionType = "fix"
            env.releaseNumber = env.currentBranch.replace('hotfix/', '')
//            env.releaseStatus = 'RC'
            break
        case ~/^bugfix\/.*$/:
            env.chainPath = "Bug Fix"
//            env.newVersionType = "fix"
            //env.releaseNumber = getReleaseNumber(env, env.currentBranch)
//            env.releaseStatus = 'RC'
            break
        case ~/^release\/.*$/:
            env.chain = "RELEASE"
            env.chainPath = "Release"
//            newVersionType = "minor"

            env.releaseNumber = env.currentBranch.replace('release/', '')
            //getReleaseNumber(env, env.currentBranch)
//            env.releaseStatus = 'RC'
            break
        case ~/^feature\/.*$/:
            env.chain = "RELEASE"
            env.chainPath = "Release"
            env.isFeature = true
            isFeature = true
            break
        case ~/^PR-\d+$/:
            isPR = true
            break
//      case ~/^master$/:
//            env.chain = "RELEASE"
//            env.chainPath = "Release"
//            newVersionType = "minor"
//            break
        default:
            break
    }

    if (notificationMail != null && "${notificationMail}" != "") {
        env.committerEmail = "${notificationMail}"
    } else {
        env.committerEmail = sh(returnStdout: true, script: "git show -s --format='%ce' HEAD").trim()
    }
    env.committer = sh(returnStdout: true, script: "git show -s --format='%cn' HEAD").trim()
    env.commitMessage = sh(returnStdout: true, script: "git show -s --format='%B' HEAD").trim()

    // Check if a message is present in the PR and use it for the teams notification
    BitbucketAPI bitbucketAPI = new BitbucketAPI(this, env.gitUrl, env.gitProject, env.gitUser)
    def res = bitbucketAPI.getPullRequestsRelatedToCommit(repoName: env.msRepoName, commit: env.commitId)
    if (res.size > 0) {
        def pr = res.values.findAll { !(it.title.contains('[devops]')) }
        if (pr.size() == 1 && pr[0].description) {
            env.commitMessage = pr[0].description
        }
    }

    // Clone DevOps repo
    cloneRepo(env.gitCiCdUser, "${env.gitUrl}/scm/${env.gitCiCdProject}/${env.gitCiCdRepo}.git", "${env.sharedLibraryBranch}", [folder: 'cicd_devops', shallow: false])
    cloneRepo(config.svc.token.noprod.credsId, "${env.gitUrl}/scm/${config.svc.token.noprod.project}/${config.svc.token.noprod.repoName}.git", "master", [folder: 'cicd_devops/tokens', shallow: true])
    if (!(isFeature || isPR) && microservice && !CommonUtils.isNullOrEmpty(env.releaseNumber)) {
        // Calculate new version number
        def tags = null
        openshift.withCluster(env.clusterOCP) {
            openshift.withProject(env.CICDProjectOCP) {
                def sel = openshift.selector("is", "${microservice}")
                if (sel.count() > 0) {
                    def obj = sel.object()
                    List tmp = obj.status.tags
                    if (!CommonUtils.isNullOrEmpty(tmp)) {
                        tags = tmp.collect { it.tag }
                    }
//                    tags = obj.spec.tags
//                    List tmp = obj.status.tags.collect { [name: it.tag] }
//                    if (tags == null && tmp.size() > 0)
//                        tags = tmp
                }
            }
        }

        String emergencyFilter = (env.emergency == 'true') ? 'em-' : ''

        List<String> versions = []
        if (tags != null) {
            // aggiungo la versione dell'immagine alla lista
            // solo se matcha la versione di release

            versions = tags.findAll { it ==~ /${emergencyFilter}${env.releaseNumber}-b\d+/ }

//            tags.each {
//                if (it.name ==~ /${env.releaseNumber}-b\d+/)
//                    versions.add(it.name)
//            }
        }

        // definizione del pattern della versione
        String versionPattern = config.version?.pattern ?: /${env.releaseNumber}-b(\d+)/
        String versionFormat = config.version?.format ?: /${env.releaseNumber}-b%d/
        if (env.emergency == 'true') {
            versionPattern = /${emergencyFilter}${env.releaseNumber}-b(\d+)/
            versionFormat = /${emergencyFilter}${env.releaseNumber}-b%d/
        }
        Versioner versioner = new Versioner(versionPattern, versionFormat)

        //def newVersion = versioner.nextVersion(versions, null, IncreaseType.fromString(env.newVersionType))
        def newVersion = versioner.nextVersion(versions, null, IncreaseType.MAJOR)
        if (newVersion == null)
            newVersion = "${emergencyFilter}${env.releaseNumber}-b1"
        env.buildTag = newVersion

        echo """
    ------------ INFO ------------
    New BuildTag: ${env.buildTag}
    Mail receiver: ${env.committerEmail}
    Env Chain: ${env.chain}
    ------------------------------
    """
    }
}

private def getReleaseNumber(def env, def branchName) {
    if (!CommonUtils.isNullOrEmpty(env.releaseNumber))
        return env.releaseNumber
    return _getReleaseNumber(branchName)
}

@NonCPS
def _getReleaseNumber(def branchName) {
    def matcher = branchName =~ /^(bugfix|hotfix|release)\/(.*)$/
    String releaseNumber = matcher[0][2]
    return releaseNumber
}
