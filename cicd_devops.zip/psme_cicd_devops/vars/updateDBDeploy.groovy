import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.DeployDAO
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dao.ViewDAO
import com.accenture.sec.db.dto.DeployDTO
import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.db.dto.ReleaseInfoDTO
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.golive.GoLiveList

import java.sql.Connection

def call(Map<String, Object> args, GoLiveList goLiveList) {
    if (CommonUtils.isNullOrEmpty(goLiveList))
        return
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'env,dbInfo,wave')
    // Masking username & password
    args.dbInfo.username = null
    args.dbInfo.password = null

    echo("UpdateDB devops args -> ${args}\n\tgoLiveList -> ${goLiveList.toString()}")
    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = initDBInfo(args)

    List dtos = []

    Connection connection = null
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo("Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}")

        /*ReleaseInfoDTO releaseInfoDTO = null*/
        ViewDAO viewDAO = new ViewDAO(connection)

        goLiveList.goLiveInfos.each { info ->
            echo("info: ${info.toMap()}")
            DeployDTO dto = new DeployDTO()
            dto.setMicroservice(info.microservice as String)
            dto.setEnv(args.env as String)
            dto.settStamp(info.timestamp)
            dto.setBuildNum("${info.version}")
            if(args.wave){
                ManifestInfoDTO manifestInfoDTO = viewDAO.getManifestInfoForUpdateDeploy("${args.wave}", "${info.microservice}", "${info.version}")
                dto.setIdManifest(manifestInfoDTO.getIdManifest())
            }
            dtos.add(dto)
        }

        return dbCall(connection, dtos)
    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
}

private Map initDBInfo(Map args) {
    // Preparo l'oggetto ManifestDTO da inserire nel db
    Map<String, String> dbInfo = args.dbInfo as Map
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione

    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    return dbInfo
}

private boolean dbCall(Connection connection, List dtos) {
    try {
        // Definisco i DAO per le operazioni sul db
        DeployDAO deployDAO = new DeployDAO(connection)

        dtos.each { dto ->
            // Inserisco/aggiorno il microservizio nella tabella manifest
            echo("Insert -> ${dto.toString()}")
            deployDAO.insert(dto)
            //echo("Insert -> ${dto.toString()}")
        }
    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
    return true
}