import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.CommonUtils

def call(String tool, Map args) {
    def allowed = ['liquibase', 'flyway']
    if (!(tool in allowed)) {
        throw new Exception("DBMigrationError: tool '${tool}' not supported. Are allowed ${allowed}")
    }
    String _check = 'migrationFolder,msName'
    tool == 'liquibase' && (_check += ',changeLog')

    CommonUtils.checkInputParameters(args, _check)
    CommonUtils.checkInputParametersOr(args, 'tokenFilePath,project,tokens')
    args.clean = args.get('clean', false)

    echo("Start migration with ${tool} tool . . .")

    String configFileName = (tool == 'liquibase') ? 'liquibase.properties' : 'flyway.conf'
    echo("Preparing ${configFileName} for the migration . . .")
    String config = libraryResource("common/dbmigration/${configFileName}")
    Map replaceTokensMap = [
            text        : config,
            microservice: args.msName,
            notEncode   : true,
            notDecode   : true
    ]
    Map replaceTokensMapAppend = null
    if(args.tokenFilePath){
        replaceTokensMapAppend = [tokenFilePath: args.tokenFilePath]
    }else if(args.project){
        replaceTokensMapAppend = [project: args.project]
    }else if(args.tokens){
        replaceTokensMapAppend = [tokens: args.tokens]
    }
    replaceTokensMapAppend && replaceTokensMap.putAll(replaceTokensMapAppend)
    config = replaceTokens(replaceTokensMap)
    if (tool in ['flyway', 'liquibase']) {
        def glob = tool == 'flyway' ? "${args.migrationFolder}/database/afterMigrate__*.sql" : "${args.migrationFolder}/afterMigrate__*.sql"
        replaceTokensMap = [
                glob        : glob,
                microservice: args.msName,
                notEncode   : true,
                notDecode   : true
        ]
        replaceTokensMapAppend && replaceTokensMap.putAll(replaceTokensMapAppend)
        replaceTokens(replaceTokensMap)
    }
    dir(args.migrationFolder) {
        writeFile(file: configFileName, text: config)
        switch (tool) {
            case 'flyway':
                if (!CommonUtils.isNullOrEmpty(config.findAll(/[^#]*flyway\.licenseKey=[A-Z0-9]+/)))
                    args.enterprise = true
                flywayMigrate(args)
                break
            case 'liquibase':
                liquibaseMigrate(args)
                break
            default:
                break
        }
    }
    echo("Completed migration.")
}

private void liquibaseMigrate(Map args) {
    args.logLevel = args.logLevel ?: 'info'
    if (args.clean) {
        sh """#!/bin/bash -e
            echo "liquibase --logLevel ${args.logLevel} dropAll"
            liquibase --logLevel ${args.logLevel} dropAll
        """
        if (CommonUtils.isNullOrEmpty(args.contexts)) {
            args.contexts = 'onClean'
        } else if (!args.contexts.contains('onClean')) {
            args.contexts += ',onClean'
        }
    }else {        
        if (CommonUtils.isNullOrEmpty(args.contexts)) {
            args.contexts = 'default'
        } else if (!args.contexts.contains('default')) {
            args.contexts += ',default'
        }
    }
    String contexts = args.contexts ? "--contexts='${args.contexts}'" : ''
    String labels = args.labels ? "--labels='${args.labels}" : ''
    sh """#!/bin/bash -e
        echo "liquibase --logLevel ${args.logLevel} ${labels} ${contexts} --changeLogFile=${args.changeLog} update"
        liquibase --logLevel ${args.logLevel} ${labels} ${contexts} --changeLogFile=${args.changeLog} update
    """
}

private void flywayMigrate(Map args) {
    def JAVA_TOOL_OPTIONS = env.JAVA_TOOL_OPTIONS
    env.JAVA_TOOL_OPTIONS = ''
    String enterprise = args.enterprise ? '-enterprise' : (args.pro ? '-pro' : '')
    // Rimuovo tutte le callback eccetto le afterMigrate__*
    sh("""#!/bin/bash -e
        find ./database ! -name 'afterMigrate__*.sql' ! -name 'V*__*.sql' ! -name 'R*__*.sql' ! -name 'U*__*.sql' -type f -exec rm -f {} +
    """)
    timeout(15) {
        echo "Running in a test environment? ${args.clean}"
        if (args.clean) {
            sh("""#!/bin/bash -e
                echo "${Colors.Bash.BLUE}flyway ${enterprise} clean${Colors.Bash.NC}\n"
                flyway ${enterprise} clean
            """)
        } else {
            // Rimuove tutti i file afterMigrate eccetto afterMigrate__permissions.sql
            sh("""#!/bin/bash
                find ./database -name 'afterMigrate__*' ! -name 'afterMigrate__permissions.sql' -type f -exec rm -f {} +
            """)
        }
        sh """#!/bin/bash
            echo "${Colors.Bash.BLUE}flyway ${enterprise} -locations=filesystem:database migrate${Colors.Bash.NC}\n"
            flyway ${enterprise} -locations=filesystem:database migrate 2> flyway-error.log
            RC=\$?
            if [[ \$RC -ne 0 ]]; then
              cat flyway-error.log
              exit \$RC
            fi
        """
    }
    env.JAVA_TOOL_OPTIONS = JAVA_TOOL_OPTIONS
}