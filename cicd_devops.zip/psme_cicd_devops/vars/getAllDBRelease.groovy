import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.ReleaseDAO
import com.accenture.sec.db.dto.ReleaseDTO
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args) {
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args, 'releaseStatus,dbInfo')
    Map<String, String> dbInfo = [:]
    dbInfo.putAll(args.dbInfo)
    CommonUtils.checkInputParameters(dbInfo, 'type,host,database,credsId')

    echo("Reading releases with status ${args.releaseStatus}")
    List<ReleaseDTO> releases = []
    List releasesMap = null
    Connection connection = null

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione
    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo "Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}"

        // Definisco i DAO per le operazioni sul db
        ReleaseDAO releaseDAO = new ReleaseDAO(connection)
        // Recupero le release e controllo che esistano
        def tmpReleases = args.releaseType != null ? releaseDAO.getAllReleaseFromStatusAndType(args.releaseStatus as String, args.releaseType as String) : releaseDAO.getAllReleaseFromStatus(args.releaseStatus as String)
        if (CommonUtils.isNullOrEmpty(tmpReleases)) {
            def msg = "No release available for " + (args.releaseType != null ? "${args.releaseType}:" : '') + "${args.releaseStatus}"
            throw new Exception(msg)
        }
        tmpReleases.each { release ->
            if (releaseDAO.hasManifest(release))
                releases.add(release)
        }
        // stampo la lista delle release recuperate come mappe
        releasesMap = convertReleaseList(releases)
        echo("Selected releases -> ${releasesMap}")

    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
    if (args.toMap)
        return releasesMap
    return releases
}

private List convertReleaseList(List<ReleaseDTO> releases) {
    List answer = []
    releases.each { release ->
        answer.add(release.toMap())
    }
    return answer
}
