def call(def path = '') {
    def info = null
    if (path != '') {
        info = readYaml file: "${path}/info.yaml"
    } else {
        info = readYaml file: "info.yaml"
    }
    return info
}