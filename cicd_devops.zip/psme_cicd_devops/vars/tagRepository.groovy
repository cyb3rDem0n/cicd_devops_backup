import com.accenture.sec.utils.GitAskPass

def call(def credentialsId, def repoURL, def commitId, def version) {
    GitAskPass askpass
    withCredentials([usernamePassword(credentialsId: credentialsId, passwordVariable: 'password', usernameVariable: 'user')]) {
        askpass = new GitAskPass(this, [user: "${user}", password: "${password}"])
    }
    askpass.init()
    askpass.exec("""git tag -a '${version}' -m "Adding tag" ${commitId}""")
    askpass.exec("""git push --tags""")
}

  
