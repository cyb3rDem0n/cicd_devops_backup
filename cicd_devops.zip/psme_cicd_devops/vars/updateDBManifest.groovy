import com.accenture.sec.db.DataSource
import com.accenture.sec.db.dao.BuildDAO
import com.accenture.sec.db.dao.MicroserviceDAO
import com.accenture.sec.db.dao.WaveDAO
import com.accenture.sec.db.dto.BuildDTO
import com.accenture.sec.db.dto.MicroserviceDTO
import com.accenture.sec.db.dto.WaveDTO
import com.accenture.sec.utils.CommonUtils

import java.sql.Connection

def call(Map<String, Object> args){
    // Controllo che esistano tutti i parametri in input obbligatori e che non siano nulli
    CommonUtils.checkInputParameters(args,'waveName,msName,msBuildNum,dbInfo')
    Map<String, String> dbInfo = [:]
    dbInfo.putAll(args.dbInfo)
    CommonUtils.checkInputParameters(dbInfo,'type,host,database,credsId')

    echo("Updating manifest for ${args.msName} . . .")
    Connection connection = null

    // Recupero username e password della connessione al db e
    // li inserisco nella mappa di configurazione della connessione
    withCredentials([usernamePassword(credentialsId: dbInfo.credsId, passwordVariable: 'psw', usernameVariable: 'usr')]) {
        dbInfo.username = env.usr
        dbInfo.password = env.psw
    }
    try {
        // Istanzio una connessione al db
        DataSource ds = DataSource.getInstance()
        connection = ds.setupConnection(dbInfo)
        echo("Connected to ${dbInfo.type} -> ${dbInfo.host}:${dbInfo.port}")

        // Definisco i DAO per le operazioni sul db
        BuildDAO manifestDAO = new BuildDAO(connection)
        MicroserviceDAO microserviceDAO = new MicroserviceDAO(connection)
        WaveDAO waveDAO = new WaveDAO(connection)
        //Recupero id microservizio
        MicroserviceDTO microserviceDTO = new MicroserviceDTO()
        microserviceDTO.setName(args.msName as String)
        microserviceDTO.setTarget(args.target as String)
        microserviceDTO = microserviceDAO.insertIfNotExists(microserviceDTO)
        WaveDTO waveDTO = new WaveDTO()
        waveDTO.setName(args.waveName as String)
        waveDTO.setVersion(args.waveName.replaceAll(/[a-zA-Z._-]+/,'') as Long)
        waveDTO = waveDAO.insertIfNotExists(waveDTO)
        // Preparo l'oggetto ManifestDTO da inserire nel db
        BuildDTO dto = new BuildDTO()
        dto.setIdMs(microserviceDTO.getId())
        dto.setIdWave(waveDTO.getId())
        dto.setBuildNum(args.msBuildNum as String)
        if(args.msDeps)
            dto.setDeps(args.msDeps)
        else dto.setDeps(new ArrayList<String>())
        // Inserisco/aggiorno il microservizio nella tabella manifest
        dto = manifestDAO.insert(dto)
        echo("Updated -> ${dto.toString()}")
    } catch (Exception e) {
        throw e
    } finally {
        if (connection != null)
            connection.close()
    }
}