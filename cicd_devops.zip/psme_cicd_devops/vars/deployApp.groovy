import hudson.AbortException


def call( def openshift, def microservice, def version, Map args = [:]) {
    def service_name = null
    def route = null
    def readinessPath = null
    //sleep(600)
    args.templatesPath = args.templatesPath ?: "deployment/templates"
    def list = openshift.process("-f", "${args.templatesPath}/${microservice}_template.yaml", "-p=IMAGE_TAG=${version}", "--local")
    if (args.dryrun)
        return
    def _timeout = args.timeout ?: 10
    def dc_updated = false
    def map_updated = false
    def dc_name = null
    for (el in list) {
        echo("Processing ${el.kind.toLowerCase()}/${el.metadata.name}...")
        def sel = openshift.selector("${el.kind.toLowerCase()}/${el.metadata.name}")
        if (!sel.exists()) {
            result = openshift.create(el)
            if (el.kind.toLowerCase() == "deploymentconfig") {
                dc_updated = true
            }
            echo("Created ${el.kind.toLowerCase()}/${el.metadata.name}")
        } else {
            if (el.kind.toLowerCase() == "persistentvolumeclaim") {
                continue
            } else if (el.kind.toLowerCase() == "route") {
                result = openshift.replace(el, '--force=true', '--grace-period=0')
                //result = openshift.replace(el,'--grace-period=')
                echo("Updated ${el.kind.toLowerCase()}/${el.metadata.name}")
                continue
            }
            def revision = sel.object().metadata.resourceVersion
            def result = openshift.apply(el, '--overwrite')
            if (revision != "${result.object().metadata.resourceVersion}") {
                if (el.kind.toLowerCase() == "deploymentconfig") {
                    dc_updated = true
                } else if (el.kind.toLowerCase() in ['configmap', 'secret']) {
                    map_updated = true
                }
                echo("Updated ${el.kind.toLowerCase()}/${el.metadata.name}")
            } else {
                echo("There are no changes on ${el.kind.toLowerCase()}/${el.metadata.name}")
            }
        }
        if (el.kind.toLowerCase() == "deploymentconfig") {
            dc_name = el.metadata.name
            container = el.spec.template.spec.containers[0]
            def readinessProbe = container.get('readinessProbe')
            if (readinessProbe != null && readinessProbe.httpGet != null) {
                readinessPath = readinessProbe.httpGet.path
            }
        } else if (el.kind.toLowerCase() == "service") {
            service_name = el.metadata.name
        } else if (el.kind.toLowerCase() == "route") {
            // route = "http://${el.spec.host}:${el.spec.port.targetPort.replace('-tcp','')}"
            route = "https://${el.spec.host}"
            if (el.spec.path) {
                route = "${route}${el.spec.path}"
            }
        }
    }
    try {
        timeout(_timeout) {
            def rollout = openshift.selector("dc", "${dc_name}").rollout()
            sleep(2) // step sleep in secondi
            String lastStatus = openshift.raw("rollout history dc/${dc_name}").actions[0].out.tokenize('\n')[-1].tokenize('\t')[1].trim()
            if (!dc_updated || map_updated || lastStatus == 'Failed' || (args.force && !(lastStatus in ['Pending', 'Running']))) {
                echo "Manual rollout..."
                try {
                    rollout.latest()
                } catch (Exception rollEx) {
                    if (!rollEx.getMessage().contains('is already in progress')) {
                        throw rollEx
                    }
                }
            }
            rollout.status()
        }
    } catch (Exception e) {
        if (e instanceof InterruptedException || (e instanceof AbortException && (e.getMessage().contains('error: watch closed before Until timeout') || e.getMessage().contains('has failed progressing')))) {
            echo("Timeout for ${dc_name}")
            def dc = openshift.selector("dc", "${dc_name}").object()
            def selectorPods = openshift.selector('pods', [deployment: "${dc.metadata.name}-${dc.status.latestVersion}"])
            def podEvents = parseEvents(openshift, selectorPods)
            echo("podEvents: ${podEvents}")
            if (podEvents) {
                error("***During Pod creation*** ${dc_name} is not starting correctly.\n\n${podEvents}")
            }
            if (!args.get('ignoreTimeout', false)) {
                if (!podEvents) {
                    def podLog
                    try {
                        echo("getting pod logs")
                        podLog = parseLogs(openshift, selectorPods)
                    } catch (Exception exLog) {
                        echo("Unable to get pod logs\nException: ${exLog.toString()}")
                        throw e
                    }
                    error("***Timeout during pod startup*** ${dc_name} is not starting correctly. Check the pod log on openshift or above in pipeline log to check the reason\n\n${podLog}")
                }
            }
        } else {
            echo("Exception: ${e.toString()}")
            throw e
        }
    }

    if (route) {
        env.route = route
    }
    if (service_name) {
        def context = "${microservice}"
        if (readinessPath) {
            context = readinessPath.replaceAll('/', '')
        }
        def baseURL = "http://${service_name}.${openshift.project()}.svc:8080"
        if (context == '/') {
            return baseURL
        }
        return "${baseURL}/${context}"
    }
    return null
}

private def parseEvents(def openshift, def selectorPods) {
    def events = openshift.selector('events').objects()
    def podNames = (selectorPods.names().collect { return it.replace('pod/', '') })
    def msg = ""
    String formatStr
    podNames.each { podName ->
        def podEvents = events.findAll {
            it.involvedObject.kind == "Pod" && it.involvedObject.name == podName
        }
        if (podEvents.find { it.reason == 'Failed' }) {
            def types = podEvents.collect { return it.type }
            def reasons = podEvents.collect { return it.reason }
            int typeLen = types.max { it.size() }.size() + 3
            int reasonLen = reasons.max { it.size() }.size() + 3

            formatStr = "| %-${typeLen}s\t| %-${reasonLen}s\t| %s \n".toString()
            msg += "***************************** ${podName} *****************************\n"
            msg += String.format(formatStr, "Type", "Reason", "Message")
            msg += String.format(formatStr, "---------", "---------", "---------")
            podEvents.each { event ->
                msg += String.format(formatStr, event.type, event.reason, event.message)
            }
            msg += "*******************************************************************\n\n"
        }
    }
    return (msg == "" ? null : msg)
}

private def parseLogs(def openshift, def selectorPods, def pipeline = null) {
    pipeline && pipeline.echo("Getting logs of failed pods")
    def _logs = []
    def podNames = selectorPods.names().collect { return it.replace('pod/', '') }
    pipeline && pipeline.echo("podNames: ${podNames}")
    boolean skip = false
    podNames.each { podName ->
        if (skip)
            return
        try {
            pipeline && pipeline.echo("Getting logs for: ${podName}")
            _logs.add("***************************** ${podName} *****************************")
            def since = openshift.project().contains('test') ? '--since=10s' : ''
            def tail = '--tail=500'
            def logs = openshift.raw("logs ${tail} pod/${podName}").actions[0].out.tokenize('\n')
            pipeline && pipeline.echo("logs for ${podName}: \n${logs}")
            _logs.addAll(logs)
        } catch (Exception e) {
            if (e.getMessage().contains("CreateContainerConfigError")) {
                _logs.add("*** Error on the container configuration")
                _logs.add("*** Check on: ${openshift.cluster()}/console/project/${openshift.project()}/browse/${podName}?tab=details")
            } else {
                _logs.add("*** Pod is not creating correctly")
            }
        } finally {
            _logs.add("***************************** END LOG *****************************\n")
        }
        skip = true // stampa il log di un solo pod?
    }
    return _logs.join('\n')
}
