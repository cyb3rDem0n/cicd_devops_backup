import com.accenture.sec.utils.Colors

def call(def contextDir) {
    def buildPath
    dir(contextDir){
        sh """#!/bin/bash -e
        	echo "\nDownloading dependencies...\n"
            echo "${Colors.Bash.BLUE}npm i -dd${Colors.Bash.NC}\n"
           	# npm cache clean -f
            npm i -dd
            cat package.json
            echo "\nBuilding App...\n"
            echo "${Colors.Bash.BLUE}ng build --prod${Colors.Bash.NC}\n"
            pwd
            ls -a
            npm -dd run build-jenkins
        """

        def angularJson = readJSON(file: "${WORKSPACE}/${contextDir}/angular.json")
        def defaultProject = angularJson.defaultProject
        buildPath = angularJson.projects[defaultProject].architect.build.options.outputPath
    }
    return buildPath
}
