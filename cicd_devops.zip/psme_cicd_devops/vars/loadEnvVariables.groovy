import com.accenture.sec.utils.CommonUtils

def call(String cicdChain = null, Map infoMap = [:]) {
    def configText = ""

    echo("Recupero il branch della shared library")
//    def jobName = env.JOB_NAME
//    if(env.JOB_BASE_NAME.contains('/')){
//        jobName = jobName.replace(env.JOB_BASE_NAME, env.JOB_BASE_NAME.replace('/','%2F'))
//    }
//    env.sharedLibraryBranch = CommonUtils.getSharedLibraryBranch(jobName, env.BUILD_NUMBER)
    if(!env.sharedLibraryBranch)
        env.sharedLibraryBranch = CommonUtils.getSharedLibraryBranch(currentBuild)

    echo "Carico config.yaml dal resources della shared library"
    if (env.sharedLibraryBranch.equals("master")) {
        configText = libraryResource("master/config.yaml")
        echo("Leggo master/config.yaml")
    } else if(env.sharedLibraryBranch.equals("target")){
        configText = libraryResource("target/config.yaml")
        echo("Leggo target/config.yaml")
    } else {
        configText = libraryResource("develop/config.yaml")
        echo("Leggo develop/config.yaml")
    }
    // Get configs

    def config = readYaml(text: "${configText}")
    def step = null

    if (cicdChain) {
        // recupero chain
        // CASO CI => la recupero partendo dal branch da cui sto buildando
        if (cicdChain.equals("CI")) {
            env.currentBranch = "${env.BRANCH_NAME}"
            switch (env.currentBranch) {
                case ~/^develop$/:
                    step = "RELEASE"
                    env.chainPath = "Release"
                    break
                case ~/^hotfix\/.*$/:
                    step = "FIX"
                    env.chainPath = "Hot Fix"
                    break
                case ~/^bugfix\/.*$/:
                    // non setto lo step per bugfix, dedicato a build di emergenza
                    //step = "FIX"
                    env.chainPath = "Bug Fix"
                    break
                case ~/^release\/.*$/:
                    step = "RELEASE"
                    env.chainPath = "Release"
                    break
                case ~/^feature\/.*$/:
                    step = "RELEASE"
                    env.chainPath = "Release"
                    env.isFeature = true
                    break
                default:
                    break
            }
            if(infoMap.containsKey('step')){
                step = infoMap.step
            }
        } else {
            // qualsiasi caso (per ora solo CD), la recupero dalla mappa passata in input
            step = infoMap.step
        }
    }


    // variabili d'ambiente per OCP
    infoMap.releaseType = infoMap.releaseType ?: "MICROSERVICE"
    infoMap.clusterType = infoMap.clusterType ?: "test"

    env.clusterOCP = config.ocp[infoMap.clusterType].cluster
    env.clusterCredsId = config.ocp[infoMap.clusterType].credsId
    env.CICDProjectOCP = config.ocp[infoMap.clusterType].project.cicd
    env.ocpAppLabel = config.ocp.filter?.appLabel
    env.ocpSecretPrefix = config.ocp.filter?.secretPrefix
    if (cicdChain && step) {
        env.targetProjectOCP = config.ocp[infoMap.clusterType].project[cicdChain][infoMap.releaseType][step]
        env.step = step
    }

    env.gitURL = config.svc.url
    env.gitUser = config.svc.credsId
    env.gitApproverUser = config.svc.approverCredsId
    env.gitProject = config.svc.project
    env.gitCiCdProject = config.svc.cicd.project
    env.gitCiCdRepo = config.svc.cicd.repoName
    env.gitCiCdUser = (config.svc.cicd.credsId ?: config.svc.credsId)

    env.sonarURL = config.sonarqube.url
    env.sonarTokenCredsId = config.sonarqube.tokenCredsId

    env.nexusURL = config.nexus.url
    env.nexusUser = config.nexus.credsId
    env.nexusArtifactRepo = config.nexus.artifact.repository
    env.nexusArtifactGroupId = config.nexus.artifact.group

    env.seleniumServer = config.selenium.url

    // carico variabili specifiche per pipeline di tipo CI
    if (cicdChain && cicdChain.equals("CI")) {

        echo "Preparo variabili d'ambiente per pipeline CI"
        CIPrepareEnvVariables(infoMap.microservice, infoMap.notificationMail, config)
    }

    return config
}