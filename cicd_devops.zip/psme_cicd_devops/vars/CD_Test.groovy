import com.accenture.sec.db.dto.ManifestInfoDTO
import com.accenture.sec.managers.Deployer
import com.accenture.sec.managers.NexusManager
import com.accenture.sec.managers.OpenshiftAdminManager
import com.accenture.sec.testers.TestResult
import com.accenture.sec.utils.Colors
import com.accenture.sec.utils.CommonUtils
import com.accenture.sec.utils.Manifest
import com.accenture.sec.utils.OpenshiftUtils

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def pipelineParams = [:]
    def servicesURL = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

    env.manifestFile = null
    env.chain = pipelineParams.TYPE
    env.releaseType = "MICROSERVICE"
    env.clusterOCP = null
    env.targetProjectOCP = null

    Manifest manifest = null
    List deployGroupsList = []

    def testNotifications = [:]
    def notificationManifest = null
    def webhook = null
    def failedTests = []
    def tests = null
    def services = null
    def config = null

    def statefulSets = ['datagrid-service']

    def stat = ['deployed': false, 'test': false]

    OpenshiftAdminManager ocpAdmMng = null
    NexusManager nxMgr = null

    def doDeploy = false

    pipeline {
        agent {
            label 'cd-test-maven'
        }

        options {
            disableConcurrentBuilds()
            timeout(time: 60, unit: 'MINUTES')
            buildDiscarder(logRotator(daysToKeepStr: '3', numToKeepStr: '15', artifactNumToKeepStr: '30'))
        }

        parameters {
            string(name: 'WAVE', description: 'Define wave to be deployed')
            choice(name: 'TESTS', choices: '\nrelease\nnoregression', description: 'Choose the tests that have to be run')
            booleanParam(name: 'FORCE_RELEASE_TESTS', defaultValue: false, description: '')
            booleanParam(name: 'FORCE_REDEPLOY', defaultValue: false, description: 'If true force redeploy of all MS in manifest')
            booleanParam(name: 'SKIP_KAFKA', defaultValue: false, description: 'If true and FORCE_REDEPLOY is true skip the deploy of kafka')
            string(name: 'NOTIFICATION_MAIL', defaultValue: '', description: 'Insert mails to be notified, comma separated. This override the mail of the last committer')
        }


        stages {

            stage('Preliminary steps') {
                steps {
                    script {
                        ansiColor('xterm') {

                            printTime() {
                                if (CommonUtils.isNullOrEmpty(params.WAVE)) {
                                    error("WAVE parameter is mandatory")
                                }

                                config = loadEnvVariables(
                                        "CD",
                                        [
                                                step       : env.chain,
                                                releaseType: env.releaseType,
                                                clusterType: 'test'
                                        ])
                                env.e2eRepoURL = config.e2e_repo_url
                                webhook = config.teamsChannelNotification.CD[env.releaseType][env.chain]

                                nxMgr = new NexusManager(this, env.nexusURL, env.nexusUser)
                                ocpAdmMng = new OpenshiftAdminManager(this)

                                //env.targetProjectOCP = "${env.targetProjectOCP}-${params.WAVE}"
								// Il namespace su OpenShift è stato denominato psme-wave1, e non con la vecchia combinazione in stile: am-test-amlet-wave1
                              	env.targetProjectOCP = "${params.WAVE}"

                                if (params.TESTS) {
                                    switch (params.TESTS) {
                                        case 'release':
                                            tests = 'release'
                                            break
                                        case 'noregression':
                                            tests = 'noregression'
                                            break
                                        default:
                                            tests = null
                                            break
                                    }
                                }

                                // download del repository con i test automatizzati
                                cloneRepo(env.gitUser, env.e2eRepoURL, 'master', [folder: 'e2eTests', shallow: true])
                                cloneRepo(config.svc.token.noprod.credsId, "${env.gitUrl}/scm/${config.svc.token.noprod.project}/${config.svc.token.noprod.repoName}.git", "master", [folder: 'tokens', shallow: true])

                                // Prepare Slave
                                sh """#!/bin/bash -e
                git config --global user.email "noreply@example.com"
                git config --global user.name "${env.gitUser}"
              """
                                echo """
              ------------------------------------------------
              Path: ${env.chain}
              Release Selected: ${params.WAVE}
              Project: ${env.targetProjectOCP}
              ------------------------------------------------
              """
                            }
                        }
                    }
                }
            }

            stage('Calculate manifest') {
                steps {
                    script {
                        ansiColor('xterm') {
                            printTime() {
                                echo "Calculating current manifest for ${params.WAVE}..."
                                manifest = new Manifest(this)
                                manifest.init([version: "${params.WAVE}", dbInfo: config.manifest.db, env: "${env.targetProjectOCP}"])
                                manifest.getManifestListFromDb([projectPrefix: "${config.svc.project.toLowerCase()}"])

                                // Calcolo il manifest corrente dell'ambiente, leggendo i MS dal namespace ocp e da DB
                                debug("Calcolo il manifest corrente...")
                                def filterMap = [
                                        dc         : [labels: [app: config.ocp.filter.appLabel]],
                                        statefulset: [labels: [template: 'datagrid-service']]
                                ]
                                manifest.calculateCurrDeployManifestList([cluster: env.clusterOCP, project: env.targetProjectOCP], filterMap, null, ['kafka-config'])
                                // Se FORCE_REDEPLOY il manifest da deployare non sarà la differenza con quello già presente sul namespace,
                                // ma tutto quello passato in input verrà rideployato a prescindere
                                debug("Setting Force Redeploy...")
                                manifest.setForceRedeploy(params.FORCE_REDEPLOY)

                                // Calcolo il manifest completo dell'ambiente come unione del manifest calcolato dal DB con quello presente sullambiente
                                // Operazione effettuata per calcolare correttamente le dipendenze qual'ora ci siano
                                debug("Preparo skiplist...")
                                List skipList = ['kafka-config']
                                skipList.addAll(statefulSets)
//                                //Se il namespace e' vuoto lo imposto con quanto selezionato da db
//                                if(manifest.getNamespaceManifestInfo().isEmpty()){
//                                    manifest.setCurrDeployManifestList(manifest.getManifestInfo())
//                                }
                                debug("Manifest.calculateFullDeployManifestList...")
                                List fullManifest = Manifest.calculateFullDeployManifestList(manifest.getCurrDeployManifestList(), manifest.getNamespaceManifestInfo())
                                debug("Deployer.createDeployGroupList...")
                                try {
                                    timeout(120) {
                                        deployGroupsList = Deployer.createDeployGroupList(manifest.toDeployableMap(fullManifest, skipList, false), this)
                                        echo("deployGroupsList: ${deployGroupsList}")
                                    }
                                } catch (Exception e) {
                                    if(e instanceof InterruptedException){
                                        error("${Colors.Bash.RED}Calcolo delle dipendenze ha impiegato più di 2 minuti. Controllare nel log sopra il motivo del loop${Colors.Bash.NC}")
                                    }else{
                                        throw e
                                    }
                                }

                                notificationManifest = Manifest.prettyPrint(manifest.getManifestInfo(), true)

                                echo "Calculated diff manifest:\n${Manifest.toMap(manifest.getCurrDeployManifestList())}"
                                // Controllo quante differenze ci sono nel manifest per decidere se deployare o meno
                                doDeploy = manifest.getCurrDeployManifestList().size() > 0 && tests != 'noregression'
                            }
                        }
                    }
                }
            }

            stage("Deploy in Test Environment") {
                when { expression { doDeploy } }
                steps {
                    script {
                        ansiColor('xterm') {
                            printTime() {
/*                                //DA RIMUOVERE PER ABILITARE KAFKA
                                manifest.removeFromCurrDeployManifestList("kafka-config")*/
                                echo "Processing the following manifest:\n${Manifest.prettyPrint(manifest.getCurrDeployManifestList())}\n"

                                if (params.FORCE_REDEPLOY && params.SKIP_KAFKA) {
                                    echo("Skipping kafka redeploy")
                                } else {
                                    ManifestInfoDTO kafkaConfigBuild = manifest.getCurrDeployManifestList().find { it.microservice == "kafka-config" }
                                    if (kafkaConfigBuild != null) {
                                        def kafkaConfig = config.kafka.test
                                        kafkaConfig.envForDeploy = "${env.targetProjectOCP}"
                                        def args = [
                                                type            : "CD",
                                                dbInfo          : config.manifest.db,
                                                kafkaConfigBuild: kafkaConfigBuild,
                                                nxMgr           : nxMgr,
                                                kafkaConfig     : kafkaConfig,
                                                releaseNumber   : params.WAVE,
                                                execEnv         : 'dev'
                                        ]
                                        def isKafkaDifferentVersion = applyKafkaConfig(args, manifest.getGoLiveList())
                                        if (!isKafkaDifferentVersion) {
                                            manifest.removeFromCurrDeployManifestList("kafka-config")
                                        }
                                    }
                                }

                                List skipList = ['kafka-config']
                                manifest.toDeployableMap(manifest.getCurrDeployManifestList(), skipList)

                                manifest.initDeployStatusMap()
                                echo("statefulSets: ${statefulSets}")
                                statefulSets.each { ss ->
                                    if (manifest.getDeployableMap().get(ss)) {
                                        printTime("Stateful Set '${ss}'", true) {
                                            def filePath = nxMgr.download(env.nexusArtifactRepo, [groupId: env.nexusArtifactGroupId, artifactId: ss, packageVersion: manifest.getDeployableMap().get(ss).version, packaging: 'zip'], "package-${ss}")
                                            try {
                                                OpenshiftUtils.createStatefulSet(this, [filePath: filePath, name: ss, version: manifest.getDeployableMap().get(ss).version])
                                                manifest.getDeployStatus().put(ss, true)
                                            } catch (Exception e) {
                                                manifest.getDeployStatus().put(ss, false)
                                            }
                                        }
                                    }
                                }
                                def deployStages = Deployer.createDeployStages(this, nxMgr, deployGroupsList, null, servicesURL, [doMigration: true, clean: true], manifest.getDeployableMap(), [deployStatus: manifest.getDeployStatus(), skipList: statefulSets, goLiveList: manifest.getGoLiveList(), force: params.FORCE_REDEPLOY])
                                Deployer.executeDeploy(this, deployStages)
                                stat.deployed = true
                            }
                        }
                    }
                }
            }


            stage('Release tests') {
                when {
                    expression {
                        return ((doDeploy || params.FORCE_RELEASE_TESTS) && tests == 'release' &&
                                (findFiles(glob: "e2eTests/consumerdriventest/release/gateway/*.xml").size() > 0 || findFiles(glob: "e2eTests/consumerdriventest/release/opensec/*.xml").size() > 0)
                        )
                    }
                }
                steps {
                    script {
                        ansiColor('xterm') {
                            printTime() {
                                echo "Preparing pipeline to run ${tests} test on ${env.targetProjectOCP}"

                                ocpAdmMng.withCluster(env.clusterOCP) {
                                    ocpAdmMng.withProject(env.targetProjectOCP) {

                                        //crea elenco degli endpoint del progetto
                                        services = [:]
                                        def sel = ocpAdmMng.selector('svc').objects()
                                        sel.each { svc ->
                                            services.put("${svc.metadata.name}-endpoint", "${svc.metadata.name}.${env.targetProjectOCP}.svc.cluster.local:8080")
                                        }
                                        services.put('namespace', env.targetProjectOCP)
                                    }
                                }

                                def testToolNamespace = env.CICDProjectOCP

                                // Preparo il pod di SoapUI per lanciare i test
                                def dcName = "${env.targetProjectOCP}-soapui-release"
                                ocpAdmMng.withCluster(env.clusterOCP) {
                                    ocpAdmMng.withProject(testToolNamespace) {
                                        try {
                                            env.soapUIPodName = ocpAdmMng.createOndemandPod('templates/soapui_template.yaml', [parameters: [
                                                    NAME   : dcName,
                                                    PROJECT: env.targetProjectOCP
                                            ]])


                                            // Lancio i test di tipo gateway
                                            TestResult gatewayResult = runSoapUITestOnPod([
                                                    folder          : "e2eTests/consumerdriventest/release/gateway/",
                                                    kind            : "gateway",
                                                    globalProperties: services,
                                                    exportResult    : true,
                                                    ocpManager      : ocpAdmMng,
                                                    podName         : env.soapUIPodName
                                            ])
                                            failedTests.addAll(gatewayResult.getFailedWithKind())
                                            testNotifications.release || (testNotifications.release = "")
                                            testNotifications.release += gatewayResult.prettyPrint()


                                            // Lancio i test di tipo opensec
                                            TestResult opensecResult = runSoapUITestOnPod([
                                                    folder          : "e2eTests/consumerdriventest/release/opensec/",
                                                    kind            : "opensec",
                                                    globalProperties: services,
                                                    exportResult    : true,
                                                    ocpManager      : ocpAdmMng,
                                                    podName         : env.soapUIPodName
                                            ])
                                            failedTests.addAll(opensecResult.getFailedWithKind())
                                            testNotifications.release || (testNotifications.release = "")
                                            testNotifications.release += opensecResult.prettyPrint()

                                            /**
                                             * Export risultati dei test
                                             */
                                            if (config.nexus?.testResult?.repository && (gatewayResult.resultFolder || opensecResult.resultFolder)) {
                                                def resultZipFile = "release-test-result-${env.BUILD_NUMBER}.zip"
                                                def results = ""
                                                gatewayResult.resultFolder && (results += "${gatewayResult.resultFolder} ")
                                                opensecResult.resultFolder && (results += "${opensecResult.resultFolder} ")
                                                sh """#!/bin/bash
                                                zip -x *hsperfdata_root* -r ${resultZipFile} ${results}
                                            """
                                                env.testResultUrl = nxMgr.upload(config.nexus.testResult.repository, resultZipFile, [directory: "consumerdriventest/${tests}"])
                                            }
                                        } catch (Exception e) {
                                            throw e
                                        } finally {
                                            // Spengo il pod dedicato ai test
                                            ocpAdmMng.scalePod(dcName, 0)
                                        }
                                    }
                                }
                                if (failedTests.size() > 0)
                                    currentBuild.result = 'UNSTABLE'
                            }
                        }
                    }
                }
            }

            stage('NoRegression tests') {
                when {
                    expression {
                        return (tests == 'noregression' &&
                                (findFiles(glob: "e2eTests/consumerdriventest/noregression/gateway/*.xml").size() > 0 || findFiles(glob: "e2eTests/consumerdriventest/noregression/opensec/*.xml").size() > 0)
                        )
                    }
                }
                steps {
                    script {
                        ansiColor('xterm') {
                            printTime() {
                                ocpAdmMng.withCluster(env.clusterOCP) {
                                    ocpAdmMng.withProject(env.targetProjectOCP) {

                                        //crea elenco degli endpoint del progetto
                                        services = [:]
                                        def sel = ocpAdmMng.selector('svc').objects()
                                        sel.each { svc ->
                                            services.put("${svc.metadata.name}-endpoint", "${svc.metadata.name}.${env.targetProjectOCP}.svc.cluster.local:8080")
                                        }
                                        services.put('namespace', env.targetProjectOCP)
                                    }
                                }

                                def testToolNamespace = env.CICDProjectOCP

                                // Preparo il pod di SoapUI per lanciare i test
                                def dcName = "${env.targetProjectOCP}-soapui-noregression"
                                ocpAdmMng.withCluster(env.clusterOCP) {
                                    ocpAdmMng.withProject(testToolNamespace) {
                                        try {
                                            env.soapUIPodName = ocpAdmMng.createOndemandPod('templates/soapui_template.yaml', [parameters: [
                                                    NAME   : dcName,
                                                    PROJECT: env.targetProjectOCP
                                            ]])


                                            // Lancio i test di tipo gateway
                                            TestResult gatewayResult = runSoapUITestOnPod([
                                                    folder          : "e2eTests/consumerdriventest/noregression/gateway/",
                                                    kind            : "gateway",
                                                    globalProperties: services,
                                                    exportResult    : true,
                                                    ocpManager      : ocpAdmMng,
                                                    podName         : env.soapUIPodName
                                            ])
                                            failedTests.addAll(gatewayResult.getFailedWithKind())
                                            testNotifications.noregression || (testNotifications.noregression = "")
                                            testNotifications.noregression += gatewayResult.prettyPrint()


                                            // Lancio i test di tipo opensec
                                            TestResult opensecResult = runSoapUITestOnPod([
                                                    folder          : "e2eTests/consumerdriventest/noregression/opensec/",
                                                    kind            : "opensec",
                                                    globalProperties: services,
                                                    exportResult    : true,
                                                    ocpManager      : ocpAdmMng,
                                                    podName         : env.soapUIPodName
                                            ])
                                            failedTests.addAll(opensecResult.getFailedWithKind())
                                            testNotifications.noregression || (testNotifications.noregression = "")
                                            testNotifications.noregression += opensecResult.prettyPrint()

                                            /**
                                             * Export risultati dei test
                                             */
                                            if (config.nexus?.testResult?.repository && (gatewayResult.resultFolder || opensecResult.resultFolder)) {
                                                def resultZipFile = "noregression-test-result-${env.BUILD_NUMBER}.zip"
                                                def results = ""
                                                gatewayResult.resultFolder && (results += "${gatewayResult.resultFolder} ")
                                                opensecResult.resultFolder && (results += "${opensecResult.resultFolder} ")
                                                sh """#!/bin/bash
                                                zip -x *hsperfdata_root* -r ${resultZipFile} ${results}
                                            """
                                                env.testResultUrl = nxMgr.upload(config.nexus.testResult.repository, resultZipFile, [directory: "consumerdriventest/${tests}"])
                                            }
                                        } catch (Exception e) {
                                            throw e
                                        } finally {
                                            // Spengo il pod dedicato ai test
                                            ocpAdmMng.scalePod(dcName, 0)
                                        }
                                    }
                                }
                                if (failedTests.size() > 0)
                                    currentBuild.result = 'UNSTABLE'
                            }
                        }
                    }
                }
            }

        }

        post {
            always {
                deleteDir()
                script {
                    env.JOB_NAME = env.JOB_NAME.replaceAll('%2F', '/')
                    def result = currentBuild.currentResult
                    boolean postException = false

                    def failed = manifest?.getDeployStatus().findAll { it.value == false }?.keySet()
                    def notDeployed = manifest?.getDeployStatus().findAll { it.value == null }?.keySet()
                    def success = manifest?.getDeployStatus().findAll { it.value == true }?.keySet()
                    def newManifestVersion = null
                    try {
                        if (failed?.size() > 0 || notDeployed?.size() > 0) {
                            failed.each { entry ->
                                ManifestInfoDTO manifestInfoDTO = manifest.getNamespaceManifestInfo().find { dto ->
                                    dto.microservice == entry
                                }
                                ManifestInfoDTO current = manifest.getManifestInfo().find { currEntry ->
                                    currEntry.microservice == entry
                                }
                                if (manifestInfoDTO != null) {
                                    current.setWave(manifestInfoDTO.getWave())
                                    current.setIdBuild(manifestInfoDTO.getIdBuild())
                                    current.setIdWave(manifestInfoDTO.getIdWave())
                                    current.setBuildNum(manifestInfoDTO.getBuildNum())
                                }
                            }

                            notDeployed.each { entry ->
                                ManifestInfoDTO manifestInfoDTO = manifest.getNamespaceManifestInfo().find { dto ->
                                    dto.microservice == entry
                                }
                                ManifestInfoDTO current = manifest.getManifestInfo().find { currEntry ->
                                    currEntry.microservice == entry
                                }
                                if (manifestInfoDTO != null) {
                                    current.setWave(manifestInfoDTO.getWave())
                                    current.setIdBuild(manifestInfoDTO.getIdBuild())
                                    current.setIdWave(manifestInfoDTO.getIdWave())
                                    current.setBuildNum(manifestInfoDTO.getBuildNum())
                                }
                            }
                        }

                        if (doDeploy) {
                            newManifestVersion = insertNewManifest(
                                    [
                                            env          : "${env.targetProjectOCP}",
                                            projectPrefix: "${config.svc.project.toLowerCase()}",
                                            dbInfo       : config.manifest.db,
                                            wave         : params.WAVE,
                                            clusterType  : 'test',
                                            changedMf    : false as Boolean
                                    ],
                                    manifest.getManifestInfo()
                            )
                            if(newManifestVersion){
                                echo("${Colors.Bash.GREEN}Created new manfiest version: ${Colors.Bash.BLUE}${newManifestVersion}${Colors.Bash.NC}")
                            }

                            if (success?.size() > 0) {
                                updateDBDeploy(
                                        [
                                                env          : "${env.targetProjectOCP}",
                                                projectPrefix: "${config.svc.project.toLowerCase()}",
                                                dbInfo       : config.manifest.db,
                                                wave         : params.WAVE,
                                                logicEnv     : 'test'
                                        ],
                                        manifest?.getGoLiveList()
                                )
                            }

                            printGoLiveInfo(manifest?.getGoLiveList())
                        }
                    } catch (Exception e) {
                        echo("${Colors.Bash.ORANGE}WARNING: error in post\n${e.toString()}${Colors.Bash.NC}")
                        postException = true
                        if (result != 'FAILURE')
                            result = 'UNSTABLE'
                    }


                    def manifestTitle = env.chain == 'FIX' ? 'HotFix Manifest' : 'Release Candidate Manifest'
                    def mailMessages = [
                            'SUCCESS' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] completata con successo",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]],
                            'FAILURE' : [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] fallita",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} fallito</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]],
                            'UNSTABLE': [
                                    'subject': "Pipeline ${env.JOB_NAME} [${env.BUILD_NUMBER}] instabile",
                                    'body'   : [
                                            'type': 'text/html',
                                            'msg' : """
<p>Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo ma test automatizzati falliti</p>
<p>Check console output at "<a href="${env.RUN_DISPLAY_URL}">${env.JOB_NAME} [${env.BUILD_NUMBER}]</a>"</p>
                """]]]

                    // Invio della mail solo se è stato deployato qualcosa (se la diff ha trovato differenze da deployare)
                    if (doDeploy) {
                        notifyMail("${NOTIFICATION_MAIL}", mailMessages, result)
                    }

                    def teamsMessages, infoMap, user
                    //def chainPath = env.chain == 'FIX' ? 'HotFix Path' : 'Release Path'
                    wrap([$class: 'BuildUser']) {
                        user = env.BUILD_USER
                        if (CommonUtils.isNullOrEmpty(user))
                            user = "Scheduler"
                    }
                    if (doDeploy) {
                        teamsMessages = [
                                'SUCCESS' : "Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo",
                                'FAILURE' : "Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} fallito",
                                'UNSTABLE': "Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo ma test automatizzati falliti"]
                        postException && teamsMessages.put('UNSTABLE', "Deploy ambiente ${env.targetProjectOCP} da ${manifestTitle} effettuato con successo ma fallito allineamento manifest su DB interno.")
                    } else if (tests == 'release' && params.FORCE_RELEASE_TESTS) {
                        teamsMessages = [
                                'SUCCESS' : "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}. Release tests superati con successo",
                                'FAILURE' : "Errore nella pipeline",
                                'UNSTABLE': "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}. Alcuni Release tests sono falliti"]
                    } else if (tests == 'noregression') {
                        teamsMessages = [
                                'SUCCESS' : "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}. NoRegression tests superati con successo",
                                'FAILURE' : "Errore nella pipeline",
                                'UNSTABLE': "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}. Alcuni No Regression tests sono falliti"]
                    } else {
                        teamsMessages = [
                                'SUCCESS': "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}.",
                                'FAILURE': "Errore nella pipeline"]
                        postException && teamsMessages.put('UNSTABLE', "Nessuna modifica per ${manifestTitle} in ambiente ${env.targetProjectOCP}. Errore nelle post-operazioni della pipeline")
                    }

                    infoMap = [
                            'Triggered by'    : user,
                            'Project'         : env.targetProjectOCP,
                            'Wave'            : params.WAVE,
                            'Manifest Version': (!notificationManifest ? 'NA' : (newManifestVersion ?: 'Stessa del precedente deploy')),
                            'SECTIONS'        : [],
                            'ACTIONS'         : [
                                    ['name': 'View Environment', 'url': "https://openshift.dv.seccloud.internal:8443/console/project/${env.targetProjectOCP}/browse/deployments"]
                            ]
                    ]

                    if (doDeploy) {
                        if (success) {
                            infoMap['SECTIONS'].add(['activityTitle': "Deployed services", 'activityText': "<pre>${Manifest.prettyPrint(manifest?.getCurrDeployManifestList()?.findAll { it.microservice in success }, true)}</pre>", "markdown": false])
                        }
                        (failed) && infoMap.put('Failed deploy', "${failed}")
                        (notDeployed) && infoMap.put('Not deployed', "${notDeployed}")
                    }
                    if (notificationManifest)
                        infoMap['SECTIONS'].add(['activityTitle': "Richiesto deploy del seguente ${manifestTitle}", 'activityText': "<pre>${notificationManifest}</pre>", "markdown": false])

                    if (!CommonUtils.isNullOrEmpty(tests)) {
                        if (!CommonUtils.isNullOrEmpty(env.testResultUrl))
                            infoMap['ACTIONS'].add(['name': 'View Test Logs', 'url': env.testResultUrl])
                        if (testNotifications.get(tests))
                            infoMap['SECTIONS'].add(['activityTitle': "${tests == 'release' ? 'Release Tests' : 'NoRegression Tests'}", 'activityText': "<pre>${testNotifications.get(tests)}</pre>", "markdown": false])
                    }

                    webhook.each {
                        notifyTeams(result, teamsMessages, it, infoMap)
                    }
                }
            }
        }
    }

}
