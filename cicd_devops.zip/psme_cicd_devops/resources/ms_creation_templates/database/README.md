# Database versioning model
Lo scopo di questa cartella è di raccogliere tutti i delta applicati al database applicativo durante la sua vita.
L'applicazione dei delta viene effettuata tramite il tool Liquibase che è stato sviluppato per gestire il versionamento del datamodel di un database tramite applicazione di script delta.

## Struttura cartella
La struttura di cartelle e file deve essere ben definita e seguire lo schema illustrato sotto: 
  - database/ 
     - dbchangelog.xml 
     - afterMigrate__permissions.sql 
     - changesets/ 
       - V1.0.0__prima_release.sql 
       - V2.0.0__seconda_release.sql

## ChangeLog file
Il file **dbchangelog.xml** viene utilizzato dal tool come file root su cui andare a leggere la lista dei changeset da applicare.
Questo file deve esistere sempre all'interno del repository e deve esere aggiornato solo nel caso in cui debba essere aggiunto un changeset specifico. Questo può essere fatto nella sezione apposita come mostrato nell'esempio sotto.

L'approccio DevOps prevede che il file **dbchangelog.xml** abbia al suo interno le sole direttive include e includeAll per processare tutti i changeset nella sottocartella changesets e il changeset speciale *afterMigrate__permissions.sql* come da esempio:

```xml
<?xml version="1.0" encoding="UTF-8"?>
  <databaseChangeLog 
    xmlns="http://www.liquibase.org/xml/ns/dbchangelog"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:schemaLocation="http://www.liquibase.org/xml/ns/dbchangelog
    http://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-3.8.xsd">
    
    <!-- Include tutti i file presenti nella path specificata -->
    <includeAll path="changesets" relativeToChangelogFile="true" />

    <!-- Inizio sezione modificabile -->
    <!-- Fine sezione modificabile -->

    <!-- Insert di dati di test, viene processato solo se viene effettuata la pulizia del DB -->
    <!-- <include file="afterMigrate__testdata.sql" relativeToChangelogFile="true" context="onClean" /> -->

    <!-- Applicazione dei permessi necessari sulle risorse create. DEVE essere l'ultima include -->
    <include file="afterMigrate__permissions.sql" relativeToChangelogFile="true" />

  </databaseChangeLog>
```

La sezione tra i commenti <!-- Inizio sezione modificabile --> e <!-- Fine sezione modificabile --> serve per poter includere altri eventuali changeset specifici da eseguire dopo tutti gli altri, un esempio è *afterMigrate__testdata.sql* non incluso nella cartella changesets.

## Changesets
Come descritto nella documentazione i changeset possono essere scritti in diverse linguaggi. In questo progetto viene usato come default il linguaggio sql.

Per scrivere un changeset sql è OBBLIGATORIO seguire alcune regole:
 * ogni file deve seguire la nomenclatura **V{release}__{descrizione}.sql** 
 * tutti i file sql DEVONO cominciare con la riga **--liquibase formatted sql**
 * ogni changeset DEVE cominciare con **--changeset {author}:{changesetID} [optional parameters] **
    * changesetID può essere una stringa alfanumerica
 * ogni file può contenere più changeset solo se facenti parte della stessa release.

In questo caso il changesetID deve seguire la nomenclatura *{release}-{indice incrementale}*

Per maggiori informazioni su cosa può essere passato alla direttiva changeset fate riferimento a https://www.liquibase.org/documentation/sql_format.html

Di seguito un esempio:
```sql
  --liquibase formatted sql

  --changeset testuser:1.0.0-1
  --comment: Create table TEST_TABLE
  CREATE TABLE "TEST_TABLE"
  ("SERVICE_NAME" VARCHAR2(1000 CHAR) NOT NULL ENABLE,
  "ISTITUTO" VARCHAR2(255),
  PRIMARY KEY ("ISTITUTO", "SERVICE_NAME")
  USING INDEX
  TABLESPACE "TEST_TABLE_INDEX"  ENABLE
  ) SEGMENT CREATION IMMEDIATE
  COMPRESS FOR OLTP LOGGING
  TABLESPACE "TEST_TABLE_DATA";

  --changeset testuser:1.0.0-2
  --comment: Alter table TEST_TABLE
  ALTER TABLE TEST_TABLE
  ADD STATUS_CODE varchar(50);
```

### afterMigrate__permissions.sql
**afterMigrate__permissions.sql** è un file speciale che è utilizzato per assegnare permessi all'utente readonly per tutte le nuove risorse a cui deve avere accesso.
Ogni statement DEVE essere tokenizzato per poter usare lo stesso script in ogni ambiente senza doverne definire di specifici.
Il changeset implementato qui è configurato per essere lanciato ogni volta che viene cambiato il suo contenuto, questo **E' CONSENTITO SOLO** quando viene aggiunta una nuova changeset che prevede la creazione di una risorsa a cui deve essere consentito l'accesso readonly

`IMPORTANTE: NON modificare le opzioni di questo changeset, aggiungere solo gli statement necessari.`

Di seguito un esempio:
```sql
  --liquibase formatted sql

  --changeset permissions:permissions runOnChange:true
  --comment: Apply required permissions
  GRANT SELECT ON ###DB_USER###.TEST_TABLE TO ###DB_USER###_RO;
```
dove `###DB_USER###` è il token che rappresenta il nome dell'utente a cui appartengono gli oggetti creati.

### afterMigrate__testdata.sql
**afterMigrate__testdata.sql** è un file speciale che è utilizzato per inserire all'interno del DB dei dati di test.
Il changeset implementato qui è configurato per essere lanciato solo nel caso in cui venga pulito prima il DB

`IMPORTANTE: NON modificare le opzioni di questo changeset, aggiungere solo gli statement necessari.`

Di seguito un esempio:
```sql
  --liquibase formatted sql

  --changeset testdata:testdata runOnChange:true context:onClean
  --comment: insert test data
  INSERT INTO TEST_TABLE VALUES "test1","test1";
  INSERT INTO TEST_TABLE VALUES "test2","test2";
  INSERT INTO TEST_TABLE VALUES "test3","test3";
```
In questo esempio le modifiche sono applicate ad un DB Oracle