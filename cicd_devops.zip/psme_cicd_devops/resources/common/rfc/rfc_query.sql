SET NOCOUNT ON;
SELECT codice_rfc, ambiente, dataora_iniziointervento, dataora_fineintervento,
applicazione_cod, applicazione_nome, tipo_intervento, tipo_passaggio, referente_nome,
referente_cognome, referente_username, referente_email, descrizione_change, stato_rfc
from rfc_maininfo_extended
where codice_rfc = #COD_RFC#;